import { Fragment } from 'react';
import { Avatar, Button, Dialog, Icon, IconButton, Input, Select } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Quotes" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Parenting quotes"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader active="community" />
      <main>
        <section style={{ background: 'var(--lilac-50)' }}>
          <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '28px 24px 56px', boxSizing: 'border-box' }}>
            <nav
              aria-label="Breadcrumb"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                flexWrap: 'wrap',
                fontSize: '15px',
                color: 'var(--text-muted)',
                marginBottom: '32px',
              }}
            >
              <a
                className="hv-1"
                href={toUrl('/')}
                style={{ color: 'var(--text-muted)', textDecoration: 'none', fontWeight: '600' }}
              >
                Home
              </a>
              <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
              <a
                className="hv-1"
                href={toUrl('/communities')}
                style={{ color: 'var(--text-muted)', textDecoration: 'none', fontWeight: '600' }}
              >
                Just for parents
              </a>
              <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
              <span>Parenting quotes</span>
            </nav>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '40px 56px', alignItems: 'center' }}>
              <div style={{ flex: '1 1 400px', minWidth: '0' }}>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--lilac-700)',
                    marginBottom: '14px',
                  }}
                >
                  <Icon name="quote" size={18} color="var(--lilac-700)" />
                  Just for fun · Community
                </div>
                <h1
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(40px,5.4vw,64px)',
                    lineHeight: '1.05',
                    letterSpacing: '-0.02em',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0',
                    textWrap: 'balance',
                  }}
                >
                  Words that keep parents going
                </h1>
                <p
                  style={{
                    fontFamily: 'var(--font-serif)',
                    fontSize: '21px',
                    lineHeight: '1.6',
                    color: 'var(--text-body)',
                    margin: '18px 0 0',
                    maxWidth: '520px',
                    textWrap: 'pretty',
                  }}
                >
                  Good day or tough day, you’re not alone. Find a little encouragement here — and share the quotes that
                  help you.
                </p>
                <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', marginTop: '28px' }}>
                  <Button variant="primary" size="lg" icon="pen-line" onClick={v.openShare}>
                    Share a quote
                  </Button>
                  <Button variant="secondary" size="lg" icon="shuffle" onClick={v.surprise}>
                    Surprise me
                  </Button>
                </div>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    marginTop: '24px',
                    fontSize: '15px',
                    color: 'var(--text-muted)',
                  }}
                >
                  <Avatar name="Team ParentCircle" size={32} />
                  <span>
                    <strong style={{ color: 'var(--text-strong)' }}>Team ParentCircle</strong>
                    {' · 31.7K views · '}
                    {v.countText}
                  </span>
                </div>
                {v.shared ? (
                  <div
                    role="status"
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '10px',
                      marginTop: '20px',
                      padding: '12px 16px',
                      borderRadius: '12px',
                      background: 'var(--white)',
                      color: 'var(--sage-700)',
                      fontSize: '17px',
                      fontWeight: '600',
                    }}
                  >
                    <Icon name="circle-check" size={22} color="var(--sage-700)" />
                    Thank you — your quote is now at the top of the list.
                  </div>
                ) : null}
              </div>
              <article
                aria-label="Quote of the day"
                style={{
                  flex: '1.1 1 420px',
                  minWidth: '0',
                  borderRadius: '24px',
                  background: 'var(--white)',
                  boxShadow: 'var(--shadow-md)',
                  overflow: 'hidden',
                }}
              >
                <div style={{ position: 'relative', aspectRatio: '21 / 8', background: 'var(--lilac-100)' }}>
                  <image-slot
                    id="quotes-featured"
                    shape="rect"
                    placeholder="Quote of the day image: a parent and child sharing a quiet moment"
                  ></image-slot>{' '}
                  <span
                    style={{
                      position: 'absolute',
                      left: '20px',
                      bottom: '-26px',
                      zIndex: '1',
                      width: '56px',
                      height: '56px',
                      borderRadius: '50%',
                      background: 'var(--pc-orange)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      boxShadow: 'var(--shadow-sm)',
                    }}
                  >
                    <Icon name="quote" size={28} color="var(--white)" />
                  </span>
                </div>
                <div style={{ padding: '40px 28px 24px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '12px',
                      flexWrap: 'wrap',
                    }}
                  >
                    <span
                      style={{
                        fontSize: '14px',
                        fontWeight: '700',
                        letterSpacing: '0.08em',
                        textTransform: 'uppercase',
                        color: 'var(--orange-700)',
                      }}
                    >
                      {'Quote of the day · '}
                      {v.lead?.theme}
                    </span>
                    <span style={{ fontSize: '15px', fontWeight: '600', color: 'var(--text-muted)' }}>{v.leadPos}</span>
                  </div>
                  <blockquote
                    style={{
                      margin: '0',
                      fontFamily: 'var(--font-display)',
                      fontSize: 'clamp(24px,2.6vw,32px)',
                      lineHeight: '1.3',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      textWrap: 'balance',
                    }}
                  >
                    {v.lead?.text}
                  </blockquote>
                  <div style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                    {'— '}
                    {v.lead?.by}
                  </div>
                  {v.lead?.hasNote ? (
                    <p
                      style={{
                        fontFamily: 'var(--font-serif)',
                        fontSize: '18px',
                        lineHeight: '1.6',
                        color: 'var(--text-body)',
                        margin: '0',
                      }}
                    >
                      {v.lead?.note}
                    </p>
                  ) : null}
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '10px',
                      flexWrap: 'wrap',
                      paddingTop: '14px',
                      borderTop: '1px solid var(--border-subtle)',
                    }}
                  >
                    <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                      <button
                        type="button"
                        aria-pressed={v.lead?.liked}
                        onClick={v.lead?.toggleLike}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px',
                          height: '40px',
                          padding: '0 14px',
                          borderRadius: '999px',
                          border: '0',
                          background: v.lead?.likeBg,
                          font: 'inherit',
                          fontSize: '15px',
                          fontWeight: '700',
                          color: v.lead?.likeFg,
                          cursor: 'pointer',
                        }}
                      >
                        <Icon name="heart" size={18} color="currentColor" />
                        {v.lead?.likes}
                      </button>
                      <Button variant="secondary" size="sm" icon={v.lead?.shareIcon} onClick={v.lead?.share}>
                        {v.lead?.shareText}
                      </Button>
                    </div>
                    <div style={{ display: 'flex', gap: '4px' }}>
                      <IconButton icon="chevron-left" label="Previous quote" onClick={v.prev} />
                      <IconButton icon="chevron-right" label="Next quote" onClick={v.next} />
                    </div>
                  </div>
                </div>
              </article>
            </div>
          </div>
        </section>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '56px 24px 0', boxSizing: 'border-box' }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'flex-end',
              justifyContent: 'space-between',
              gap: '16px',
              flexWrap: 'wrap',
              marginBottom: '20px',
            }}
          >
            <div>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(28px,3vw,36px)',
                  lineHeight: '1.2',
                  letterSpacing: '-0.01em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                }}
              >
                Find a quote for today
              </h2>
              <p style={{ fontSize: '17px', color: 'var(--text-muted)', margin: '6px 0 0' }}>{v.shownText}</p>
            </div>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '32px' }}>
            {(v.themeChips ?? []).map((c, $i0) => (
              <Fragment key={$i0}>
                <button
                  type="button"
                  aria-pressed={c?.on}
                  onClick={c?.toggle}
                  style={{
                    height: '44px',
                    padding: '0 16px',
                    borderRadius: '999px',
                    border: `1.5px solid ${c?.bd ?? ''}`,
                    background: c?.bg,
                    color: c?.fg,
                    font: 'inherit',
                    fontSize: '15px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    cursor: 'pointer',
                    transition: 'background 150ms',
                  }}
                >
                  <span style={{ width: '10px', height: '10px', borderRadius: '50%', background: c?.dot }}></span>
                  {c?.label}
                </button>
              </Fragment>
            ))}
          </div>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,300px),1fr))',
              gap: '20px',
              alignItems: 'stretch',
            }}
          >
            {(v.quotes ?? []).map((q, $i0) => (
              <Fragment key={$i0}>
                <article
                  data-quote={q?.id}
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '14px',
                    minWidth: '0',
                    boxSizing: 'border-box',
                    padding: '24px',
                    borderRadius: '20px',
                    background: q?.tint,
                    outline: q?.outline,
                    outlineOffset: '3px',
                    transition: 'outline-color 300ms',
                  }}
                >
                  {q?.hasImage ? (
                    <div
                      style={{
                        position: 'relative',
                        overflow: 'hidden',
                        aspectRatio: '16 / 7',
                        borderRadius: '14px',
                        background: 'var(--white)',
                        marginBottom: '4px',
                      }}
                    >
                      <image-slot
                        id={`quotes-${q?.id ?? ''}`}
                        shape="rounded"
                        radius="14"
                        placeholder={q?.photo}
                      ></image-slot>
                    </div>
                  ) : null}
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' }}>
                    <span
                      style={{
                        fontSize: '14px',
                        fontWeight: '700',
                        letterSpacing: '0.08em',
                        textTransform: 'uppercase',
                        color: q?.ink,
                      }}
                    >
                      {q?.theme}
                    </span>
                    <Icon name="quote" size={26} color={q?.ink} />
                  </div>
                  <blockquote
                    style={{
                      margin: '0',
                      fontFamily: 'var(--font-serif)',
                      fontSize: '22px',
                      lineHeight: '1.45',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textWrap: 'pretty',
                    }}
                  >
                    {q?.text}
                  </blockquote>
                  <div style={{ fontSize: '16px', fontWeight: '700', color: 'var(--text-strong)' }}>
                    {'— '}
                    {q?.by}
                  </div>
                  {q?.hasNote ? (
                    <p style={{ fontSize: '16px', lineHeight: '1.55', color: 'var(--text-body)', margin: '0' }}>
                      {q?.note}
                    </p>
                  ) : null}
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '8px',
                      marginTop: 'auto',
                      paddingTop: '12px',
                      borderTop: `1px solid ${q?.rule ?? ''}`,
                    }}
                  >
                    <span
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        minWidth: '0',
                        fontSize: '15px',
                        color: 'var(--text-muted)',
                      }}
                    >
                      <Avatar name={q?.poster} size={28} />
                      <span style={{ minWidth: '0' }}>{q?.when}</span>
                    </span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                      <button
                        type="button"
                        aria-pressed={q?.liked}
                        aria-label="Like this quote"
                        onClick={q?.toggleLike}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px',
                          height: '40px',
                          padding: '0 12px',
                          borderRadius: '999px',
                          border: '0',
                          background: q?.likeBg,
                          font: 'inherit',
                          fontSize: '15px',
                          fontWeight: '700',
                          color: q?.likeFg,
                          cursor: 'pointer',
                        }}
                      >
                        <Icon name="heart" size={18} color="currentColor" />
                        {q?.likes}
                      </button>
                      <button
                        type="button"
                        aria-label="Copy quote"
                        onClick={q?.share}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          width: '40px',
                          height: '40px',
                          borderRadius: '999px',
                          border: '0',
                          background: 'var(--white)',
                          color: 'var(--text-strong)',
                          cursor: 'pointer',
                        }}
                      >
                        <Icon name={q?.shareIcon} size={18} color="currentColor" />
                      </button>
                    </span>
                  </div>
                </article>
              </Fragment>
            ))}
          </div>
        </section>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '40px 24px 0', boxSizing: 'border-box' }}>
          <div
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '20px 40px',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: 'clamp(28px,4vw,40px)',
              borderRadius: '24px',
              background: 'var(--orange-50)',
            }}
          >
            <div style={{ flex: '1 1 380px', minWidth: '0', display: 'flex', gap: '18px', alignItems: 'center' }}>
              <span
                style={{
                  width: '56px',
                  height: '56px',
                  flex: 'none',
                  borderRadius: '50%',
                  background: 'var(--white)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Icon name="message-square-quote" size={26} color="var(--orange-700)" />
              </span>
              <div>
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(22px,2.6vw,28px)',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    marginBottom: '4px',
                  }}
                >
                  Have a quote that keeps you going?
                </div>
                <p style={{ fontSize: '17px', color: 'var(--text-body)', margin: '0' }}>
                  From a grandparent, a teacher or a book — share it with other parents.
                </p>
              </div>
            </div>
            <Button variant="primary" size="lg" icon="pen-line" onClick={v.openShare}>
              Share a quote
            </Button>
          </div>
        </section>
        <section style={{ marginTop: '64px', background: 'var(--neutral-50)' }}>
          <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '48px 24px 56px', boxSizing: 'border-box' }}>
            <h2
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(24px,2.6vw,30px)',
                lineHeight: '1.2',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 18px',
              }}
            >
              More quote collections
            </h2>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
              {(v.alsoRead ?? []).map((r, $i0) => (
                <Fragment key={$i0}>
                  <a
                    className="hv-3"
                    href={toUrl(r?.href)}
                    style={{
                      height: '44px',
                      padding: '0 16px',
                      borderRadius: '999px',
                      border: '1.5px solid var(--border-default)',
                      background: 'var(--white)',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
                    {r?.label}
                  </a>
                </Fragment>
              ))}
            </div>
          </div>
        </section>
      </main>
      {v.shareOpen ? (
        <Dialog title="Share a quote" width={560} onClose={v.closeShare}>
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
              maxHeight: 'calc(100vh - 200px)',
              overflow: 'auto',
              padding: '4px',
              margin: '0 -4px',
            }}
          >
            <Input
              label="The quote"
              multiline={true}
              rows={3}
              placeholder="Words that keep you going…"
              value={v.fText}
              onChange={v.onFText}
              error={v.err?.text}
            />
            <Input
              label="Who said it?"
              placeholder="e.g. My grandmother"
              value={v.fBy}
              onChange={v.onFBy}
              error={v.err?.by}
            />
            <Select label="Theme" options={v.themeOptions} value={v.fTheme} onChange={v.onFTheme} />
            <Input
              label="Why it matters to you (optional)"
              multiline={true}
              rows={2}
              value={v.fNote}
              onChange={v.onFNote}
            />
            <div
              style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end', flexWrap: 'wrap', marginTop: '4px' }}
            >
              <Button variant="ghost" onClick={v.closeShare}>
                Cancel
              </Button>
              <Button variant="primary" icon="send" onClick={v.submitShare}>
                Share quote
              </Button>
            </div>
          </div>
        </Dialog>
      ) : null}
      <SiteFooter />
    </div>
  );
}
