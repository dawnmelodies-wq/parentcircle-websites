import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = {
    idx: 0,
    hi: '',
    theme: 'All',
    liked: [],
    saved: [],
    copied: '',
    shareOpen: false,
    shared: false,
    mine: [],
    f: { text: '', by: '', theme: 'Love and bonding', note: '' },
    err: {},
  };
  THEMES = {
    Emotions: 'blush',
    Confidence: 'butter',
    Communication: 'sky',
    Discipline: 'lilac',
    'Play and learning': 'sage',
    'Love and bonding': 'blush',
    'Self-care': 'sage',
  };
  Q = [
    [
      'pam',
      'Discipline',
      'You can’t teach children to behave better by making them feel worse.',
      'Pam Leo, author of Connection Parenting',
      'Harsh words and punishment leave children sad, fearful and angry. Clear expectations, said with firmness and kindness, help them feel safe.',
      '1 day ago',
      'Parent kneeling to talk gently with a child',
    ],
    [
      'becky',
      'Emotions',
      'Your job isn’t to stop your child from feeling upset. Your job is to help them feel safe when they are.',
      'Dr Becky Kennedy, clinical psychologist',
      'Let them know it’s normal to feel upset — then comfort them until they feel better.',
      '7 Oct',
      'Mother hugging a tearful child on the sofa',
    ],
    [
      'markham',
      'Confidence',
      'When children feel understood, their ability to listen expands.',
      'Dr Laura Markham, clinical psychologist',
      'Listening without judgement makes children want to cooperate with you.',
      '30 Sep',
      'Father listening closely to his daughter',
    ],
    [
      'malala',
      'Confidence',
      'One child, one teacher, one book, and one pen can change the world.',
      'Malala Yousafzai, Nobel Peace Prize laureate',
      'One person’s belief in themselves can spark action for a better world.',
      '23 Sep',
      'Child writing in a notebook at a school desk',
    ],
    [
      'wallace',
      'Communication',
      'If you want children to talk to you as they grow up, listen when they are small.',
      'Catherine M. Wallace, author',
      'Patient listening today builds the trust that keeps them talking tomorrow.',
      '16 Sep',
      'Toddler chatting to a parent at the table',
    ],
    [
      'purvis',
      'Discipline',
      'Before you can change a child’s behaviour, you have to connect with their heart.',
      'Dr Karyn Purvis, child development expert',
      'Try connecting with your child’s feelings before correcting the behaviour.',
      '9 Sep',
      'Parent and child holding hands on a walk',
    ],
    [
      'rogers',
      'Play and learning',
      'For children, play is serious learning.',
      'Fred Rogers',
      'Play isn’t a break from learning — it is learning itself.',
      '26 Aug',
      'Children building a block tower together',
    ],
    [
      'knost',
      'Emotions',
      'When little people are overwhelmed by big emotions, it’s our job to share our calm, not join their chaos.',
      'L. R. Knost, author',
      'Pause and breathe first. Your calm is often enough to calm them.',
      '29 Jul',
      'Parent breathing calmly beside an upset toddler',
    ],
    [
      'doyle',
      'Self-care',
      'Don’t become so concerned with raising a good kid that you forget you already have one.',
      'Glennon Doyle, author',
      'Notice and encourage the goodness that’s already in your child.',
      '8 Jul',
      'Parent smiling at a child doing homework',
    ],
    [
      'greene',
      'Love and bonding',
      'It is in the connection, not the correction, that we find the power to shape behaviour.',
      'Dr Ross Greene, psychologist',
      'Understanding comes first — then children want to listen.',
      '1 Jul',
      'Grandparent and child sharing a laugh',
    ],
    [
      'nutrition',
      'Self-care',
      'You don’t have to change everything at once. Start with one healthier choice today.',
      'ParentCircle',
      'Let your first small step lead to the next, until it becomes a habit.',
      '2 Sep',
      'Family sharing a colourful home-cooked meal',
    ],
    [
      'tsabary',
      'Self-care',
      'Parenting is not about being perfect. It’s about doing your best and forgiving yourself when you get it wrong.',
      'Dr Shefali Tsabary, clinical psychologist',
      'Be as kind to yourself as you are to your child.',
      '29 Apr',
      'Parent resting with a cup of tea while a child plays',
    ],
    [
      'hugo',
      'Love and bonding',
      'A mother’s arms are made of tenderness and children sleep soundly in them.',
      'Victor Hugo, writer',
      '',
      '4 Mar',
      'Baby asleep in a mother’s arms',
    ],
    [
      'johnson',
      'Love and bonding',
      'To be in your children’s memories tomorrow, you have to be in their lives today.',
      'Barbara Johnson',
      'Shared by a member: being close to your children is such a fulfilling experience.',
      '14 Feb',
      'Family looking through an old photo album',
      'Mumtaz Vinchu',
    ],
  ];
  ALSO = [
    '5 famous quotes of Mahatma Gandhi',
    'Children’s Day wishes from parents',
    'Father’s Day quotes',
    '30 beautiful Mother’s Day quotes',
    '10 motivational quotes for students',
    'Women’s Day: 16 powerful quotes',
    'Life lessons from Winnie the Pooh',
    '10 quotes about learning',
    '10 inspiring quotes on peace',
  ];
  base = {
    pam: 48,
    becky: 36,
    markham: 29,
    malala: 41,
    wallace: 33,
    purvis: 27,
    rogers: 22,
    knost: 39,
    doyle: 31,
    greene: 26,
    nutrition: 14,
    tsabary: 44,
    hugo: 19,
    johnson: 12,
  };
  chip(on) {
    return on
      ? { bg: 'var(--neutral-900)', fg: 'var(--white)', bd: 'var(--neutral-900)' }
      : { bg: 'var(--white)', fg: 'var(--text-strong)', bd: 'var(--border-default)' };
  }
  toggle(k, id) {
    this.setState((s) => ({ [k]: s[k].includes(id) ? s[k].filter((x) => x !== id) : s[k].concat(id) }));
  }
  copy(id, text) {
    try {
      navigator.clipboard && navigator.clipboard.writeText(text);
    } catch (e) {}
    this.setState({ copied: id });
    clearTimeout(this.ct);
    this.ct = setTimeout(() => this.setState({ copied: '' }), 2200);
  }
  componentWillUnmount() {
    clearTimeout(this.ct);
    clearTimeout(this.ht);
  }
  setF(k, v) {
    this.setState((s) => ({ f: { ...s.f, [k]: v }, err: { ...s.err, [k]: undefined } }));
  }
  submitShare = () => {
    const f = this.state.f,
      e = {};
    if (f.text.trim().length < 10) e.text = 'Please add the quote — a sentence or two is perfect.';
    if (!f.by.trim()) e.by = 'Please tell us who said it.';
    if (Object.keys(e).length) return this.setState({ err: e });
    const id = 'mine' + Date.now();
    this.setState((s) => ({
      mine: [[id, f.theme, f.text.trim(), f.by.trim(), f.note.trim(), 'Just now', 'Your family moment', 'You']].concat(
        s.mine,
      ),
      shareOpen: false,
      shared: true,
      theme: 'All',
      idx: 0,
      f: { text: '', by: '', theme: f.theme, note: '' },
    }));
  };
  shape([id, theme, text, by, note, when, photo, poster]) {
    const S = this.state,
      hue = this.THEMES[theme] || 'neutral',
      liked = S.liked.includes(id),
      n = (this.base[id] || 0) + (liked ? 1 : 0),
      copied = S.copied === id;
    return {
      id,
      theme,
      text,
      by,
      note,
      hasNote: !!note,
      photo: 'Quote card: ' + photo,
      tint: 'var(--' + hue + '-50)',
      ink: 'var(--' + hue + '-700)',
      rule: 'var(--' + hue + '-100)',
      poster: poster || 'Team ParentCircle',
      when: (poster || 'Team ParentCircle') + ' · ' + when,
      meta: (poster || 'Team ParentCircle') + ' · ' + when,
      liked,
      likes: n,
      likeBg: liked ? 'var(--blush-100)' : 'var(--white)',
      likeFg: liked ? 'var(--blush-700)' : 'var(--text-strong)',
      outline: S.hi === id ? '3px solid var(--orange-300)' : '3px solid transparent',
      likeLabel: (liked ? 'Liked' : 'Like') + ' · ' + n,
      likeText: (liked ? 'Liked' : 'Like') + ' · ' + n,
      likeVariant: liked ? 'soft' : 'secondary',
      toggleLike: () => this.toggle('liked', id),
      saveIcon: S.saved.includes(id) ? 'bookmark-check' : 'bookmark',
      saveText: S.saved.includes(id) ? 'Saved' : 'Save',
      toggleSave: () => this.toggle('saved', id),
      shareIcon: copied ? 'check' : 'copy',
      shareText: copied ? 'Copied' : 'Copy quote',
      share: () => this.copy(id, '“' + text + '” — ' + by),
    };
  }
  surprise = () => {
    const S = this.state,
      all = S.mine.concat(this.Q);
    const list = all.filter((q) => S.theme === 'All' || q[1] === S.theme);
    const pick = list[Math.floor(Math.random() * list.length)];
    if (!pick) return;
    this.setState({ hi: pick[0] }, () =>
      setTimeout(() => {
        const el = document.querySelector('[data-quote="' + pick[0] + '"]');
        if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 120, behavior: 'smooth' });
      }, 30),
    );
    clearTimeout(this.ht);
    this.ht = setTimeout(() => this.setState({ hi: '' }), 4000);
  };
  renderVals() {
    const S = this.state,
      all = S.mine.concat(this.Q);
    const list = all.filter((q) => S.theme === 'All' || q[1] === S.theme);
    const li = ((S.idx % all.length) + all.length) % all.length;
    return {
      lead: this.shape(all[li]),
      leadPos: li + 1 + ' of ' + all.length,
      prev: () => this.setState((s) => ({ idx: s.idx - 1 })),
      next: () => this.setState((s) => ({ idx: s.idx + 1 })),
      surprise: this.surprise,
      countText: this.Q.length + S.mine.length + ' quotes',
      themeChips: ['All']
        .concat(Object.keys(this.THEMES))
        .map((t) => ({
          label: t,
          on: S.theme === t,
          dot: t === 'All' ? 'var(--pc-orange)' : 'var(--' + this.THEMES[t] + '-700)',
          toggle: () => this.setState({ theme: t }),
          ...this.chip(S.theme === t),
        })),
      quotes: list.map((q) => ({ ...this.shape(q), hasImage: true })),
      shownText: list.length === 1 ? '1 quote' : list.length + ' quotes',
      alsoRead: this.ALSO.map((l) => ({ label: l, href: '/search?query=' + encodeURIComponent(l) })),
      shareOpen: S.shareOpen,
      shared: S.shared,
      openShare: () => this.setState({ shareOpen: true, err: {} }),
      closeShare: () => this.setState({ shareOpen: false }),
      fText: S.f.text,
      fBy: S.f.by,
      fTheme: S.f.theme,
      fNote: S.f.note,
      themeOptions: Object.keys(this.THEMES),
      onFText: (e) => this.setF('text', e.target.value),
      onFBy: (e) => this.setF('by', e.target.value),
      onFTheme: (e) => this.setF('theme', e.target.value),
      onFNote: (e) => this.setF('note', e.target.value),
      err: { text: S.err.text, by: S.err.by },
      submitShare: this.submitShare,
    };
  }
}

export default PageLogic;
