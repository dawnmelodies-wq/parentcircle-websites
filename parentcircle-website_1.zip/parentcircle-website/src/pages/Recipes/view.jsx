import { Fragment } from 'react';
import { Button, Icon, IconButton } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Recipes" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Recipes"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader active="read" />
      <main>
        <section style={{ background: 'var(--butter-50)' }}>
          <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '28px 24px 48px', boxSizing: 'border-box' }}>
            <nav
              aria-label="Breadcrumb"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                flexWrap: 'wrap',
                fontSize: '15px',
                color: 'var(--text-muted)',
                marginBottom: '28px',
              }}
            >
              <a
                className="hv-1"
                href={toUrl('/')}
                style={{ color: 'var(--text-muted)', textDecoration: 'none', fontWeight: '600' }}
              >
                Home
              </a>
              <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
              <a
                className="hv-1"
                href={toUrl('/stories')}
                style={{ color: 'var(--text-muted)', textDecoration: 'none', fontWeight: '600' }}
              >
                Lifestyle
              </a>
              <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
              <span>Recipes</span>
            </nav>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '32px 56px', alignItems: 'center' }}>
              <div style={{ flex: '1 1 420px', minWidth: '0' }}>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--butter-700)',
                    marginBottom: '12px',
                  }}
                >
                  <Icon name="chef-hat" size={18} color="var(--butter-700)" />
                  Family kitchen
                </div>
                <h1
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(38px,5vw,60px)',
                    lineHeight: '1.08',
                    letterSpacing: '-0.015em',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0',
                    textWrap: 'balance',
                  }}
                >
                  Recipes and dishes
                </h1>
                <p
                  style={{
                    fontFamily: 'var(--font-serif)',
                    fontSize: '21px',
                    lineHeight: '1.6',
                    color: 'var(--text-body)',
                    margin: '16px 0 0',
                    maxWidth: '540px',
                    textWrap: 'pretty',
                  }}
                >
                  Healthy, easy dishes for the whole family — and plenty of ways to cook together with your little ones.
                  Serve hot, with a sprinkle of love.
                </p>
              </div>
              <div
                style={{
                  flex: '1 1 360px',
                  minWidth: '0',
                  position: 'relative',
                  aspectRatio: '4 / 3',
                  borderRadius: '24px',
                  overflow: 'hidden',
                  background: 'var(--white)',
                }}
              >
                <image-slot
                  id="recipes-hero"
                  shape="rounded"
                  radius="24"
                  placeholder="Photo: a family cooking together in a sunny kitchen"
                ></image-slot>
              </div>
            </div>
          </div>
        </section>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '32px 24px 0', boxSizing: 'border-box' }}>
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
              padding: '20px',
              borderRadius: '20px',
              background: 'var(--neutral-50)',
            }}
          >
            <div style={{ display: 'flex', gap: '10px 16px', flexWrap: 'wrap', alignItems: 'flex-start' }}>
              <span
                style={{
                  flex: 'none',
                  width: '92px',
                  fontSize: '15px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  lineHeight: '40px',
                }}
              >
                Meal type
              </span>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', flex: '1', minWidth: '0' }}>
                {(v.catChips ?? []).map((c, $i0) => (
                  <Fragment key={$i0}>
                    <button
                      type="button"
                      aria-pressed={c?.on}
                      onClick={c?.toggle}
                      style={{
                        height: '40px',
                        padding: '0 14px',
                        borderRadius: '999px',
                        border: `1.5px solid ${c?.bd ?? ''}`,
                        background: c?.bg,
                        color: c?.fg,
                        font: 'inherit',
                        fontSize: '15px',
                        fontWeight: '600',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        cursor: 'pointer',
                        transition: 'background 150ms',
                      }}
                    >
                      <Icon name={c?.icon} size={16} color="currentColor" />
                      {c?.label}
                    </button>
                  </Fragment>
                ))}
              </div>
            </div>
            <div style={{ display: 'flex', gap: '10px 16px', flexWrap: 'wrap', alignItems: 'flex-start' }}>
              <span
                style={{
                  flex: 'none',
                  width: '92px',
                  fontSize: '15px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  lineHeight: '40px',
                }}
              >
                Age group
              </span>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', flex: '1', minWidth: '0' }}>
                {(v.ageChips ?? []).map((a, $i0) => (
                  <Fragment key={$i0}>
                    <button
                      type="button"
                      aria-pressed={a?.on}
                      onClick={a?.toggle}
                      style={{
                        height: '40px',
                        padding: '0 14px',
                        borderRadius: '999px',
                        border: `1.5px solid ${a?.bd ?? ''}`,
                        background: a?.bg,
                        color: a?.fg,
                        font: 'inherit',
                        fontSize: '15px',
                        fontWeight: '600',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        cursor: 'pointer',
                        transition: 'background 150ms',
                      }}
                    >
                      {a?.label}
                    </button>
                  </Fragment>
                ))}
              </div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
              <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{v.countLabel}</span>
              {v.hasFilters ? (
                <button
                  className="hv-8"
                  type="button"
                  onClick={v.clearFilters}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px',
                    border: '0',
                    background: 'none',
                    padding: '6px 0',
                    font: 'inherit',
                    fontSize: '15px',
                    fontWeight: '700',
                    color: 'var(--text-link)',
                    cursor: 'pointer',
                  }}
                >
                  <Icon name="x" size={16} color="currentColor" />
                  Clear filters
                </button>
              ) : null}
            </div>
          </div>
        </section>
        {v.showLead ? (
          <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '40px 24px 0', boxSizing: 'border-box' }}>
            <article
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: '24px 40px',
                alignItems: 'center',
                paddingBottom: '40px',
                borderBottom: '1px solid var(--border-subtle)',
              }}
            >
              <div
                style={{
                  flex: '1.3 1 420px',
                  minWidth: '0',
                  position: 'relative',
                  overflow: 'hidden',
                  aspectRatio: '16 / 10',
                  borderRadius: '24px',
                  background: v.lead?.tint,
                }}
              >
                <image-slot
                  id={`recipes-${v.lead?.slot ?? ''}`}
                  shape="rounded"
                  radius="24"
                  placeholder={v.lead?.photo}
                ></image-slot>{' '}
                <span
                  style={{
                    position: 'absolute',
                    top: '16px',
                    left: '16px',
                    zIndex: '1',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px',
                    height: '32px',
                    padding: '0 12px',
                    borderRadius: '999px',
                    background: 'var(--white)',
                    color: 'var(--text-strong)',
                    fontSize: '15px',
                    fontWeight: '700',
                    boxShadow: 'var(--shadow-xs)',
                  }}
                >
                  <Icon name="flame" size={16} color="var(--orange-600)" />
                  Most loved
                </span>
              </div>
              <div style={{ flex: '1 1 340px', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                <span
                  style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: v.lead?.ink,
                  }}
                >
                  {v.lead?.cat}
                </span>
                <a
                  className="hv-5"
                  href={toUrl('/article')}
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(26px,3vw,34px)',
                    lineHeight: '1.2',
                    letterSpacing: '-0.01em',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                    textWrap: 'balance',
                  }}
                >
                  {v.lead?.title}
                </a>
                <p
                  style={{
                    fontFamily: 'var(--font-serif)',
                    fontSize: '19px',
                    lineHeight: '1.6',
                    color: 'var(--text-body)',
                    margin: '0',
                    textWrap: 'pretty',
                  }}
                >
                  {v.lead?.dek}
                </p>
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{v.lead?.meta}</span>
                <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginTop: '4px' }}>
                  <a href={toUrl('/article')} style={{ textDecoration: 'none' }}>
                    <Button variant="primary" icon="cooking-pot">
                      Get the recipes
                    </Button>
                  </a>
                  <Button variant="secondary" icon={v.lead?.saveIcon} onClick={v.lead?.toggleSave}>
                    {v.lead?.saveText}
                  </Button>
                </div>
              </div>
            </article>
          </section>
        ) : null}
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '40px 24px 0', boxSizing: 'border-box' }}>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,270px),1fr))',
              gap: '36px 24px',
            }}
          >
            {(v.recipes ?? []).map((r, $i0) => (
              <Fragment key={$i0}>
                <article style={{ display: 'flex', flexDirection: 'column', gap: '10px', minWidth: '0' }}>
                  <div
                    style={{
                      position: 'relative',
                      overflow: 'hidden',
                      aspectRatio: '4 / 3',
                      borderRadius: '16px',
                      background: r?.tint,
                    }}
                  >
                    <image-slot
                      id={`recipes-${r?.slot ?? ''}`}
                      shape="rounded"
                      radius="16"
                      placeholder={r?.photo}
                    ></image-slot>
                  </div>
                  <span
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px',
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: r?.ink,
                    }}
                  >
                    <Icon name={r?.icon} size={16} color={r?.ink} />
                    {r?.cat}
                  </span>
                  <a
                    className="hv-5"
                    href={toUrl('/article')}
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '20px',
                      lineHeight: '1.3',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                      textWrap: 'pretty',
                    }}
                  >
                    {r?.title}
                  </a>
                  <p
                    style={{
                      fontFamily: 'var(--font-serif)',
                      fontSize: '17px',
                      lineHeight: '1.5',
                      color: 'var(--text-body)',
                      margin: '0',
                      display: '-webkit-box',
                      WebkitLineClamp: '2',
                      WebkitBoxOrient: 'vertical',
                      overflow: 'hidden',
                    }}
                  >
                    {r?.dek}
                  </p>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '8px',
                      marginTop: 'auto',
                    }}
                  >
                    <span style={{ fontSize: '15px', lineHeight: '1.4', color: 'var(--text-muted)' }}>{r?.meta}</span>
                    <IconButton icon={r?.saveIcon} label={r?.saveLabel} onClick={r?.toggleSave} />
                  </div>
                </article>
              </Fragment>
            ))}
          </div>
          {v.empty ? (
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'flex-start',
                gap: '12px',
                padding: '28px',
                borderRadius: '20px',
                background: 'var(--neutral-50)',
              }}
            >
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '22px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                }}
              >
                No recipes match these filters
              </div>
              <p style={{ fontSize: '17px', color: 'var(--text-body)', margin: '0' }}>
                Try another meal type or age group.
              </p>
              <Button variant="dark" icon="x" onClick={v.clearFilters}>
                Clear filters
              </Button>
            </div>
          ) : null}
          {v.canMore ? (
            <div style={{ display: 'flex', justifyContent: 'center', paddingTop: '40px' }}>
              <Button variant="secondary" icon="chevron-down" onClick={v.showMore}>
                Load more recipes
              </Button>
            </div>
          ) : null}
        </section>
        <section style={{ marginTop: '72px', background: 'var(--sage-50)' }}>
          <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '56px 24px 64px', boxSizing: 'border-box' }}>
            <h2
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(26px,3vw,32px)',
                lineHeight: '1.2',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 6px',
              }}
            >
              Popular in family life
            </h2>
            <p style={{ fontSize: '17px', color: 'var(--text-body)', margin: '0 0 28px' }}>
              The most-read stories from parents this month.
            </p>
            <ol
              style={{
                listStyle: 'none',
                margin: '0',
                padding: '0',
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,320px),1fr))',
                gap: '12px 24px',
              }}
            >
              {(v.popular ?? []).map((p, $i0) => (
                <Fragment key={$i0}>
                  <li>
                    <a
                      className="hv-6"
                      href={toUrl('/article')}
                      style={{
                        display: 'flex',
                        gap: '14px',
                        alignItems: 'center',
                        padding: '12px',
                        borderRadius: '16px',
                        background: 'var(--white)',
                        textDecoration: 'none',
                        color: 'inherit',
                        transition: 'transform 200ms cubic-bezier(.2,0,0,1), box-shadow 200ms cubic-bezier(.2,0,0,1)',
                      }}
                    >
                      <span
                        style={{
                          fontFamily: 'var(--font-display)',
                          fontSize: '28px',
                          lineHeight: '1',
                          fontWeight: '700',
                          color: 'var(--pc-orange)',
                          width: '24px',
                          flex: 'none',
                          textAlign: 'center',
                        }}
                      >
                        {p?.n}
                      </span>
                      <span style={{ display: 'flex', flexDirection: 'column', gap: '4px', minWidth: '0' }}>
                        <span
                          style={{
                            fontFamily: 'var(--font-display)',
                            fontSize: '17px',
                            lineHeight: '1.35',
                            fontWeight: '700',
                            color: 'var(--text-strong)',
                            textWrap: 'pretty',
                          }}
                        >
                          {p?.title}
                        </span>
                        <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{p?.meta}</span>
                      </span>
                    </a>
                  </li>
                </Fragment>
              ))}
            </ol>
          </div>
        </section>
        <section aria-labelledby="top-searches" style={{ background: 'var(--neutral-50)' }}>
          <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '48px 24px 56px', boxSizing: 'border-box' }}>
            <h2
              id="top-searches"
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(24px,2.6vw,30px)',
                lineHeight: '1.2',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 18px',
              }}
            >
              Top searches
            </h2>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
              <a
                className="hv-3"
                href="https://www.dotlearningcircle.com/comprehensive-curriculum-for-pre-primary-children"
                target="_blank"
                rel="noopener"
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  border: '1.5px solid var(--border-default)',
                  background: 'var(--white)',
                  fontSize: '16px',
                  fontWeight: '600',
                  color: 'var(--text-strong)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
                Kindergarten curriculum
              </a>
              <a
                className="hv-3"
                href={toUrl('/search?query=Kitchen%20essentials')}
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  border: '1.5px solid var(--border-default)',
                  background: 'var(--white)',
                  fontSize: '16px',
                  fontWeight: '600',
                  color: 'var(--text-strong)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
                Kitchen essentials
              </a>
              <a
                className="hv-3"
                href={toUrl('/search?query=Picture%20books')}
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  border: '1.5px solid var(--border-default)',
                  background: 'var(--white)',
                  fontSize: '16px',
                  fontWeight: '600',
                  color: 'var(--text-strong)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
                Picture books
              </a>
              <a
                className="hv-3"
                href={toUrl('/search?query=Product%20reviews')}
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  border: '1.5px solid var(--border-default)',
                  background: 'var(--white)',
                  fontSize: '16px',
                  fontWeight: '600',
                  color: 'var(--text-strong)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
                Product reviews
              </a>
              <a
                className="hv-3"
                href={toUrl('/search?query=Going%20green')}
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  border: '1.5px solid var(--border-default)',
                  background: 'var(--white)',
                  fontSize: '16px',
                  fontWeight: '600',
                  color: 'var(--text-strong)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
                Going green
              </a>
              <a
                className="hv-3"
                href={toUrl('/search?query=Recycle%2C%20reuse%2C%20reduce')}
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  border: '1.5px solid var(--border-default)',
                  background: 'var(--white)',
                  fontSize: '16px',
                  fontWeight: '600',
                  color: 'var(--text-strong)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
                Recycle, reuse, reduce
              </a>
              <a
                className="hv-3"
                href={toUrl('/search?query=Parenting%20books')}
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  border: '1.5px solid var(--border-default)',
                  background: 'var(--white)',
                  fontSize: '16px',
                  fontWeight: '600',
                  color: 'var(--text-strong)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
                Parenting books
              </a>
              <a
                className="hv-3"
                href={toUrl('/search?query=Self-help%20books')}
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  border: '1.5px solid var(--border-default)',
                  background: 'var(--white)',
                  fontSize: '16px',
                  fontWeight: '600',
                  color: 'var(--text-strong)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
                Self-help books
              </a>
              <a
                className="hv-3"
                href={toUrl('/search?query=Environment')}
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  border: '1.5px solid var(--border-default)',
                  background: 'var(--white)',
                  fontSize: '16px',
                  fontWeight: '600',
                  color: 'var(--text-strong)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
                Environment
              </a>
              <a
                className="hv-3"
                href={toUrl('/search?query=Volunteering')}
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  border: '1.5px solid var(--border-default)',
                  background: 'var(--white)',
                  fontSize: '16px',
                  fontWeight: '600',
                  color: 'var(--text-strong)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
                Volunteering
              </a>
              <a
                className="hv-3"
                href={toUrl('/search?query=Gadgets')}
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  border: '1.5px solid var(--border-default)',
                  background: 'var(--white)',
                  fontSize: '16px',
                  fontWeight: '600',
                  color: 'var(--text-strong)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
                Gadgets
              </a>
              <a
                className="hv-3"
                href={toUrl('/search?query=Lifestyle%20community')}
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  border: '1.5px solid var(--border-default)',
                  background: 'var(--white)',
                  fontSize: '16px',
                  fontWeight: '600',
                  color: 'var(--text-strong)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
                Lifestyle community
              </a>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
