import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = { cat: 'All', ages: [], more: false, saved: [] };
  AGES = ['Infant', 'Toddler', 'Pre-schooler', 'Primary', 'Pre-teen', 'Teen', '18+', 'Parent'];
  CATS = {
    Breakfast: ['butter', 'egg-fried'],
    Snacks: ['sage', 'cookie'],
    'Desserts and cakes': ['blush', 'cake-slice'],
    Drinks: ['sky', 'cup-soda'],
    'Festive and regional': ['butter', 'sparkles'],
    'Family favourites': ['lilac', 'utensils'],
    'Grandma’s kitchen': ['blush', 'cooking-pot'],
    'Cooking with kids': ['sky', 'chef-hat'],
  };
  LIST = [
    [
      'Grandma’s recipes: healthy, nostalgic dishes straight from her kitchen',
      'Traditional, little-known recipes flavoured with a grandmother’s love.',
      'Grandma’s kitchen',
      'Pre-schooler',
      'Parent',
      13,
      41900,
      'Grandmother cooking in a traditional kitchen',
    ],
    [
      'Traditional recipes from a grandma’s kitchen for healthy family meals',
      'Comfort food passed down the generations — and truly incomparable.',
      'Grandma’s kitchen',
      'Parent',
      'Parent',
      4,
      40100,
      'Traditional dishes laid out on a banana leaf',
    ],
    [
      'Festive treats from a celebrity chef',
      'A walnut cheese log, pasta — and chocolate-covered dates for the season.',
      'Festive and regional',
      'Teen',
      'Parent',
      3,
      1100,
      'Walnut cheese log and chocolate-dipped dates on a festive table',
    ],
    [
      'Power-packed breakfast bites to start the day on a healthy note',
      'Three simple recipes that give the whole family’s mornings an energy boost.',
      'Breakfast',
      'Pre-schooler',
      'Parent',
      4,
      6100,
      'A family breakfast of healthy bites',
    ],
    [
      'A classic royal dessert with a twist for Valentine’s Day',
      'Plus two savoury bites to share with family and friends.',
      'Desserts and cakes',
      'Primary',
      'Parent',
      3,
      1100,
      'A classic Indian dessert served in small bowls',
    ],
    [
      'Four delicious recipes from four young cooking stars',
      'Winning dishes from our cooking contest for children.',
      'Cooking with kids',
      'Pre-schooler',
      'Pre-teen',
      4,
      1500,
      'Children in aprons proudly holding their dishes',
    ],
    [
      '10 popular birthday cake themes to try for your child',
      'Plan the most special part of the party with these crowd-pleasers.',
      'Desserts and cakes',
      'Toddler',
      'Parent',
      3,
      21800,
      'A colourful cartoon-themed birthday cake',
    ],
    [
      '6 high-protein snacks for kids you can make in minutes',
      'Ragi uthapam, banana nut pancakes, chikoo milkshake and more.',
      'Snacks',
      'Pre-schooler',
      'Parent',
      6,
      6500,
      'Ragi uthapam and banana-nut pancakes on a plate',
    ],
    [
      '4 mothers share their favourite dishes — and the stories behind them',
      'Heart-warming family stories that come with a recipe.',
      'Family favourites',
      'Parent',
      'Parent',
      9,
      2200,
      'Mothers cooking their favourite dishes together',
    ],
    [
      '5 super-quick summer desserts your children will love',
      'No-bake, no-fuss treats for those unstoppable cravings.',
      'Desserts and cakes',
      'Toddler',
      '18+',
      4,
      11700,
      'Chilled fruit desserts in glass cups',
    ],
    [
      'Bake a special chocolate birthday cake at home',
      'A recipe you and your child will enjoy making together.',
      'Desserts and cakes',
      'Toddler',
      'Pre-teen',
      4,
      11000,
      'Parent and child icing a chocolate cake',
    ],
    [
      'Quick, healthy 10-minute snacks for hungry children',
      'Ready in a jiffy for evening tea or after school.',
      'Snacks',
      'Primary',
      '18+',
      4,
      19700,
      'Evening tea snacks on a steel plate',
    ],
    [
      'Picky eater? Fun ways to make fruit and vegetables more appealing',
      'Simple ideas to make food look tempting and mealtimes fun.',
      'Cooking with kids',
      'Toddler',
      'Parent',
      9,
      17400,
      'Fruit and vegetables arranged into a smiley face',
    ],
    [
      'Easy, healthy baked chips from Chef Sabyasachi Gorai',
      'A light, oil-free, crunchy snack for children to munch on.',
      'Snacks',
      'Pre-teen',
      'Parent',
      5,
      4700,
      'Crunchy baked vegetable chips in a bowl',
    ],
    [
      '5 delicious smoothies that pack a healthy punch',
      'Tasty ways to serve milk and fruit goodness at home.',
      'Drinks',
      'Primary',
      'Teen',
      2,
      8000,
      'Five colourful smoothies in glasses',
    ],
    [
      'Seasonal recipes from across India to lift mood and energy',
      'Five regional specialities for eating right in every season.',
      'Festive and regional',
      'Pre-schooler',
      'Parent',
      10,
      6600,
      'Seasonal dishes from different Indian states',
    ],
    [
      'David Rocco’s versatile red sauce — and four dishes to make with it',
      'One sauce, lots of variety for children who love new meals.',
      'Family favourites',
      'Teen',
      'Parent',
      4,
      3500,
      'A pot of red sauce with pasta and vegetables',
    ],
    [
      'Meet Little Chef Kicha: a young cook’s road to stardom',
      'How Nihal Raj cooked his way onto international talk shows.',
      'Cooking with kids',
      'Pre-schooler',
      'Teen',
      5,
      8200,
      'A young chef cooking in his home kitchen',
    ],
  ];
  POP = [
    ['World Nature Conservation Day: eco-friendly activities for kids', 5, 47300],
    ['Traditional Indian games for kids and their lasting benefits', 11, 41800],
    ['Awesome apps for new mothers', 5, 21700],
    ['Simple ways to make boring food exciting for kids', 6, 12300],
    ['Travelling with your toddler? Car safety tips to keep in mind', 3, 17000],
    ['How to choose learning apps that support your child', 8, 176],
  ];
  chip(on) {
    return on
      ? { bg: 'var(--neutral-900)', fg: 'var(--white)', bd: 'var(--neutral-900)' }
      : { bg: 'var(--white)', fg: 'var(--text-strong)', bd: 'var(--border-default)' };
  }
  views(n) {
    return n >= 1000 ? (Math.round(n / 100) / 10).toString().replace(/\.0$/, '') + 'K views' : n + ' views';
  }
  span(a0, a1) {
    return this.AGES.slice(this.AGES.indexOf(a0), this.AGES.indexOf(a1) + 1);
  }
  shape(r) {
    const [title, dek, cat, a0, a1, min, v, ph] = r,
      [hue, icon] = this.CATS[cat],
      idx = this.LIST.indexOf(r),
      on = this.state.saved.includes(idx);
    return {
      slot: 'r' + idx,
      title,
      dek,
      cat,
      icon,
      photo: 'Photo: ' + ph,
      tint: 'var(--' + hue + '-50)',
      ink: 'var(--' + hue + '-700)',
      meta: (a0 === a1 ? a0 : a0 + ' to ' + a1) + ' · ' + min + ' min read · ' + this.views(v),
      saveIcon: on ? 'bookmark-check' : 'bookmark',
      saveLabel: on ? 'Saved' : 'Save recipe',
      saveText: on ? 'Saved' : 'Save',
      toggleSave: () =>
        this.setState((s) => ({
          saved: s.saved.includes(idx) ? s.saved.filter((x) => x !== idx) : s.saved.concat(idx),
        })),
    };
  }
  renderVals() {
    const S = this.state;
    const rows = this.LIST.filter(
      (r) =>
        (S.cat === 'All' || r[2] === S.cat) &&
        (!S.ages.length || this.span(r[3], r[4]).some((a) => S.ages.includes(a))),
    );
    const nf = (S.cat !== 'All' ? 1 : 0) + S.ages.length,
      showLead = nf === 0;
    const rest = showLead ? rows.slice(1) : rows,
      lim = S.more ? rest : rest.slice(0, 8);
    return {
      catChips: ['All']
        .concat(Object.keys(this.CATS))
        .map((c) => ({
          label: c,
          icon: c === 'All' ? 'utensils-crossed' : this.CATS[c][1],
          on: S.cat === c,
          toggle: () => this.setState({ cat: c, more: false }),
          ...this.chip(S.cat === c),
        })),
      ageChips: this.AGES.map((a) => ({
        label: a,
        on: S.ages.includes(a),
        toggle: () =>
          this.setState((s) => ({
            ages: s.ages.includes(a) ? s.ages.filter((x) => x !== a) : s.ages.concat(a),
            more: false,
          })),
        ...this.chip(S.ages.includes(a)),
      })),
      countLabel: rows.length === 1 ? '1 recipe' : rows.length + ' recipes',
      hasFilters: nf > 0,
      clearFilters: () => this.setState({ cat: 'All', ages: [], more: false }),
      showLead,
      lead: this.shape(this.LIST[0]),
      recipes: lim.map((r) => this.shape(r)),
      empty: rows.length === 0,
      canMore: !S.more && rest.length > 8,
      showMore: () => this.setState({ more: true }),
      popular: this.POP.map(([title, min, v], i) => ({ n: i + 1, title, meta: min + ' min read · ' + this.views(v) })),
    };
  }
}

export default PageLogic;
