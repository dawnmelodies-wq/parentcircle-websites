import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = { gender: 'girl', letter: 'A', cat: 'All', more: false, saved: [], joined: false };
  CATS = {
    'Boy names': ['sky', 'baby'],
    'Girl names': ['blush', 'baby'],
    Festivals: ['butter', 'sparkles'],
    'Gods and mythology': ['lilac', 'flower-2'],
    Trending: ['sage', 'trending-up'],
  };
  LIST = [
    [
      'Trending and popular baby names inspired by celebrities, mythology and literature',
      'Don’t choose a boring name in a hurry — here are trendy names that will help your child stand out.',
      'Trending',
      '',
      'Parent',
      'Parent',
      7,
      212500,
      'Parents holding their baby’s tiny feet',
    ],
    [
      'Baby girl names starting with G: traditional and modern ideas',
      'A curated list of beautiful, meaningful names that are just right for your little one.',
      'Girl names',
      'G',
      'Infant',
      'Infant',
      4,
      92500,
      'Newborn girl wrapped in a soft pink blanket',
    ],
    [
      'Modern Lord Ganesha-inspired names for baby boys, with meanings',
      'Sanskrit names of the Elephant God — plus modern and unique ones, with numerology.',
      'Gods and mythology',
      '',
      'Infant',
      'Parent',
      11,
      511900,
      'A small Ganesha idol beside a baby’s cradle',
    ],
    [
      'Baby boy names starting with U',
      'A list of trendy boy names starting with U for your little son.',
      'Boy names',
      'U',
      'Infant',
      'Parent',
      3,
      56200,
      'Baby boy smiling in his father’s arms',
    ],
    [
      'Top 10 baby names for children born on Diwali',
      'Names that resound with the spirit of the festival — to welcome the new light in your life.',
      'Festivals',
      '',
      'Infant',
      'Toddler',
      4,
      149500,
      'Baby beside glowing diyas on Diwali',
    ],
    [
      'Baby girl names starting with O',
      'A list of unique, trendy girl names starting with O.',
      'Girl names',
      'O',
      'Infant',
      'Parent',
      4,
      68100,
      'Baby girl holding her mother’s finger',
    ],
    [
      'Traditional baby names inspired by Indian festivals',
      'Names inspired by Ganesh Chaturthi, Ramzan, Christmas and more — with their meanings.',
      'Festivals',
      '',
      'Infant',
      'Infant',
      7,
      633200,
      'Family celebrating a festival with their baby',
    ],
    [
      'Baby boy names starting with F',
      'A list of unique boy names starting with F for you to choose from.',
      'Boy names',
      'F',
      'Infant',
      'Parent',
      2,
      36700,
      'Baby boy asleep on his mother’s shoulder',
    ],
    [
      'Baby girl names starting with F',
      'A list of unique girl names starting with F for you to choose from.',
      'Girl names',
      'F',
      'Infant',
      'Parent',
      3,
      39600,
      'Grandmother cradling a baby girl',
    ],
    [
      'Baby girl names starting with Z',
      'Unique and trendy names starting with Z for your little daughter.',
      'Girl names',
      'Z',
      'Infant',
      'Parent',
      3,
      36600,
      'Close-up of a baby girl’s tiny hand',
    ],
    [
      'Baby boy names starting with W',
      'A list of trendy boy names starting with W for you to choose from.',
      'Boy names',
      'W',
      'Infant',
      'Parent',
      3,
      29700,
      'Father lifting his baby boy in the air',
    ],
    [
      'Baby girl names starting with W',
      'A list of trendy girl names starting with W for you to choose from.',
      'Girl names',
      'W',
      'Parent',
      'Parent',
      2,
      30100,
      'Mother kissing her baby girl’s forehead',
    ],
    [
      'Baby girl names starting with I',
      'A list of unique girl names starting with I for you to choose from.',
      'Girl names',
      'I',
      'Infant',
      'Parent',
      4,
      41000,
      'Baby girl in a cotton frock lying on a mat',
    ],
    [
      'Baby boy names starting with O',
      'A list of trendy boy names starting with O for you to choose from.',
      'Boy names',
      'O',
      'Infant',
      'Parent',
      4,
      42600,
      'Baby boy crawling on a rug',
    ],
    [
      'Baby girl names starting with U',
      'A list of baby girl names starting with U for your little daughter.',
      'Girl names',
      'U',
      'Infant',
      'Parent',
      3,
      60300,
      'Baby girl laughing during bath time',
    ],
    [
      'Baby boy names starting with Z',
      'Unique and trendy names starting with Z for your little son.',
      'Boy names',
      'Z',
      'Infant',
      'Parent',
      2,
      28300,
      'Baby boy with a soft toy',
    ],
    [
      'Baby boy names starting with I',
      'A list of trendy boy names starting with I for you to choose from.',
      'Boy names',
      'I',
      'Infant',
      'Parent',
      4,
      41400,
      'Grandfather holding his grandson',
    ],
    [
      'Baby boy names starting with Q',
      'A list of trendy boy names starting with Q for you to choose from.',
      'Boy names',
      'Q',
      'Infant',
      'Parent',
      2,
      23100,
      'Baby boy peeking out from a blanket',
    ],
  ];
  POP = [
    ['50 unique and interesting baby girl names', 14, 863900],
    ['Modern Lord Ganesha-inspired names for baby boys', 11, 511900],
    ['Baby boy names starting with J', 5, 147500],
    ['Baby boy names starting with I', 4, 41400],
    ['Third trimester of pregnancy: what to eat and how to exercise', 10, 34400],
  ];
  chip(on) {
    return on
      ? { bg: 'var(--neutral-900)', fg: 'var(--white)', bd: 'var(--neutral-900)' }
      : { bg: 'var(--white)', fg: 'var(--text-strong)', bd: 'var(--border-default)' };
  }
  views(n) {
    return n >= 1000 ? (Math.round(n / 100) / 10).toString().replace(/\.0$/, '') + 'K views' : n + ' views';
  }
  shape(r) {
    const [title, dek, cat, letter, a0, a1, min, v, ph] = r,
      [hue, icon] = this.CATS[cat],
      idx = this.LIST.indexOf(r),
      on = this.state.saved.includes(idx);
    return {
      slot: 'n' + idx,
      title,
      dek,
      cat: cat.replace(' names', ''),
      icon,
      letter,
      hasLetter: !!letter,
      photo: 'Photo: ' + ph,
      tint: 'var(--' + hue + '-50)',
      ink: 'var(--' + hue + '-700)',
      meta: (a0 === a1 ? a0 : a0 + ' to ' + a1) + ' · ' + min + ' min read · ' + this.views(v),
      saveIcon: on ? 'bookmark-check' : 'bookmark',
      saveLabel: on ? 'Saved' : 'Save list',
      saveText: on ? 'Saved' : 'Save',
      toggleSave: () =>
        this.setState((s) => ({
          saved: s.saved.includes(idx) ? s.saved.filter((x) => x !== idx) : s.saved.concat(idx),
        })),
    };
  }
  renderVals() {
    const S = this.state,
      girl = S.gender === 'girl';
    const rows = this.LIST.filter((r) => S.cat === 'All' || r[2] === S.cat);
    const showLead = S.cat === 'All',
      rest = showLead ? rows.slice(1) : rows,
      lim = S.more ? rest : rest.slice(0, 8);
    const on = (ch) => ch === S.letter;
    return {
      genderTabs: [
        { value: 'girl', label: 'Girl names' },
        { value: 'boy', label: 'Boy names' },
      ],
      gender: S.gender,
      setGender: (v) => this.setState({ gender: v }),
      letters: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        .split('')
        .map((ch) => ({
          ch,
          on: on(ch),
          pick: () => this.setState({ letter: ch }),
          bg: on(ch) ? 'var(--neutral-900)' : 'var(--white)',
          fg: on(ch) ? 'var(--white)' : 'var(--text-strong)',
          bd: on(ch) ? 'var(--neutral-900)' : 'var(--border-default)',
        })),
      seeHref: '/name-list?g=' + S.gender + '&l=' + S.letter,
      letter: S.letter,
      pickTitle: (girl ? 'Baby girl' : 'Baby boy') + ' names starting with ' + S.letter,
      pickTint: girl ? 'var(--blush-50)' : 'var(--sky-50)',
      pickInk: girl ? 'var(--blush-700)' : 'var(--sky-700)',
      catChips: ['All']
        .concat(Object.keys(this.CATS))
        .map((c) => ({
          label: c,
          icon: c === 'All' ? 'list' : this.CATS[c][1],
          on: S.cat === c,
          toggle: () => this.setState({ cat: c, more: false }),
          ...this.chip(S.cat === c),
        })),
      countLabel: rows.length === 1 ? '1 name list' : rows.length + ' name lists',
      hasFilters: S.cat !== 'All',
      clearFilters: () => this.setState({ cat: 'All', more: false }),
      showLead,
      lead: this.shape(this.LIST[0]),
      items: lim.map((r) => this.shape(r)),
      canMore: !S.more && rest.length > 8,
      showMore: () => this.setState({ more: true }),
      popular: this.POP.map(([title, min, v], i) => ({ n: i + 1, title, meta: min + ' min read · ' + this.views(v) })),
      joinLabel: S.joined ? 'Joined' : 'Join circle',
      joinVariant: S.joined ? 'secondary' : 'dark',
      joinIcon: S.joined ? 'check' : 'plus',
      toggleJoin: () => this.setState((s) => ({ joined: !s.joined })),
    };
  }
}

export default PageLogic;
