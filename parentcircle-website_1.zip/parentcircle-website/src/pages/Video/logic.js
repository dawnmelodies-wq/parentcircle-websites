import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = {
    playing: false,
    liked: false,
    saved: false,
    copied: false,
    autoplay: true,
    pledged: false,
    draft: '',
    comments: [],
  };
  videoId = 'ohUrZvUvlbE';

  share = () => {
    try {
      navigator.clipboard && navigator.clipboard.writeText(window.location.href);
    } catch (e) {}
    this.setState({ copied: true });
    clearTimeout(this._t);
    this._t = setTimeout(() => this.setState({ copied: false }), 2500);
  };
  componentWillUnmount() {
    clearTimeout(this._t);
  }

  renderVals() {
    const S = this.state,
      n = S.comments.length;
    return {
      playing: S.playing,
      notPlaying: !S.playing,
      play: () => this.setState({ playing: true }),
      embedSrc: 'https://www.youtube-nocookie.com/embed/' + this.videoId + '?autoplay=1&rel=0&modestbranding=1',
      likeLabel: S.liked ? 'Helpful · 1' : 'Helpful',
      likeVariant: S.liked ? 'soft' : 'secondary',
      toggleLike: () => this.setState((s) => ({ liked: !s.liked })),
      saveIcon: S.saved ? 'bookmark-check' : 'bookmark',
      saveLabel: S.saved ? 'Saved' : 'Save',
      toggleSave: () => this.setState((s) => ({ saved: !s.saved })),
      share: this.share,
      shareLabel: S.copied ? 'Link copied' : 'Share',
      autoplay: S.autoplay,
      setAutoplay: (v) => this.setState({ autoplay: v }),
      pledged: S.pledged,
      notPledged: !S.pledged,
      pledge: () => this.setState({ pledged: true }),
      commentHeading: n === 0 ? 'Comments' : n === 1 ? '1 comment' : n + ' comments',
      noComments: n === 0,
      comments: S.comments,
      draft: S.draft,
      draftEmpty: !S.draft.trim(),
      onDraft: (e) => this.setState({ draft: e.target.value }),
      postComment: () => {
        const t = S.draft.trim();
        if (!t) return;
        this.setState((s) => ({
          draft: '',
          comments: [{ id: 'n' + Date.now(), name: 'You', when: 'Just now', text: t }, ...s.comments],
        }));
      },
    };
  }
}

export default PageLogic;
