import { Fragment } from 'react';
import { Avatar, Badge, Button, Card, Icon, Input, Switch, Tag } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Video" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Video"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader communityHref="/#community" />
      <main style={{ maxWidth: '1200px', margin: '0 auto', padding: '28px 24px 0', boxSizing: 'border-box' }}>
        <nav
          aria-label="Breadcrumb"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            flexWrap: 'wrap',
            fontSize: '15px',
            color: 'var(--text-muted)',
            marginBottom: '24px',
          }}
        >
          <a
            className="hv-1"
            href={toUrl('/')}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              color: 'var(--text-muted)',
              textDecoration: 'none',
              fontWeight: '600',
            }}
          >
            <Icon name="arrow-left" size={18} />
            Home
          </a>
          <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
          <a className="hv-1" href={toUrl('/#watch')} style={{ color: 'var(--text-muted)', textDecoration: 'none' }}>
            Watch
          </a>
          <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
          <a className="hv-1" href="#pledge" style={{ color: 'var(--text-muted)', textDecoration: 'none' }}>
            #GadgetFreeHour
          </a>
        </nav>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '40px', alignItems: 'flex-start' }}>
          <div style={{ flex: '999 1 560px', minWidth: '0' }}>
            <div
              style={{
                width: '100%',
                aspectRatio: '16 / 9',
                position: 'relative',
                borderRadius: '24px',
                overflow: 'hidden',
                background: 'var(--neutral-900)',
                boxShadow: 'var(--shadow-md)',
              }}
            >
              {v.notPlaying ? (
                <button
                  className="hv-t"
                  type="button"
                  onClick={v.play}
                  aria-label="Play video: Raising kids in a digital era"
                  style={{
                    position: 'absolute',
                    inset: '0',
                    width: '100%',
                    height: '100%',
                    padding: '0',
                    border: '0',
                    cursor: 'pointer',
                    background: 'var(--neutral-900)',
                    display: 'block',
                  }}
                >
                  <img
                    src="https://img.youtube.com/vi/ohUrZvUvlbE/maxresdefault.jpg"
                    alt=""
                    style={{ position: 'absolute', inset: '0', width: '100%', height: '100%', objectFit: 'cover' }}
                  />{' '}
                  <span
                    style={{
                      position: 'absolute',
                      left: '50%',
                      top: '50%',
                      transform: 'translate(-50%,-50%)',
                      width: '96px',
                      height: '96px',
                      borderRadius: '50%',
                      background: 'var(--action-primary)',
                      color: 'var(--white)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      boxShadow: 'var(--shadow-lg)',
                    }}
                  >
                    <Icon name="play" size={44} />
                  </span>{' '}
                  <span
                    style={{
                      position: 'absolute',
                      left: '20px',
                      bottom: '20px',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      height: '40px',
                      padding: '0 16px',
                      borderRadius: '999px',
                      background: 'var(--white)',
                      color: 'var(--text-strong)',
                      fontFamily: 'var(--font-ui)',
                      fontSize: '16px',
                      fontWeight: '600',
                      boxShadow: 'var(--shadow-sm)',
                    }}
                  >
                    <Icon name="volume-2" size={20} color="var(--orange-600)" />
                    Tap to watch with sound
                  </span>
                </button>
              ) : null}
              {v.playing ? (
                <iframe
                  src={toUrl(v.embedSrc)}
                  title="Raising kids in a digital era: Maria Goretti Warsi"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen={true}
                  style={{ position: 'absolute', inset: '0', width: '100%', height: '100%', border: '0' }}
                ></iframe>
              ) : null}
            </div>
            <div style={{ marginTop: '28px', maxWidth: '820px' }}>
              <div
                style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap', marginBottom: '14px' }}
              >
                <span
                  style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--lilac-700)',
                  }}
                >
                  #GadgetFreeHour · Screen time
                </span>
                <Badge tone="neutral">Video</Badge>
                <Badge tone="neutral">Preschooler to parent</Badge>
              </div>
              <h1
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(30px,3.6vw,44px)',
                  lineHeight: '1.15',
                  letterSpacing: '-0.015em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                  textWrap: 'balance',
                }}
              >
                Raising kids in a digital era means less family time: Maria Goretti Warsi
              </h1>
            </div>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '12px 16px',
                flexWrap: 'wrap',
                padding: '20px 0',
                borderBottom: '1px solid var(--border-default)',
              }}
            >
              <Avatar name="ParentCircle Team" size={48} ring={true} />
              <div style={{ flex: '1 1 200px', minWidth: '0' }}>
                <div style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                  Team ParentCircle
                </div>
                <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>3 Nov 2023 · 2,600 views</div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                <Button size="sm" variant={v.likeVariant} icon="heart" onClick={v.toggleLike}>
                  {v.likeLabel}
                </Button>
                <Button size="sm" variant="secondary" icon={v.saveIcon} onClick={v.toggleSave}>
                  {v.saveLabel}
                </Button>
                <Button size="sm" variant="secondary" icon="share-2" onClick={v.share}>
                  {v.shareLabel}
                </Button>
              </div>
            </div>
            <div style={{ maxWidth: '720px', paddingTop: '28px' }}>
              <p
                style={{
                  fontFamily: 'var(--font-reading)',
                  fontSize: '21px',
                  lineHeight: '1.7',
                  color: 'var(--text-body)',
                  margin: '0 0 1.1em',
                  textWrap: 'pretty',
                }}
              >
                In this #GadgetFreeHour special, chef and former VJ Maria Goretti Warsi talks openly about family life
                with screens everywhere. Her favourite family time? A holiday with no Wi-Fi at all.
              </p>
              <p
                style={{
                  fontFamily: 'var(--font-reading)',
                  fontSize: '21px',
                  lineHeight: '1.7',
                  color: 'var(--text-body)',
                  margin: '0 0 1.1em',
                  textWrap: 'pretty',
                }}
              >
                She also shares how hard it is to keep her children off their devices when being online seems to be
                their favourite pastime — and why she worries about what growing up this way means for the time families
                spend together.
              </p>
              <div
                style={{
                  background: 'var(--lilac-50)',
                  borderRadius: '16px',
                  padding: '24px 28px',
                  margin: '28px 0 0',
                }}
              >
                <div
                  style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--lilac-700)',
                    marginBottom: '16px',
                  }}
                >
                  In this video
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  <div style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                    <span
                      style={{
                        width: '44px',
                        height: '44px',
                        flex: 'none',
                        borderRadius: '12px',
                        background: 'var(--white)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Icon name="wifi-off" size={22} color="var(--lilac-700)" />
                    </span>
                    <span style={{ fontSize: '18px', lineHeight: '1.5', color: 'var(--text-body)', paddingTop: '9px' }}>
                      Why a holiday with no Wi-Fi is her favourite family memory
                    </span>
                  </div>
                  <div style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                    <span
                      style={{
                        width: '44px',
                        height: '44px',
                        flex: 'none',
                        borderRadius: '12px',
                        background: 'var(--white)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Icon name="smartphone" size={22} color="var(--lilac-700)" />
                    </span>
                    <span style={{ fontSize: '18px', lineHeight: '1.5', color: 'var(--text-body)', paddingTop: '9px' }}>
                      The everyday struggle of keeping children away from screens
                    </span>
                  </div>
                  <div style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                    <span
                      style={{
                        width: '44px',
                        height: '44px',
                        flex: 'none',
                        borderRadius: '12px',
                        background: 'var(--white)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Icon name="users" size={22} color="var(--lilac-700)" />
                    </span>
                    <span style={{ fontSize: '18px', lineHeight: '1.5', color: 'var(--text-body)', paddingTop: '9px' }}>
                      Her worry about raising children in a digital age
                    </span>
                  </div>
                </div>
              </div>
              <div style={{ padding: '32px 0 0' }}>
                <div
                  style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--text-muted)',
                    marginBottom: '14px',
                  }}
                >
                  Related topics
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  <Tag topic="teens">Responsible screen time</Tag>
                  <Tag topic="teens">Navigating social media</Tag>
                  <Tag topic="emotions">Managing child behaviour</Tag>
                  <Tag>Parenting styles</Tag>
                </div>
              </div>
              <section id="comments" style={{ padding: '48px 0 0', scrollMarginTop: '96px' }}>
                <h2
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '27px',
                    lineHeight: '1.25',
                    letterSpacing: '-0.01em',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0 0 20px',
                  }}
                >
                  {v.commentHeading}
                </h2>
                <Card padding={20}>
                  <div style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                    <Avatar name="You" size={44} />
                    <div style={{ flex: '1', minWidth: '0' }}>
                      <Input
                        multiline={true}
                        rows={2}
                        placeholder="How does your family switch off from screens?"
                        value={v.draft}
                        onChange={v.onDraft}
                      />
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          gap: '12px',
                          flexWrap: 'wrap',
                          marginTop: '12px',
                        }}
                      >
                        <span
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '6px',
                            fontSize: '15px',
                            color: 'var(--text-muted)',
                          }}
                        >
                          <Icon name="lock" size={16} />
                          Be kind. Every family is different.
                        </span>
                        <Button size="sm" disabled={v.draftEmpty} onClick={v.postComment}>
                          Post comment
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
                {v.noComments ? (
                  <p
                    style={{
                      fontFamily: 'var(--font-serif)',
                      fontSize: '19px',
                      lineHeight: '1.6',
                      color: 'var(--text-muted)',
                      margin: '24px 0 0',
                    }}
                  >
                    No comments yet. Be the first to share how your family unplugs.
                  </p>
                ) : null}
                {(v.comments ?? []).map((m, $i0) => (
                  <Fragment key={$i0}>
                    <article style={{ padding: '24px 0', borderBottom: '1px solid var(--border-subtle)' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                        <Avatar name={m?.name} size={36} />
                        <span style={{ fontSize: '16px', fontWeight: '600', color: 'var(--text-strong)' }}>
                          {m?.name}
                        </span>
                        <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                          {'· '}
                          {m?.when}
                        </span>
                      </div>
                      <p
                        style={{
                          fontFamily: 'var(--font-serif)',
                          fontSize: '19px',
                          lineHeight: '1.6',
                          color: 'var(--text-body)',
                          margin: '0',
                          textWrap: 'pretty',
                        }}
                      >
                        {m?.text}
                      </p>
                    </article>
                  </Fragment>
                ))}
              </section>
            </div>
          </div>
          <aside style={{ flex: '1 1 240px', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '20px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '12px' }}>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '24px',
                  lineHeight: '1.25',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                }}
              >
                Up next
              </h2>
              <Switch label="Autoplay" checked={v.autoplay} onChange={v.setAutoplay} />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              <a
                className="hv-c"
                href="#"
                style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '12px 14px',
                  padding: '12px 0',
                  borderBottom: '1px solid var(--border-subtle)',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <span
                  style={{
                    flex: '1 1 150px',
                    minWidth: '0',
                    maxWidth: '100%',
                    aspectRatio: '16 / 9',
                    position: 'relative',
                    borderRadius: '12px',
                    background: 'var(--lilac-100)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="play" size={26} color="var(--lilac-700)" />
                </span>
                <span
                  style={{ display: 'flex', flexDirection: 'column', gap: '4px', minWidth: '0', flex: '999 1 160px' }}
                >
                  <span
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.04em',
                      textTransform: 'uppercase',
                      color: 'var(--lilac-700)',
                      overflowWrap: 'anywhere',
                    }}
                  >
                    #GadgetFreeHour
                  </span>
                  <span
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '17px',
                      lineHeight: '1.35',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      textWrap: 'pretty',
                    }}
                  >
                    Pradeepthi Vissamsetti takes the #GadgetFreeHour pledge
                  </span>
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>1,100 views</span>
                </span>
              </a>
              <a
                className="hv-c"
                href="#"
                style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '12px 14px',
                  padding: '12px 0',
                  borderBottom: '1px solid var(--border-subtle)',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <span
                  style={{
                    flex: '1 1 150px',
                    minWidth: '0',
                    maxWidth: '100%',
                    aspectRatio: '16 / 9',
                    position: 'relative',
                    borderRadius: '12px',
                    background: 'var(--lilac-100)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="play" size={26} color="var(--lilac-700)" />
                </span>
                <span
                  style={{ display: 'flex', flexDirection: 'column', gap: '4px', minWidth: '0', flex: '999 1 160px' }}
                >
                  <span
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.04em',
                      textTransform: 'uppercase',
                      color: 'var(--lilac-700)',
                      overflowWrap: 'anywhere',
                    }}
                  >
                    #GadgetFreeHour
                  </span>
                  <span
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '17px',
                      lineHeight: '1.35',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      textWrap: 'pretty',
                    }}
                  >
                    Reading is our favourite gadget-free activity: Chef Ranveer Brar
                  </span>
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>1,300 views</span>
                </span>
              </a>
              <a
                className="hv-c"
                href="#"
                style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '12px 14px',
                  padding: '12px 0',
                  borderBottom: '1px solid var(--border-subtle)',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <span
                  style={{
                    flex: '1 1 150px',
                    minWidth: '0',
                    maxWidth: '100%',
                    aspectRatio: '16 / 9',
                    position: 'relative',
                    borderRadius: '12px',
                    background: 'var(--sage-100)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="play" size={26} color="var(--sage-700)" />
                  <span
                    style={{
                      position: 'absolute',
                      right: '6px',
                      bottom: '6px',
                      padding: '2px 7px',
                      borderRadius: '6px',
                      background: 'var(--neutral-900)',
                      color: 'var(--text-inverse)',
                      fontSize: '13px',
                      fontWeight: '600',
                    }}
                  >
                    6:12
                  </span>
                </span>
                <span
                  style={{ display: 'flex', flexDirection: 'column', gap: '4px', minWidth: '0', flex: '999 1 160px' }}
                >
                  <span
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--sage-700)',
                    }}
                  >
                    Baby care
                  </span>
                  <span
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '17px',
                      lineHeight: '1.35',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      textWrap: 'pretty',
                    }}
                  >
                    A 5-minute baby massage routine, step by step
                  </span>
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Dr. Kavitha Rao</span>
                </span>
              </a>
              <a
                className="hv-c"
                href="#"
                style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '12px 14px',
                  padding: '12px 0',
                  borderBottom: '1px solid var(--border-subtle)',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <span
                  style={{
                    flex: '1 1 150px',
                    minWidth: '0',
                    maxWidth: '100%',
                    aspectRatio: '16 / 9',
                    position: 'relative',
                    borderRadius: '12px',
                    background: 'var(--sky-100)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="play" size={26} color="var(--sky-700)" />
                  <span
                    style={{
                      position: 'absolute',
                      right: '6px',
                      bottom: '6px',
                      padding: '2px 7px',
                      borderRadius: '6px',
                      background: 'var(--neutral-900)',
                      color: 'var(--text-inverse)',
                      fontSize: '13px',
                      fontWeight: '600',
                    }}
                  >
                    4:48
                  </span>
                </span>
                <span
                  style={{ display: 'flex', flexDirection: 'column', gap: '4px', minWidth: '0', flex: '999 1 160px' }}
                >
                  <span
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--sky-700)',
                    }}
                  >
                    Language
                  </span>
                  <span
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '17px',
                      lineHeight: '1.35',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      textWrap: 'pretty',
                    }}
                  >
                    Story time that builds language: 3 simple tricks
                  </span>
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Lakshmi Venkat</span>
                </span>
              </a>
              <a
                className="hv-c"
                href="#"
                style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '12px 14px',
                  padding: '12px 0',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <span
                  style={{
                    flex: '1 1 150px',
                    minWidth: '0',
                    maxWidth: '100%',
                    aspectRatio: '16 / 9',
                    position: 'relative',
                    borderRadius: '12px',
                    background: 'var(--blush-100)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="play" size={26} color="var(--blush-700)" />
                  <span
                    style={{
                      position: 'absolute',
                      right: '6px',
                      bottom: '6px',
                      padding: '2px 7px',
                      borderRadius: '6px',
                      background: 'var(--neutral-900)',
                      color: 'var(--text-inverse)',
                      fontSize: '13px',
                      fontWeight: '600',
                    }}
                  >
                    5:30
                  </span>
                </span>
                <span
                  style={{ display: 'flex', flexDirection: 'column', gap: '4px', minWidth: '0', flex: '999 1 160px' }}
                >
                  <span
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--blush-700)',
                    }}
                  >
                    Emotions
                  </span>
                  <span
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '17px',
                      lineHeight: '1.35',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      textWrap: 'pretty',
                    }}
                  >
                    How to set up a calm-down corner at home
                  </span>
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Dr. Meera Iyer</span>
                </span>
              </a>
            </div>
            <Button variant="secondary" iconRight="arrow-right" fullWidth={true}>
              All videos
            </Button>
          </aside>
        </div>
      </main>
      <section id="pledge" style={{ marginTop: '96px', background: 'var(--butter-50)', scrollMarginTop: '72px' }}>
        <div
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '64px 24px',
            boxSizing: 'border-box',
            display: 'flex',
            flexWrap: 'wrap',
            gap: '40px 56px',
            alignItems: 'center',
          }}
        >
          <div style={{ flex: '1 1 420px', minWidth: '0' }}>
            <div
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--butter-700)',
                marginBottom: '12px',
              }}
            >
              #GadgetFreeHour · World Children’s Day
            </div>
            <h2
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(30px,3.4vw,40px)',
                lineHeight: '1.15',
                letterSpacing: '-0.01em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0',
                textWrap: 'balance',
              }}
            >
              One hour. No gadgets. Just your family.
            </h2>
            <p
              style={{
                fontFamily: 'var(--font-serif)',
                fontSize: '21px',
                lineHeight: '1.6',
                color: 'var(--text-body)',
                margin: '16px 0 28px',
                maxWidth: '560px',
                textWrap: 'pretty',
              }}
            >
              On 20 November, put every phone, tablet and TV away for one hour and spend it together — grandparents too.
            </p>
            {v.notPledged ? (
              <Button variant="primary" size="lg" icon="hand-heart" onClick={v.pledge}>
                Take the pledge
              </Button>
            ) : null}
            {v.pledged ? (
              <div
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '10px',
                  padding: '14px 18px',
                  borderRadius: '10px',
                  background: 'var(--white)',
                  color: 'var(--sage-700)',
                  fontSize: '18px',
                  fontWeight: '600',
                  boxShadow: 'var(--shadow-sm)',
                }}
              >
                <Icon name="circle-check" size={24} />
                You’re in. See you on 20 November.
              </div>
            ) : null}
          </div>
          <div
            style={{
              flex: '1 1 420px',
              minWidth: '0',
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,160px),1fr))',
              gap: '12px',
            }}
          >
            <div
              style={{
                background: 'var(--white)',
                borderRadius: '16px',
                padding: '20px',
                display: 'flex',
                flexDirection: 'column',
                gap: '12px',
              }}
            >
              <Icon name="chef-hat" size={30} color="var(--butter-700)" />
              <span style={{ fontSize: '17px', lineHeight: '1.4', fontWeight: '600', color: 'var(--text-strong)' }}>
                Cook a simple dinner together
              </span>
            </div>
            <div
              style={{
                background: 'var(--white)',
                borderRadius: '16px',
                padding: '20px',
                display: 'flex',
                flexDirection: 'column',
                gap: '12px',
              }}
            >
              <Icon name="dices" size={30} color="var(--butter-700)" />
              <span style={{ fontSize: '17px', lineHeight: '1.4', fontWeight: '600', color: 'var(--text-strong)' }}>
                Play a board game, or pallanguzhi
              </span>
            </div>
            <div
              style={{
                background: 'var(--white)',
                borderRadius: '16px',
                padding: '20px',
                display: 'flex',
                flexDirection: 'column',
                gap: '12px',
              }}
            >
              <Icon name="book-open" size={30} color="var(--butter-700)" />
              <span style={{ fontSize: '17px', lineHeight: '1.4', fontWeight: '600', color: 'var(--text-strong)' }}>
                Read a story aloud
              </span>
            </div>
          </div>
        </div>
      </section>
      <section aria-labelledby="top-searches" style={{ background: 'var(--neutral-50)' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '48px 24px 56px', boxSizing: 'border-box' }}>
          <h2
            id="top-searches"
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(24px,2.6vw,30px)',
              lineHeight: '1.2',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0 0 18px',
            }}
          >
            Top searches
          </h2>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
            <a
              className="hv-3"
              href="https://www.dotlearningcircle.com/comprehensive-curriculum-for-pre-primary-children"
              target="_blank"
              rel="noopener"
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Kindergarten curriculum
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Parenting%20tips%20for%20infants')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parenting tips for infants
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Parenting%20tips%20for%20toddlers')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parenting tips for toddlers
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Parenting%20tips%20for%20preschoolers')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parenting tips for preschoolers
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Parenting%20tips%20for%20primary%20school%20children')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parenting tips for primary school children
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Parenting%20tips%20for%20pre-teens')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parenting tips for pre-teens
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Parenting%20tips%20for%20teens')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parenting tips for teens
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Parenting%20tips%20for%20parents%20of%20adults')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parenting tips for parents of adults
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Parenting%20tips%20for%20parents')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parenting tips for parents
            </a>
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
