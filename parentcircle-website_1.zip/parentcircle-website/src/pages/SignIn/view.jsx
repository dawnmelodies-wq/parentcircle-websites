import { Fragment } from 'react';
import { Button, Icon, IconButton, Input, Logo } from '../../components/ds';
import { toUrl } from '../../lib/paths';

/** Markup for the "Sign In" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Sign in"
      style={{
        minHeight: '100vh',
        background:
          'linear-gradient(135deg,var(--orange-50) 0%,var(--blush-50) 40%,var(--lilac-50) 70%,var(--sky-50) 100%)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      <header
        style={{
          maxWidth: '1200px',
          width: '100%',
          margin: '0 auto',
          padding: '0 24px',
          height: '72px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '16px',
          boxSizing: 'border-box',
        }}
      >
        <a href={toUrl('/')} aria-label="ParentCircle home" style={{ display: 'flex' }}>
          <Logo height={28} />
        </a>
        <a
          className="hv-1"
          href={toUrl('/')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            fontSize: '16px',
            fontWeight: '600',
            color: 'var(--text-muted)',
            textDecoration: 'none',
          }}
        >
          <Icon name="arrow-left" size={18} />
          Back to ParentCircle
        </a>
      </header>
      <main
        style={{
          flex: '1',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '24px 16px 64px',
          boxSizing: 'border-box',
        }}
      >
        <div
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            width: '100%',
            maxWidth: '1040px',
            borderRadius: '32px',
            overflow: 'hidden',
            background: 'var(--white)',
            boxShadow: 'var(--shadow-lg)',
          }}
        >
          <aside
            style={{
              position: 'relative',
              overflow: 'hidden',
              flex: '1 1 380px',
              minWidth: '0',
              padding: 'clamp(28px,4vw,48px)',
              boxSizing: 'border-box',
              background: 'linear-gradient(160deg,var(--orange-100) 0%,var(--blush-100) 50%,var(--lilac-100) 100%)',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              gap: '28px',
            }}
          >
            <div style={{ position: 'relative' }}>
              <div
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '8px',
                  height: '34px',
                  padding: '0 14px',
                  borderRadius: '999px',
                  background: 'var(--white)',
                  fontSize: '15px',
                  fontWeight: '700',
                  color: 'var(--orange-700)',
                  marginBottom: '18px',
                }}
              >
                <Icon name="heart" size={16} color="var(--orange-600)" />
                Hello, wonderful parent
              </div>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(30px,3.6vw,42px)',
                  lineHeight: '1.12',
                  letterSpacing: '-0.015em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0 0 12px',
                  textWrap: 'balance',
                }}
              >
                It takes a village to raise a child
              </h2>
              <p
                style={{
                  fontFamily: 'var(--font-serif)',
                  fontSize: '20px',
                  lineHeight: '1.55',
                  color: 'var(--text-body)',
                  margin: '0',
                  textWrap: 'pretty',
                }}
              >
                Sign in to join friendly circles, save stories you love and ask our experts anything.
              </p>
            </div>
            <div style={{ position: 'relative', display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '14px',
                  padding: '14px 16px',
                  borderRadius: '18px',
                  background: 'rgba(255,255,255,.85)',
                }}
              >
                <span
                  style={{
                    width: '44px',
                    height: '44px',
                    flex: 'none',
                    borderRadius: '50%',
                    background: 'var(--sage-700)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="bookmark" size={22} color="var(--sage-50)" />
                </span>
                <span style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                  Save stories for later
                </span>
              </div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '14px',
                  padding: '14px 16px',
                  borderRadius: '18px',
                  background: 'rgba(255,255,255,.85)',
                }}
              >
                <span
                  style={{
                    width: '44px',
                    height: '44px',
                    flex: 'none',
                    borderRadius: '50%',
                    background: 'var(--sky-700)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="users" size={22} color="var(--sky-50)" />
                </span>
                <span style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                  Join circles of parents like you
                </span>
              </div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '14px',
                  padding: '14px 16px',
                  borderRadius: '18px',
                  background: 'rgba(255,255,255,.85)',
                }}
              >
                <span
                  style={{
                    width: '44px',
                    height: '44px',
                    flex: 'none',
                    borderRadius: '50%',
                    background: 'var(--blush-700)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="stethoscope" size={22} color="var(--blush-50)" />
                </span>
                <span style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                  Ask experts, get real answers
                </span>
              </div>
            </div>
          </aside>
          <div
            role="dialog"
            aria-labelledby="auth-title"
            style={{
              position: 'relative',
              flex: '1 1 420px',
              minWidth: '0',
              background: 'var(--white)',
              padding: 'clamp(28px,5vw,56px)',
              boxSizing: 'border-box',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
            }}
          >
            <div style={{ position: 'absolute', top: '12px', right: '12px' }}>
              <IconButton icon="x" label="Close" onClick={v.close} />
            </div>
            {v.isSignin ? (
              <Fragment>
                <h1
                  id="auth-title"
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '30px',
                    lineHeight: '1.2',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0 0 6px',
                    paddingRight: '40px',
                  }}
                >
                  Welcome to ParentCircle
                </h1>
                <p style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-muted)', margin: '0 0 28px' }}>
                  Sign in to save stories, join circles and ask our experts.
                </p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
                  <Input
                    label="Email or mobile number"
                    icon="user-round"
                    placeholder="you@example.com or 98765 43210"
                    value={v.id}
                    onChange={v.onId}
                    error={v.err?.id}
                  />
                  <Input
                    label="Password"
                    type={v.pwType}
                    icon="lock"
                    value={v.pw}
                    onChange={v.onPw}
                    error={v.err?.pw}
                  />
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '12px',
                      flexWrap: 'wrap',
                      marginTop: '-4px',
                    }}
                  >
                    <label
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '10px',
                        minHeight: '32px',
                        cursor: 'pointer',
                        fontSize: '17px',
                        lineHeight: '1',
                        color: 'var(--text-body)',
                      }}
                    >
                      <input
                        type="checkbox"
                        checked={v.showPw ?? false}
                        onChange={v.onShowPw}
                        style={{
                          width: '22px',
                          height: '22px',
                          margin: '0',
                          flex: 'none',
                          accentColor: 'var(--orange-700)',
                          cursor: 'pointer',
                        }}
                      />
                      Show password
                    </label>
                    <button
                      className="hv-8"
                      type="button"
                      onClick={v.toForgot}
                      style={{
                        border: '0',
                        background: 'none',
                        padding: '8px 0',
                        font: 'inherit',
                        fontSize: '16px',
                        fontWeight: '600',
                        color: 'var(--text-link)',
                        cursor: 'pointer',
                      }}
                    >
                      Forgot password?
                    </button>
                  </div>
                  {v.formError ? (
                    <div
                      role="alert"
                      style={{
                        display: 'flex',
                        gap: '10px',
                        alignItems: 'flex-start',
                        padding: '12px 14px',
                        borderRadius: '12px',
                        background: 'var(--blush-50)',
                        fontSize: '16px',
                        lineHeight: '1.45',
                        color: 'var(--text-strong)',
                      }}
                    >
                      <Icon name="circle-alert" size={20} color="var(--blush-700)" />
                      {v.formError}
                    </div>
                  ) : null}
                  <Button variant="primary" size="lg" fullWidth={true} disabled={v.busy} onClick={v.signIn}>
                    {v.signInLabel}
                  </Button>
                </div>
                <p style={{ fontSize: '17px', color: 'var(--text-body)', margin: '20px 0 0', textAlign: 'center' }}>
                  {'New to ParentCircle? '}
                  <button
                    className="hv-8"
                    type="button"
                    onClick={v.toSignup}
                    style={{
                      border: '0',
                      background: 'none',
                      padding: '4px 2px',
                      font: 'inherit',
                      fontWeight: '700',
                      color: 'var(--text-link)',
                      cursor: 'pointer',
                    }}
                  >
                    Create a free account
                  </button>
                </p>
              </Fragment>
            ) : null}
            {v.isSignup ? (
              <Fragment>
                <h1
                  id="auth-title"
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '30px',
                    lineHeight: '1.2',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0 0 6px',
                    paddingRight: '40px',
                  }}
                >
                  Join ParentCircle
                </h1>
                <p style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-muted)', margin: '0 0 28px' }}>
                  Free for parents and grandparents. It takes less than a minute.
                </p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
                  <Input label="Your name" icon="user-round" value={v.name} onChange={v.onName} error={v.err?.name} />
                  <Input label="Email or mobile number" icon="mail" value={v.id} onChange={v.onId} error={v.err?.id} />
                  <Input
                    label="Create a password"
                    type={v.pwType}
                    icon="lock"
                    helper="At least 6 characters"
                    value={v.pw}
                    onChange={v.onPw}
                    error={v.err?.pw}
                  />
                  <label
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '10px',
                      minHeight: '32px',
                      cursor: 'pointer',
                      fontSize: '17px',
                      lineHeight: '1',
                      color: 'var(--text-body)',
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={v.showPw ?? false}
                      onChange={v.onShowPw}
                      style={{
                        width: '22px',
                        height: '22px',
                        margin: '0',
                        flex: 'none',
                        accentColor: 'var(--orange-700)',
                        cursor: 'pointer',
                      }}
                    />
                    Show password
                  </label>
                  <p style={{ fontSize: '15px', lineHeight: '1.5', color: 'var(--text-muted)', margin: '0' }}>
                    {'By joining, you agree to our '}
                    <a href={toUrl('/terms')}>Terms of use</a>
                    {' and '}
                    <a href={toUrl('/privacy')}>Privacy policy</a>.
                  </p>
                  <Button variant="primary" size="lg" fullWidth={true} disabled={v.busy} onClick={v.signUp}>
                    {v.signUpLabel}
                  </Button>
                </div>
                <p style={{ fontSize: '17px', color: 'var(--text-body)', margin: '20px 0 0', textAlign: 'center' }}>
                  {'Already a member? '}
                  <button
                    className="hv-8"
                    type="button"
                    onClick={v.toSignin}
                    style={{
                      border: '0',
                      background: 'none',
                      padding: '4px 2px',
                      font: 'inherit',
                      fontWeight: '700',
                      color: 'var(--text-link)',
                      cursor: 'pointer',
                    }}
                  >
                    Sign in
                  </button>
                </p>
              </Fragment>
            ) : null}
            {v.isForgot ? (
              <Fragment>
                <button
                  className="hv-s"
                  type="button"
                  onClick={v.toSignin}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    border: '0',
                    background: 'none',
                    padding: '6px 0',
                    margin: '0 0 16px',
                    font: 'inherit',
                    fontSize: '16px',
                    fontWeight: '600',
                    color: 'var(--text-muted)',
                    cursor: 'pointer',
                  }}
                >
                  <Icon name="arrow-left" size={18} />
                  Back to sign in
                </button>
                <h1
                  id="auth-title"
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '30px',
                    lineHeight: '1.2',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0 0 6px',
                    paddingRight: '40px',
                  }}
                >
                  Reset your password
                </h1>
                {v.notSent ? (
                  <Fragment>
                    <p style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-muted)', margin: '0 0 28px' }}>
                      Enter your email or mobile number and we’ll send you a link to set a new password.
                    </p>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
                      <Input
                        label="Email or mobile number"
                        icon="user-round"
                        value={v.id}
                        onChange={v.onId}
                        error={v.err?.id}
                      />
                      <Button variant="primary" size="lg" fullWidth={true} disabled={v.busy} onClick={v.sendReset}>
                        {v.resetLabel}
                      </Button>
                    </div>
                  </Fragment>
                ) : null}
                {v.sent ? (
                  <div
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'flex-start',
                      gap: '14px',
                      marginTop: '12px',
                    }}
                  >
                    <span
                      style={{
                        width: '56px',
                        height: '56px',
                        borderRadius: '50%',
                        background: 'var(--sage-50)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Icon name="mail-check" size={28} color="var(--sage-700)" />
                    </span>
                    <p style={{ fontSize: '18px', lineHeight: '1.55', color: 'var(--text-body)', margin: '0' }}>
                      {'If an account exists for '}
                      <strong style={{ color: 'var(--text-strong)' }}>{v.id}</strong>, you’ll receive a reset link
                      shortly. Check your spam folder too.
                    </p>
                    <Button variant="secondary" fullWidth={true} onClick={v.toSignin}>
                      Back to sign in
                    </Button>
                  </div>
                ) : null}
              </Fragment>
            ) : null}
            {v.isDone ? (
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  textAlign: 'center',
                  gap: '14px',
                  padding: '24px 0 8px',
                }}
              >
                <span
                  style={{
                    width: '64px',
                    height: '64px',
                    borderRadius: '50%',
                    background: 'var(--sage-50)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="circle-check" size={32} color="var(--sage-700)" />
                </span>
                <h1
                  id="auth-title"
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '28px',
                    lineHeight: '1.2',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0',
                  }}
                >
                  {v.doneTitle}
                </h1>
                <p style={{ fontSize: '17px', color: 'var(--text-muted)', margin: '0' }}>
                  Taking you to your homepage…
                </p>
              </div>
            ) : null}
            {v.showSocial ? (
              <Fragment>
                <div style={{ display: 'flex', alignItems: 'center', gap: '14px', margin: '28px 0 18px' }}>
                  <span style={{ flex: '1', height: '1px', background: 'var(--border-default)' }}></span>
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Sign in with</span>
                  <span style={{ flex: '1', height: '1px', background: 'var(--border-default)' }}></span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'center', gap: '16px' }}>
                  <button
                    className="hv-l"
                    type="button"
                    aria-label="Sign in with Google"
                    onClick={v.social}
                    style={{
                      width: '56px',
                      height: '56px',
                      borderRadius: '50%',
                      border: '1px solid var(--border-default)',
                      background: 'var(--white)',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      padding: '0',
                      overflow: 'hidden',
                    }}
                  >
                    <img
                      src={toUrl('/images/social/google.png')}
                      alt=""
                      style={{ width: '100%', height: '100%', borderRadius: '50%', display: 'block' }}
                    />
                  </button>
                  <button
                    className="hv-l"
                    type="button"
                    aria-label="Sign in with Facebook"
                    onClick={v.social}
                    style={{
                      width: '56px',
                      height: '56px',
                      borderRadius: '50%',
                      border: '0',
                      background: '#3b5998',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      padding: '0',
                    }}
                  >
                    <img
                      src={toUrl('/images/social/facebook.png')}
                      alt=""
                      style={{ width: '100%', height: '100%', borderRadius: '50%', display: 'block' }}
                    />
                  </button>
                  <button
                    className="hv-l"
                    type="button"
                    aria-label="Sign in with X (Twitter)"
                    onClick={v.social}
                    style={{
                      width: '56px',
                      height: '56px',
                      borderRadius: '50%',
                      border: '0',
                      background: '#55acee',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      padding: '0',
                    }}
                  >
                    <img
                      src={toUrl('/images/social/twitter.png')}
                      alt=""
                      style={{ width: '100%', height: '100%', borderRadius: '50%', display: 'block' }}
                    />
                  </button>
                </div>
              </Fragment>
            ) : null}
          </div>
        </div>
      </main>
    </div>
  );
}
