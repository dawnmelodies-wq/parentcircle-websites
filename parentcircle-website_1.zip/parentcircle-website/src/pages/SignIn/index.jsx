import { createPage } from '../../lib/createPage';
import view from './view';
import Logic from './logic';

const css = `body{margin:0;background:var(--neutral-50);color:var(--text-body);font-family:var(--font-ui)}
a{color:var(--text-link)} a:hover{color:var(--text-link-hover)}
button:focus-visible,a:focus-visible{outline:3px solid var(--orange-300);outline-offset:2px}
@media (prefers-reduced-motion: reduce){*{transition:none!important}}
`;

export default createPage({ name: 'Sign In', css, view, Logic });
