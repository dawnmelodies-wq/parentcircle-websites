import React from 'react';
import { PageLogicBase } from '../../lib/createPage';
import { toUrl, pageLocation } from '../../lib/paths';

class PageLogic extends PageLogicBase {
  state = {
    mode: 'signin',
    id: '',
    pw: '',
    name: '',
    showPw: false,
    err: {},
    formError: '',
    busy: false,
    sent: false,
    done: '',
  };
  componentDidMount() {
    if (pageLocation().hash === '#signup') this.setState({ mode: 'signup' });
  }
  componentWillUnmount() {
    clearTimeout(this.t);
  }
  validId(v) {
    const s = v.replace(/[\s-]/g, '');
    return /^\S+@\S+\.\S+$/.test(s) || /^(\+?91)?[6-9]\d{9}$/.test(s);
  }
  go(mode) {
    this.setState({ mode, err: {}, formError: '', busy: false, sent: false });
  }
  later(fn, ms) {
    clearTimeout(this.t);
    this.t = setTimeout(fn, ms);
  }
  finish(title) {
    try {
      localStorage.setItem('pc-signed-in', '1');
      const n = (this.state.name || '').trim().split(' ')[0];
      if (n) localStorage.setItem('pc-user-name', n);
    } catch (e) {}
    this.setState({ busy: false, done: title, mode: 'done' });
    this.later(() => {
      location.href = toUrl('/');
    }, 1600);
  }
  signIn = () => {
    const S = this.state,
      err = {};
    if (!S.id.trim()) err.id = 'Please enter your email or mobile number.';
    else if (!this.validId(S.id)) err.id = 'That doesn’t look like an email or 10-digit mobile number.';
    if (!S.pw) err.pw = 'Please enter your password.';
    if (Object.keys(err).length) return this.setState({ err, formError: '' });
    this.setState({ busy: true, err: {}, formError: '' });
    this.later(() => this.finish('Welcome back!'), 900);
  };
  signUp = () => {
    const S = this.state,
      err = {};
    if (!S.name.trim()) err.name = 'Please tell us your name.';
    if (!this.validId(S.id)) err.id = 'Please enter a valid email or 10-digit mobile number.';
    if (S.pw.length < 6) err.pw = 'Your password needs at least 6 characters.';
    if (Object.keys(err).length) return this.setState({ err });
    this.setState({ busy: true, err: {} });
    this.later(() => this.finish('Welcome, ' + S.name.trim().split(' ')[0] + '!'), 900);
  };
  sendReset = () => {
    if (!this.validId(this.state.id))
      return this.setState({ err: { id: 'Please enter a valid email or 10-digit mobile number.' } });
    this.setState({ busy: true, err: {} });
    this.later(() => this.setState({ busy: false, sent: true }), 800);
  };
  field = (k) => (e) => {
    const v = e.target.value;
    this.setState((s) => ({ [k]: v, err: { ...s.err, [k === 'pw' ? 'pw' : k]: undefined }, formError: '' }));
  };
  renderVals() {
    const S = this.state,
      m = S.mode;
    return {
      isSignin: m === 'signin',
      isSignup: m === 'signup',
      isForgot: m === 'forgot',
      isDone: m === 'done',
      showSocial: m === 'signin' || m === 'signup',
      id: S.id,
      pw: S.pw,
      name: S.name,
      onId: this.field('id'),
      onPw: this.field('pw'),
      onName: this.field('name'),
      showPw: S.showPw,
      onShowPw: (v) => this.setState({ showPw: typeof v === 'boolean' ? v : !S.showPw }),
      pwType: S.showPw ? 'text' : 'password',
      err: { id: S.err.id, pw: S.err.pw, name: S.err.name },
      formError: S.formError,
      busy: S.busy,
      signInLabel: S.busy ? 'Signing in…' : 'Sign in',
      signUpLabel: S.busy ? 'Creating your account…' : 'Create free account',
      resetLabel: S.busy ? 'Sending…' : 'Send reset link',
      sent: S.sent,
      notSent: !S.sent,
      doneTitle: S.done,
      signIn: this.signIn,
      signUp: this.signUp,
      sendReset: this.sendReset,
      toSignin: () => this.go('signin'),
      toSignup: () => {
        location.href = toUrl('/join');
      },
      toForgot: () => this.go('forgot'),
      social: () => this.finish('Welcome back!'),
      close: () => {
        if (history.length > 1) history.back();
        else location.href = toUrl('/');
      },
    };
  }
}

export default PageLogic;
