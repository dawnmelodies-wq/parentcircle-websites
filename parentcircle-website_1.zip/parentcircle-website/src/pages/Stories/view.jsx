import { Fragment } from 'react';
import { Button, Icon, IconButton, Select } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Stories" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Stories"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader active="read" />
      <main>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '28px 24px 0', boxSizing: 'border-box' }}>
          <nav
            aria-label="Breadcrumb"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              fontSize: '15px',
              color: 'var(--text-muted)',
              marginBottom: '24px',
            }}
          >
            <a
              className="hv-1"
              href={toUrl('/')}
              style={{ color: 'var(--text-muted)', textDecoration: 'none', fontWeight: '600' }}
            >
              Home
            </a>
            <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
            <span>Stories</span>
          </nav>
          <div
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '20px 40px',
              alignItems: 'flex-end',
              justifyContent: 'space-between',
            }}
          >
            <div style={{ flex: '1 1 480px', minWidth: '0' }}>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-700)',
                  marginBottom: '12px',
                }}
              >
                <Icon name="star" size={18} color="var(--orange-700)" />
                Editor’s picks
              </div>
              <h1
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(36px,4.6vw,56px)',
                  lineHeight: '1.08',
                  letterSpacing: '-0.015em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                  textWrap: 'balance',
                }}
              >
                Stories our editors love
              </h1>
              <p
                style={{
                  fontFamily: 'var(--font-serif)',
                  fontSize: '22px',
                  lineHeight: '1.55',
                  color: 'var(--text-body)',
                  margin: '14px 0 0',
                  maxWidth: '600px',
                  textWrap: 'pretty',
                }}
              >
                A handpicked selection of the latest and most-read stories on parenting — for every age and stage.
              </p>
            </div>
            <a href={toUrl('/search?query=')} style={{ textDecoration: 'none' }}>
              <Button variant="secondary" icon="search">
                Search stories
              </Button>
            </a>
          </div>
        </section>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '32px 24px 0', boxSizing: 'border-box' }}>
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
              padding: '28px',
              borderRadius: '24px',
              background: 'var(--neutral-50)',
            }}
          >
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '12px',
                flexWrap: 'wrap',
                marginBottom: '2px',
              }}
            >
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                }}
              >
                Filter stories
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                {v.hasFilters ? (
                  <button
                    className="hv-8"
                    type="button"
                    onClick={v.clearFilters}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px',
                      border: '0',
                      background: 'none',
                      padding: '6px 0',
                      font: 'inherit',
                      fontSize: '15px',
                      fontWeight: '700',
                      color: 'var(--text-link)',
                      cursor: 'pointer',
                    }}
                  >
                    <Icon name="x" size={16} color="currentColor" />
                    Clear filters
                  </button>
                ) : null}
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{v.countLabel}</span>
              </div>
            </div>
            <div style={{ display: 'flex', gap: '10px 16px', flexWrap: 'wrap', alignItems: 'center' }}>
              <span
                style={{
                  flex: 'none',
                  width: '92px',
                  fontSize: '15px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                }}
              >
                Category
              </span>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', flex: '1', minWidth: '0' }}>
                {(v.catChips ?? []).map((c, $i0) => (
                  <Fragment key={$i0}>
                    <button
                      type="button"
                      aria-pressed={c?.on}
                      onClick={c?.toggle}
                      style={{
                        height: '40px',
                        padding: '0 14px',
                        borderRadius: '999px',
                        border: `1.5px solid ${c?.bd ?? ''}`,
                        background: c?.bg,
                        color: c?.fg,
                        font: 'inherit',
                        fontSize: '15px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        transition: 'background 150ms',
                      }}
                    >
                      {c?.label}
                    </button>
                  </Fragment>
                ))}
              </div>
            </div>
            {v.hasSubtopics ? (
              <div style={{ display: 'flex', gap: '10px 16px', flexWrap: 'wrap', alignItems: 'center' }}>
                <span
                  style={{
                    flex: 'none',
                    width: '92px',
                    fontSize: '15px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                  }}
                >
                  Topic
                </span>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', flex: '1', minWidth: '0' }}>
                  {(v.topicChips ?? []).map((t, $i0) => (
                    <Fragment key={$i0}>
                      <button
                        type="button"
                        aria-pressed={t?.on}
                        onClick={t?.toggle}
                        style={{
                          height: '36px',
                          padding: '0 14px',
                          borderRadius: '999px',
                          border: `1.5px solid ${t?.bd ?? ''}`,
                          background: t?.bg,
                          color: t?.fg,
                          font: 'inherit',
                          fontSize: '15px',
                          fontWeight: '600',
                          cursor: 'pointer',
                          transition: 'background 150ms',
                        }}
                      >
                        {t?.label}
                      </button>
                    </Fragment>
                  ))}
                </div>
              </div>
            ) : null}
            <div style={{ display: 'flex', gap: '10px 16px', flexWrap: 'wrap', alignItems: 'center' }}>
              <span
                style={{
                  flex: 'none',
                  width: '92px',
                  fontSize: '15px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                }}
              >
                Age group
              </span>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', flex: '1', minWidth: '0' }}>
                {(v.ageChips ?? []).map((a, $i0) => (
                  <Fragment key={$i0}>
                    <button
                      type="button"
                      aria-pressed={a?.on}
                      onClick={a?.toggle}
                      style={{
                        height: '40px',
                        padding: '0 14px',
                        borderRadius: '999px',
                        border: `1.5px solid ${a?.bd ?? ''}`,
                        background: a?.bg,
                        color: a?.fg,
                        font: 'inherit',
                        fontSize: '15px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        transition: 'background 150ms',
                      }}
                    >
                      {a?.label}
                    </button>
                  </Fragment>
                ))}
              </div>
            </div>
          </div>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: '12px',
              flexWrap: 'wrap',
              paddingTop: '16px',
            }}
          >
            <div style={{ width: '200px', marginLeft: 'auto' }}>
              <Select options={v.sortOptions} value={v.sort} onChange={v.onSort} aria-label="Sort stories" />
            </div>
          </div>
        </section>
        {v.showFeatured ? (
          <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '40px 24px 0', boxSizing: 'border-box' }}>
            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: '24px 40px',
                alignItems: 'center',
                paddingBottom: '48px',
                borderBottom: '1px solid var(--border-subtle)',
              }}
            >
              <div
                className="hv-o"
                style={{
                  flex: '1.3 1 420px',
                  minWidth: '0',
                  position: 'relative',
                  overflow: 'hidden',
                  aspectRatio: '16 / 10',
                  borderRadius: '24px',
                  background: v.lead?.tint,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transition: 'transform 200ms cubic-bezier(.2,0,0,1), box-shadow 200ms cubic-bezier(.2,0,0,1)',
                }}
              >
                <image-slot
                  id={`stories-${v.lead?.slot ?? ''}`}
                  shape="rounded"
                  radius="24"
                  placeholder={v.lead?.photo}
                ></image-slot>
                <span
                  style={{
                    position: 'absolute',
                    top: '16px',
                    left: '16px',
                    zIndex: '1',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px',
                    height: '32px',
                    padding: '0 12px',
                    borderRadius: '999px',
                    background: 'var(--white)',
                    color: 'var(--text-strong)',
                    fontSize: '15px',
                    fontWeight: '700',
                    boxShadow: 'var(--shadow-xs)',
                  }}
                >
                  <Icon name="star" size={16} color="var(--orange-600)" />
                  Featured
                </span>
              </div>
              <div style={{ flex: '1 1 360px', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '14px' }}>
                <span
                  style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: v.lead?.ink,
                  }}
                >
                  {v.lead?.topic}
                </span>
                <a
                  className="hv-5"
                  href={toUrl('/article')}
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(28px,3.2vw,38px)',
                    lineHeight: '1.15',
                    letterSpacing: '-0.01em',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                    textWrap: 'balance',
                  }}
                >
                  {v.lead?.title}
                </a>
                <p
                  style={{
                    fontFamily: 'var(--font-serif)',
                    fontSize: '20px',
                    lineHeight: '1.6',
                    color: 'var(--text-body)',
                    margin: '0',
                    textWrap: 'pretty',
                  }}
                >
                  {v.lead?.dek}
                </p>
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{v.lead?.meta}</span>
                <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginTop: '4px' }}>
                  <a href={toUrl('/article')} style={{ textDecoration: 'none' }}>
                    <Button variant="primary" iconRight="arrow-right">
                      Read story
                    </Button>
                  </a>
                  <Button variant="secondary" icon={v.lead?.saveIcon} onClick={v.lead?.toggleSave}>
                    {v.lead?.saveText}
                  </Button>
                </div>
              </div>
            </div>
            <h2
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(26px,3vw,32px)',
                lineHeight: '1.2',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '40px 0 24px',
              }}
            >
              More editor’s picks
            </h2>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,280px),1fr))',
                gap: '40px 28px',
              }}
            >
              {(v.featured ?? []).map((f, $i0) => (
                <Fragment key={$i0}>
                  <article style={{ display: 'flex', flexDirection: 'column', gap: '10px', minWidth: '0' }}>
                    <div
                      className="hv-o"
                      style={{
                        position: 'relative',
                        overflow: 'hidden',
                        aspectRatio: '16 / 10',
                        borderRadius: '16px',
                        background: f?.tint,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        transition: 'transform 200ms cubic-bezier(.2,0,0,1), box-shadow 200ms cubic-bezier(.2,0,0,1)',
                      }}
                    >
                      <image-slot
                        id={`stories-${f?.slot ?? ''}`}
                        shape="rounded"
                        radius="16"
                        placeholder={f?.photo}
                      ></image-slot>
                      {f?.featured ? (
                        <span
                          style={{
                            position: 'absolute',
                            top: '12px',
                            left: '12px',
                            zIndex: '1',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '4px',
                            height: '28px',
                            padding: '0 10px',
                            borderRadius: '999px',
                            background: 'var(--white)',
                            color: 'var(--text-strong)',
                            fontSize: '14px',
                            fontWeight: '700',
                            boxShadow: 'var(--shadow-xs)',
                          }}
                        >
                          <Icon name="star" size={14} color="var(--orange-600)" />
                          Featured
                        </span>
                      ) : null}
                    </div>
                    <span
                      style={{
                        fontSize: '14px',
                        fontWeight: '700',
                        letterSpacing: '0.08em',
                        textTransform: 'uppercase',
                        color: f?.ink,
                      }}
                    >
                      {f?.topic}
                    </span>
                    <a
                      className="hv-5"
                      href={toUrl('/article')}
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '21px',
                        lineHeight: '1.3',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        textDecoration: 'none',
                        textWrap: 'pretty',
                      }}
                    >
                      {f?.title}
                    </a>
                    <p
                      style={{
                        fontFamily: 'var(--font-serif)',
                        fontSize: '17px',
                        lineHeight: '1.5',
                        color: 'var(--text-body)',
                        margin: '0',
                        display: '-webkit-box',
                        WebkitLineClamp: '3',
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden',
                      }}
                    >
                      {f?.dek}
                    </p>
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: '8px',
                        marginTop: 'auto',
                        paddingTop: '4px',
                      }}
                    >
                      <span style={{ fontSize: '15px', lineHeight: '1.4', color: 'var(--text-muted)' }}>{f?.meta}</span>
                      <IconButton icon={f?.saveIcon} label={f?.saveLabel} onClick={f?.toggleSave} />
                    </div>
                  </article>
                </Fragment>
              ))}
            </div>
          </section>
        ) : null}
        <section style={{ marginTop: '64px', background: 'color-mix(in srgb, var(--sky-50) 45%, #ffffff)' }}>
          <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '56px 24px 64px', boxSizing: 'border-box' }}>
            <h2
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(26px,3vw,32px)',
                lineHeight: '1.2',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 24px',
              }}
            >
              {v.listTitle}
            </h2>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,280px),1fr))',
                gap: '40px 28px',
              }}
            >
              {(v.latest ?? []).map((s, $i0) => (
                <Fragment key={$i0}>
                  <article style={{ display: 'flex', flexDirection: 'column', gap: '10px', minWidth: '0' }}>
                    <div
                      className="hv-o"
                      style={{
                        position: 'relative',
                        overflow: 'hidden',
                        aspectRatio: '16 / 10',
                        borderRadius: '16px',
                        background: s?.tint,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        transition: 'transform 200ms cubic-bezier(.2,0,0,1), box-shadow 200ms cubic-bezier(.2,0,0,1)',
                      }}
                    >
                      <image-slot
                        id={`stories-${s?.slot ?? ''}`}
                        shape="rounded"
                        radius="16"
                        placeholder={s?.photo}
                      ></image-slot>
                      {s?.featured ? (
                        <span
                          style={{
                            position: 'absolute',
                            top: '12px',
                            left: '12px',
                            zIndex: '1',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '4px',
                            height: '28px',
                            padding: '0 10px',
                            borderRadius: '999px',
                            background: 'var(--white)',
                            color: 'var(--text-strong)',
                            fontSize: '14px',
                            fontWeight: '700',
                            boxShadow: 'var(--shadow-xs)',
                          }}
                        >
                          <Icon name="star" size={14} color="var(--orange-600)" />
                          Featured
                        </span>
                      ) : null}
                    </div>
                    <span
                      style={{
                        fontSize: '14px',
                        fontWeight: '700',
                        letterSpacing: '0.08em',
                        textTransform: 'uppercase',
                        color: s?.ink,
                      }}
                    >
                      {s?.topic}
                    </span>
                    <a
                      className="hv-5"
                      href={toUrl('/article')}
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '21px',
                        lineHeight: '1.3',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        textDecoration: 'none',
                        textWrap: 'pretty',
                      }}
                    >
                      {s?.title}
                    </a>
                    <p
                      style={{
                        fontFamily: 'var(--font-serif)',
                        fontSize: '17px',
                        lineHeight: '1.5',
                        color: 'var(--text-body)',
                        margin: '0',
                        display: '-webkit-box',
                        WebkitLineClamp: '3',
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden',
                      }}
                    >
                      {s?.dek}
                    </p>
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: '8px',
                        marginTop: 'auto',
                        paddingTop: '4px',
                      }}
                    >
                      <span style={{ fontSize: '15px', lineHeight: '1.4', color: 'var(--text-muted)' }}>{s?.meta}</span>
                      <IconButton icon={s?.saveIcon} label={s?.saveLabel} onClick={s?.toggleSave} />
                    </div>
                  </article>
                </Fragment>
              ))}
            </div>
            {v.empty ? (
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'flex-start',
                  gap: '14px',
                  padding: '32px',
                  borderRadius: '20px',
                  background: 'var(--white)',
                }}
              >
                <Icon name="search-x" size={28} color="var(--text-muted)" />
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '24px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                  }}
                >
                  No stories match these filters
                </div>
                <p style={{ fontSize: '17px', color: 'var(--text-body)', margin: '0' }}>
                  Try another age or topic — or ask our experts directly.
                </p>
                <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                  <Button variant="dark" icon="x" onClick={v.clearFilters}>
                    Clear filters
                  </Button>
                  <a href={toUrl('/ask-the-expert')} style={{ textDecoration: 'none' }}>
                    <Button variant="secondary" icon="message-circle">
                      Ask an expert
                    </Button>
                  </a>
                </div>
              </div>
            ) : null}
            {v.canMore ? (
              <div style={{ display: 'flex', justifyContent: 'center', paddingTop: '40px' }}>
                <Button variant="secondary" icon="chevron-down" onClick={v.showMore}>
                  Load more stories
                </Button>
              </div>
            ) : null}
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
