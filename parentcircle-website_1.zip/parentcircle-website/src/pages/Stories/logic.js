import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = { cat: 'all', topic: '', ages: [], sort: 'recent', more: false, saved: [] };
  AGES = ['Infant', 'Toddler', 'Pre-schooler', 'Primary', 'Pre-teen', 'Teen', '18+', 'Parent'];
  CATS = {
    Learning: ['sky', ['Academics', 'Building skills', 'Special education', 'Special needs', 'Technology']],
    Lifestyle: ['butter', ['Books', 'Community', 'Environment', 'Family life', 'Gadgets', 'Product reviews']],
    Parenting: [
      'blush',
      [
        'Baby care',
        'Becoming a confident parent',
        'Managing child behaviour',
        'Nurturing families',
        'Pregnancy care',
        'Raising a confident child',
        'Stories',
      ],
    ],
    Wellness: [
      'sage',
      ['Developmental conditions', 'Health and fitness', 'Illnesses', 'Mental health', 'Preventive care'],
    ],
  };
  ICONS = {
    Academics: 'graduation-cap',
    'Building skills': 'puzzle',
    'Health and fitness': 'apple',
    'Mental health': 'brain',
    'Managing child behaviour': 'heart',
    'Becoming a confident parent': 'shield-check',
    'Raising a confident child': 'sparkles',
    'Nurturing families': 'house',
    'Baby care': 'baby',
    'Family life': 'users',
    'Product reviews': 'star',
  };
  LIST = [
    [
      'How to keep your child healthy: 9 simple everyday habits every parent can follow',
      'Good health is built day by day — through sleep, meals, play, hygiene and feelings. Nine practical habits to start with.',
      'Wellness',
      'Health and fitness',
      'Pre-schooler',
      'Pre-teen',
      6,
      14600,
      true,
    ],
    [
      'How to choose the right pre-primary school: a complete guide for parents',
      'What a good pre-primary programme looks like — and a practical checklist for your school visits.',
      'Learning',
      'Academics',
      'Pre-schooler',
      'Parent',
      7,
      2600,
      true,
    ],
    [
      'Child mental health: expert answers to the questions every parent wants to ask',
      'Dr Shelja Sen on emotional well-being, diagnosis, school support and the everyday habits that help children thrive.',
      'Wellness',
      'Mental health',
      'Primary',
      'Teen',
      14,
      18500,
      true,
    ],
    [
      'Why pre-primary education matters: 10 benefits of a strong start',
      'A teacher explains how good early learning builds life skills, friendships and a love of learning.',
      'Learning',
      'Academics',
      'Pre-schooler',
      'Parent',
      3,
      41600,
      true,
    ],
    [
      'Scolding children to discipline them: what parents need to know about harsh words',
      'How harsh words affect children — and calmer ways to set limits that still work.',
      'Parenting',
      'Managing child behaviour',
      'Toddler',
      'Parent',
      7,
      418500,
      true,
    ],
    [
      'Finding parenting strategies that match your child’s unique temperament',
      'Every child reacts to the world differently. How to support their feelings, reduce daily conflict and stay close.',
      'Parenting',
      'Becoming a confident parent',
      'Pre-schooler',
      'Parent',
      7,
      13000,
      true,
    ],
    [
      'Simple ways to strengthen your preschooler’s memory through everyday experiences',
      'Play, routines and storytelling that help little ones remember more — and learn better.',
      'Learning',
      'Building skills',
      'Pre-schooler',
      'Parent',
      6,
      279,
      false,
    ],
    [
      '10 life lessons from Mahatma Gandhi to teach children and parents today',
      'Truth, courage, simplicity and caring for others — and simple ways to talk about them at home.',
      'Parenting',
      'Raising a confident child',
      'Primary',
      'Parent',
      9,
      318,
      false,
    ],
    [
      'Navratri for kids: 9 fascinating facts and traditions about the festival',
      'Why we celebrate, the nine forms of Goddess Durga, and how customs differ across India.',
      'Parenting',
      'Nurturing families',
      'Pre-schooler',
      'Parent',
      6,
      27400,
      false,
    ],
    [
      'Best nuts to boost your child’s health, immunity, brain power and growth',
      'The benefits, safe portions and easy ways to add nuts to everyday meals.',
      'Wellness',
      'Health and fitness',
      'Toddler',
      'Parent',
      7,
      2200,
      false,
    ],
    [
      'How humour in parenting strengthens your bond with your child',
      'Laughter eases stress and encourages cooperation. Simple ways to bring more play into everyday moments.',
      'Parenting',
      'Raising a confident child',
      'Primary',
      'Parent',
      7,
      212,
      false,
    ],
    [
      'Cyberbullying in children: warning signs and how to protect your child online',
      'How to spot the signs, prevent online bullying and support your child with care.',
      'Parenting',
      'Managing child behaviour',
      'Pre-teen',
      'Parent',
      5,
      316,
      false,
    ],
    [
      'Breastfeeding positions and latching tips: a new mother’s guide',
      'A good latch and a comfortable position can make feeds easier for you and your baby.',
      'Parenting',
      'Baby care',
      'Infant',
      'Parent',
      6,
      498,
      false,
    ],
    [
      'How to talk to children about mental health: a guide to open conversations',
      'Everyday moments — and listening without rushing to fix — make it easier for children to ask for help.',
      'Wellness',
      'Mental health',
      'Pre-schooler',
      'Parent',
      8,
      350,
      false,
    ],
    [
      'How to celebrate Diwali as a family and create happy memories for your child',
      'Warm, meaningful ways to share traditions, build bonds and teach life skills this festive season.',
      'Lifestyle',
      'Family life',
      'Toddler',
      'Parent',
      12,
      27600,
      false,
    ],
    [
      'Choosing the right toys for children: a toy designer’s practical guide',
      'What a toy designer learned about matching toys to interests, readiness and real play.',
      'Lifestyle',
      'Product reviews',
      'Pre-schooler',
      'Parent',
      8,
      235,
      false,
    ],
    [
      'Working mother and career: finding a healthy balance between work and family',
      'Handling daily demands, making time for yourself and building a career after motherhood.',
      'Parenting',
      'Becoming a confident parent',
      'Parent',
      'Parent',
      4,
      261,
      false,
    ],
    [
      'Physical activity and teen confidence: how sports help teens overcome insecurities',
      'A sportsman shares how finding an activity he loved helped him focus on his strengths.',
      'Wellness',
      'Health and fitness',
      'Primary',
      'Parent',
      8,
      235,
      false,
    ],
  ];
  chip(on) {
    return on
      ? { bg: 'var(--neutral-900)', fg: 'var(--white)', bd: 'var(--neutral-900)' }
      : { bg: 'var(--white)', fg: 'var(--text-strong)', bd: 'var(--border-default)' };
  }
  views(n) {
    return n >= 1000 ? (Math.round(n / 100) / 10).toString().replace(/\.0$/, '') + 'K views' : n + ' views';
  }
  toggleSave(t) {
    this.setState((s) => ({ saved: s.saved.includes(t) ? s.saved.filter((x) => x !== t) : s.saved.concat(t) }));
  }
  shape(r) {
    const [title, dek, cat, topic, a0, a1, min, views, featured] = r;
    const hue = this.CATS[cat][0],
      on = this.state.saved.includes(title);
    const idx = this.LIST.indexOf(r);
    return {
      slot: 's' + idx,
      photo:
        'Photo: ' +
        ([
          'Child brushing teeth beside a parent at the sink',
          'Parent and preschooler visiting a classroom',
          'Child and parent talking quietly on a bench',
          'Preschoolers playing with blocks in class',
          'Parent kneeling to talk calmly with a toddler',
          'Two siblings reacting differently to the same toy',
          'Preschooler matching picture cards with a parent',
          'Grandparent telling a story to a child',
          'Children in festive clothes dancing garba',
          'A small bowl of almonds, cashews and walnuts',
          'Parent and child laughing together at home',
          'Pre-teen looking worried at a phone screen',
          'Mother feeding her newborn in a quiet room',
          'Parent listening to a child at the dinner table',
          'Family lighting diyas together on Diwali',
          'Child choosing wooden toys from a shelf',
          'Mother working on a laptop with her child nearby',
          'Teen playing football with friends',
        ][idx] || title),
      title,
      dek,
      topic,
      featured,
      tint: 'var(--' + hue + '-50)',
      ink: 'var(--' + hue + '-700)',
      icon: this.ICONS[topic] || 'book-open',
      meta: (a0 === a1 ? a0 : a0 + ' to ' + a1) + ' · ' + min + ' min read · ' + this.views(views),
      saveIcon: on ? 'bookmark-check' : 'bookmark',
      saveLabel: on ? 'Saved' : 'Save story',
      saveText: on ? 'Saved' : 'Save',
      toggleSave: () => this.toggleSave(title),
    };
  }
  renderVals() {
    const S = this.state;
    const span = (a0, a1) => this.AGES.slice(this.AGES.indexOf(a0), this.AGES.indexOf(a1) + 1);
    let rows = this.LIST.map((r, i) => ({ r, i })).filter(
      ({ r }) =>
        (S.cat === 'all' || r[2] === S.cat) &&
        (!S.topic || r[3] === S.topic) &&
        (!S.ages.length || span(r[4], r[5]).some((a) => S.ages.includes(a))),
    );
    if (S.sort === 'popular') rows = rows.slice().sort((a, b) => b.r[7] - a.r[7]);
    const nf = (S.cat !== 'all' ? 1 : 0) + (S.topic ? 1 : 0) + S.ages.length;
    const showFeatured = nf === 0 && S.sort === 'recent';
    const feat = this.LIST.filter((r) => r[8]);
    const list = showFeatured ? rows.filter(({ r }) => !r[8]) : rows;
    const lim = S.more ? list : list.slice(0, 8);
    const subs = S.cat !== 'all' ? this.CATS[S.cat][1] : [];
    return {
      catChips: ['all']
        .concat(Object.keys(this.CATS))
        .map((c) => ({
          label: c === 'all' ? 'All' : c,
          on: S.cat === c,
          toggle: () => this.setState({ cat: c, topic: '', more: false }),
          ...this.chip(S.cat === c),
        })),
      hasSubtopics: subs.length > 0,
      topicChips: subs.map((t) => ({
        label: t,
        on: S.topic === t,
        toggle: () => this.setState({ topic: S.topic === t ? '' : t, more: false }),
        ...this.chip(S.topic === t),
      })),
      ageChips: this.AGES.map((a) => ({
        label: a,
        on: S.ages.includes(a),
        toggle: () =>
          this.setState((s) => ({
            ages: s.ages.includes(a) ? s.ages.filter((x) => x !== a) : s.ages.concat(a),
            more: false,
          })),
        ...this.chip(S.ages.includes(a)),
      })),
      countLabel: rows.length === 1 ? '1 story' : rows.length + ' stories',
      hasFilters: nf > 0,
      clearFilters: () => this.setState({ cat: 'all', topic: '', ages: [], more: false }),
      sortOptions: [
        { value: 'recent', label: 'Most recent' },
        { value: 'popular', label: 'Most read' },
      ],
      sort: S.sort,
      onSort: (e) => this.setState({ sort: e.target.value, more: false }),
      showFeatured,
      lead: this.shape(feat[0]),
      featured: feat.slice(1).map((r) => this.shape(r)),
      listTitle: showFeatured
        ? 'Latest stories'
        : S.sort === 'popular' && nf === 0
          ? 'Most-read stories'
          : 'Stories for you',
      latest: lim.map(({ r }) => ({ ...this.shape(r), tint: 'var(--white)' })),
      empty: rows.length === 0,
      canMore: !S.more && list.length > 8,
      showMore: () => this.setState({ more: true }),
    };
  }
}

export default PageLogic;
