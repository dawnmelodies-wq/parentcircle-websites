import { Fragment } from 'react';
import { Button, Icon, Input } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Community Help" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      id="top"
      data-screen-label="Community help"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader active="community" />
      <main>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '32px 24px 0', boxSizing: 'border-box' }}>
          <nav aria-label="Company" style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '48px' }}>
            <a
              className="hv-0"
              href={toUrl('/about')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              About us
            </a>
            <a
              className="hv-0"
              href={toUrl('/press')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Press releases
            </a>
            <a
              className="hv-0"
              href={toUrl('/guidelines')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Community guidelines
            </a>
            <a
              href={toUrl('/community-help')}
              aria-current="page"
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                background: 'var(--neutral-900)',
                color: 'var(--text-inverse)',
                fontSize: '16px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Community help
            </a>
            <a
              className="hv-0"
              href={toUrl('/terms')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Terms of use
            </a>
            <a
              className="hv-0"
              href={toUrl('/privacy')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Privacy policy
            </a>
            <a
              className="hv-0"
              href={toUrl('/contact')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Contact us
            </a>
          </nav>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '24px 56px', alignItems: 'flex-end' }}>
            <div style={{ flex: '1 1 460px', minWidth: '0' }}>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-700)',
                  marginBottom: '12px',
                }}
              >
                Community help
              </div>
              <h1
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(38px,5vw,60px)',
                  lineHeight: '1.08',
                  letterSpacing: '-0.015em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                  textWrap: 'balance',
                }}
              >
                How can we help?
              </h1>
              <p
                style={{
                  fontFamily: 'var(--font-serif)',
                  fontSize: '22px',
                  lineHeight: '1.55',
                  color: 'var(--text-body)',
                  margin: '18px 0 0',
                  maxWidth: '560px',
                  textWrap: 'pretty',
                }}
              >
                Quick answers about taking part in circles, managing your posts and looking after your account.
              </p>
            </div>
            <div data-help-search="" role="search" style={{ flex: '1 1 340px', minWidth: '0', maxWidth: '460px' }}>
              <Input
                label="Search help"
                icon="search"
                placeholder="e.g. username, delete, report"
                value={v.q}
                onChange={v.onQ}
              />
            </div>
          </div>
          <div
            style={{
              marginTop: '36px',
              position: 'relative',
              aspectRatio: '21 / 8',
              borderRadius: '24px',
              overflow: 'hidden',
              background: 'var(--sage-50)',
            }}
          >
            <image-slot
              id="help-hero"
              shape="rounded"
              radius="24"
              placeholder="Photo: parents and grandparents chatting together at a ParentCircle meetup"
            ></image-slot>
          </div>
        </section>
        {v.notSearching ? (
          <section style={{ marginTop: '56px', background: 'var(--sage-50)' }}>
            <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '56px 24px', boxSizing: 'border-box' }}>
              <div
                style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '16px 40px',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  marginBottom: '28px',
                }}
              >
                <div style={{ flex: '1 1 420px', minWidth: '0' }}>
                  <div
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--sage-700)',
                      marginBottom: '10px',
                    }}
                  >
                    Getting started
                  </div>
                  <h2
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: 'clamp(28px,3vw,36px)',
                      lineHeight: '1.2',
                      letterSpacing: '-0.01em',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      margin: '0 0 8px',
                    }}
                  >
                    How to take part in a circle
                  </h2>
                  <p style={{ fontSize: '18px', lineHeight: '1.55', color: 'var(--text-body)', margin: '0' }}>
                    Circles are small groups of parents who share an interest. Sign in, open our circles and choose one
                    that fits your family.
                  </p>
                </div>
                <a href={toUrl('/communities')} style={{ textDecoration: 'none' }}>
                  <Button variant="dark" iconRight="arrow-right">
                    Browse circles
                  </Button>
                </a>
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '20px' }}>
                <div
                  style={{
                    flex: '1 1 320px',
                    minWidth: '0',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '18px',
                    padding: '28px',
                    borderRadius: '20px',
                    background: 'var(--white)',
                    boxShadow: 'var(--shadow-sm)',
                  }}
                >
                  <div
                    style={{
                      position: 'relative',
                      aspectRatio: '16 / 9',
                      borderRadius: '16px',
                      overflow: 'hidden',
                      background: 'var(--neutral-50)',
                      margin: '-8px -8px 0',
                    }}
                  >
                    <image-slot
                      id="help-step-new"
                      shape="rounded"
                      radius="16"
                      placeholder="Photo: a mother typing a question on her phone"
                    ></image-slot>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <span
                      style={{
                        width: '48px',
                        height: '48px',
                        flex: 'none',
                        borderRadius: '14px',
                        background: 'var(--orange-50)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Icon name="square-pen" size={24} color="var(--orange-700)" />
                    </span>
                    <h3
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '22px',
                        lineHeight: '1.25',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0',
                      }}
                    >
                      Ask or share something new
                    </h3>
                  </div>
                  <ol
                    style={{
                      listStyle: 'none',
                      margin: '0',
                      padding: '0',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '14px',
                    }}
                  >
                    <li style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                      <span
                        style={{
                          width: '32px',
                          height: '32px',
                          flex: 'none',
                          borderRadius: '50%',
                          background: 'var(--neutral-900)',
                          color: 'var(--white)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '15px',
                          fontWeight: '700',
                        }}
                      >
                        1
                      </span>
                      <span
                        style={{ fontSize: '17px', lineHeight: '1.55', color: 'var(--text-body)', paddingTop: '3px' }}
                      >
                        {'Choose a topic in the circle and tap '}
                        <strong style={{ color: 'var(--text-strong)' }}>New discussion</strong>.
                      </span>
                    </li>
                    <li style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                      <span
                        style={{
                          width: '32px',
                          height: '32px',
                          flex: 'none',
                          borderRadius: '50%',
                          background: 'var(--neutral-900)',
                          color: 'var(--white)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '15px',
                          fontWeight: '700',
                        }}
                      >
                        2
                      </span>
                      <span
                        style={{ fontSize: '17px', lineHeight: '1.55', color: 'var(--text-body)', paddingTop: '3px' }}
                      >
                        Give it a clear title that sums up what you want to ask or share — it’s the best way to get
                        replies from other parents.
                      </span>
                    </li>
                    <li style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                      <span
                        style={{
                          width: '32px',
                          height: '32px',
                          flex: 'none',
                          borderRadius: '50%',
                          background: 'var(--neutral-900)',
                          color: 'var(--white)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '15px',
                          fontWeight: '700',
                        }}
                      >
                        3
                      </span>
                      <span
                        style={{ fontSize: '17px', lineHeight: '1.55', color: 'var(--text-body)', paddingTop: '3px' }}
                      >
                        {'Tap '}
                        <strong style={{ color: 'var(--text-strong)' }}>Post discussion</strong>, and you’re done.
                      </span>
                    </li>
                  </ol>
                </div>
                <div
                  style={{
                    flex: '1 1 320px',
                    minWidth: '0',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '18px',
                    padding: '28px',
                    borderRadius: '20px',
                    background: 'var(--white)',
                    boxShadow: 'var(--shadow-sm)',
                  }}
                >
                  <div
                    style={{
                      position: 'relative',
                      aspectRatio: '16 / 9',
                      borderRadius: '16px',
                      overflow: 'hidden',
                      background: 'var(--neutral-50)',
                      margin: '-8px -8px 0',
                    }}
                  >
                    <image-slot
                      id="help-step-reply"
                      shape="rounded"
                      radius="16"
                      placeholder="Photo: two parents reading replies together on a tablet"
                    ></image-slot>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <span
                      style={{
                        width: '48px',
                        height: '48px',
                        flex: 'none',
                        borderRadius: '14px',
                        background: 'var(--sky-50)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Icon name="message-circle" size={24} color="var(--sky-700)" />
                    </span>
                    <h3
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '22px',
                        lineHeight: '1.25',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0',
                      }}
                    >
                      Reply to a discussion
                    </h3>
                  </div>
                  <ol
                    style={{
                      listStyle: 'none',
                      margin: '0',
                      padding: '0',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '14px',
                    }}
                  >
                    <li style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                      <span
                        style={{
                          width: '32px',
                          height: '32px',
                          flex: 'none',
                          borderRadius: '50%',
                          background: 'var(--neutral-900)',
                          color: 'var(--white)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '15px',
                          fontWeight: '700',
                        }}
                      >
                        1
                      </span>
                      <span
                        style={{ fontSize: '17px', lineHeight: '1.55', color: 'var(--text-body)', paddingTop: '3px' }}
                      >
                        Open the discussion you’d like to join.
                      </span>
                    </li>
                    <li style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                      <span
                        style={{
                          width: '32px',
                          height: '32px',
                          flex: 'none',
                          borderRadius: '50%',
                          background: 'var(--neutral-900)',
                          color: 'var(--white)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '15px',
                          fontWeight: '700',
                        }}
                      >
                        2
                      </span>
                      <span
                        style={{ fontSize: '17px', lineHeight: '1.55', color: 'var(--text-body)', paddingTop: '3px' }}
                      >
                        {'Write your thoughts in the '}
                        <strong style={{ color: 'var(--text-strong)' }}>Comment</strong>
                        {' box.'}
                      </span>
                    </li>
                    <li style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                      <span
                        style={{
                          width: '32px',
                          height: '32px',
                          flex: 'none',
                          borderRadius: '50%',
                          background: 'var(--neutral-900)',
                          color: 'var(--white)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '15px',
                          fontWeight: '700',
                        }}
                      >
                        3
                      </span>
                      <span
                        style={{ fontSize: '17px', lineHeight: '1.55', color: 'var(--text-body)', paddingTop: '3px' }}
                      >
                        {'Tap '}
                        <strong style={{ color: 'var(--text-strong)' }}>Send</strong>.
                      </span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </section>
        ) : null}
        <section style={{ maxWidth: '860px', margin: '0 auto', padding: '64px 24px 0', boxSizing: 'border-box' }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'baseline',
              justifyContent: 'space-between',
              gap: '12px',
              flexWrap: 'wrap',
              marginBottom: '8px',
            }}
          >
            <h2
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(28px,3vw,36px)',
                lineHeight: '1.2',
                letterSpacing: '-0.01em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0',
              }}
            >
              {v.faqTitle}
            </h2>
            <button
              className="hv-8"
              type="button"
              onClick={v.toggleAll}
              style={{
                border: '0',
                background: 'none',
                padding: '8px 0',
                font: 'inherit',
                fontSize: '16px',
                fontWeight: '700',
                color: 'var(--text-link)',
                cursor: 'pointer',
              }}
            >
              {v.toggleAllLabel}
            </button>
          </div>
          {(v.groups ?? []).map((g, $i0) => (
            <Fragment key={$i0}>
              <div style={{ paddingTop: '48px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '14px' }}>
                  <Icon name={g?.icon} size={20} color={g?.ink} />
                  <h3
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: g?.ink,
                      margin: '0',
                    }}
                  >
                    {g?.title}
                  </h3>
                </div>
                <div style={{ borderTop: '1px solid var(--border-default)' }}>
                  {(g?.items ?? []).map((it, $i1) => (
                    <Fragment key={$i1}>
                      <div style={{ borderBottom: '1px solid var(--border-default)' }}>
                        <button
                          type="button"
                          aria-expanded={it?.open}
                          onClick={it?.toggle}
                          style={{
                            width: '100%',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            gap: '16px',
                            minHeight: '64px',
                            padding: '16px 0',
                            background: 'none',
                            border: '0',
                            cursor: 'pointer',
                            textAlign: 'left',
                            fontFamily: 'var(--font-ui)',
                            fontSize: '19px',
                            fontWeight: '600',
                            color: 'var(--text-strong)',
                          }}
                        >
                          <span>{it?.q}</span>
                          <span
                            style={{
                              flex: 'none',
                              width: '40px',
                              height: '40px',
                              borderRadius: '50%',
                              background: 'var(--neutral-100)',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              transform: it?.rot,
                              transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
                            }}
                          >
                            <Icon name="chevron-down" size={20} />
                          </span>
                        </button>
                        {it?.open ? (
                          <div
                            style={{
                              display: 'flex',
                              flexDirection: 'column',
                              alignItems: 'flex-start',
                              gap: '14px',
                              padding: '0 56px 20px 0',
                            }}
                          >
                            <p
                              style={{
                                fontFamily: 'var(--font-serif)',
                                fontSize: '19px',
                                lineHeight: '1.6',
                                color: 'var(--text-body)',
                                margin: '0',
                                textWrap: 'pretty',
                              }}
                            >
                              {it?.a}
                            </p>
                            {it?.isEmail ? (
                              <a href="mailto:community@parentcircle.in" style={{ textDecoration: 'none' }}>
                                <Button variant="secondary" size="sm" icon="mail">
                                  community@parentcircle.in
                                </Button>
                              </a>
                            ) : null}
                            {it?.isGuide ? (
                              <a href={toUrl('/guidelines')} style={{ textDecoration: 'none' }}>
                                <Button variant="secondary" size="sm" iconRight="arrow-right" onClick={v.goGuidelines}>
                                  Read the guidelines
                                </Button>
                              </a>
                            ) : null}
                          </div>
                        ) : null}
                      </div>
                    </Fragment>
                  ))}
                </div>
              </div>
            </Fragment>
          ))}
          {v.noMatch ? (
            <div
              style={{
                marginTop: '24px',
                padding: '24px',
                borderRadius: '16px',
                background: 'var(--neutral-50)',
                display: 'flex',
                gap: '14px',
                alignItems: 'flex-start',
              }}
            >
              <Icon name="search-x" size={24} color="var(--text-muted)" />
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <span style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                  No help topics match your search.
                </span>
                <span style={{ fontSize: '16px', color: 'var(--text-body)' }}>
                  Try a different word, or email us below — we’re happy to help.
                </span>
              </div>
            </div>
          ) : null}
        </section>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '80px 24px 0', boxSizing: 'border-box' }}>
          <div
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '24px 40px',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: 'clamp(28px,4vw,48px)',
              borderRadius: '24px',
              background: 'var(--orange-50)',
            }}
          >
            <div
              style={{
                flex: 'none',
                width: '96px',
                height: '96px',
                borderRadius: '50%',
                background: 'var(--orange-700)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="message-circle-heart" size={44} color="var(--orange-50)" />
            </div>
            <div style={{ flex: '1 1 420px', minWidth: '0' }}>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(26px,3vw,34px)',
                  lineHeight: '1.2',
                  letterSpacing: '-0.01em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0 0 8px',
                }}
              >
                Still have a question?
              </h2>
              <p style={{ fontSize: '19px', lineHeight: '1.5', color: 'var(--text-body)', margin: '0' }}>
                No worries — email our community team and we’ll be happy to help.
              </p>
            </div>
            <a href="mailto:community@parentcircle.in" style={{ textDecoration: 'none' }}>
              <Button variant="primary" size="lg" icon="mail">
                Email the community team
              </Button>
            </a>
          </div>
        </section>
      </main>
      <SiteFooter spaced />
    </div>
  );
}
