import React from 'react';
import { PageLogicBase } from '../../lib/createPage';
import { toUrl } from '../../lib/paths';

class PageLogic extends PageLogicBase {
  state = { open: [], q: '' };
  GROUPS = [
    [
      'Your posts',
      'square-pen',
      'orange',
      [
        [
          'I can’t edit my discussion',
          'You can edit a discussion for 24 hours after posting. After that, email our admin with the new text and the reason for the change, and we’ll update it for you.',
          'email',
        ],
        [
          'How do I delete my comment or discussion?',
          'You can’t delete your own posts. If you feel it’s necessary, email us with the reason and we’ll take a look.',
          'email',
        ],
        [
          'How do I report a discussion or comment?',
          'If something needs attention — a discussion under the wrong topic, or a comment that may break our rules — email us and we’ll review it.',
          'email',
        ],
      ],
    ],
    [
      'Your account',
      'user-round',
      'sky',
      [
        ['I want to change my username', 'Email us and we’ll create a new username for you.', 'email'],
        ['I have a new email address', 'Email us your new details and we’ll update your account.', 'email'],
        [
          'I want to delete my account',
          'We’re sorry to see you go. If there’s anything we can do to make you stay, please tell us. If you’d still like to leave, email us and we’ll take care of it for you.',
          'email',
        ],
      ],
    ],
    [
      'Taking part',
      'users',
      'sage',
      [
        [
          'Are there rules for taking part in the community?',
          'Yes. Please read our community guidelines — five simple promises that keep every circle kind and safe.',
          'guide',
        ],
        [
          'Can I send a private message to another parent?',
          'Yes. We have a secure messaging system that lets you message other parents in the community.',
          '',
        ],
      ],
    ],
  ];
  toggle(id) {
    this.setState((s) => ({ open: s.open.includes(id) ? s.open.filter((x) => x !== id) : s.open.concat(id) }));
  }
  renderVals() {
    const S = this.state,
      q = S.q.trim().toLowerCase();
    const groups = this.GROUPS.map(([title, icon, hue, items]) => ({
      title,
      icon,
      ink: 'var(--' + hue + '-700)',
      items: items
        .map(([qq, a, cta]) => ({ id: qq, q: qq, a, cta }))
        .filter((it) => !q || (it.q + ' ' + it.a).toLowerCase().includes(q))
        .map((it) => {
          const open = !!q || S.open.includes(it.id);
          return {
            q: it.q,
            a: it.a,
            open,
            isEmail: it.cta === 'email',
            isGuide: it.cta === 'guide',
            rot: open ? 'rotate(180deg)' : 'none',
            toggle: () => this.toggle(it.id),
          };
        }),
    })).filter((g) => g.items.length);
    const n = groups.reduce((t, g) => t + g.items.length, 0);
    const allIds = this.GROUPS.flatMap((g) => g[3].map((i) => i[0]));
    const allOpen = S.open.length === allIds.length;
    return {
      q: S.q,
      onQ: (e) => this.setState({ q: e.target.value }),
      notSearching: !q,
      faqTitle: q ? (n === 1 ? '1 answer' : n + ' answers') : 'Common questions',
      groups,
      noMatch: !!q && n === 0,
      goGuidelines: (e) => {
        if (e) e.preventDefault();
        window.location.href = toUrl('/guidelines');
      },
      toggleAllLabel: allOpen ? 'Collapse all' : 'Expand all',
      toggleAll: () => this.setState({ open: allOpen ? [] : allIds }),
    };
  }
}

export default PageLogic;
