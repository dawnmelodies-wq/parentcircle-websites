import React from 'react';
import { PageLogicBase } from '../../lib/createPage';
import { toUrl } from '../../lib/paths';

class PageLogic extends PageLogicBase {
  state = {
    stage: 'toddler',
    topic: 'all',
    saved: ['a3'],
    lang: null,
    langOpen: false,
    searchOpen: false,
    q: '',
    email: '',
    emailError: '',
    subscribed: false,
    joined: [],
  };

  stageList = [
    { id: 'baby', label: 'Baby', age: '0–1 year', feed: 'For your baby', photo: 'Baby' },
    { id: 'toddler', label: 'Toddler', age: '1–3 years', feed: 'For your toddler', photo: 'Toddler' },
    { id: 'preschool', label: 'Preschooler', age: '3–6 years', feed: 'For your preschooler', photo: 'Preschooler' },
    { id: 'primary', label: 'Primary school', age: '6–10 years', feed: 'For your school-goer', photo: 'School-goer' },
    { id: 'preteen', label: 'Pre-teen', age: '10–13 years', feed: 'For your pre-teen', photo: 'Pre-teen' },
    { id: 'teen', label: 'Teen', age: '13–18 years', feed: 'For your teenager', photo: 'Teen' },
  ];

  topicList = [
    { id: 'all', label: 'For you' },
    { id: 'health', label: 'Health' },
    { id: 'learning', label: 'Learning' },
    { id: 'emotions', label: 'Emotions' },
    { id: 'play', label: 'Activities' },
    { id: 'teens', label: 'Teens & tweens' },
  ];

  articles = [
    {
      id: 'a14',
      topic: 'health',
      category: 'Nutrition',
      stages: ['baby'],
      title: 'Your baby’s first foods: a ragi-to-rice weaning plan',
      dek: 'A paediatric dietitian’s week-by-week guide from 6 months.',
      author: 'Anjali Rao',
      readTime: '7 min read',
    },
    {
      id: 'a2',
      topic: 'health',
      category: 'Nutrition',
      stages: ['toddler', 'preschool'],
      title: '5 iron-rich foods your toddler will actually eat',
      dek: 'Simple swaps for everyday Indian meals — ragi, dates, greens and more.',
      author: 'Anjali Rao',
      readTime: '5 min read',
    },
    {
      id: 'a6',
      topic: 'health',
      category: 'Child health',
      stages: ['baby', 'toddler'],
      title: 'Fever in babies: when to wait and when to call the doctor',
      dek: 'A paediatrician’s clear guide for worried parents and grandparents.',
      author: 'Dr. S. Raman',
      readTime: '6 min read',
    },
    {
      id: 'a12',
      topic: 'emotions',
      category: 'Behaviour',
      stages: ['toddler'],
      title: 'Biting, hitting, throwing: what your toddler is trying to tell you',
      dek: 'Most of it is communication, not bad behaviour. Here’s how to respond.',
      author: 'Dr. Meera Iyer',
      readTime: '6 min read',
    },
    {
      id: 'a7',
      topic: 'learning',
      category: 'Sleep',
      stages: ['baby', 'toddler'],
      title: 'Night waking at 9 months: is it a sleep regression?',
      dek: 'What’s normal, what helps, and when to talk to your doctor.',
      author: 'Dr. Kavitha Rao',
      readTime: '5 min read',
    },
    {
      id: 'a5',
      topic: 'play',
      category: 'Activities',
      stages: ['toddler', 'preschool', 'primary'],
      title: '10 rainy-day games using things already in your kitchen',
      dek: 'No screens, no shopping, plenty of laughter.',
      author: 'Priya Nair',
      readTime: '4 min read',
    },
    {
      id: 'a3',
      topic: 'learning',
      category: 'School & learning',
      stages: ['preschool', 'primary'],
      title: 'Is my child ready for Class 1? A gentle checklist',
      dek: 'It’s less about reading early and more about these six everyday skills.',
      author: 'Lakshmi Venkat',
      readTime: '8 min read',
    },
    {
      id: 'a13',
      topic: 'play',
      category: 'Activities',
      stages: ['preschool'],
      title: 'Little hands, big skills: 6 fine-motor games for 3-year-olds',
      dek: 'Rangoli dots, peeling peas and other everyday play that builds pencil grip.',
      author: 'Priya Nair',
      readTime: '5 min read',
    },
    {
      id: 'a8',
      topic: 'emotions',
      category: 'Emotional wellness',
      stages: ['preschool', 'primary', 'preteen'],
      title: 'When your child says “I hate you” — what to say next',
      dek: 'It stings. A child psychologist on staying calm and reconnecting.',
      author: 'Dr. Meera Iyer',
      readTime: '6 min read',
    },
    {
      id: 'a15',
      topic: 'learning',
      category: 'School & learning',
      stages: ['primary'],
      title: 'Homework without tears: a 20-minute routine that works',
      dek: 'Fewer reminders, more independence — tested by families in Chennai.',
      author: 'Lakshmi Venkat',
      readTime: '6 min read',
    },
    {
      id: 'a9',
      topic: 'emotions',
      category: 'Relationships',
      stages: ['baby', 'toddler', 'preschool', 'primary', 'preteen', 'teen'],
      title: 'Parents and grandparents disagree on discipline? Try this middle path',
      dek: 'Three conversations that help the whole family stay on the same side.',
      author: 'Ravi Kumar',
      readTime: '7 min read',
    },
    {
      id: 'a4',
      topic: 'teens',
      category: 'Teens',
      stages: ['preteen', 'teen'],
      title: 'Talking to your teenager about screen time — without a fight',
      dek: 'Make an agreement together instead of laying down rules.',
      author: 'Ravi Kumar',
      readTime: '7 min read',
    },
    {
      id: 'a10',
      topic: 'teens',
      category: 'Digital life',
      stages: ['preteen', 'teen'],
      title: 'Your child’s first phone: a family agreement you can print',
      dek: 'What to agree on before you hand it over — in plain words.',
      author: 'Sneha Pillai',
      readTime: '5 min read',
    },
    {
      id: 'a11',
      topic: 'learning',
      category: 'Exams',
      stages: ['teen'],
      title: 'Board exam stress: how to help without adding pressure',
      dek: 'What to say, what to skip, and how to spot when your teen needs more support.',
      author: 'Dr. Arvind Shankar',
      readTime: '8 min read',
    },
  ];

  circleList = [
    { id: 'toddler', name: 'Toddler Parents', members: '12,400 parents' },
    { id: 'grand', name: 'Grandparents Corner', members: '3,100 members' },
    { id: 'teen', name: 'Parents of Teens', members: '8,700 parents' },
  ];

  noop = () => {
    window.location.href = toUrl('/article');
  };
  navIds = ['read', 'watch', 'community', 'programs'];
  componentDidMount() {
    this._spy = () => {
      if (this._raf) return;
      this._raf = requestAnimationFrame(() => {
        this._raf = null;
        let active = 'read';
        for (const id of this.navIds) {
          const el = document.getElementById(id);
          if (el && el.getBoundingClientRect().top < window.innerHeight * 0.35) active = id;
        }
        if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 4) active = 'programs';
        if (active !== this.state.activeNav) this.setState({ activeNav: active });
      });
    };
    window.addEventListener('scroll', this._spy, { passive: true });
    this._spy();
    this.syncLang();
    window.__pcHomeNav = true;
    this._ro = new ResizeObserver(() => this.measureNav());
    const hdr = document.querySelector('header');
    if (hdr) this._ro.observe(hdr);
    this.observeNav();
    setTimeout(this.measureNav, 300);
    setTimeout(this.measureNav, 1500);
    setTimeout(this.measureNav, 3000);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => requestAnimationFrame(this.measureNav));
    if (document.fonts && document.fonts.addEventListener) {
      this._fontsDone = () => this.measureNav();
      document.fonts.addEventListener('loadingdone', this._fontsDone);
    }
    this._docClick = (e) => {
      if (this.state.langOpen && !e.target.closest('[data-lang-menu]')) this.setState({ langOpen: false });
    };
    this._docKey = (e) => {
      if (e.key !== 'Escape') return;
      if (this.state.langOpen) this.setState({ langOpen: false });
      else if (this.state.searchOpen) this.closeSearch();
    };
    document.addEventListener('mousedown', this._docClick);
    document.addEventListener('keydown', this._docKey);
  }
  componentWillUnmount() {
    window.__pcHomeNav = false;
    window.removeEventListener('scroll', this._spy);
    if (this._raf) cancelAnimationFrame(this._raf);
    if (this._mo) this._mo.disconnect();
    if (this._ro) this._ro.disconnect();
    if (this._fontsDone && document.fonts) document.fonts.removeEventListener('loadingdone', this._fontsDone);
    document.removeEventListener('mousedown', this._docClick);
    document.removeEventListener('keydown', this._docKey);
  }
  curLang() {
    return 'en';
  }
  syncLang() {
    const l = this.curLang();
    document.documentElement.lang = l;
    if (!this._tr) {
      if (l !== 'en' && !this._trLoading) {
        this._trLoading = true;
        import('../../lib/tamilStrings.js')
          .then((m) => {
            this._tr = m;
            this.syncLang();
          })
          .catch((e) => console.warn('Tamil strings failed to load', e));
      }
      return;
    }
    this._tr.translate(document.body, l);
    if (l !== 'en' && !this._mo) {
      this._mo = new MutationObserver(() => {
        if (this._moRaf) return;
        this._moRaf = requestAnimationFrame(() => {
          this._moRaf = 0;
          const c = this.curLang();
          if (c !== 'en') this._tr.translate(document.body, c);
        });
      });
      this._mo.observe(document.body, {
        subtree: true,
        childList: true,
        characterData: true,
        attributes: true,
        attributeFilter: ['placeholder', 'aria-label', 'alt', 'title'],
      });
    }
  }
  observeNav = () => {
    const nav = document.querySelector('header nav[data-main-nav]');
    if (!nav || !this._ro || nav === this._obsNav) return;
    this._obsNav = nav;
    this._ro.observe(nav);
    nav.querySelectorAll('a').forEach((a) => this._ro.observe(a));
  };
  measureNav = () => {
    const nav = document.querySelector('header nav[data-main-nav]');
    if (!nav) return;
    nav.style.maxWidth = '';
    const links = [...nav.querySelectorAll('a[href^="#"]')];
    if (!links.length) return;
    const top0 = links[0].getBoundingClientRect().top;
    const vis = links.filter((l) => l.getBoundingClientRect().top <= top0 + 4);
    const hidden = links.filter((l) => !vis.includes(l)).map((l) => l.getAttribute('href').slice(1));
    if (hidden.length)
      nav.style.maxWidth =
        Math.ceil(vis[vis.length - 1].getBoundingClientRect().right - nav.getBoundingClientRect().left) + 'px';
    const cur = (this.state.hiddenNav || []).join(',');
    if (hidden.join(',') !== cur) this.setState({ hiddenNav: hidden });
  };
  componentDidUpdate(pp, ps) {
    this.syncLang();
    if (ps && ps.lang !== this.state.lang)
      requestAnimationFrame(() => {
        this.observeNav();
        this.measureNav();
        setTimeout(this.measureNav, 400);
      });
  }
  clipCard = { style: { overflow: 'hidden', height: '100%', boxSizing: 'border-box' } };

  openSearch = () =>
    this.setState({ searchOpen: true, langOpen: false }, () =>
      setTimeout(() => {
        const i = document.querySelector('[data-search-panel] input');
        if (i) i.focus();
      }, 40),
    );
  closeSearch = () => this.setState({ searchOpen: false, q: '' });
  popularList = [
    ['Tantrums', 'tantrum'],
    ['Iron-rich foods', 'iron'],
    ['Screen time', 'screen'],
    ['Sleep', 'sleep'],
    ['Homework', 'homework'],
    ['Fever', 'fever'],
    ['Board exams', 'board exam'],
  ];
  hue = {
    health: ['sage', 'apple'],
    learning: ['sky', 'graduation-cap'],
    emotions: ['blush', 'heart'],
    play: ['butter', 'puzzle'],
    teens: ['lilac', 'smartphone'],
  };
  searchVals(lang) {
    const S = this.state,
      q = S.q.trim().toLowerCase();
    const tl = (s) => (this._tr && lang !== 'en' ? this._tr.tr(s, lang) || '' : '').toLowerCase();
    const corpus = [
      {
        id: 'lead',
        topic: 'emotions',
        category: 'Managing behaviour',
        title: 'How and when to respond to your child’s tantrums',
        dek: 'Is it a call for help, or a bid to get their way?',
        author: 'Saakshi Kapoor Kumar',
        readTime: '9 min read',
      },
    ].concat(this.articles);
    const hit = q
      ? corpus.filter((a) =>
          [a.title, a.dek, a.category, a.author].some((x) => x.toLowerCase().includes(q) || tl(x).includes(q)),
        )
      : [];
    return {
      searchOpen: S.searchOpen,
      q: S.q,
      onQ: (e) => this.setState({ q: e.target.value }),
      seeAllHref: '/search?query=' + encodeURIComponent(S.q.trim()),
      submitSearch: (e) => {
        e.preventDefault();
        location.href = toUrl('/search?query=') + encodeURIComponent(S.q.trim());
      },
      toggleSearch: () => (S.searchOpen ? this.closeSearch() : this.openSearch()),
      closeSearch: this.closeSearch,
      searchIcon: S.searchOpen ? 'x' : 'search',
      searchBtnLabel: S.searchOpen ? 'Close search' : 'Search',
      noQuery: !q,
      hasResults: hit.length > 0,
      noResults: !!q && hit.length === 0,
      resultCount: hit.length === 1 ? '1 story' : hit.length + ' stories',
      popular: this.popularList.map(([label, v]) => ({ label, pick: () => this.setState({ q: v }) })),
      results: hit.slice(0, 6).map((a) => {
        const [c, icon] = this.hue[a.topic] || ['neutral', 'book-open'];
        return {
          title: a.title,
          category: a.category,
          readTime: a.readTime,
          icon,
          tint: 'var(--' + c + '-50)',
          ink: 'var(--' + c + '-700)',
        };
      }),
    };
  }

  toggleSave = (id) =>
    this.setState((s) => ({ saved: s.saved.includes(id) ? s.saved.filter((x) => x !== id) : [...s.saved, id] }));
  toggleJoin = (id) =>
    this.setState((s) => ({ joined: s.joined.includes(id) ? s.joined.filter((x) => x !== id) : [...s.joined, id] }));
  onEmail = (e) => this.setState({ email: e.target.value, emailError: '' });
  onSubscribe = () => {
    if (!/\S+@\S+\.\S+/.test(this.state.email))
      this.setState({ emailError: 'Please add your email so we can send the letter.' });
    else this.setState({ subscribed: true });
  };

  renderVals() {
    const S = this.state,
      P = this.props;
    const lang = this.curLang();
    const sv = this.searchVals(lang);
    const grid = (P.feedLayout ?? 'Grid') === 'Grid';
    const stage = this.stageList.find((s) => s.id === S.stage);

    const stages = this.stageList.map((s) => {
      const on = S.stage === s.id;
      return {
        ...s,
        pressed: on ? 'true' : 'false',
        onClick: () => this.setState({ stage: on ? null : s.id }),
        ring: on ? '0 0 0 4px var(--neutral-50), 0 0 0 7px var(--pc-orange)' : '0 0 0 0 transparent',
        bg: on ? 'var(--neutral-900)' : 'transparent',
        fg: on ? 'var(--text-inverse)' : 'var(--text-strong)',
        sub: on ? 'var(--neutral-200)' : 'var(--text-muted)',
      };
    });

    const topics = this.topicList.map((t) => ({
      ...t,
      selected: S.topic === t.id,
      onClick: () => this.setState({ topic: t.id }),
    }));

    const matches = this.articles.filter(
      (a) => (!S.stage || a.stages.includes(S.stage)) && (S.topic === 'all' || a.topic === S.topic),
    );
    const PH = {
      a14: 'Baby tasting ragi porridge from a steel spoon',
      a2: 'Toddler eating a ragi laddoo at the table',
      a6: 'Parent checking a baby’s temperature at home',
      a12: 'Mother calming her toddler after an outburst',
      a7: 'Baby asleep in a cradle at night',
      a5: 'Children playing with steel tumblers and bowls',
      a3: 'Child with a new school bag at the gate',
      a13: 'Small hands threading beads and peeling peas',
      a8: 'Parent hugging a child after an argument',
      a15: 'Child doing homework with a parent nearby',
      a9: 'Grandparents and parents talking with a child',
      a4: 'Teen and father talking on the sofa',
      a10: 'Child holding a first phone with a parent',
      a11: 'Teen studying for board exams at a desk',
    };
    const HUE = { health: 'sage', learning: 'sky', emotions: 'blush', play: 'butter', teens: 'lilac' };
    const feed = matches.slice(0, 6).map((a) => ({
      id: a.id,
      photo: 'Photo: ' + (PH[a.id] || a.title),
      tint: 'var(--' + (HUE[a.topic] || 'neutral') + '-50)',
      ink: 'var(--' + (HUE[a.topic] || 'neutral') + '-700)',
      meta: a.author + ' · ' + a.readTime,
      saveIcon: S.saved.includes(a.id) ? 'bookmark-check' : 'bookmark',
      saveLabel: S.saved.includes(a.id) ? 'Saved' : 'Save story',
      card: {
        title: a.title,
        dek: a.dek,
        category: a.category,
        topic: a.topic,
        author: a.author,
        readTime: a.readTime,
        saved: S.saved.includes(a.id),
        onSave: () => this.toggleSave(a.id),
        onClick: this.noop,
      },
    }));
    const n = matches.length;

    const circles = this.circleList.map((c) => {
      const on = S.joined.includes(c.id);
      return {
        ...c,
        btn: on ? 'Joined' : 'Join',
        variant: on ? 'ghost' : 'secondary',
        icon: on ? 'check' : undefined,
        onClick: () => this.toggleJoin(c.id),
      };
    });

    const act = S.activeNav || 'read';
    const nav = Object.fromEntries(
      this.navIds.map((id) => [
        id,
        {
          bg: act === id ? 'var(--neutral-100)' : 'transparent',
          fg: act === id ? 'var(--text-strong)' : 'var(--text-muted)',
          current: act === id ? 'true' : undefined,
        },
      ]),
    );
    return {
      ...sv,
      goTop: (e) => {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: 'smooth' });
        document.documentElement.scrollTop = 0;
        document.body.scrollTop = 0;
      },
      goLink: (e) => {
        const href = e.currentTarget && e.currentTarget.getAttribute('href');
        if (href) {
          e.preventDefault();
          window.location.href = href;
        }
      },
      hiddenNav: (S.hiddenNav || []).map((id) => ({
        href: '#' + id,
        label: { read: 'Read', watch: 'Watch', community: 'Community', programs: 'Programs' }[id] || id,
        icon:
          { read: 'book-open', watch: 'circle-play', community: 'users', programs: 'graduation-cap' }[id] || 'circle',
      })),
      hasHiddenNav: (S.hiddenNav || []).length > 0,
      nav,
      isEn: lang !== 'ta',
      isTa: lang === 'ta',
      langLabel: { en: 'English', ta: 'தமிழ்', hi: 'हिन्दी' }[lang],
      langOpen: S.langOpen,
      toggleLang: () => this.setState((s) => ({ langOpen: !s.langOpen })),
      langOptions: [
        ['en', 'English', 'English'],
        ['ta', 'தமிழ்', 'Tamil'],
        ['hi', 'हिन्दी', 'Hindi'],
      ].map(([v, native, english]) => ({
        native,
        english,
        on: v === lang,
        bg: v === lang ? 'var(--orange-50)' : 'transparent',
        pick: () => {
          try {
            localStorage.setItem('pc-lang', v);
          } catch (e) {}
          this.setState({ lang: v, langOpen: false });
        },
      })),
      stages,
      topics,
      feed,
      circles,
      feedTitle: stage ? stage.feed : 'Latest for every age',
      feedSub: (n === 1 ? '1 story' : n + ' stories') + (stage ? ' · ' + stage.age : ''),
      showList: !grid && n > 0,
      showGrid: grid && n > 0,
      isEmpty: n === 0,
      showAllAges: () => this.setState({ stage: null, topic: 'all' }),
      email: S.email,
      emailError: S.emailError || undefined,
      onEmail: this.onEmail,
      onSubscribe: this.onSubscribe,
      subscribed: S.subscribed,
      notSubscribed: !S.subscribed,
      clipCard: this.clipCard,
    };
  }
}

export default PageLogic;
