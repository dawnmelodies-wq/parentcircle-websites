import { Fragment } from 'react';
import { Avatar, Badge, Button, Card, Icon, IconButton, Input, Logo, Tag } from '../../components/ds';
import { toUrl } from '../../lib/paths';

/** Markup for the "Home v2" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Home v2"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <header
        style={{
          position: 'sticky',
          top: '0',
          zIndex: '20',
          background: 'rgba(255,255,255,0.94)',
          backdropFilter: 'blur(8px)',
          WebkitBackdropFilter: 'blur(8px)',
          borderBottom: '1px solid var(--border-default)',
        }}
      >
        <div
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '0 24px',
            height: '72px',
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
          }}
        >
          <a href="#read" aria-label="ParentCircle home" style={{ flex: 'none', display: 'flex', marginRight: '20px' }}>
            <Logo height={28} />
          </a>
          {v.isEn ? (
            <Fragment>
              <nav
                aria-label="Main"
                data-main-nav=""
                style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  height: '44px',
                  gap: '4px',
                  flex: '0 1 auto',
                  minWidth: '0',
                  overflow: 'hidden',
                }}
              >
                <a
                  className="hv-3"
                  href="#read"
                  aria-current={v.nav?.read?.current}
                  style={{
                    height: '44px',
                    padding: '0 12px',
                    borderRadius: '999px',
                    background: v.nav?.read?.bg,
                    color: v.nav?.read?.fg,
                    transition: 'background 200ms cubic-bezier(.2,0,0,1), color 200ms cubic-bezier(.2,0,0,1)',
                    fontSize: '17px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    textDecoration: 'none',
                    whiteSpace: 'nowrap',
                  }}
                >
                  Read
                </a>
                <a
                  className="hv-3"
                  href="#watch"
                  aria-current={v.nav?.watch?.current}
                  style={{
                    height: '44px',
                    padding: '0 12px',
                    borderRadius: '999px',
                    background: v.nav?.watch?.bg,
                    color: v.nav?.watch?.fg,
                    transition: 'background 200ms cubic-bezier(.2,0,0,1), color 200ms cubic-bezier(.2,0,0,1)',
                    fontSize: '17px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    textDecoration: 'none',
                    whiteSpace: 'nowrap',
                  }}
                >
                  Watch
                </a>
                <a
                  className="hv-3"
                  href="#community"
                  aria-current={v.nav?.community?.current}
                  style={{
                    height: '44px',
                    padding: '0 12px',
                    borderRadius: '999px',
                    background: v.nav?.community?.bg,
                    color: v.nav?.community?.fg,
                    transition: 'background 200ms cubic-bezier(.2,0,0,1), color 200ms cubic-bezier(.2,0,0,1)',
                    fontSize: '17px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    textDecoration: 'none',
                    whiteSpace: 'nowrap',
                  }}
                >
                  Community
                </a>
                <a
                  className="hv-3"
                  href="#programs"
                  aria-current={v.nav?.programs?.current}
                  style={{
                    height: '44px',
                    padding: '0 12px',
                    borderRadius: '999px',
                    background: v.nav?.programs?.bg,
                    color: v.nav?.programs?.fg,
                    transition: 'background 200ms cubic-bezier(.2,0,0,1), color 200ms cubic-bezier(.2,0,0,1)',
                    fontSize: '17px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    textDecoration: 'none',
                    whiteSpace: 'nowrap',
                  }}
                >
                  Programs
                </a>
              </nav>
              <details data-more-menu="" style={{ position: 'static', flex: 'none', marginLeft: '-8px' }}>
                <summary
                  className="hv-3"
                  style={{
                    height: '44px',
                    padding: '0 10px 0 12px',
                    borderRadius: '999px',
                    color: 'var(--text-muted)',
                    fontSize: '17px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px',
                    cursor: 'pointer',
                    listStyle: 'none',
                    whiteSpace: 'nowrap',
                    userSelect: 'none',
                  }}
                >
                  More
                  <Icon name="chevron-down" size={16} />
                </summary>
                <div
                  style={{
                    position: 'absolute',
                    top: 'calc(100% + 8px)',
                    left: '50%',
                    transform: 'translateX(-50%)',
                    zIndex: '40',
                    width: 'min(940px, calc(100% - 32px))',
                    maxHeight: 'calc(100vh - 96px)',
                    overflow: 'auto',
                    padding: '16px',
                    boxSizing: 'border-box',
                    borderRadius: '20px',
                    background: 'var(--white)',
                    border: '1px solid var(--border-default)',
                    boxShadow: 'var(--shadow-lg)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '8px',
                  }}
                >
                  {v.hasHiddenNav ? (
                    <Fragment>
                      <div
                        style={{
                          fontSize: '14px',
                          fontWeight: '700',
                          letterSpacing: '0.08em',
                          textTransform: 'uppercase',
                          color: 'var(--text-muted)',
                          padding: '10px 12px 4px',
                        }}
                      >
                        Sections
                      </div>
                      {(v.hiddenNav ?? []).map((hn, $i0) => (
                        <Fragment key={$i0}>
                          <a
                            className="hv-0"
                            href={toUrl(hn?.href)}
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '12px',
                              minHeight: '44px',
                              padding: '8px 12px',
                              borderRadius: '10px',
                              fontSize: '16px',
                              fontWeight: '600',
                              color: 'var(--text-strong)',
                              textDecoration: 'none',
                            }}
                          >
                            <Icon name={hn?.icon} size={20} color="var(--text-muted)" />
                            {hn?.label}
                          </a>
                        </Fragment>
                      ))}
                      <div style={{ height: '1px', background: 'var(--border-subtle)', margin: '6px 4px' }}></div>
                    </Fragment>
                  ) : null}
                  <div
                    style={{
                      display: 'grid',
                      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,180px),1fr))',
                      gap: '8px 20px',
                    }}
                  >
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                      <div
                        style={{
                          fontSize: '14px',
                          fontWeight: '700',
                          letterSpacing: '0.08em',
                          textTransform: 'uppercase',
                          color: 'var(--text-muted)',
                          padding: '6px 10px 6px',
                        }}
                      >
                        Read
                      </div>
                      <a
                        className="hv-0"
                        href={toUrl('/search?query=')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="compass" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Explore</span>
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/stories')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="book-open" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Stories</span>
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/parents-of-india')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="map-pin" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Parents of India</span>
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/ask-the-expert')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="stethoscope" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Ask an expert</span>
                      </a>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                      <div
                        style={{
                          fontSize: '14px',
                          fontWeight: '700',
                          letterSpacing: '0.08em',
                          textTransform: 'uppercase',
                          color: 'var(--text-muted)',
                          padding: '6px 10px 6px',
                        }}
                      >
                        Community
                      </div>
                      <a
                        className="hv-0"
                        href={toUrl('/communities')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="users" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Community</span>
                        <span
                          style={{
                            height: '22px',
                            padding: '0 8px',
                            borderRadius: '999px',
                            background: 'var(--orange-600)',
                            color: 'var(--white)',
                            fontSize: '14px',
                            fontWeight: '700',
                            display: 'inline-flex',
                            alignItems: 'center',
                          }}
                        >
                          New
                        </span>
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/guidelines')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="shield-check" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Community guidelines</span>
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/community-help')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="life-buoy" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Community help</span>
                      </a>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                      <div
                        style={{
                          fontSize: '14px',
                          fontWeight: '700',
                          letterSpacing: '0.08em',
                          textTransform: 'uppercase',
                          color: 'var(--text-muted)',
                          padding: '6px 10px 6px',
                        }}
                      >
                        Initiatives
                      </div>
                      <a
                        className="hv-0"
                        href="https://www.parentcircle.com/gadget-free-hour/"
                        target="_blank"
                        rel="noopener"
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="hourglass" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Gadget Free Hour</span>
                        <Icon name="arrow-up-right" size={16} color="var(--neutral-400)" />
                      </a>
                      <a
                        className="hv-0"
                        href="https://www.dotlearningcircle.com/"
                        target="_blank"
                        rel="noopener"
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="graduation-cap" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>The Dot Learning Circle</span>
                        <Icon name="arrow-up-right" size={16} color="var(--neutral-400)" />
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/press')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="newspaper" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Press releases</span>
                      </a>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                      <div
                        style={{
                          fontSize: '14px',
                          fontWeight: '700',
                          letterSpacing: '0.08em',
                          textTransform: 'uppercase',
                          color: 'var(--text-muted)',
                          padding: '6px 10px 6px',
                        }}
                      >
                        About
                      </div>
                      <a
                        className="hv-0"
                        href={toUrl('/about')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="info" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>About us</span>
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/privacy')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="lock" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Privacy policy</span>
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/terms')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="file-text" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Terms of use</span>
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/contact')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="mail" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Contact us</span>
                      </a>
                    </div>
                  </div>
                </div>
              </details>
            </Fragment>
          ) : null}
          {v.isTa ? (
            <Fragment>
              <nav
                aria-label="Main"
                data-main-nav=""
                style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  height: '44px',
                  gap: '2px',
                  flex: '0 1 auto',
                  minWidth: '0',
                  overflow: 'hidden',
                  fontFamily: 'var(--font-tamil-sans)',
                }}
              >
                <a
                  className="hv-3"
                  href="#read"
                  aria-current={v.nav?.read?.current}
                  style={{
                    height: '44px',
                    padding: '0 8px',
                    borderRadius: '999px',
                    background: v.nav?.read?.bg,
                    color: v.nav?.read?.fg,
                    transition: 'background 200ms cubic-bezier(.2,0,0,1), color 200ms cubic-bezier(.2,0,0,1)',
                    fontSize: '16px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    textDecoration: 'none',
                    whiteSpace: 'nowrap',
                  }}
                >
                  படிக்க
                </a>
                <a
                  className="hv-3"
                  href="#watch"
                  aria-current={v.nav?.watch?.current}
                  style={{
                    height: '44px',
                    padding: '0 8px',
                    borderRadius: '999px',
                    background: v.nav?.watch?.bg,
                    color: v.nav?.watch?.fg,
                    transition: 'background 200ms cubic-bezier(.2,0,0,1), color 200ms cubic-bezier(.2,0,0,1)',
                    fontSize: '16px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    textDecoration: 'none',
                    whiteSpace: 'nowrap',
                  }}
                >
                  பார்க்க
                </a>
                <a
                  className="hv-3"
                  href="#community"
                  aria-current={v.nav?.community?.current}
                  style={{
                    height: '44px',
                    padding: '0 8px',
                    borderRadius: '999px',
                    background: v.nav?.community?.bg,
                    color: v.nav?.community?.fg,
                    transition: 'background 200ms cubic-bezier(.2,0,0,1), color 200ms cubic-bezier(.2,0,0,1)',
                    fontSize: '16px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    textDecoration: 'none',
                    whiteSpace: 'nowrap',
                  }}
                >
                  சமூகம்
                </a>
                <a
                  className="hv-3"
                  href="#programs"
                  aria-current={v.nav?.programs?.current}
                  style={{
                    height: '44px',
                    padding: '0 8px',
                    borderRadius: '999px',
                    background: v.nav?.programs?.bg,
                    color: v.nav?.programs?.fg,
                    transition: 'background 200ms cubic-bezier(.2,0,0,1), color 200ms cubic-bezier(.2,0,0,1)',
                    fontSize: '16px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    textDecoration: 'none',
                    whiteSpace: 'nowrap',
                  }}
                >
                  திட்டங்கள்
                </a>
              </nav>
              <details data-more-menu="" style={{ position: 'static', flex: 'none', marginLeft: '-8px' }}>
                <summary
                  className="hv-3"
                  style={{
                    height: '44px',
                    padding: '0 10px 0 12px',
                    borderRadius: '999px',
                    color: 'var(--text-muted)',
                    fontSize: '17px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px',
                    cursor: 'pointer',
                    listStyle: 'none',
                    whiteSpace: 'nowrap',
                    userSelect: 'none',
                  }}
                >
                  More
                  <Icon name="chevron-down" size={16} />
                </summary>
                <div
                  style={{
                    position: 'absolute',
                    top: 'calc(100% + 8px)',
                    left: '50%',
                    transform: 'translateX(-50%)',
                    zIndex: '40',
                    width: 'min(940px, calc(100% - 32px))',
                    maxHeight: 'calc(100vh - 96px)',
                    overflow: 'auto',
                    padding: '16px',
                    boxSizing: 'border-box',
                    borderRadius: '20px',
                    background: 'var(--white)',
                    border: '1px solid var(--border-default)',
                    boxShadow: 'var(--shadow-lg)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '8px',
                  }}
                >
                  {v.hasHiddenNav ? (
                    <Fragment>
                      <div
                        style={{
                          fontSize: '14px',
                          fontWeight: '700',
                          letterSpacing: '0.08em',
                          textTransform: 'uppercase',
                          color: 'var(--text-muted)',
                          padding: '10px 12px 4px',
                        }}
                      >
                        Sections
                      </div>
                      {(v.hiddenNav ?? []).map((hn, $i0) => (
                        <Fragment key={$i0}>
                          <a
                            className="hv-0"
                            href={toUrl(hn?.href)}
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '12px',
                              minHeight: '44px',
                              padding: '8px 12px',
                              borderRadius: '10px',
                              fontSize: '16px',
                              fontWeight: '600',
                              color: 'var(--text-strong)',
                              textDecoration: 'none',
                            }}
                          >
                            <Icon name={hn?.icon} size={20} color="var(--text-muted)" />
                            {hn?.label}
                          </a>
                        </Fragment>
                      ))}
                      <div style={{ height: '1px', background: 'var(--border-subtle)', margin: '6px 4px' }}></div>
                    </Fragment>
                  ) : null}
                  <div
                    style={{
                      display: 'grid',
                      gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,180px),1fr))',
                      gap: '8px 20px',
                    }}
                  >
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                      <div
                        style={{
                          fontSize: '14px',
                          fontWeight: '700',
                          letterSpacing: '0.08em',
                          textTransform: 'uppercase',
                          color: 'var(--text-muted)',
                          padding: '6px 10px 6px',
                        }}
                      >
                        Read
                      </div>
                      <a
                        className="hv-0"
                        href={toUrl('/search?query=')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="compass" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Explore</span>
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/stories')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="book-open" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Stories</span>
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/parents-of-india')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="map-pin" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Parents of India</span>
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/ask-the-expert')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="stethoscope" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Ask an expert</span>
                      </a>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                      <div
                        style={{
                          fontSize: '14px',
                          fontWeight: '700',
                          letterSpacing: '0.08em',
                          textTransform: 'uppercase',
                          color: 'var(--text-muted)',
                          padding: '6px 10px 6px',
                        }}
                      >
                        Community
                      </div>
                      <a
                        className="hv-0"
                        href={toUrl('/communities')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="users" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Community</span>
                        <span
                          style={{
                            height: '22px',
                            padding: '0 8px',
                            borderRadius: '999px',
                            background: 'var(--orange-600)',
                            color: 'var(--white)',
                            fontSize: '14px',
                            fontWeight: '700',
                            display: 'inline-flex',
                            alignItems: 'center',
                          }}
                        >
                          New
                        </span>
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/guidelines')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="shield-check" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Community guidelines</span>
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/community-help')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="life-buoy" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Community help</span>
                      </a>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                      <div
                        style={{
                          fontSize: '14px',
                          fontWeight: '700',
                          letterSpacing: '0.08em',
                          textTransform: 'uppercase',
                          color: 'var(--text-muted)',
                          padding: '6px 10px 6px',
                        }}
                      >
                        Initiatives
                      </div>
                      <a
                        className="hv-0"
                        href="https://www.parentcircle.com/gadget-free-hour/"
                        target="_blank"
                        rel="noopener"
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="hourglass" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Gadget Free Hour</span>
                        <Icon name="arrow-up-right" size={16} color="var(--neutral-400)" />
                      </a>
                      <a
                        className="hv-0"
                        href="https://www.dotlearningcircle.com/"
                        target="_blank"
                        rel="noopener"
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="graduation-cap" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>The Dot Learning Circle</span>
                        <Icon name="arrow-up-right" size={16} color="var(--neutral-400)" />
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/press')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="newspaper" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Press releases</span>
                      </a>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                      <div
                        style={{
                          fontSize: '14px',
                          fontWeight: '700',
                          letterSpacing: '0.08em',
                          textTransform: 'uppercase',
                          color: 'var(--text-muted)',
                          padding: '6px 10px 6px',
                        }}
                      >
                        About
                      </div>
                      <a
                        className="hv-0"
                        href={toUrl('/about')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="info" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>About us</span>
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/privacy')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="lock" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Privacy policy</span>
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/terms')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="file-text" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Terms of use</span>
                      </a>
                      <a
                        className="hv-0"
                        href={toUrl('/contact')}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '8px 10px',
                          borderRadius: '10px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="mail" size={20} color="var(--text-muted)" />
                        <span style={{ flex: '1', minWidth: '0' }}>Contact us</span>
                      </a>
                    </div>
                  </div>
                </div>
              </details>
            </Fragment>
          ) : null}
          <div style={{ display: 'flex', alignItems: 'center', gap: '4px', flex: 'none', marginLeft: 'auto' }}>
            <IconButton
              icon={v.searchIcon}
              label={v.searchBtnLabel}
              aria-expanded={v.searchOpen}
              onClick={v.toggleSearch}
            />
            <span data-auth="out" style={{ display: 'contents' }}>
              <a href={toUrl('/sign-in')} style={{ display: 'flex', textDecoration: 'none' }}>
                <Button variant="ghost" size="sm">
                  Sign in
                </Button>
              </a>{' '}
              <a href={toUrl('/join')} style={{ display: 'flex', textDecoration: 'none' }}>
                <Button variant="primary" size="sm">
                  Join free
                </Button>
              </a>
            </span>
            <span data-auth="in" style={{ display: 'none', alignItems: 'center', gap: '8px' }}>
              <a
                className="hv-3"
                href={toUrl('/profile#notification')}
                aria-label="Notifications, 3 new"
                style={{
                  position: 'relative',
                  width: '48px',
                  height: '48px',
                  borderRadius: '999px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: 'var(--text-strong)',
                  textDecoration: 'none',
                }}
              >
                <Icon name="bell" size={22} />
                <span
                  style={{
                    position: 'absolute',
                    top: '6px',
                    right: '6px',
                    minWidth: '18px',
                    height: '18px',
                    padding: '0 5px',
                    boxSizing: 'border-box',
                    borderRadius: '999px',
                    background: 'var(--orange-600)',
                    color: 'var(--white)',
                    fontSize: '12px',
                    fontWeight: '700',
                    lineHeight: '18px',
                    textAlign: 'center',
                    boxShadow: '0 0 0 2px var(--white)',
                  }}
                >
                  3
                </span>
              </a>{' '}
              <a
                className="hv-0"
                href={toUrl('/profile#activities')}
                aria-label="Your profile"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  height: '44px',
                  padding: '0 14px 0 4px',
                  borderRadius: '999px',
                  border: '1px solid var(--border-default)',
                  textDecoration: 'none',
                  color: 'var(--text-strong)',
                }}
              >
                <Avatar name="Priya Raman" size={36} />
                <span data-auth-name="" style={{ fontSize: '16px', fontWeight: '600' }}>
                  Priya
                </span>
              </a>
            </span>
          </div>
        </div>
        {v.searchOpen ? (
          <div
            data-search-panel=""
            role="search"
            style={{
              position: 'absolute',
              top: '100%',
              left: '0',
              right: '0',
              background: 'var(--white)',
              borderBottom: '1px solid var(--border-default)',
              boxShadow: 'var(--shadow-md)',
              maxHeight: 'calc(100vh - 72px)',
              overflow: 'auto',
            }}
          >
            <div
              style={{
                maxWidth: '760px',
                margin: '0 auto',
                padding: '20px 24px 28px',
                boxSizing: 'border-box',
                display: 'flex',
                flexDirection: 'column',
                gap: '20px',
              }}
            >
              <div style={{ display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
                <form onSubmit={v.submitSearch} style={{ flex: '1', minWidth: '0', margin: '0' }}>
                  <Input
                    icon="search"
                    placeholder="Search stories, topics and experts"
                    aria-label="Search"
                    value={v.q}
                    onChange={v.onQ}
                  />
                </form>
                <Button variant="ghost" onClick={v.closeSearch}>
                  Cancel
                </Button>
              </div>
              {v.noQuery ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <div
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--text-muted)',
                    }}
                  >
                    Popular searches
                  </div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                    {(v.popular ?? []).map((p, $i0) => (
                      <Fragment key={$i0}>
                        <button
                          className="hv-e"
                          type="button"
                          onClick={p?.pick}
                          style={{
                            height: '44px',
                            padding: '0 16px',
                            borderRadius: '999px',
                            border: '1.5px solid var(--border-default)',
                            background: 'var(--white)',
                            font: 'inherit',
                            fontSize: '16px',
                            fontWeight: '600',
                            color: 'var(--text-strong)',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '8px',
                            cursor: 'pointer',
                          }}
                        >
                          <Icon name="trending-up" size={16} color="var(--text-muted)" />
                          {p?.label}
                        </button>
                      </Fragment>
                    ))}
                  </div>
                </div>
              ) : null}
              {v.hasResults ? (
                <div style={{ display: 'flex', flexDirection: 'column' }}>
                  <div
                    style={{ fontSize: '15px', fontWeight: '600', color: 'var(--text-muted)', paddingBottom: '6px' }}
                  >
                    {v.resultCount}
                  </div>
                  {(v.results ?? []).map((r, $i0) => (
                    <Fragment key={$i0}>
                      <a
                        className="hv-f"
                        href={toUrl('/article')}
                        style={{
                          display: 'flex',
                          gap: '14px',
                          alignItems: 'center',
                          padding: '12px 8px',
                          margin: '0 -8px',
                          borderRadius: '12px',
                          textDecoration: 'none',
                          color: 'inherit',
                        }}
                      >
                        <span
                          style={{
                            width: '48px',
                            height: '48px',
                            flex: 'none',
                            borderRadius: '12px',
                            background: r?.tint,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}
                        >
                          <Icon name={r?.icon} size={22} color={r?.ink} />
                        </span>
                        <span
                          style={{ flex: '1', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '2px' }}
                        >
                          <span
                            style={{
                              fontFamily: 'var(--font-display)',
                              fontSize: '18px',
                              lineHeight: '1.35',
                              fontWeight: '700',
                              color: 'var(--text-strong)',
                              textWrap: 'pretty',
                            }}
                          >
                            {r?.title}
                          </span>
                          <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                            {r?.category}
                            {' · '}
                            {r?.readTime}
                          </span>
                        </span>
                        <Icon name="arrow-right" size={18} color="var(--orange-600)" />
                      </a>
                    </Fragment>
                  ))}
                  <a
                    className="hv-8"
                    href={toUrl(v.seeAllHref)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px',
                      marginTop: '10px',
                      padding: '10px 0',
                      fontSize: '16px',
                      fontWeight: '700',
                      color: 'var(--text-link)',
                      textDecoration: 'none',
                    }}
                  >
                    See all results
                    <Icon name="arrow-right" size={16} />
                  </a>
                </div>
              ) : null}
              {v.noResults ? (
                <div
                  style={{
                    display: 'flex',
                    gap: '14px',
                    alignItems: 'flex-start',
                    padding: '18px 20px',
                    borderRadius: '16px',
                    background: 'var(--neutral-50)',
                  }}
                >
                  <Icon name="search-x" size={24} color="var(--text-muted)" />
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', alignItems: 'flex-start' }}>
                    <span style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                      No stories match your search.
                    </span>
                    <span style={{ fontSize: '16px', color: 'var(--text-body)' }}>
                      Try a simpler word, or ask our experts.
                    </span>
                    <a href={toUrl('/ask-the-expert')} style={{ textDecoration: 'none' }}>
                      <Button variant="secondary" size="sm" icon="message-circle">
                        Ask an expert
                      </Button>
                    </a>
                  </div>
                </div>
              ) : null}
            </div>
          </div>
        ) : null}
      </header>
      {v.searchOpen ? (
        <div
          onClick={v.closeSearch}
          aria-hidden="true"
          style={{ position: 'fixed', inset: '0', zIndex: '19', background: 'rgba(31,27,24,0.32)' }}
        ></div>
      ) : null}
      <main>
        <nav
          aria-label="Quick links"
          style={{ background: 'var(--neutral-50)', borderBottom: '1px solid var(--border-subtle)' }}
        >
          <div
            style={{
              maxWidth: '1200px',
              margin: '0 auto',
              padding: '20px 24px 18px',
              boxSizing: 'border-box',
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit,minmax(88px,1fr))',
              gap: '12px 4px',
            }}
          >
            <a
              className="hv-g"
              href={toUrl('/parents-of-india')}
              onClick={v.goLink}
              style={{
                minWidth: '0',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '10px',
                padding: '6px 2px',
                textDecoration: 'none',
                color: 'var(--text-strong)',
                transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
              }}
            >
              <span
                style={{
                  width: '72px',
                  height: '72px',
                  boxSizing: 'border-box',
                  flex: 'none',
                  borderRadius: '50%',
                  display: 'flex',
                }}
              >
                <span
                  style={{
                    flex: '1',
                    borderRadius: '50%',
                    background: '#d85775',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="heart-handshake" size={26} color="var(--white)" />
                </span>
              </span>
              <span
                style={{
                  fontSize: '15px',
                  fontWeight: '700',
                  lineHeight: '1.3',
                  textAlign: 'center',
                  textWrap: 'balance',
                }}
              >
                Parents of India
              </span>
            </a>
            <a
              className="hv-g"
              href={toUrl('/superstar')}
              onClick={v.goLink}
              style={{
                minWidth: '0',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '10px',
                padding: '6px 2px',
                textDecoration: 'none',
                color: 'var(--text-strong)',
                transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
              }}
            >
              <span
                style={{
                  width: '72px',
                  height: '72px',
                  boxSizing: 'border-box',
                  flex: 'none',
                  borderRadius: '50%',
                  display: 'flex',
                }}
              >
                <span
                  style={{
                    flex: '1',
                    borderRadius: '50%',
                    background: '#e0a51d',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="star" size={26} color="var(--white)" />
                </span>
              </span>
              <span
                style={{
                  fontSize: '15px',
                  fontWeight: '700',
                  lineHeight: '1.3',
                  textAlign: 'center',
                  textWrap: 'balance',
                }}
              >
                SuperStar Program
              </span>
            </a>
            <a
              className="hv-g"
              href={toUrl('/videos')}
              onClick={v.goLink}
              style={{
                minWidth: '0',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '10px',
                padding: '6px 2px',
                textDecoration: 'none',
                color: 'var(--text-strong)',
                transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
              }}
            >
              <span
                style={{
                  width: '72px',
                  height: '72px',
                  boxSizing: 'border-box',
                  flex: 'none',
                  borderRadius: '50%',
                  display: 'flex',
                }}
              >
                <span
                  style={{
                    flex: '1',
                    borderRadius: '50%',
                    background: '#4388c4',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="circle-play" size={26} color="var(--white)" />
                </span>
              </span>
              <span
                style={{
                  fontSize: '15px',
                  fontWeight: '700',
                  lineHeight: '1.3',
                  textAlign: 'center',
                  textWrap: 'balance',
                }}
              >
                Videos
              </span>
            </a>
            <a
              className="hv-g"
              href={toUrl('/communities')}
              onClick={v.goLink}
              style={{
                minWidth: '0',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '10px',
                padding: '6px 2px',
                textDecoration: 'none',
                color: 'var(--text-strong)',
                transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
              }}
            >
              <span
                style={{
                  width: '72px',
                  height: '72px',
                  boxSizing: 'border-box',
                  flex: 'none',
                  borderRadius: '50%',
                  display: 'flex',
                }}
              >
                <span
                  style={{
                    flex: '1',
                    borderRadius: '50%',
                    background: '#489d65',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="users" size={26} color="var(--white)" />
                </span>
              </span>
              <span
                style={{
                  fontSize: '15px',
                  fontWeight: '700',
                  lineHeight: '1.3',
                  textAlign: 'center',
                  textWrap: 'balance',
                }}
              >
                Community
              </span>
            </a>
            <a
              className="hv-g"
              href={toUrl('/quotes')}
              onClick={v.goLink}
              style={{
                minWidth: '0',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '10px',
                padding: '6px 2px',
                textDecoration: 'none',
                color: 'var(--text-strong)',
                transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
              }}
            >
              <span
                style={{
                  width: '72px',
                  height: '72px',
                  boxSizing: 'border-box',
                  flex: 'none',
                  borderRadius: '50%',
                  display: 'flex',
                }}
              >
                <span
                  style={{
                    flex: '1',
                    borderRadius: '50%',
                    background: '#836cc6',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="quote" size={26} color="var(--white)" />
                </span>
              </span>
              <span
                style={{
                  fontSize: '15px',
                  fontWeight: '700',
                  lineHeight: '1.3',
                  textAlign: 'center',
                  textWrap: 'balance',
                }}
              >
                Parenting quotes
              </span>
            </a>
            <a
              className="hv-g"
              href={toUrl('/ask-the-expert')}
              onClick={v.goLink}
              style={{
                minWidth: '0',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '10px',
                padding: '6px 2px',
                textDecoration: 'none',
                color: 'var(--text-strong)',
                transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
              }}
            >
              <span
                style={{
                  width: '72px',
                  height: '72px',
                  boxSizing: 'border-box',
                  flex: 'none',
                  borderRadius: '50%',
                  display: 'flex',
                }}
              >
                <span
                  style={{
                    flex: '1',
                    borderRadius: '50%',
                    background: '#ea7c22',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="stethoscope" size={26} color="var(--white)" />
                </span>
              </span>
              <span
                style={{
                  fontSize: '15px',
                  fontWeight: '700',
                  lineHeight: '1.3',
                  textAlign: 'center',
                  textWrap: 'balance',
                }}
              >
                Ask the experts
              </span>
            </a>
            <a
              className="hv-g"
              href={toUrl('/recipes')}
              onClick={v.goLink}
              style={{
                minWidth: '0',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '10px',
                padding: '6px 2px',
                textDecoration: 'none',
                color: 'var(--text-strong)',
                transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
              }}
            >
              <span
                style={{
                  width: '72px',
                  height: '72px',
                  boxSizing: 'border-box',
                  flex: 'none',
                  borderRadius: '50%',
                  display: 'flex',
                }}
              >
                <span
                  style={{
                    flex: '1',
                    borderRadius: '50%',
                    background: '#e0a51d',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="cooking-pot" size={26} color="var(--white)" />
                </span>
              </span>
              <span
                style={{
                  fontSize: '15px',
                  fontWeight: '700',
                  lineHeight: '1.3',
                  textAlign: 'center',
                  textWrap: 'balance',
                }}
              >
                Recipes
              </span>
            </a>
            <a
              className="hv-g"
              href={toUrl('/baby-names')}
              onClick={v.goLink}
              style={{
                minWidth: '0',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '10px',
                padding: '6px 2px',
                textDecoration: 'none',
                color: 'var(--text-strong)',
                transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
              }}
            >
              <span
                style={{
                  width: '72px',
                  height: '72px',
                  boxSizing: 'border-box',
                  flex: 'none',
                  borderRadius: '50%',
                  display: 'flex',
                }}
              >
                <span
                  style={{
                    flex: '1',
                    borderRadius: '50%',
                    background: '#4388c4',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="baby" size={26} color="var(--white)" />
                </span>
              </span>
              <span
                style={{
                  fontSize: '15px',
                  fontWeight: '700',
                  lineHeight: '1.3',
                  textAlign: 'center',
                  textWrap: 'balance',
                }}
              >
                Baby names
              </span>
            </a>
          </div>
        </nav>
        <section
          id="read"
          style={{ maxWidth: '1200px', margin: '0 auto', padding: '40px 24px 72px', scrollMarginTop: '88px' }}
        >
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '40px', alignItems: 'flex-start' }}>
            <a
              className="hv-c"
              href={toUrl('/article')}
              style={{
                flex: '1.4 1 520px',
                minWidth: '0',
                display: 'flex',
                flexDirection: 'column',
                gap: '24px',
                textDecoration: 'none',
                color: 'inherit',
              }}
            >
              <div
                style={{
                  width: '100%',
                  aspectRatio: '16 / 10',
                  position: 'relative',
                  borderRadius: '24px',
                  background: 'var(--blush-100)',
                  color: 'var(--blush-700)',
                  overflow: 'hidden',
                }}
              >
                <image-slot
                  id="v2-hero"
                  shape="rounded"
                  radius="24"
                  placeholder="Photo: a parent kneeling beside a crying 2-year-old"
                ></image-slot>
              </div>
              <div>
                {v.isEn ? (
                  <Fragment>
                    <div
                      style={{
                        display: 'flex',
                        gap: '12px',
                        alignItems: 'center',
                        flexWrap: 'wrap',
                        marginBottom: '14px',
                      }}
                    >
                      <span
                        style={{
                          fontSize: '14px',
                          fontWeight: '700',
                          letterSpacing: '0.08em',
                          textTransform: 'uppercase',
                          color: 'var(--blush-700)',
                        }}
                      >
                        Managing behaviour
                      </span>
                      <Badge tone="success">Expert verified</Badge>
                    </div>
                    <h1
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: 'clamp(32px,3.8vw,48px)',
                        lineHeight: '1.12',
                        letterSpacing: '-0.015em',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0',
                        textWrap: 'balance',
                      }}
                    >
                      How and when to respond to your child’s tantrums
                    </h1>
                    <p
                      style={{
                        fontFamily: 'var(--font-serif)',
                        fontSize: '21px',
                        lineHeight: '1.5',
                        color: 'var(--text-muted)',
                        margin: '14px 0 18px',
                        textWrap: 'pretty',
                        maxWidth: '620px',
                      }}
                    >
                      Is it a call for help, or a bid to get their way? A psychologist explains how to tell the
                      difference — and a five-step way to calm both.
                    </p>
                  </Fragment>
                ) : null}
                {v.isTa ? (
                  <Fragment>
                    <div
                      style={{
                        display: 'flex',
                        gap: '12px',
                        alignItems: 'center',
                        flexWrap: 'wrap',
                        marginBottom: '14px',
                        fontFamily: 'var(--font-tamil-sans)',
                      }}
                    >
                      <span style={{ fontSize: '15px', fontWeight: '700', color: 'var(--blush-700)' }}>
                        நடத்தை மேலாண்மை
                      </span>
                      <Badge tone="success">நிபுணர் சரிபார்த்தது</Badge>
                    </div>
                    <h1
                      style={{
                        fontFamily: 'var(--font-tamil-serif)',
                        fontSize: 'clamp(28px,3.2vw,40px)',
                        lineHeight: '1.4',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0',
                        textWrap: 'balance',
                      }}
                    >
                      குழந்தையின் அடத்துக்கு எப்போது, எப்படிப் பதில் அளிப்பது
                    </h1>
                    <p
                      style={{
                        fontFamily: 'var(--font-tamil-serif)',
                        fontSize: '19px',
                        lineHeight: '1.85',
                        color: 'var(--text-muted)',
                        margin: '14px 0 18px',
                        textWrap: 'pretty',
                        maxWidth: '620px',
                      }}
                    >
                      இது உதவிக்கான அழைப்பா, அல்லது விரும்பியதைப் பெறும் வழியா? வேறுபாட்டையும், இரண்டையும் தணிக்கும் ஐந்து படிகளையும்
                      ஒரு உளவியலாளர் விளக்குகிறார்.
                    </p>
                  </Fragment>
                ) : null}
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <Avatar name="Saakshi Kapoor Kumar" size={40} ring={true} />
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                    <span style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                      Saakshi Kapoor Kumar
                    </span>
                    {' · Psychologist & educator · 11 min read'}
                  </span>
                </div>
              </div>
            </a>
            <div
              style={{
                flex: '1 1 380px',
                minWidth: '0',
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,170px),1fr))',
                gap: '28px 24px',
              }}
            >
              <a
                className="hv-c"
                href={toUrl('/article')}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '12px',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <div
                  style={{
                    width: '100%',
                    aspectRatio: '4 / 3',
                    position: 'relative',
                    borderRadius: '16px',
                    background: 'var(--sage-100)',
                    color: 'var(--sage-700)',
                    overflow: 'hidden',
                  }}
                >
                  <image-slot
                    id="v2-mosaic-1"
                    shape="rounded"
                    radius="16"
                    placeholder="Ragi dosa on a steel plate"
                  ></image-slot>
                </div>
                <span
                  style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--sage-700)',
                  }}
                >
                  Nutrition
                </span>
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '19px',
                    lineHeight: '1.3',
                    fontWeight: '700',
                    letterSpacing: '-0.01em',
                    color: 'var(--text-strong)',
                    textWrap: 'pretty',
                  }}
                >
                  5 iron-rich foods your toddler will actually eat
                </span>
              </a>
              <a
                className="hv-c"
                href={toUrl('/article')}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '12px',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <div
                  style={{
                    width: '100%',
                    aspectRatio: '4 / 3',
                    position: 'relative',
                    borderRadius: '16px',
                    background: 'var(--sky-100)',
                    color: 'var(--sky-700)',
                    overflow: 'hidden',
                  }}
                >
                  <image-slot
                    id="v2-mosaic-2"
                    shape="rounded"
                    radius="16"
                    placeholder="Child with a new school bag"
                  ></image-slot>
                </div>
                <span
                  style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--sky-700)',
                  }}
                >
                  {'School & learning'}
                </span>
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '19px',
                    lineHeight: '1.3',
                    fontWeight: '700',
                    letterSpacing: '-0.01em',
                    color: 'var(--text-strong)',
                    textWrap: 'pretty',
                  }}
                >
                  Is my child ready for Class 1? A gentle checklist
                </span>
              </a>
              <a
                className="hv-c"
                href={toUrl('/article')}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '12px',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <div
                  style={{
                    width: '100%',
                    aspectRatio: '4 / 3',
                    position: 'relative',
                    borderRadius: '16px',
                    background: 'var(--butter-100)',
                    color: 'var(--butter-700)',
                    overflow: 'hidden',
                  }}
                >
                  <image-slot
                    id="v2-mosaic-3"
                    shape="rounded"
                    radius="16"
                    placeholder="Kids playing with steel tumblers"
                  ></image-slot>
                </div>
                <span
                  style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--butter-700)',
                  }}
                >
                  Activities
                </span>
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '19px',
                    lineHeight: '1.3',
                    fontWeight: '700',
                    letterSpacing: '-0.01em',
                    color: 'var(--text-strong)',
                    textWrap: 'pretty',
                  }}
                >
                  10 rainy-day games using things already in your kitchen
                </span>
              </a>
              <a
                className="hv-c"
                href={toUrl('/article')}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '12px',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <div
                  style={{
                    width: '100%',
                    aspectRatio: '4 / 3',
                    position: 'relative',
                    borderRadius: '16px',
                    background: 'var(--lilac-100)',
                    color: 'var(--lilac-700)',
                    overflow: 'hidden',
                  }}
                >
                  <image-slot
                    id="v2-mosaic-4"
                    shape="rounded"
                    radius="16"
                    placeholder="Teen and father on the sofa"
                  ></image-slot>
                </div>
                <span
                  style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--lilac-700)',
                  }}
                >
                  Teens
                </span>
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '19px',
                    lineHeight: '1.3',
                    fontWeight: '700',
                    letterSpacing: '-0.01em',
                    color: 'var(--text-strong)',
                    textWrap: 'pretty',
                  }}
                >
                  Talking to your teenager about screen time — without a fight
                </span>
              </a>
            </div>
          </div>
        </section>
        <section aria-labelledby="age-h" style={{ background: 'var(--neutral-50)' }}>
          <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '64px 24px 72px' }}>
            <div style={{ textAlign: 'center' }}>
              <h2
                id="age-h"
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '34px',
                  lineHeight: '1.2',
                  letterSpacing: '-0.01em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                }}
              >
                How old is your child?
              </h2>
              <p style={{ fontSize: '19px', lineHeight: '1.45', color: 'var(--text-muted)', margin: '8px 0 32px' }}>
                Pick an age and we’ll tailor the stories below.
              </p>
            </div>
            <div
              role="group"
              aria-label="Child's age"
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,120px),1fr))',
                gap: '24px 16px',
              }}
            >
              {(v.stages ?? []).map((s, $i0) => (
                <Fragment key={$i0}>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '14px' }}>
                    <div
                      style={{
                        width: '100%',
                        maxWidth: '136px',
                        aspectRatio: '1',
                        position: 'relative',
                        borderRadius: '50%',
                        background: 'var(--white)',
                        color: 'var(--orange-700)',
                        boxShadow: s?.ring,
                        transition: 'box-shadow 200ms cubic-bezier(.2,0,0,1)',
                      }}
                    >
                      <image-slot id={`v2-age-${s?.id ?? ''}`} shape="circle" placeholder={s?.photo}></image-slot>
                    </div>
                    <button
                      className="hv-h"
                      type="button"
                      aria-pressed={s?.pressed}
                      onClick={s?.onClick}
                      style={{
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        gap: '2px',
                        minHeight: '56px',
                        padding: '6px 18px',
                        borderRadius: '14px',
                        border: '0',
                        background: s?.bg,
                        color: s?.fg,
                        cursor: 'pointer',
                        fontFamily: 'var(--font-ui)',
                        transition: 'background 200ms cubic-bezier(.2,0,0,1)',
                      }}
                    >
                      <span style={{ fontSize: '18px', fontWeight: '700' }}>{s?.label}</span>
                      <span style={{ fontSize: '15px', color: s?.sub }}>{s?.age}</span>
                    </button>
                  </div>
                </Fragment>
              ))}
            </div>
          </div>
        </section>
        <section
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '72px 24px',
            display: 'flex',
            flexWrap: 'wrap',
            gap: '56px',
            alignItems: 'flex-start',
          }}
        >
          <div style={{ flex: '999 1 560px', minWidth: '0' }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'baseline',
                justifyContent: 'space-between',
                gap: '16px',
                flexWrap: 'wrap',
                paddingBottom: '20px',
                borderBottom: '1px solid var(--border-default)',
              }}
            >
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '27px',
                  lineHeight: '1.25',
                  letterSpacing: '-0.01em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                }}
              >
                {v.feedTitle}
              </h2>
              <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{v.feedSub}</span>
            </div>
            <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', margin: '20px 0 4px' }}>
              {(v.topics ?? []).map((t, $i0) => (
                <Fragment key={$i0}>
                  <Tag selected={t?.selected} onClick={t?.onClick}>
                    {t?.label}
                  </Tag>
                </Fragment>
              ))}
            </div>
            {v.showGrid ? (
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,230px),1fr))',
                  gap: '40px 28px',
                  paddingTop: '28px',
                }}
              >
                {(v.feed ?? []).map((a, $i0) => (
                  <Fragment key={$i0}>
                    <article style={{ display: 'flex', flexDirection: 'column', gap: '10px', minWidth: '0' }}>
                      <div
                        style={{
                          position: 'relative',
                          aspectRatio: '16 / 10',
                          borderRadius: '16px',
                          overflow: 'hidden',
                          background: a?.tint,
                        }}
                      >
                        <image-slot
                          id={`v2-feed-${a?.id ?? ''}`}
                          shape="rounded"
                          radius="16"
                          placeholder={a?.photo}
                        ></image-slot>
                      </div>
                      <span
                        style={{
                          fontSize: '14px',
                          fontWeight: '700',
                          letterSpacing: '0.08em',
                          textTransform: 'uppercase',
                          color: a?.ink,
                        }}
                      >
                        {a?.card?.category}
                      </span>
                      <a
                        className="hv-5"
                        href={toUrl('/article')}
                        style={{
                          fontFamily: 'var(--font-display)',
                          fontSize: '20px',
                          lineHeight: '1.3',
                          fontWeight: '700',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                          textWrap: 'pretty',
                        }}
                      >
                        {a?.card?.title}
                      </a>
                      <p
                        style={{
                          fontFamily: 'var(--font-serif)',
                          fontSize: '17px',
                          lineHeight: '1.5',
                          color: 'var(--text-body)',
                          margin: '0',
                          display: '-webkit-box',
                          WebkitLineClamp: '3',
                          WebkitBoxOrient: 'vertical',
                          overflow: 'hidden',
                        }}
                      >
                        {a?.card?.dek}
                      </p>
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          gap: '8px',
                          marginTop: 'auto',
                        }}
                      >
                        <span style={{ fontSize: '15px', lineHeight: '1.4', color: 'var(--text-muted)' }}>
                          {a?.meta}
                        </span>
                        <IconButton icon={a?.saveIcon} label={a?.saveLabel} onClick={a?.card?.onSave} />
                      </div>
                    </article>
                  </Fragment>
                ))}
              </div>
            ) : null}
            {v.showList ? (
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                {(v.feed ?? []).map((a, $i0) => (
                  <Fragment key={$i0}>
                    <div style={{ padding: '28px 0', borderBottom: '1px solid var(--border-subtle)' }}>
                      <article style={{ display: 'flex', gap: '20px', alignItems: 'flex-start' }}>
                        <div style={{ flex: '1', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                          <span
                            style={{
                              fontSize: '14px',
                              fontWeight: '700',
                              letterSpacing: '0.08em',
                              textTransform: 'uppercase',
                              color: a?.ink,
                            }}
                          >
                            {a?.card?.category}
                          </span>
                          <a
                            className="hv-5"
                            href={toUrl('/article')}
                            style={{
                              fontFamily: 'var(--font-display)',
                              fontSize: '20px',
                              lineHeight: '1.3',
                              fontWeight: '700',
                              color: 'var(--text-strong)',
                              textDecoration: 'none',
                              textWrap: 'pretty',
                            }}
                          >
                            {a?.card?.title}
                          </a>
                          <p
                            style={{
                              fontFamily: 'var(--font-serif)',
                              fontSize: '17px',
                              lineHeight: '1.5',
                              color: 'var(--text-body)',
                              margin: '0',
                              display: '-webkit-box',
                              WebkitLineClamp: '3',
                              WebkitBoxOrient: 'vertical',
                              overflow: 'hidden',
                            }}
                          >
                            {a?.card?.dek}
                          </p>
                          <div
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'space-between',
                              gap: '8px',
                              marginTop: 'auto',
                            }}
                          >
                            <span style={{ fontSize: '15px', lineHeight: '1.4', color: 'var(--text-muted)' }}>
                              {a?.meta}
                            </span>
                            <IconButton icon={a?.saveIcon} label={a?.saveLabel} onClick={a?.card?.onSave} />
                          </div>
                        </div>
                        <div
                          style={{
                            position: 'relative',
                            flex: 'none',
                            width: 'clamp(110px,22vw,180px)',
                            aspectRatio: '4 / 3',
                            borderRadius: '16px',
                            overflow: 'hidden',
                            background: a?.tint,
                          }}
                        >
                          <image-slot
                            id={`v2-feed-${a?.id ?? ''}`}
                            shape="rounded"
                            radius="16"
                            placeholder={a?.photo}
                          ></image-slot>
                        </div>
                      </article>
                    </div>
                  </Fragment>
                ))}
              </div>
            ) : null}
            {v.isEmpty ? (
              <div
                style={{
                  padding: '40px 0',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'flex-start',
                  gap: '16px',
                }}
              >
                <p
                  style={{
                    fontFamily: 'var(--font-serif)',
                    fontSize: '20px',
                    lineHeight: '1.5',
                    color: 'var(--text-body)',
                    margin: '0',
                  }}
                >
                  We don’t have stories on this topic for this age yet. Try another topic, or see every age.
                </p>
                <Button variant="secondary" onClick={v.showAllAges}>
                  Show all ages
                </Button>
              </div>
            ) : null}
            <div style={{ paddingTop: '36px' }}>
              <Button variant="secondary" iconRight="arrow-right">
                See all stories
              </Button>
            </div>
          </div>
          <aside style={{ flex: '1 1 300px', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '40px' }}>
            <Card tint="sage" padding={0} {...v.clipCard}>
              <div
                style={{
                  width: '100%',
                  aspectRatio: '16 / 9',
                  position: 'relative',
                  background: 'var(--sage-100)',
                  color: 'var(--sage-700)',
                }}
              >
                <image-slot id="v2-expert" shape="rect" placeholder="Paediatrician with a parent and baby"></image-slot>
              </div>
              <div style={{ padding: '24px' }}>
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0 0 6px',
                  }}
                >
                  Ask an expert
                </div>
                <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)', marginBottom: '18px' }}>
                  Paediatricians, psychologists and educators answer within 48 hours. You can ask anonymously.
                </div>
                <a href={toUrl('/ask-the-expert')} style={{ display: 'block', textDecoration: 'none' }}>
                  <Button variant="dark" fullWidth={true}>
                    Ask a question
                  </Button>
                </a>
              </div>
            </Card>
            <div>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                  marginBottom: '8px',
                }}
              >
                Circles to join
              </div>
              {(v.circles ?? []).map((c, $i0) => (
                <Fragment key={$i0}>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '14px',
                      padding: '12px 0',
                      borderBottom: '1px solid var(--border-subtle)',
                    }}
                  >
                    <Avatar name={c?.name} size={52} />
                    <div style={{ flex: '1', minWidth: '0' }}>
                      <div style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>{c?.name}</div>
                      <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{c?.members}</div>
                    </div>
                    <Button size="sm" variant={c?.variant} icon={c?.icon} onClick={c?.onClick}>
                      {c?.btn}
                    </Button>
                  </div>
                </Fragment>
              ))}
            </div>
            <Card padding={24}>
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '22px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0 0 6px',
                }}
              >
                The Sunday letter
              </div>
              <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-muted)', marginBottom: '18px' }}>
                One calm email a week, matched to your child’s age. No spam, ever.
              </div>
              {v.notSubscribed ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <Input
                    type="email"
                    placeholder="Your email"
                    icon="mail"
                    value={v.email}
                    onChange={v.onEmail}
                    error={v.emailError}
                  />
                  <Button variant="primary" fullWidth={true} onClick={v.onSubscribe}>
                    Sign me up
                  </Button>
                </div>
              ) : null}
              {v.subscribed ? (
                <div
                  style={{
                    display: 'flex',
                    gap: '10px',
                    alignItems: 'flex-start',
                    padding: '14px 16px',
                    borderRadius: '10px',
                    background: 'var(--sage-50)',
                    color: 'var(--sage-700)',
                    fontSize: '17px',
                    lineHeight: '1.45',
                  }}
                >
                  <Icon name="circle-check" size={22} />
                  <span>Thank you. Your first letter arrives this Sunday.</span>
                </div>
              ) : null}
            </Card>
          </aside>
        </section>
        <section style={{ background: 'var(--butter-50)' }}>
          <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '64px 24px', boxSizing: 'border-box' }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'flex-end',
                justifyContent: 'space-between',
                gap: '20px',
                flexWrap: 'wrap',
                marginBottom: '28px',
              }}
            >
              <div>
                <div
                  style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--butter-700)',
                    marginBottom: '10px',
                  }}
                >
                  Play ideas
                </div>
                <h2
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(30px,3.4vw,40px)',
                    lineHeight: '1.15',
                    letterSpacing: '-0.01em',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0',
                  }}
                >
                  Something to do together this weekend
                </h2>
              </div>
              <Button variant="secondary" iconRight="arrow-right">
                More activities
              </Button>
            </div>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,220px),1fr))',
                gap: '28px 24px',
              }}
            >
              <a
                className="hv-c"
                href="#"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '12px',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <div
                  style={{
                    width: '100%',
                    aspectRatio: '1',
                    position: 'relative',
                    borderRadius: '16px',
                    background: 'var(--butter-100)',
                    color: 'var(--butter-700)',
                    overflow: 'hidden',
                  }}
                >
                  <image-slot
                    id="v2-play-1"
                    shape="rounded"
                    radius="16"
                    placeholder="Paper boats in a bucket of water"
                  ></image-slot>
                </div>
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '20px',
                    lineHeight: '1.3',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                  }}
                >
                  Paper-boat race in a bucket
                </span>
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Ages 3–6 · 20 minutes</span>
              </a>
              <a
                className="hv-c"
                href="#"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '12px',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <div
                  style={{
                    width: '100%',
                    aspectRatio: '1',
                    position: 'relative',
                    borderRadius: '16px',
                    background: 'var(--butter-100)',
                    color: 'var(--butter-700)',
                    overflow: 'hidden',
                  }}
                >
                  <image-slot
                    id="v2-play-2"
                    shape="rounded"
                    radius="16"
                    placeholder="Child drawing a rice-flour kolam"
                  ></image-slot>
                </div>
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '20px',
                    lineHeight: '1.3',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                  }}
                >
                  Your first kolam with rice flour
                </span>
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Ages 4–10 · 30 minutes</span>
              </a>
              <a
                className="hv-c"
                href="#"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '12px',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <div
                  style={{
                    width: '100%',
                    aspectRatio: '1',
                    position: 'relative',
                    borderRadius: '16px',
                    background: 'var(--butter-100)',
                    color: 'var(--butter-700)',
                    overflow: 'hidden',
                  }}
                >
                  <image-slot
                    id="v2-play-3"
                    shape="rounded"
                    radius="16"
                    placeholder="Sock puppets behind a sofa"
                  ></image-slot>
                </div>
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '20px',
                    lineHeight: '1.3',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                  }}
                >
                  Sock-puppet theatre with grandparents
                </span>
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Ages 3–8 · 40 minutes</span>
              </a>
              <a
                className="hv-c"
                href="#"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '12px',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <div
                  style={{
                    width: '100%',
                    aspectRatio: '1',
                    position: 'relative',
                    borderRadius: '16px',
                    background: 'var(--butter-100)',
                    color: 'var(--butter-700)',
                    overflow: 'hidden',
                  }}
                >
                  <image-slot
                    id="v2-play-4"
                    shape="rounded"
                    radius="16"
                    placeholder="Small hands sorting dals into bowls"
                  ></image-slot>
                </div>
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '20px',
                    lineHeight: '1.3',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                  }}
                >
                  The dal-sorting game
                </span>
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Ages 2–4 · 15 minutes</span>
              </a>
            </div>
          </div>
        </section>
        <section
          id="watch"
          style={{ maxWidth: '1200px', margin: '0 auto', padding: '72px 24px', scrollMarginTop: '88px' }}
        >
          <div
            style={{
              display: 'flex',
              alignItems: 'flex-end',
              justifyContent: 'space-between',
              gap: '20px',
              flexWrap: 'wrap',
              marginBottom: '28px',
            }}
          >
            <div>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                  marginBottom: '10px',
                }}
              >
                Watch
              </div>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(30px,3.4vw,40px)',
                  lineHeight: '1.15',
                  letterSpacing: '-0.01em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                }}
              >
                Short videos from our experts
              </h2>
            </div>
            <a href={toUrl('/videos')} style={{ textDecoration: 'none' }}>
              <Button variant="secondary" iconRight="arrow-right">
                All videos
              </Button>
            </a>
          </div>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,300px),1fr))',
              gap: '32px 24px',
            }}
          >
            <a
              className="hv-c"
              href={toUrl('/video')}
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '14px',
                textDecoration: 'none',
                color: 'inherit',
              }}
            >
              <div
                style={{
                  width: '100%',
                  aspectRatio: '16 / 9',
                  position: 'relative',
                  borderRadius: '16px',
                  background: 'var(--lilac-100)',
                  color: 'var(--lilac-700)',
                  overflow: 'hidden',
                }}
              >
                <image-slot
                  id="v2-video-1"
                  shape="rounded"
                  radius="16"
                  placeholder="Video still: Maria Goretti Warsi"
                ></image-slot>{' '}
                <span
                  style={{
                    position: 'absolute',
                    left: '16px',
                    bottom: '16px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    height: '40px',
                    padding: '0 14px 0 10px',
                    borderRadius: '999px',
                    background: 'var(--white)',
                    color: 'var(--text-strong)',
                    fontSize: '15px',
                    fontWeight: '600',
                    boxShadow: 'var(--shadow-sm)',
                    pointerEvents: 'none',
                  }}
                >
                  <Icon name="play" size={20} color="var(--orange-600)" />
                  Watch
                </span>
              </div>
              <span
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--lilac-700)',
                }}
              >
                #GadgetFreeHour
              </span>
              <span
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '21px',
                  lineHeight: '1.3',
                  fontWeight: '700',
                  letterSpacing: '-0.01em',
                  color: 'var(--text-strong)',
                  textWrap: 'pretty',
                }}
              >
                Raising kids in a digital era means less family time: Maria Goretti Warsi
              </span>
              <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Chef and former VJ</span>
            </a>
            <a
              className="hv-c"
              href={toUrl('/video')}
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '14px',
                textDecoration: 'none',
                color: 'inherit',
              }}
            >
              <div
                style={{
                  width: '100%',
                  aspectRatio: '16 / 9',
                  position: 'relative',
                  borderRadius: '16px',
                  background: 'var(--sky-100)',
                  color: 'var(--sky-700)',
                  overflow: 'hidden',
                }}
              >
                <image-slot
                  id="v2-video-2"
                  shape="rounded"
                  radius="16"
                  placeholder="Video still: grandmother reading to a child"
                ></image-slot>{' '}
                <span
                  style={{
                    position: 'absolute',
                    left: '16px',
                    bottom: '16px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    height: '40px',
                    padding: '0 14px 0 10px',
                    borderRadius: '999px',
                    background: 'var(--white)',
                    color: 'var(--text-strong)',
                    fontSize: '15px',
                    fontWeight: '600',
                    boxShadow: 'var(--shadow-sm)',
                    pointerEvents: 'none',
                  }}
                >
                  <Icon name="play" size={20} color="var(--orange-600)" />
                  4:48
                </span>
              </div>
              <span
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--sky-700)',
                }}
              >
                Language
              </span>
              <span
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '21px',
                  lineHeight: '1.3',
                  fontWeight: '700',
                  letterSpacing: '-0.01em',
                  color: 'var(--text-strong)',
                  textWrap: 'pretty',
                }}
              >
                Story time that builds language: 3 simple tricks
              </span>
              <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Lakshmi Venkat, Early-years educator</span>
            </a>
            <a
              className="hv-c"
              href={toUrl('/video')}
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '14px',
                textDecoration: 'none',
                color: 'inherit',
              }}
            >
              <div
                style={{
                  width: '100%',
                  aspectRatio: '16 / 9',
                  position: 'relative',
                  borderRadius: '16px',
                  background: 'var(--blush-100)',
                  color: 'var(--blush-700)',
                  overflow: 'hidden',
                }}
              >
                <image-slot
                  id="v2-video-3"
                  shape="rounded"
                  radius="16"
                  placeholder="Video still: a calm-down corner at home"
                ></image-slot>{' '}
                <span
                  style={{
                    position: 'absolute',
                    left: '16px',
                    bottom: '16px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    height: '40px',
                    padding: '0 14px 0 10px',
                    borderRadius: '999px',
                    background: 'var(--white)',
                    color: 'var(--text-strong)',
                    fontSize: '15px',
                    fontWeight: '600',
                    boxShadow: 'var(--shadow-sm)',
                    pointerEvents: 'none',
                  }}
                >
                  <Icon name="play" size={20} color="var(--orange-600)" />
                  5:30
                </span>
              </div>
              <span
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--blush-700)',
                }}
              >
                Emotions
              </span>
              <span
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '21px',
                  lineHeight: '1.3',
                  fontWeight: '700',
                  letterSpacing: '-0.01em',
                  color: 'var(--text-strong)',
                  textWrap: 'pretty',
                }}
              >
                How to set up a calm-down corner at home
              </span>
              <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Dr. Meera Iyer, Child psychologist</span>
            </a>
          </div>
        </section>
        <section id="community" style={{ background: 'var(--sage-50)', scrollMarginTop: '72px' }}>
          <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '72px 24px' }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'flex-end',
                justifyContent: 'space-between',
                gap: '20px',
                flexWrap: 'wrap',
                marginBottom: '32px',
              }}
            >
              <div>
                <div
                  style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--text-muted)',
                    marginBottom: '10px',
                  }}
                >
                  Community
                </div>
                <h2
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(30px,3.4vw,40px)',
                    lineHeight: '1.15',
                    letterSpacing: '-0.01em',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0',
                    textWrap: 'balance',
                  }}
                >
                  Parents and grandparents, helping each other
                </h2>
              </div>
              <a href={toUrl('/communities')} style={{ textDecoration: 'none', flex: 'none' }}>
                <Button variant="secondary" iconRight="arrow-right">
                  Visit the community
                </Button>
              </a>
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '48px', alignItems: 'flex-start' }}>
              <article
                style={{
                  flex: '1 1 460px',
                  minWidth: '0',
                  background: 'var(--white)',
                  boxShadow: 'var(--shadow-sm)',
                  borderRadius: '24px',
                  padding: 'clamp(24px,4vw,40px)',
                  boxSizing: 'border-box',
                }}
              >
                <div
                  style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap', marginBottom: '16px' }}
                >
                  <Badge tone="success">Expert answer</Badge>
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                    in Toddler Parents · Kavya S asked 2 hours ago
                  </span>
                </div>
                <h3
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '24px',
                    lineHeight: '1.3',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0',
                    textWrap: 'pretty',
                  }}
                >
                  “My 2-year-old refuses to sleep without the phone. How did you stop it?”
                </h3>
                <div
                  style={{
                    width: '48px',
                    height: '3px',
                    borderRadius: '2px',
                    background: 'var(--pc-orange)',
                    margin: '24px 0 20px',
                  }}
                ></div>
                <p
                  style={{
                    fontFamily: 'var(--font-serif)',
                    fontSize: '22px',
                    lineHeight: '1.6',
                    color: 'var(--text-body)',
                    margin: '0 0 24px',
                    textWrap: 'pretty',
                  }}
                >
                  You’re not doing anything wrong — you’re teaching a new habit. Swap the phone for a short, predictable
                  routine: bath, two books, one song. Expect three or four hard nights. Then it gets easier.
                </p>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
                  <Avatar name="Meera Iyer" size={40} ring={true} />
                  <div style={{ flex: '1 1 auto' }}>
                    <div style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                      Dr. Meera Iyer
                    </div>
                    <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Child psychologist, Chennai</div>
                  </div>
                  <div style={{ display: 'flex', gap: '20px', fontSize: '16px', color: 'var(--text-muted)' }}>
                    <span style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
                      <Icon name="heart" size={20} />
                      58 found helpful
                    </span>
                    <span style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
                      <Icon name="message-circle" size={20} />
                      34 replies
                    </span>
                  </div>
                </div>
              </article>
              <div style={{ flex: '1 1 360px', minWidth: '0' }}>
                <div
                  style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--text-muted)',
                    marginBottom: '4px',
                  }}
                >
                  Waiting for your answer
                </div>
                <article style={{ padding: '20px 0', borderBottom: '1px solid var(--border-default)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                    <Avatar name="Bala Narayanan" size={32} />
                    <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                      <span style={{ fontWeight: '600', color: 'var(--text-strong)' }}>Bala Narayanan</span>
                      {' · Grandparents Corner'}
                    </span>
                  </div>
                  <h3
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '20px',
                      lineHeight: '1.35',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      margin: '0',
                      textWrap: 'pretty',
                    }}
                  >
                    Grandfather here — how do I help my grandson with homework without confusing him?
                  </h3>
                  <div
                    style={{
                      display: 'flex',
                      gap: '6px',
                      alignItems: 'center',
                      marginTop: '10px',
                      fontSize: '15px',
                      color: 'var(--text-muted)',
                    }}
                  >
                    <Icon name="message-circle" size={18} />
                    21 replies · 5 hours ago
                  </div>
                </article>
                <article style={{ padding: '20px 0', borderBottom: '1px solid var(--border-default)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                    <Avatar name="Shalini M" size={32} />
                    <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                      <span style={{ fontWeight: '600', color: 'var(--text-strong)' }}>Shalini M</span>
                      {' · Picky Eaters'}
                    </span>
                  </div>
                  <h3
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '20px',
                      lineHeight: '1.35',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      margin: '0',
                      textWrap: 'pretty',
                    }}
                  >
                    Tiffin ideas that actually come back empty? My 5-year-old is so picky.
                  </h3>
                  <div
                    style={{
                      display: 'flex',
                      gap: '6px',
                      alignItems: 'center',
                      marginTop: '10px',
                      fontSize: '15px',
                      color: 'var(--text-muted)',
                    }}
                  >
                    <Icon name="message-circle" size={18} />
                    62 replies · Yesterday
                  </div>
                </article>
                <div style={{ paddingTop: '20px' }}>
                  <Button variant="primary" icon="message-circle">
                    Ask the community
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section
          id="programs"
          style={{ maxWidth: '1200px', margin: '0 auto', padding: '72px 24px', scrollMarginTop: '88px' }}
        >
          <div
            style={{
              fontSize: '14px',
              fontWeight: '700',
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              color: 'var(--text-muted)',
              marginBottom: '10px',
            }}
          >
            Programs
          </div>
          <h2
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(30px,3.4vw,40px)',
              lineHeight: '1.15',
              letterSpacing: '-0.01em',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0 0 32px',
            }}
          >
            Learn alongside your child
          </h2>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,420px),1fr))',
              gap: '24px',
            }}
          >
            <div style={{ height: '100%' }}>
              <Card tint="butter" padding={0} {...v.clipCard}>
                <div
                  style={{
                    width: '100%',
                    aspectRatio: '16 / 9',
                    position: 'relative',
                    background: 'var(--butter-100)',
                    color: 'var(--butter-700)',
                  }}
                >
                  <image-slot
                    id="v2-prog-little"
                    shape="rect"
                    placeholder="Preschooler and mother doing a learning activity"
                  ></image-slot>
                </div>
                <div style={{ padding: '28px 32px 32px', display: 'flex', flexDirection: 'column', gap: '18px' }}>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '12px',
                      flexWrap: 'wrap',
                    }}
                  >
                    <h3
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '27px',
                        lineHeight: '1.25',
                        letterSpacing: '-0.01em',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0',
                      }}
                    >
                      Little Learners @Home
                    </h3>
                    <Badge tone="warning">Ages 2–6</Badge>
                  </div>
                  <p
                    style={{
                      fontFamily: 'var(--font-serif)',
                      fontSize: '19px',
                      lineHeight: '1.55',
                      color: 'var(--text-body)',
                      margin: '0',
                      textWrap: 'pretty',
                    }}
                  >
                    Play-based preschool learning you can do together at home, in about 20 minutes a day.
                  </p>
                  <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                    <Button variant="primary">Start free week</Button>
                    <Button variant="ghost">See a sample day</Button>
                  </div>
                </div>
              </Card>
            </div>
            <a
              href={toUrl('/superstar')}
              aria-label="SuperStar Program"
              style={{ display: 'block', height: '100%', textDecoration: 'none', color: 'inherit' }}
            >
              <div style={{ height: '100%' }}>
                <Card tint="sky" padding={0} interactive={true} {...v.clipCard}>
                  <div
                    style={{
                      width: '100%',
                      aspectRatio: '16 / 9',
                      position: 'relative',
                      background: 'var(--sky-100)',
                      color: 'var(--sky-700)',
                    }}
                  >
                    <image-slot
                      id="v2-prog-superstar"
                      shape="rect"
                      placeholder="SuperStar members together"
                    ></image-slot>
                  </div>
                  <div style={{ padding: '28px 32px 32px', display: 'flex', flexDirection: 'column', gap: '18px' }}>
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: '12px',
                        flexWrap: 'wrap',
                      }}
                    >
                      <h3
                        style={{
                          fontFamily: 'var(--font-display)',
                          fontSize: '27px',
                          lineHeight: '1.25',
                          letterSpacing: '-0.01em',
                          fontWeight: '700',
                          color: 'var(--text-strong)',
                          margin: '0',
                        }}
                      >
                        SuperStar Program
                      </h3>
                      <Badge tone="info">Community</Badge>
                    </div>
                    <p
                      style={{
                        fontFamily: 'var(--font-serif)',
                        fontSize: '19px',
                        lineHeight: '1.55',
                        color: 'var(--text-body)',
                        margin: '0',
                        textWrap: 'pretty',
                      }}
                    >
                      Share your ParentCircle story, inspire other parents, and get invited to exclusive meetups and
                      events.
                    </p>
                    <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                      <Button variant="primary" icon="star">
                        Become a SuperStar
                      </Button>
                      <Button variant="ghost" iconRight="arrow-right">
                        Learn more
                      </Button>
                    </div>
                  </div>
                </Card>
              </div>
            </a>
          </div>
        </section>
      </main>
      <footer
        style={{
          background: '#1e2528',
          color: 'var(--text-inverse)',
          '--neutral-100': '#eef2f3',
          '--neutral-200': '#d5dde0',
          '--neutral-300': '#b0bcc1',
          '--neutral-600': '#56666d',
          '--neutral-700': '#3b494f',
          '--neutral-800': '#2b363b',
        }}
      >
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '64px 24px 0', boxSizing: 'border-box' }}>
          <div
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '32px 48px',
              alignItems: 'flex-start',
              justifyContent: 'space-between',
              paddingBottom: '48px',
              borderBottom: '1px solid var(--neutral-700)',
            }}
          >
            <div
              style={{
                flex: '1 1 340px',
                minWidth: '0',
                maxWidth: '460px',
                display: 'flex',
                flexDirection: 'column',
                gap: '18px',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'flex-start', alignSelf: 'stretch' }}>
                <Logo variant="white" height={32} />
              </div>
              <p
                style={{
                  fontFamily: 'var(--font-serif)',
                  fontSize: '20px',
                  lineHeight: '1.55',
                  color: 'var(--neutral-200)',
                  margin: '0',
                  textWrap: 'pretty',
                }}
              >
                Expert-backed guidance for every stage of raising a child — from infancy to the teenage years.
              </p>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                <a
                  className="hv-i"
                  href="https://www.instagram.com/parentcircle/"
                  target="_blank"
                  rel="noopener"
                  style={{
                    height: '40px',
                    padding: '0 14px 0 12px',
                    borderRadius: '999px',
                    background: 'var(--neutral-800)',
                    color: 'var(--neutral-100)',
                    fontSize: '15px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="instagram" size={18} color="currentColor" />
                  Instagram
                </a>
                <a
                  className="hv-i"
                  href="https://www.facebook.com/ParentCirclemagazine/"
                  target="_blank"
                  rel="noopener"
                  style={{
                    height: '40px',
                    padding: '0 14px 0 12px',
                    borderRadius: '999px',
                    background: 'var(--neutral-800)',
                    color: 'var(--neutral-100)',
                    fontSize: '15px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="facebook" size={18} color="currentColor" />
                  Facebook
                </a>
                <a
                  className="hv-i"
                  href="https://www.youtube.com/user/parentcircleindia"
                  target="_blank"
                  rel="noopener"
                  style={{
                    height: '40px',
                    padding: '0 14px 0 12px',
                    borderRadius: '999px',
                    background: 'var(--neutral-800)',
                    color: 'var(--neutral-100)',
                    fontSize: '15px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="youtube" size={18} color="currentColor" />
                  YouTube
                </a>
                <a
                  className="hv-i"
                  href="https://twitter.com/Parent_Circle"
                  target="_blank"
                  rel="noopener"
                  style={{
                    height: '40px',
                    padding: '0 14px 0 12px',
                    borderRadius: '999px',
                    background: 'var(--neutral-800)',
                    color: 'var(--neutral-100)',
                    fontSize: '15px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="twitter" size={18} color="currentColor" />X
                </a>
                <a
                  className="hv-i"
                  href="https://www.pinterest.com/parentcirclecom/"
                  target="_blank"
                  rel="noopener"
                  style={{
                    height: '40px',
                    padding: '0 14px 0 12px',
                    borderRadius: '999px',
                    background: 'var(--neutral-800)',
                    color: 'var(--neutral-100)',
                    fontSize: '15px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="pin" size={18} color="currentColor" />
                  Pinterest
                </a>
              </div>
            </div>
            <div
              style={{
                flex: '1 1 320px',
                minWidth: '0',
                maxWidth: '420px',
                padding: '28px',
                borderRadius: '20px',
                background: 'var(--neutral-800)',
                display: 'flex',
                flexDirection: 'column',
                gap: '10px',
                boxSizing: 'border-box',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-300)',
                }}
              >
                <Icon name="stethoscope" size={18} color="var(--orange-300)" />
                Need help?
              </div>
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '24px',
                  lineHeight: '1.25',
                  fontWeight: '700',
                  color: 'var(--white)',
                }}
              >
                Ask our experts
              </div>
              <p style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--neutral-200)', margin: '0 0 8px' }}>
                Paediatricians, psychologists and educators answer within 48 hours — you can ask anonymously.
              </p>
              <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                <a href={toUrl('/ask-the-expert')} style={{ textDecoration: 'none' }}>
                  <Button variant="primary" icon="message-circle">
                    Ask a question
                  </Button>
                </a>
                <a
                  className="hv-i"
                  href={toUrl('/join')}
                  style={{
                    height: '48px',
                    padding: '0 18px',
                    borderRadius: 'var(--radius-md)',
                    border: '1.5px solid var(--neutral-600)',
                    color: 'var(--white)',
                    fontSize: '17px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    textDecoration: 'none',
                  }}
                >
                  Join free
                </a>
              </div>
            </div>
          </div>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,180px),1fr))',
              gap: '36px 32px',
              padding: '48px 0',
            }}
          >
            <nav aria-label="Read" style={{ display: 'flex', flexDirection: 'column', gap: '14px', minWidth: '0' }}>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-300)',
                }}
              >
                Read
              </div>
              <a
                className="hv-j"
                href={toUrl('/stories')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Stories
              </a>
              <a
                className="hv-j"
                href={toUrl('/parents-of-india')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Parents of India
              </a>
              <a
                className="hv-j"
                href={toUrl('/ask-the-expert')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Ask an expert
              </a>
              <a
                className="hv-j"
                href={toUrl('/search?query=')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Explore
              </a>
            </nav>
            <nav
              aria-label="Community"
              style={{ display: 'flex', flexDirection: 'column', gap: '14px', minWidth: '0' }}
            >
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-300)',
                }}
              >
                Community
              </div>
              <a
                className="hv-j"
                href={toUrl('/communities')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                All circles
              </a>
              <a
                className="hv-j"
                href={toUrl('/guidelines')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Community guidelines
              </a>
              <a
                className="hv-j"
                href={toUrl('/community-help')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Community help
              </a>
            </nav>
            <nav aria-label="Programs" style={{ display: 'flex', flexDirection: 'column', gap: '14px', minWidth: '0' }}>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-300)',
                }}
              >
                Programs
              </div>
              <a
                className="hv-j"
                href={toUrl('/programs')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                All programs
              </a>
              <a
                className="hv-j"
                href={toUrl('/superstar')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                SuperStar Parenting
              </a>
              <a
                className="hv-j"
                href={toUrl('/programs')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Little Learners @Home
              </a>
            </nav>
            <nav aria-label="About" style={{ display: 'flex', flexDirection: 'column', gap: '14px', minWidth: '0' }}>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-300)',
                }}
              >
                About
              </div>
              <a
                className="hv-j"
                href={toUrl('/about')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                About us
              </a>
              <a
                className="hv-j"
                href={toUrl('/press')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Press releases
              </a>
              <a
                className="hv-j"
                href={toUrl('/contact')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Contact us
              </a>
            </nav>
          </div>
        </div>
        <div style={{ borderTop: '1px solid var(--neutral-700)' }}>
          <div
            style={{
              maxWidth: '1200px',
              margin: '0 auto',
              padding: '20px 24px 28px',
              boxSizing: 'border-box',
              display: 'flex',
              flexWrap: 'wrap',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: '12px 24px',
            }}
          >
            <span style={{ fontSize: '15px', lineHeight: '1.5', color: 'var(--neutral-300)' }}>
              © 2026 Shri Harini Media Ltd. · A Ramco Group company · Chennai
            </span>
            <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '8px 20px' }}>
              <a
                className="hv-j"
                href={toUrl('/privacy')}
                style={{ fontSize: '15px', color: 'var(--neutral-200)', textDecoration: 'none' }}
              >
                Privacy policy
              </a>
              <a
                className="hv-j"
                href={toUrl('/terms')}
                style={{ fontSize: '15px', color: 'var(--neutral-200)', textDecoration: 'none' }}
              >
                Terms of use
              </a>
              <a
                className="hv-i"
                href="#top"
                onClick={v.goTop}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  height: '40px',
                  padding: '0 14px',
                  borderRadius: '999px',
                  background: 'var(--neutral-800)',
                  fontSize: '15px',
                  fontWeight: '600',
                  color: 'var(--neutral-100)',
                  textDecoration: 'none',
                }}
              >
                <Icon name="arrow-up" size={16} color="currentColor" />
                Back to top
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
