import React from 'react';
import { PageLogicBase } from '../../lib/createPage';
import { toUrl, pageLocation } from '../../lib/paths';

class PageLogic extends PageLogicBase {
  state = {
    q: 'tantrums',
    input: 'tantrums',
    tab: 'all',
    ages: [],
    topics: [],
    moreTopics: false,
    saved: [],
    joined: [],
    following: [],
  };
  IMG = 'https://pcprd.azureedge.net/image/';
  AGES = [
    ['Infant', 'baby', '0–1 year', 'blush'],
    ['Toddler', 'footprints', '1–3 years', 'butter'],
    ['Pre-schooler', 'blocks', '3–5 years', 'sage'],
    ['Primary', 'backpack', '5–10 years', 'sky'],
    ['Pre-teen', 'bike', '10–12 years', 'lilac'],
    ['Teen', 'headphones', '13–17 years', 'blush'],
    ['18+', 'briefcase', 'Grown-up children', 'butter'],
    ['Parent', 'heart-handshake', 'Just for you', 'sage'],
  ];
  TOPICS = [
    ['Academics', 'Academics', 'sky', 'graduation-cap'],
    ['Baby care', 'Baby-Care', 'sage', 'baby'],
    ['Becoming a confident parent', 'Becoming-A-Confident-Parent', 'sky', 'shield-check'],
    ['Building skills', 'Building-Skill', 'butter', 'puzzle'],
    ['Community', 'Community', 'butter', 'message-circle'],
    ['Developmental conditions', 'Development-Condition', 'lilac', 'sprout'],
    ['Family life', 'Family', 'blush', 'users'],
    ['Health and fitness', 'Health-Fitness', 'sage', 'apple'],
    ['Illnesses', 'Illness', 'sage', 'stethoscope'],
    ['Managing child behaviour', 'Managing-Child-Behaviour', 'blush', 'heart'],
    ['Mental health', 'Mental-Health', 'blush', 'brain'],
    ['Nurturing families', 'Nurturing-Families', 'blush', 'house'],
    ['Parents of India', 'parents-of-india', 'sky', 'map-pin'],
    ['Pregnancy care', 'Pregnancy-Care', 'sage', 'heart-pulse'],
    ['Product reviews', 'Product-Reviews', 'butter', 'star'],
    ['Raising a confident child', 'Raising-Confident-Child', 'butter', 'sparkles'],
    ['Special education', 'Special-Education', 'lilac', 'book-open'],
    ['Special needs', 'Special-Needs', 'lilac', 'hand-heart'],
    ['Technology', 'Technology', 'lilac', 'smartphone'],
  ];
  ARTICLES = [
    [
      'How and when to respond to your child’s tantrums',
      'Is it a call for help, or a bid to get their way? A psychologist explains how to tell — and a five-step way to calm both.',
      'Managing child behaviour',
      ['Toddler', 'Pre-schooler'],
      'Saakshi Kapoor Kumar',
      9,
    ],
    [
      'Why tantrums peak at age two — and the one thing that calms them',
      'Your toddler’s feelings are bigger than their words. Here’s how to help them catch up.',
      'Managing child behaviour',
      ['Toddler'],
      'Dr. Meera Iyer',
      6,
    ],
    [
      'Public meltdowns: a calm plan for tantrums at the mall or temple',
      'What to do in the moment, what to say afterwards, and how to stop worrying about who’s watching.',
      'Managing child behaviour',
      ['Toddler', 'Pre-schooler'],
      'Priya Nair',
      5,
    ],
    [
      'Tantrum or sensory overload? How to tell the difference',
      'Some meltdowns are about too much noise, light or touch. A paediatrician explains the signs.',
      'Developmental conditions',
      ['Toddler', 'Pre-schooler', 'Primary'],
      'Dr. Kavitha Rao',
      7,
    ],
    [
      'Bedtime tantrums: a 15-minute routine that ends the battle',
      'Bath, two books, one song — and why the same order every night matters.',
      'Family life',
      ['Toddler', 'Pre-schooler'],
      'Dr. S. Raman',
      5,
    ],
    [
      'When your 8-year-old still has tantrums',
      'Older children melt down too. Most families find these three changes help within a fortnight.',
      'Managing child behaviour',
      ['Primary'],
      'Lakshmi Venkat',
      6,
    ],
    [
      'Teen anger is not a tantrum: what’s really going on',
      'Slammed doors usually mean stress, not disrespect. How to keep talking when they shut down.',
      'Mental health',
      ['Pre-teen', 'Teen'],
      'Dr. Arvind Shankar',
      8,
    ],
    [
      'Grandparents and tantrums: staying calm when it’s not your rule',
      'Three ways to support your grandchild — and their parents — at the same time.',
      'Nurturing families',
      ['Toddler', 'Pre-schooler', 'Parent'],
      'Ravi Kumar',
      5,
    ],
    [
      'Screen-time tantrums: how to switch off without the shouting',
      'Warnings, timers and a “last episode” rule that most families can keep.',
      'Technology',
      ['Pre-schooler', 'Primary'],
      'Sneha Pillai',
      5,
    ],
    [
      '5 iron-rich foods your toddler will actually eat',
      'Simple swaps for everyday Indian meals — ragi, dates, greens and more.',
      'Health and fitness',
      ['Toddler', 'Pre-schooler'],
      'Anjali Rao',
      5,
    ],
    [
      'Fever in babies: when to wait and when to call the doctor',
      'A paediatrician’s clear guide for worried parents and grandparents.',
      'Illnesses',
      ['Infant', 'Toddler'],
      'Dr. S. Raman',
      6,
    ],
    [
      'Night waking at 9 months: is it a sleep regression?',
      'What’s normal, what helps, and when to talk to your doctor.',
      'Baby care',
      ['Infant'],
      'Dr. Kavitha Rao',
      5,
    ],
    [
      'Homework without tears: a 20-minute routine that works',
      'Fewer reminders, more independence — tested by families in Chennai.',
      'Academics',
      ['Primary'],
      'Lakshmi Venkat',
      6,
    ],
    [
      'Talking to your teenager about screen time — without a fight',
      'Make an agreement together instead of laying down rules.',
      'Technology',
      ['Pre-teen', 'Teen'],
      'Ravi Kumar',
      7,
    ],
    [
      'Board exam stress: how to help without adding pressure',
      'What to say, what to skip, and how to spot when your teen needs more support.',
      'Academics',
      ['Teen'],
      'Dr. Arvind Shankar',
      8,
    ],
    [
      'Parents of India: the Madurai father who swapped his commute for school runs',
      'Why one dad changed jobs to spend his mornings with his twins — and what it taught him.',
      'Parents of India',
      ['Primary', 'Parent'],
      'ParentCircle team',
      6,
    ],
    [
      'Parents of India: raising three children in a Jaipur joint family',
      'Grandparents, cousins and one shared kitchen — what this family has learned about sharing the load.',
      'Parents of India',
      ['Parent'],
      'ParentCircle team',
      7,
    ],
    [
      'Parents of India: the Kochi mother who started a library on her street',
      'Forty books, one verandah and a Sunday story hour that now draws children from five lanes.',
      'Parents of India',
      ['Toddler', 'Pre-schooler', 'Primary'],
      'ParentCircle team',
      5,
    ],
    [
      'Is my child ready for Class 1? A gentle checklist',
      'It’s less about reading early and more about these six everyday skills.',
      'Academics',
      ['Pre-schooler', 'Primary'],
      'Lakshmi Venkat',
      8,
    ],
  ];
  CIRCLES = [
    [
      'Toddler Parents',
      '12,400 parents',
      'Everyday wins and wobbles from 1 to 3 years — tantrums, sleep and first words.',
      'Managing child behaviour',
      'tantrums toddler sleep',
    ],
    [
      'Calm Parenting',
      '5,600 parents',
      'Gentle ways to handle big feelings — yours and your child’s.',
      'Mental health',
      'tantrums anger calm behaviour',
    ],
    [
      'Grandparents Corner',
      '3,100 members',
      'For grandparents helping raise the next generation.',
      'Nurturing families',
      'tantrums grandparents homework',
    ],
    [
      'Parents of Teens',
      '8,700 parents',
      'Exams, screens, moods and everything in between.',
      'Technology',
      'teen screen exam anger',
    ],
    [
      'Picky Eaters',
      '4,200 parents',
      'Tiffin ideas and tips for children who won’t eat.',
      'Health and fitness',
      'food iron tiffin',
    ],
    [
      'Sleep Support',
      '6,300 parents',
      'Night waking, bedtimes and naps, from babies to school-goers.',
      'Baby care',
      'sleep bedtime night',
    ],
  ];
  DISCUSSIONS = [
    [
      '“My 3-year-old throws herself on the floor at every shop. What worked for you?”',
      'Toddler Parents',
      'Kavya S',
      48,
      true,
      ['Pre-schooler'],
      'Managing child behaviour',
    ],
    [
      'Do you ignore tantrums or talk through them?',
      'Calm Parenting',
      'Arjun M',
      31,
      false,
      ['Toddler', 'Pre-schooler'],
      'Managing child behaviour',
    ],
    [
      'Tantrums started after the new baby arrived — is this normal?',
      'Toddler Parents',
      'Deepa R',
      22,
      true,
      ['Toddler'],
      'Family life',
    ],
    [
      'My grandson’s tantrums at dinner — how do I handle them without upsetting his parents?',
      'Grandparents Corner',
      'Bala Narayanan',
      17,
      false,
      ['Pre-schooler', 'Parent'],
      'Nurturing families',
    ],
    [
      'Screen-off tantrums every evening. Timers? Warnings?',
      'Calm Parenting',
      'Shalini M',
      26,
      false,
      ['Primary'],
      'Technology',
    ],
    ['Night waking at 18 months — anyone else?', 'Sleep Support', 'Nisha K', 19, true, ['Toddler'], 'Baby care'],
    [
      'Tiffin ideas that actually come back empty?',
      'Picky Eaters',
      'Shalini M',
      40,
      false,
      ['Pre-schooler', 'Primary'],
      'Health and fitness',
    ],
  ];
  PEOPLE = [
    ['Saakshi Kapoor Kumar', 'Psychologist & educator', true, 'tantrums behaviour emotions'],
    ['Dr. Meera Iyer', 'Child psychologist, Chennai', true, 'tantrums behaviour sleep anger'],
    ['Priya Nair', 'Writer · parent of two', false, 'tantrums activities play'],
    ['Dr. S. Raman', 'Paediatrician', true, 'fever sleep bedtime iron'],
    ['Lakshmi Venkat', 'Early-years educator', true, 'homework school class tantrums'],
  ];
  POPULAR = ['Tantrums', 'Screen time', 'Sleep', 'Fever', 'Homework', 'Board exams', 'Picky eaters'];

  componentDidMount() {
    const p = new URLSearchParams(pageLocation().search);
    if (p.has('topic')) {
      const t = p.get('topic');
      this.setState({ q: '', input: '', topics: [t], moreTopics: true });
    } else if (p.has('query')) {
      const v = p.get('query') || '';
      this.setState({ q: v, input: v });
    }
  }
  topicMeta(name) {
    const t = this.TOPICS.find((x) => x[0] === name) || [name, '', 'neutral', 'book-open'];
    return { hue: t[2], icon: t[3] };
  }
  tokens(q) {
    return q
      .toLowerCase()
      .split(/\s+/)
      .filter(Boolean)
      .map((t) => t.replace(/[^\p{L}\p{N}-]/gu, ''))
      .filter(Boolean)
      .map((t) => (t.length > 3 ? t.replace(/(es|s)$/, '') : t));
  }
  match(text, toks) {
    const s = text.toLowerCase();
    return toks.every((t) => s.includes(t));
  }
  parts(text, toks) {
    if (!toks.length) return [{ t: text, bg: 'transparent' }];
    const re = new RegExp(
      '(' + toks.map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\p{L}*').join('|') + ')',
      'giu',
    );
    return text
      .split(re)
      .map((t, i) => ({ t, bg: i % 2 ? 'var(--butter-100)' : 'transparent' }))
      .filter((p) => p.t);
  }
  go(q) {
    const v = q.trim();
    this.setState({ q: v, input: v, tab: 'all', ages: [], topics: [] });
    try {
      history.replaceState(null, '', toUrl('/search?query=' + encodeURIComponent(v)));
    } catch (e) {}
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  toggle(key, v) {
    this.setState((s) => ({ [key]: s[key].includes(v) ? s[key].filter((x) => x !== v) : s[key].concat(v) }));
  }
  chip(on) {
    return on
      ? { bg: 'var(--neutral-900)', fg: 'var(--white)', bd: 'var(--neutral-900)' }
      : { bg: 'var(--white)', fg: 'var(--text-strong)', bd: 'var(--border-default)' };
  }
  plural(n, one, many) {
    return n === 1 ? '1 ' + one : n + ' ' + many;
  }

  renderVals() {
    const S = this.state,
      q = S.q.trim(),
      toks = this.tokens(q),
      nf0 = S.ages.length + S.topics.length,
      hasQ = toks.length > 0 || nf0 > 0,
      browsing = !toks.length && nf0 > 0;
    const ageOk = (a) => !S.ages.length || a.some((x) => S.ages.includes(x));
    const topOk = (t) => !S.topics.length || S.topics.includes(t);
    const arts = hasQ
      ? this.ARTICLES.filter(
          ([t, d, top, ages, au]) => this.match([t, d, top, au].join(' '), toks) && ageOk(ages) && topOk(top),
        )
      : [];
    const circ = hasQ
      ? this.CIRCLES.filter(([n, m, d, top, kw]) => this.match([n, d, kw].join(' '), toks) && topOk(top))
      : [];
    const disc = hasQ
      ? this.DISCUSSIONS.filter(
          ([t, c, au, r, e, ages, top]) => this.match([t, c].join(' '), toks) && ageOk(ages) && topOk(top),
        )
      : [];
    const ppl =
      toks.length && !S.ages.length && !S.topics.length
        ? this.PEOPLE.filter(([n, r, e, kw]) => this.match([n, r, kw].join(' '), toks))
        : [];
    const total = arts.length + circ.length + disc.length + ppl.length;
    const all = S.tab === 'all';
    const lim = (arr, n) => (all ? arr.slice(0, n) : arr);
    const shownTopics = S.moreTopics
      ? this.TOPICS
      : this.TOPICS.filter(
          (t, i) =>
            i < 0 ||
            [
              'Managing child behaviour',
              'Mental health',
              'Family life',
              'Health and fitness',
              'Academics',
              'Technology',
              'Baby care',
            ].includes(t[0]) ||
            S.topics.includes(t[0]),
        );
    const nf = S.ages.length + S.topics.length;
    return {
      heading: browsing
        ? 'Browse: ' + S.ages.concat(S.topics).join(' · ')
        : hasQ
          ? 'Results for “' + q + '”'
          : 'What would you like to know?',
      summary: hasQ
        ? total
          ? this.plural(total, 'result', 'results') + (nf ? ' with your filters' : '')
          : 'No results yet'
        : 'Search for a worry, a topic or an expert — or browse below.',
      input: S.input,
      onInput: (e) => this.setState({ input: e.target.value }),
      submit: (e) => {
        e.preventDefault();
        this.go(S.input);
      },
      focusSearch: () => {
        const i = document.querySelector('[data-search-main] input');
        if (i) {
          window.scrollTo({ top: 0, behavior: 'smooth' });
          i.focus();
          i.select();
        }
      },
      hasQuery: hasQ,
      tabs: [
        ['all', 'All', total],
        ['articles', 'Articles', arts.length],
        ['circles', 'Circles', circ.length],
        ['discussions', 'Discussions', disc.length],
        ['people', 'People', ppl.length],
      ].map(([value, l, n]) => ({ value, label: l + ' (' + n + ')' })),
      tab: S.tab,
      setTab: (v) => this.setState({ tab: v }),
      ageChips: this.AGES.map(([a]) => ({
        label: a,
        on: S.ages.includes(a),
        toggle: () => this.toggle('ages', a),
        ...this.chip(S.ages.includes(a)),
      })),
      topicChips: shownTopics.map(([t]) => ({
        label: t,
        on: S.topics.includes(t),
        toggle: () => this.toggle('topics', t),
        ...this.chip(S.topics.includes(t)),
      })),
      toggleMoreTopics: () => this.setState((s) => ({ moreTopics: !s.moreTopics })),
      moreTopicsLabel: S.moreTopics ? 'Fewer topics' : 'All 19 topics',
      moreTopicsIcon: S.moreTopics ? 'chevron-up' : 'chevron-down',
      hasFilters: nf > 0,
      filterSummary: this.plural(nf, 'filter', 'filters') + ' on',
      clearFilters: () => this.setState({ ages: [], topics: [] }),
      showArticles: arts.length > 0 && (all || S.tab === 'articles'),
      articleCount: arts.length,
      articlesMore: all && arts.length > 4,
      seeArticles: () => this.setState({ tab: 'articles' }),
      articles: lim(arts, 4).map(([t, d, top, ages, au, min]) => {
        const m = this.topicMeta(top),
          on = S.saved.includes(t);
        return {
          parts: this.parts(t, toks),
          dek: d,
          topic: top,
          meta: au + ' · ' + min + ' min read · ' + ages.join(', '),
          tint: 'var(--' + m.hue + '-50)',
          ink: 'var(--' + m.hue + '-700)',
          icon: m.icon,
          saveIcon: on ? 'bookmark-check' : 'bookmark',
          saveLabel: on ? 'Saved' : 'Save story',
          toggleSave: () => this.toggle('saved', t),
        };
      }),
      showCircles: circ.length > 0 && (all || S.tab === 'circles'),
      circleCount: circ.length,
      circlesMore: all && circ.length > 3,
      seeCircles: () => this.setState({ tab: 'circles' }),
      circles: lim(circ, 3).map(([n, mem, d, top]) => {
        const m = this.topicMeta(top),
          on = S.joined.includes(n);
        return {
          name: n,
          members: mem,
          desc: d,
          tint: 'var(--' + m.hue + '-50)',
          ink: 'var(--' + m.hue + '-700)',
          icon: 'users',
          joinLabel: on ? 'Joined' : 'Join circle',
          variant: on ? 'secondary' : 'dark',
          icon2: on ? 'check' : 'plus',
          toggle: () => this.toggle('joined', n),
        };
      }),
      showDiscussions: disc.length > 0 && (all || S.tab === 'discussions'),
      discussionCount: disc.length,
      discussionsMore: all && disc.length > 3,
      seeDiscussions: () => this.setState({ tab: 'discussions' }),
      discussions: lim(disc, 3).map(([t, c, au, r, e]) => ({
        parts: this.parts(t, toks),
        author: au,
        meta: au + ' in ' + c,
        replies: r + ' replies',
        expert: e,
      })),
      showPeople: ppl.length > 0 && (all || S.tab === 'people'),
      peopleCount: ppl.length,
      peopleMore: all && ppl.length > 3,
      seePeople: () => this.setState({ tab: 'people' }),
      people: lim(ppl, 3).map(([n, r, e]) => {
        const on = S.following.includes(n);
        return {
          name: n,
          role: r,
          expert: e,
          followLabel: on ? 'Following' : 'Follow',
          variant: on ? 'secondary' : 'dark',
          toggle: () => this.toggle('following', n),
        };
      }),
      noResults: hasQ && total === 0,
      noResultsTitle: nf || browsing ? 'Nothing matches these filters' : 'We couldn’t find “' + q + '”',
      noResultsHint: nf
        ? 'Try removing a filter, or search for a simpler word.'
        : 'Check the spelling or try a simpler word — or ask our experts directly.',
      showPopular: !hasQ || total === 0,
      popular: this.POPULAR.map((p) => ({ label: p, pick: () => this.go(p) })),
      ageTiles: this.AGES.map(([a, icon, range, hue]) => {
        const on = S.ages.includes(a);
        return {
          label: a,
          range,
          icon,
          ink: 'var(--' + hue + '-50)',
          on,
          tint: 'var(--' + hue + '-700)',
          bg: on ? 'var(--orange-50)' : 'var(--white)',
          bd: on ? 'var(--orange-600)' : 'transparent',
          pick: () => {
            this.toggle('ages', a);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          },
        };
      }),
      hasAgeFilter: S.ages.length > 0,
      clearAges: () => this.setState({ ages: [] }),
      topicTiles: this.TOPICS.map(([t, f, hue, icon]) => ({
        label: t,
        icon,
        tint: 'var(--' + hue + '-50)',
        ink: 'var(--' + hue + '-700)',
        pick: () => {
          this.setState({ topics: [t], moreTopics: true, tab: 'all' });
          window.scrollTo({ top: 0, behavior: 'smooth' });
        },
      })),
    };
  }
}

export default PageLogic;
