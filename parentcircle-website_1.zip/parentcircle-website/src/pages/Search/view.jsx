import { Fragment } from 'react';
import { Avatar, Badge, Button, Icon, IconButton, Input, Logo, Tabs } from '../../components/ds';
import { SiteFooter } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Search" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Search"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <header
        style={{
          position: 'sticky',
          top: '0',
          zIndex: '20',
          background: 'rgba(255,255,255,0.94)',
          backdropFilter: 'blur(8px)',
          WebkitBackdropFilter: 'blur(8px)',
          borderBottom: '1px solid var(--border-default)',
        }}
      >
        <div
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '0 24px',
            height: '72px',
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
          }}
        >
          <a
            href={toUrl('/')}
            aria-label="ParentCircle home"
            style={{ flex: 'none', display: 'flex', marginRight: '20px' }}
          >
            <Logo height={28} />
          </a>
          <nav
            aria-label="Main"
            data-main-nav=""
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              height: '44px',
              gap: '4px',
              flex: '0 1 auto',
              minWidth: '0',
              overflow: 'hidden',
            }}
          >
            <a
              className="hv-3"
              href={toUrl('/')}
              style={{
                height: '44px',
                padding: '0 12px',
                borderRadius: '999px',
                color: 'var(--text-muted)',
                fontSize: '17px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
                whiteSpace: 'nowrap',
              }}
            >
              Read
            </a>
            <a
              className="hv-3"
              href={toUrl('/#watch')}
              style={{
                height: '44px',
                padding: '0 12px',
                borderRadius: '999px',
                color: 'var(--text-muted)',
                fontSize: '17px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
                whiteSpace: 'nowrap',
              }}
            >
              Watch
            </a>
            <a
              className="hv-3"
              href={toUrl('/communities')}
              style={{
                height: '44px',
                padding: '0 12px',
                borderRadius: '999px',
                color: 'var(--text-muted)',
                fontSize: '17px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
                whiteSpace: 'nowrap',
              }}
            >
              Community
            </a>
            <a
              className="hv-3"
              href={toUrl('/#programs')}
              style={{
                height: '44px',
                padding: '0 12px',
                borderRadius: '999px',
                color: 'var(--text-muted)',
                fontSize: '17px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
                whiteSpace: 'nowrap',
              }}
            >
              Programs
            </a>
          </nav>
          <details data-more-menu="" style={{ position: 'static', flex: 'none', marginLeft: '-8px' }}>
            <summary
              className="hv-3"
              style={{
                height: '44px',
                padding: '0 10px 0 12px',
                borderRadius: '999px',
                color: 'var(--text-muted)',
                fontSize: '17px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                cursor: 'pointer',
                listStyle: 'none',
                whiteSpace: 'nowrap',
                userSelect: 'none',
              }}
            >
              More
              <Icon name="chevron-down" size={16} />
            </summary>
            <div
              style={{
                position: 'absolute',
                top: 'calc(100% + 8px)',
                left: '50%',
                transform: 'translateX(-50%)',
                zIndex: '40',
                width: 'min(940px, calc(100% - 32px))',
                maxHeight: 'calc(100vh - 96px)',
                overflow: 'auto',
                padding: '16px',
                boxSizing: 'border-box',
                borderRadius: '20px',
                background: 'var(--white)',
                border: '1px solid var(--border-default)',
                boxShadow: 'var(--shadow-lg)',
                display: 'flex',
                flexDirection: 'column',
                gap: '8px',
              }}
            >
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,180px),1fr))',
                  gap: '8px 20px',
                }}
              >
                <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                  <div
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--text-muted)',
                      padding: '6px 10px 6px',
                    }}
                  >
                    Read
                  </div>
                  <a
                    className="hv-0"
                    href={toUrl('/search?query=')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="compass" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Explore</span>
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/stories')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="book-open" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Stories</span>
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/parents-of-india')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="map-pin" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Parents of India</span>
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/ask-the-expert')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="stethoscope" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Ask an expert</span>
                  </a>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                  <div
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--text-muted)',
                      padding: '6px 10px 6px',
                    }}
                  >
                    Community
                  </div>
                  <a
                    className="hv-0"
                    href={toUrl('/communities')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="users" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Community</span>
                    <span
                      style={{
                        height: '22px',
                        padding: '0 8px',
                        borderRadius: '999px',
                        background: 'var(--orange-600)',
                        color: 'var(--white)',
                        fontSize: '14px',
                        fontWeight: '700',
                        display: 'inline-flex',
                        alignItems: 'center',
                      }}
                    >
                      New
                    </span>
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/guidelines')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="shield-check" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Community guidelines</span>
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/community-help')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="life-buoy" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Community help</span>
                  </a>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                  <div
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--text-muted)',
                      padding: '6px 10px 6px',
                    }}
                  >
                    Initiatives
                  </div>
                  <a
                    className="hv-0"
                    href="https://www.parentcircle.com/gadget-free-hour/"
                    target="_blank"
                    rel="noopener"
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="hourglass" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Gadget Free Hour</span>
                    <Icon name="arrow-up-right" size={16} color="var(--neutral-400)" />
                  </a>
                  <a
                    className="hv-0"
                    href="https://www.dotlearningcircle.com/"
                    target="_blank"
                    rel="noopener"
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="graduation-cap" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>The Dot Learning Circle</span>
                    <Icon name="arrow-up-right" size={16} color="var(--neutral-400)" />
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/press')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="newspaper" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Press releases</span>
                  </a>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                  <div
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--text-muted)',
                      padding: '6px 10px 6px',
                    }}
                  >
                    About
                  </div>
                  <a
                    className="hv-0"
                    href={toUrl('/about')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="info" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>About us</span>
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/privacy')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="lock" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Privacy policy</span>
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/terms')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="file-text" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Terms of use</span>
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/contact')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="mail" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Contact us</span>
                  </a>
                </div>
              </div>
            </div>
          </details>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 'none', marginLeft: 'auto' }}>
            <IconButton icon="search" label="Search" onClick={v.focusSearch} />
            <span data-auth="out" style={{ display: 'contents' }}>
              <a href={toUrl('/sign-in')} style={{ display: 'flex', textDecoration: 'none' }}>
                <Button variant="ghost" size="sm">
                  Sign in
                </Button>
              </a>{' '}
              <a href={toUrl('/join')} style={{ display: 'flex', textDecoration: 'none' }}>
                <Button variant="primary" size="sm">
                  Join free
                </Button>
              </a>
            </span>
            <span data-auth="in" style={{ display: 'none', alignItems: 'center', gap: '8px' }}>
              <a
                className="hv-3"
                href={toUrl('/profile#notification')}
                aria-label="Notifications, 3 new"
                style={{
                  position: 'relative',
                  width: '48px',
                  height: '48px',
                  borderRadius: '999px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: 'var(--text-strong)',
                  textDecoration: 'none',
                }}
              >
                <Icon name="bell" size={22} />
                <span
                  style={{
                    position: 'absolute',
                    top: '6px',
                    right: '6px',
                    minWidth: '18px',
                    height: '18px',
                    padding: '0 5px',
                    boxSizing: 'border-box',
                    borderRadius: '999px',
                    background: 'var(--orange-600)',
                    color: 'var(--white)',
                    fontSize: '12px',
                    fontWeight: '700',
                    lineHeight: '18px',
                    textAlign: 'center',
                    boxShadow: '0 0 0 2px var(--white)',
                  }}
                >
                  3
                </span>
              </a>{' '}
              <a
                className="hv-0"
                href={toUrl('/profile#activities')}
                aria-label="Your profile"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  height: '44px',
                  padding: '0 14px 0 4px',
                  borderRadius: '999px',
                  border: '1px solid var(--border-default)',
                  textDecoration: 'none',
                  color: 'var(--text-strong)',
                }}
              >
                <Avatar name="Priya Raman" size={36} />
                <span data-auth-name="" style={{ fontSize: '16px', fontWeight: '600' }}>
                  Priya
                </span>
              </a>
            </span>
          </div>
        </div>
      </header>
      <section style={{ background: 'var(--neutral-50)', borderBottom: '1px solid var(--border-subtle)' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '36px 24px 28px', boxSizing: 'border-box' }}>
          <div
            style={{
              fontSize: '14px',
              fontWeight: '700',
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              color: 'var(--orange-700)',
              marginBottom: '10px',
            }}
          >
            Explore
          </div>
          <h1
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(30px,4vw,44px)',
              lineHeight: '1.15',
              letterSpacing: '-0.015em',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0 0 20px',
              textWrap: 'balance',
            }}
          >
            {v.heading}
          </h1>
          <form
            data-search-main=""
            role="search"
            onSubmit={v.submit}
            style={{
              display: 'flex',
              gap: '12px',
              flexWrap: 'wrap',
              alignItems: 'flex-start',
              maxWidth: '760px',
              margin: '0',
            }}
          >
            <div style={{ flex: '1 1 320px', minWidth: '0' }}>
              <Input
                icon="search"
                placeholder="Search stories, circles, discussions and people"
                aria-label="Search ParentCircle"
                value={v.input}
                onChange={v.onInput}
              />
            </div>
            <Button variant="primary" type="submit" icon="search">
              Search
            </Button>
          </form>
          <p style={{ fontSize: '16px', color: 'var(--text-muted)', margin: '12px 0 0', minHeight: '24px' }}>
            {v.summary}
          </p>
        </div>
      </section>
      <main style={{ maxWidth: '1200px', margin: '0 auto', padding: '28px 24px 0', boxSizing: 'border-box' }}>
        {v.hasQuery ? (
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
              padding: '20px',
              borderRadius: '20px',
              background: 'var(--neutral-50)',
            }}
          >
            <div style={{ display: 'flex', gap: '10px 16px', flexWrap: 'wrap', alignItems: 'center' }}>
              <span
                style={{
                  flex: 'none',
                  width: '92px',
                  fontSize: '15px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                }}
              >
                Age group
              </span>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', flex: '1', minWidth: '0' }}>
                {(v.ageChips ?? []).map((c, $i0) => (
                  <Fragment key={$i0}>
                    <button
                      type="button"
                      aria-pressed={c?.on}
                      onClick={c?.toggle}
                      style={{
                        height: '40px',
                        padding: '0 14px',
                        borderRadius: '999px',
                        border: `1.5px solid ${c?.bd ?? ''}`,
                        background: c?.bg,
                        color: c?.fg,
                        font: 'inherit',
                        fontSize: '15px',
                        fontWeight: '600',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        cursor: 'pointer',
                        transition: 'background 150ms',
                      }}
                    >
                      {c?.label}
                    </button>
                  </Fragment>
                ))}
              </div>
            </div>
            <div style={{ display: 'flex', gap: '10px 16px', flexWrap: 'wrap', alignItems: 'flex-start' }}>
              <span
                style={{
                  flex: 'none',
                  width: '92px',
                  fontSize: '15px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  lineHeight: '40px',
                }}
              >
                Topic
              </span>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', flex: '1', minWidth: '0' }}>
                {(v.topicChips ?? []).map((c, $i0) => (
                  <Fragment key={$i0}>
                    <button
                      type="button"
                      aria-pressed={c?.on}
                      onClick={c?.toggle}
                      style={{
                        height: '40px',
                        padding: '0 14px',
                        borderRadius: '999px',
                        border: `1.5px solid ${c?.bd ?? ''}`,
                        background: c?.bg,
                        color: c?.fg,
                        font: 'inherit',
                        fontSize: '15px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        transition: 'background 150ms',
                      }}
                    >
                      {c?.label}
                    </button>
                  </Fragment>
                ))}
                <button
                  className="hv-8"
                  type="button"
                  onClick={v.toggleMoreTopics}
                  style={{
                    height: '40px',
                    padding: '0 10px',
                    border: '0',
                    background: 'none',
                    font: 'inherit',
                    fontSize: '15px',
                    fontWeight: '700',
                    color: 'var(--text-link)',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px',
                    cursor: 'pointer',
                  }}
                >
                  {v.moreTopicsLabel}
                  <Icon name={v.moreTopicsIcon} size={16} />
                </button>
              </div>
            </div>
            {v.hasFilters ? (
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  flexWrap: 'wrap',
                  fontSize: '15px',
                  color: 'var(--text-muted)',
                }}
              >
                <span>{v.filterSummary}</span>
                <button
                  className="hv-8"
                  type="button"
                  onClick={v.clearFilters}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px',
                    border: '0',
                    background: 'none',
                    padding: '6px 0',
                    font: 'inherit',
                    fontWeight: '700',
                    color: 'var(--text-link)',
                    cursor: 'pointer',
                  }}
                >
                  <Icon name="x" size={16} />
                  Clear filters
                </button>
              </div>
            ) : null}
          </div>
        ) : null}
        {v.hasQuery ? (
          <div style={{ paddingTop: '20px', overflowX: 'auto', overflowY: 'hidden' }}>
            <Tabs variant="pill" tabs={v.tabs} value={v.tab} onChange={v.setTab} />
          </div>
        ) : null}
        <div
          style={{ display: 'flex', flexWrap: 'wrap', gap: '40px 56px', alignItems: 'flex-start', paddingTop: '28px' }}
        >
          <div style={{ flex: '999 1 560px', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '48px' }}>
            {v.showArticles ? (
              <section aria-labelledby="h-articles">
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'baseline',
                    justifyContent: 'space-between',
                    gap: '12px',
                    marginBottom: '4px',
                  }}
                >
                  <h2
                    id="h-articles"
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '26px',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      margin: '0',
                    }}
                  >
                    {'Articles '}
                    <span
                      style={{
                        fontFamily: 'var(--font-ui)',
                        fontSize: '17px',
                        fontWeight: '600',
                        color: 'var(--text-muted)',
                      }}
                    >
                      {v.articleCount}
                    </span>
                  </h2>
                  {v.articlesMore ? (
                    <button
                      className="hv-8"
                      type="button"
                      onClick={v.seeArticles}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                        border: '0',
                        background: 'none',
                        padding: '8px 0',
                        font: 'inherit',
                        fontSize: '16px',
                        fontWeight: '700',
                        color: 'var(--text-link)',
                        cursor: 'pointer',
                      }}
                    >
                      See all
                      <Icon name="arrow-right" size={16} />
                    </button>
                  ) : null}
                </div>
                {(v.articles ?? []).map((a, $i0) => (
                  <Fragment key={$i0}>
                    <div
                      style={{
                        display: 'flex',
                        gap: '20px',
                        alignItems: 'flex-start',
                        padding: '22px 0',
                        borderBottom: '1px solid var(--border-subtle)',
                      }}
                    >
                      <a
                        className="hv-c"
                        href={toUrl('/article')}
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '8px',
                          textDecoration: 'none',
                          color: 'inherit',
                        }}
                      >
                        <span
                          style={{
                            fontSize: '14px',
                            fontWeight: '700',
                            letterSpacing: '0.08em',
                            textTransform: 'uppercase',
                            color: a?.ink,
                          }}
                        >
                          {a?.topic}
                        </span>
                        <span
                          style={{
                            fontFamily: 'var(--font-display)',
                            fontSize: '21px',
                            lineHeight: '1.3',
                            fontWeight: '700',
                            color: 'var(--text-strong)',
                            textWrap: 'pretty',
                          }}
                        >
                          {(a?.parts ?? []).map((p, $i1) => (
                            <Fragment key={$i1}>
                              <span style={{ background: p?.bg, borderRadius: '3px' }}>{p?.t}</span>
                            </Fragment>
                          ))}
                        </span>
                        <span
                          style={{
                            fontFamily: 'var(--font-serif)',
                            fontSize: '17px',
                            lineHeight: '1.5',
                            color: 'var(--text-body)',
                            textWrap: 'pretty',
                          }}
                        >
                          {a?.dek}
                        </span>
                        <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{a?.meta}</span>
                      </a>
                      <div
                        style={{
                          flex: 'none',
                          display: 'flex',
                          flexDirection: 'column',
                          alignItems: 'flex-end',
                          gap: '8px',
                        }}
                      >
                        <a
                          href={toUrl('/article')}
                          aria-hidden="true"
                          tabIndex="-1"
                          style={{
                            width: 'clamp(96px,18vw,168px)',
                            aspectRatio: '4 / 3',
                            borderRadius: '16px',
                            background: a?.tint,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}
                        >
                          <Icon name={a?.icon} size={32} color={a?.ink} />
                        </a>
                        <IconButton icon={a?.saveIcon} label={a?.saveLabel} onClick={a?.toggleSave} />
                      </div>
                    </div>
                  </Fragment>
                ))}
              </section>
            ) : null}
            {v.showCircles ? (
              <section aria-labelledby="h-circles">
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'baseline',
                    justifyContent: 'space-between',
                    gap: '12px',
                    marginBottom: '16px',
                  }}
                >
                  <h2
                    id="h-circles"
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '26px',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      margin: '0',
                    }}
                  >
                    {'Circles '}
                    <span
                      style={{
                        fontFamily: 'var(--font-ui)',
                        fontSize: '17px',
                        fontWeight: '600',
                        color: 'var(--text-muted)',
                      }}
                    >
                      {v.circleCount}
                    </span>
                  </h2>
                  {v.circlesMore ? (
                    <button
                      className="hv-8"
                      type="button"
                      onClick={v.seeCircles}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                        border: '0',
                        background: 'none',
                        padding: '8px 0',
                        font: 'inherit',
                        fontSize: '16px',
                        fontWeight: '700',
                        color: 'var(--text-link)',
                        cursor: 'pointer',
                      }}
                    >
                      See all
                      <Icon name="arrow-right" size={16} />
                    </button>
                  ) : null}
                </div>
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,240px),1fr))',
                    gap: '16px',
                  }}
                >
                  {(v.circles ?? []).map((c, $i0) => (
                    <Fragment key={$i0}>
                      <div
                        style={{
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '12px',
                          padding: '20px',
                          borderRadius: '16px',
                          border: '1px solid var(--border-default)',
                          background: 'var(--white)',
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                          <span
                            style={{
                              width: '48px',
                              height: '48px',
                              flex: 'none',
                              borderRadius: '14px',
                              background: c?.tint,
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                            }}
                          >
                            <Icon name={c?.icon} size={24} color={c?.ink} />
                          </span>
                          <a
                            className="hv-b"
                            href={toUrl('/communities')}
                            style={{ minWidth: '0', textDecoration: 'none', color: 'inherit' }}
                          >
                            <div style={{ fontSize: '18px', fontWeight: '700', color: 'var(--text-strong)' }}>
                              {c?.name}
                            </div>
                            <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{c?.members}</div>
                          </a>
                        </div>
                        <p
                          style={{
                            fontSize: '16px',
                            lineHeight: '1.5',
                            color: 'var(--text-body)',
                            margin: '0',
                            flex: '1',
                          }}
                        >
                          {c?.desc}
                        </p>
                        <Button variant={c?.variant} size="sm" icon={c?.icon2} fullWidth={true} onClick={c?.toggle}>
                          {c?.joinLabel}
                        </Button>
                      </div>
                    </Fragment>
                  ))}
                </div>
              </section>
            ) : null}
            {v.showDiscussions ? (
              <section aria-labelledby="h-disc">
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'baseline',
                    justifyContent: 'space-between',
                    gap: '12px',
                    marginBottom: '4px',
                  }}
                >
                  <h2
                    id="h-disc"
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '26px',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      margin: '0',
                    }}
                  >
                    {'Discussions '}
                    <span
                      style={{
                        fontFamily: 'var(--font-ui)',
                        fontSize: '17px',
                        fontWeight: '600',
                        color: 'var(--text-muted)',
                      }}
                    >
                      {v.discussionCount}
                    </span>
                  </h2>
                  {v.discussionsMore ? (
                    <button
                      className="hv-8"
                      type="button"
                      onClick={v.seeDiscussions}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                        border: '0',
                        background: 'none',
                        padding: '8px 0',
                        font: 'inherit',
                        fontSize: '16px',
                        fontWeight: '700',
                        color: 'var(--text-link)',
                        cursor: 'pointer',
                      }}
                    >
                      See all
                      <Icon name="arrow-right" size={16} />
                    </button>
                  ) : null}
                </div>
                {(v.discussions ?? []).map((d, $i0) => (
                  <Fragment key={$i0}>
                    <a
                      className="hv-c"
                      href={toUrl('/communities')}
                      style={{
                        display: 'flex',
                        gap: '14px',
                        alignItems: 'flex-start',
                        padding: '18px 0',
                        borderBottom: '1px solid var(--border-subtle)',
                        textDecoration: 'none',
                        color: 'inherit',
                      }}
                    >
                      <Avatar name={d?.author} size={40} />
                      <span style={{ flex: '1', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                        <span
                          style={{
                            fontFamily: 'var(--font-display)',
                            fontSize: '19px',
                            lineHeight: '1.35',
                            fontWeight: '700',
                            color: 'var(--text-strong)',
                            textWrap: 'pretty',
                          }}
                        >
                          {(d?.parts ?? []).map((p, $i1) => (
                            <Fragment key={$i1}>
                              <span style={{ background: p?.bg, borderRadius: '3px' }}>{p?.t}</span>
                            </Fragment>
                          ))}
                        </span>
                        <span
                          style={{
                            display: 'flex',
                            flexWrap: 'wrap',
                            alignItems: 'center',
                            gap: '6px 12px',
                            fontSize: '15px',
                            color: 'var(--text-muted)',
                          }}
                        >
                          <span>{d?.meta}</span>
                          <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                            <Icon name="message-circle" size={16} />
                            {d?.replies}
                          </span>
                          {d?.expert ? (
                            <Badge tone="success" icon="shield-check">
                              Expert answer
                            </Badge>
                          ) : null}
                        </span>
                      </span>
                    </a>
                  </Fragment>
                ))}
              </section>
            ) : null}
            {v.showPeople ? (
              <section aria-labelledby="h-people">
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'baseline',
                    justifyContent: 'space-between',
                    gap: '12px',
                    marginBottom: '16px',
                  }}
                >
                  <h2
                    id="h-people"
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '26px',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      margin: '0',
                    }}
                  >
                    {'People '}
                    <span
                      style={{
                        fontFamily: 'var(--font-ui)',
                        fontSize: '17px',
                        fontWeight: '600',
                        color: 'var(--text-muted)',
                      }}
                    >
                      {v.peopleCount}
                    </span>
                  </h2>
                  {v.peopleMore ? (
                    <button
                      className="hv-8"
                      type="button"
                      onClick={v.seePeople}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                        border: '0',
                        background: 'none',
                        padding: '8px 0',
                        font: 'inherit',
                        fontSize: '16px',
                        fontWeight: '700',
                        color: 'var(--text-link)',
                        cursor: 'pointer',
                      }}
                    >
                      See all
                      <Icon name="arrow-right" size={16} />
                    </button>
                  ) : null}
                </div>
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,260px),1fr))',
                    gap: '12px',
                  }}
                >
                  {(v.people ?? []).map((u, $i0) => (
                    <Fragment key={$i0}>
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '14px',
                          padding: '16px',
                          borderRadius: '16px',
                          border: '1px solid var(--border-default)',
                        }}
                      >
                        <Avatar name={u?.name} size={52} />
                        <div style={{ flex: '1', minWidth: '0' }}>
                          <div style={{ fontSize: '17px', fontWeight: '700', color: 'var(--text-strong)' }}>
                            {u?.name}
                          </div>
                          <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{u?.role}</div>
                        </div>
                        <Button variant={u?.variant} size="sm" onClick={u?.toggle}>
                          {u?.followLabel}
                        </Button>
                      </div>
                    </Fragment>
                  ))}
                </div>
              </section>
            ) : null}
            {v.noResults ? (
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'flex-start',
                  gap: '16px',
                  padding: '32px',
                  borderRadius: '24px',
                  background: 'var(--neutral-50)',
                }}
              >
                <span
                  style={{
                    width: '56px',
                    height: '56px',
                    borderRadius: '50%',
                    background: 'var(--white)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="search-x" size={28} color="var(--text-muted)" />
                </span>
                <h2
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '26px',
                    lineHeight: '1.25',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0',
                  }}
                >
                  {v.noResultsTitle}
                </h2>
                <p style={{ fontSize: '17px', lineHeight: '1.55', color: 'var(--text-body)', margin: '0' }}>
                  {v.noResultsHint}
                </p>
                <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                  {v.hasFilters ? (
                    <Button variant="dark" icon="x" onClick={v.clearFilters}>
                      Clear filters
                    </Button>
                  ) : null}
                  <a href={toUrl('/ask-the-expert')} style={{ textDecoration: 'none' }}>
                    <Button variant="secondary" icon="message-circle">
                      Ask an expert
                    </Button>
                  </a>
                </div>
              </div>
            ) : null}
            {v.showPopular ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                <div
                  style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--text-muted)',
                  }}
                >
                  Popular searches
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  {(v.popular ?? []).map((p, $i0) => (
                    <Fragment key={$i0}>
                      <button
                        className="hv-e"
                        type="button"
                        onClick={p?.pick}
                        style={{
                          height: '44px',
                          padding: '0 16px',
                          borderRadius: '999px',
                          border: '1.5px solid var(--border-default)',
                          background: 'var(--white)',
                          font: 'inherit',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--text-strong)',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '8px',
                          cursor: 'pointer',
                        }}
                      >
                        <Icon name="trending-up" size={16} color="var(--text-muted)" />
                        {p?.label}
                      </button>
                    </Fragment>
                  ))}
                </div>
              </div>
            ) : null}
          </div>
          <aside style={{ flex: '1 1 300px', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '28px' }}>
            <div style={{ padding: '24px', borderRadius: '16px', background: 'var(--sage-50)' }}>
              <Icon name="stethoscope" size={28} color="var(--sage-700)" />
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '22px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '10px 0 6px',
                }}
              >
                Still looking?
              </div>
              <p style={{ fontSize: '16px', lineHeight: '1.5', color: 'var(--text-body)', margin: '0 0 16px' }}>
                Our paediatricians, psychologists and educators answer within 48 hours.
              </p>
              <a href={toUrl('/ask-the-expert')} style={{ display: 'block', textDecoration: 'none' }}>
                <Button variant="dark" icon="message-circle" fullWidth={true}>
                  Ask an expert
                </Button>
              </a>
            </div>
          </aside>
        </div>
      </main>
      <section style={{ marginTop: '80px', background: 'var(--orange-50)' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '56px 24px', boxSizing: 'border-box' }}>
          <div role="group" aria-labelledby="age-strip-label">
            <div
              style={{
                display: 'flex',
                alignItems: 'baseline',
                justifyContent: 'space-between',
                gap: '12px',
                flexWrap: 'wrap',
                marginBottom: '12px',
              }}
            >
              <h2
                id="age-strip-label"
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(28px,3vw,36px)',
                  lineHeight: '1.2',
                  letterSpacing: '-0.01em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                }}
              >
                Explore by age group
              </h2>
              {v.hasAgeFilter ? (
                <button
                  className="hv-8"
                  type="button"
                  onClick={v.clearAges}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px',
                    border: '0',
                    background: 'none',
                    padding: '6px 0',
                    font: 'inherit',
                    fontSize: '15px',
                    fontWeight: '700',
                    color: 'var(--text-link)',
                    cursor: 'pointer',
                  }}
                >
                  <Icon name="x" size={16} />
                  All ages
                </button>
              ) : null}
            </div>
            <div>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,128px),1fr))',
                  gap: '12px',
                }}
              >
                {(v.ageTiles ?? []).map((t, $i0) => (
                  <Fragment key={$i0}>
                    <button
                      className="hv-o"
                      type="button"
                      aria-pressed={t?.on}
                      onClick={t?.pick}
                      style={{
                        position: 'relative',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        gap: '8px',
                        padding: '16px 8px 14px',
                        borderRadius: '16px',
                        border: `2px solid ${t?.bd ?? ''}`,
                        background: t?.bg,
                        font: 'inherit',
                        cursor: 'pointer',
                        boxShadow: 'var(--shadow-xs)',
                        transition: 'transform 200ms cubic-bezier(.2,0,0,1), box-shadow 200ms cubic-bezier(.2,0,0,1)',
                      }}
                    >
                      <span
                        style={{
                          width: '72px',
                          height: '72px',
                          borderRadius: '50%',
                          background: t?.tint,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}
                      >
                        <Icon name={t?.icon} size={32} color={t?.ink} />
                      </span>
                      <span
                        style={{
                          fontSize: '16px',
                          fontWeight: '700',
                          color: 'var(--text-strong)',
                          lineHeight: '1.2',
                          textAlign: 'center',
                          hyphens: 'manual',
                          overflowWrap: 'normal',
                          wordBreak: 'keep-all',
                        }}
                      >
                        {t?.label}
                      </span>
                      <span
                        style={{ fontSize: '14px', color: 'var(--text-muted)', lineHeight: '1.2', textAlign: 'center' }}
                      >
                        {t?.range}
                      </span>
                      {t?.on ? (
                        <span
                          style={{
                            position: 'absolute',
                            top: '8px',
                            right: '8px',
                            width: '24px',
                            height: '24px',
                            borderRadius: '50%',
                            background: 'var(--orange-600)',
                            color: 'var(--white)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}
                        >
                          <Icon name="check" size={14} />
                        </span>
                      ) : null}
                    </button>
                  </Fragment>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
      <section style={{ background: 'var(--white)', borderTop: '1px solid var(--border-subtle)' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '56px 24px 72px', boxSizing: 'border-box' }}>
          <h2
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(28px,3vw,36px)',
              lineHeight: '1.2',
              letterSpacing: '-0.01em',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0 0 6px',
            }}
          >
            Explore topics
          </h2>
          <p style={{ fontSize: '18px', color: 'var(--text-body)', margin: '0 0 24px' }}>
            Everything we write about, from baby care to board exams.
          </p>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,240px),1fr))',
              gap: '12px',
            }}
          >
            {(v.topicTiles ?? []).map((t, $i0) => (
              <Fragment key={$i0}>
                <button
                  className="hv-o"
                  type="button"
                  onClick={t?.pick}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    padding: '14px',
                    borderRadius: '16px',
                    border: '1px solid var(--border-default)',
                    background: 'var(--white)',
                    font: 'inherit',
                    textAlign: 'left',
                    cursor: 'pointer',
                    transition: 'transform 200ms cubic-bezier(.2,0,0,1), box-shadow 200ms cubic-bezier(.2,0,0,1)',
                  }}
                >
                  <span
                    style={{
                      width: '44px',
                      height: '44px',
                      flex: 'none',
                      borderRadius: '12px',
                      background: t?.tint,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <Icon name={t?.icon} size={22} color={t?.ink} />
                  </span>
                  <span
                    style={{
                      minWidth: '0',
                      fontSize: '16px',
                      fontWeight: '600',
                      lineHeight: '1.3',
                      color: 'var(--text-strong)',
                      overflowWrap: 'anywhere',
                    }}
                  >
                    {t?.label}
                  </span>
                </button>
              </Fragment>
            ))}
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
