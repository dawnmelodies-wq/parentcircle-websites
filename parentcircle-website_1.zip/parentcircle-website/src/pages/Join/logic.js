import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  componentDidUpdate() {
    if (this.state.step >= 3 && !this._authed) {
      this._authed = true;
      try {
        localStorage.setItem('pc-signed-in', '1');
        const n = (this.state.name || '').trim().split(' ')[0];
        if (n) localStorage.setItem('pc-user-name', n);
      } catch (e) {}
    }
  }
  state = {
    step: 1,
    name: '',
    id: '',
    pw: '',
    showPw: false,
    err: {},
    busy: false,
    otp: ['', '', '', ''],
    resendIn: 30,
    ages: [],
    topics: [],
    photo: '',
    zoom: 100,
    gender: '',
    dob: '',
    city: '',
    cityPicked: false,
    kids: [{ name: '', gender: '', dob: '' }],
  };
  otpEls = [];
  fileEl = null;
  AGES = [
    ['Infant', '0–1'],
    ['Toddler', '1–3'],
    ['Pre-schooler', '3–5'],
    ['Primary', '5–10'],
    ['Pre-teen', '10–12'],
    ['Teen', '13–17'],
    ['18+', ''],
    ['Parent', 'for me'],
  ];
  TOPICS = [
    'Academics',
    'Baby care',
    'Becoming a confident parent',
    'Building skills',
    'Community',
    'Developmental conditions',
    'Family life',
    'Health and fitness',
    'Illnesses',
    'Managing child behaviour',
    'Mental health',
    'Nurturing families',
    'Parents of India',
    'Pregnancy care',
    'Product reviews',
    'Raising a confident child',
    'Special education',
    'Special needs',
    'Technology',
  ];
  CITIES = [
    'Chennai',
    'Bengaluru',
    'Mumbai',
    'Delhi',
    'Hyderabad',
    'Kolkata',
    'Pune',
    'Ahmedabad',
    'Coimbatore',
    'Madurai',
    'Kochi',
    'Jaipur',
    'Lucknow',
    'Chandigarh',
    'Mysuru',
    'Tiruchirappalli',
    'Visakhapatnam',
    'Bhubaneswar',
    'Indore',
    'Nagpur',
    'Thiruvananthapuram',
    'Salem',
    'Puducherry',
    'Noida',
    'Gurugram',
  ];
  LABELS = ['Create your account', 'Verify', 'Ages', 'Topics', 'Photo', 'About you', 'Birthday', 'City', 'Children'];
  componentWillUnmount() {
    clearInterval(this.timer);
    clearTimeout(this.t);
  }
  startTimer() {
    clearInterval(this.timer);
    this.setState({ resendIn: 30 });
    this.timer = setInterval(
      () =>
        this.setState((s) => {
          if (s.resendIn <= 1) clearInterval(this.timer);
          return { resendIn: Math.max(0, s.resendIn - 1) };
        }),
      1000,
    );
  }
  validId(v) {
    const s = v.replace(/[\s-]/g, '');
    return /^\S+@\S+\.\S+$/.test(s) || /^(\+?91)?[6-9]\d{9}$/.test(s);
  }
  go(step) {
    this.setState({ step, err: {}, busy: false });
    window.scrollTo({ top: 0 });
    if (step === 2) {
      this.startTimer();
      setTimeout(() => this.otpEls[0] && this.otpEls[0].focus(), 60);
    }
  }
  next = () => {
    const S = this.state;
    if (S.step === 1) {
      const err = {};
      if (!S.name.trim()) err.name = 'Please tell us your name.';
      if (!this.validId(S.id)) err.id = 'Please enter a valid email or 10-digit mobile number.';
      if (S.pw.length < 6) err.pw = 'Your password needs at least 6 characters.';
      if (Object.keys(err).length) return this.setState({ err });
      this.setState({ busy: true });
      clearTimeout(this.t);
      this.t = setTimeout(() => this.go(2), 700);
      return;
    }
    if (S.step === 2) {
      if (S.otp.join('').length < 4) return this.setState({ err: { otp: 'Please enter all 4 digits.' } });
      this.setState({ busy: true });
      clearTimeout(this.t);
      this.t = setTimeout(() => {
        clearInterval(this.timer);
        this.go(3);
      }, 600);
      return;
    }
    this.go(S.step + 1);
  };
  back = () => {
    if (this.state.step > 1) this.go(this.state.step - 1);
  };
  skip = () => this.go(this.state.step + 1);
  setOtp(i, v) {
    const d = v.replace(/\D/g, '').slice(-1);
    this.setState((s) => {
      const o = s.otp.slice();
      o[i] = d;
      return { otp: o, err: {} };
    });
    if (d && i < 3) this.otpEls[i + 1] && this.otpEls[i + 1].focus();
  }
  onOtpPaste = (e) => {
    const d = (e.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 4);
    if (!d) return;
    e.preventDefault();
    this.setState({ otp: [0, 1, 2, 3].map((i) => d[i] || ''), err: {} });
    this.otpEls[Math.min(d.length, 3)] && this.otpEls[Math.min(d.length, 3)].focus();
  };
  toggle(key, v) {
    this.setState((s) => ({ [key]: s[key].includes(v) ? s[key].filter((x) => x !== v) : s[key].concat(v) }));
  }
  chip(on) {
    return on
      ? { bg: 'var(--neutral-900)', fg: 'var(--white)', bd: 'var(--neutral-900)' }
      : { bg: 'var(--white)', fg: 'var(--text-strong)', bd: 'var(--border-strong)' };
  }
  setKid(i, patch) {
    this.setState((s) => ({ kids: s.kids.map((k, j) => (j === i ? { ...k, ...patch } : k)) }));
  }
  onFile = (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = () => this.setState({ photo: r.result, zoom: 100 });
    r.readAsDataURL(f);
  };
  renderVals() {
    const S = this.state,
      st = S.step,
      inFlow = st <= 9;
    const first = S.name.trim().split(/\s+/)[0] || 'there';
    const q = S.city.trim().toLowerCase();
    const sugg =
      q && !S.cityPicked
        ? this.CITIES.filter((c) => c.toLowerCase().startsWith(q) && c.toLowerCase() !== q).slice(0, 5)
        : [];
    const today = new Date().toISOString().slice(0, 10);
    const nextDisabled = S.busy || (st === 3 && !S.ages.length) || (st === 4 && !S.topics.length);
    const vals = {
      step: st,
      inFlow,
      done: st === 10,
      optional: st >= 5 && st <= 9,
      s1: st === 1,
      s2: st === 2,
      s3: st === 3,
      s4: st === 4,
      s5: st === 5,
      s6: st === 6,
      s7: st === 7,
      s8: st === 8,
      s9: st === 9,
      showNav: st >= 2 && st <= 9,
      showSigninLink: st === 1,
      showWelcome: st >= 3,
      stepLabel: 'Step ' + st + ' of 9 · ' + (this.LABELS[st - 1] || ''),
      bars: this.LABELS.map((_, i) => ({
        bg: i + 1 < st ? 'var(--orange-300)' : i + 1 === st ? 'var(--pc-orange)' : 'var(--neutral-200)',
      })),
      name: S.name,
      firstName: first,
      id: S.id,
      pw: S.pw,
      onName: (e) => {
        const v = e.target.value;
        this.setState((s) => ({ name: v, err: { ...s.err, name: undefined } }));
      },
      onId: (e) => {
        const v = e.target.value;
        this.setState((s) => ({ id: v, err: { ...s.err, id: undefined } }));
      },
      onPw: (e) => {
        const v = e.target.value;
        this.setState((s) => ({ pw: v, err: { ...s.err, pw: undefined } }));
      },
      showPw: S.showPw,
      onShowPw: (v) => this.setState({ showPw: typeof v === 'boolean' ? v : !S.showPw }),
      pwType: S.showPw ? 'text' : 'password',
      err: { name: S.err.name, id: S.err.id, pw: S.err.pw, otp: S.err.otp, dob: S.err.dob },
      busy: S.busy,
      next: this.next,
      back: this.back,
      skip: this.skip,
      nextDisabled,
      nextLabel:
        st === 1
          ? S.busy
            ? 'Sending code…'
            : 'Sign up'
          : st === 2
            ? S.busy
              ? 'Verifying…'
              : 'Verify'
            : st === 9
              ? 'Save and finish'
              : 'Next',
      socialJoin: () => {
        if (!S.name.trim()) this.setState({ name: 'Parent' });
        this.go(3);
      },
      otpTitle: S.id.includes('@') ? 'Check your email' : 'Check your phone',
      otpBoxes: S.otp.map((v, i) => ({
        val: v,
        label: 'Digit ' + (i + 1),
        bd: S.err.otp ? 'var(--blush-500)' : v ? 'var(--neutral-900)' : 'var(--border-strong)',
        ref: (el) => {
          this.otpEls[i] = el;
        },
        onChange: (e) => this.setOtp(i, e.target.value),
        onKey: (e) => {
          if (e.key === 'Backspace' && !S.otp[i] && i > 0) this.otpEls[i - 1].focus();
          if (e.key === 'Enter') this.next();
        },
      })),
      onOtpPaste: this.onOtpPaste,
      resendIn: S.resendIn,
      canResend: S.resendIn === 0,
      waitResend: S.resendIn > 0,
      resend: () => {
        this.setState({ otp: ['', '', '', ''] });
        this.startTimer();
        this.otpEls[0] && this.otpEls[0].focus();
      },
      ageChips: this.AGES.map(([a, h]) => ({
        label: a,
        hint: h,
        on: S.ages.includes(a),
        toggle: () => this.toggle('ages', a),
        ...this.chip(S.ages.includes(a)),
      })),
      topicChips: this.TOPICS.map((t) => ({
        label: t,
        on: S.topics.includes(t),
        toggle: () => this.toggle('topics', t),
        ...this.chip(S.topics.includes(t)),
      })),
      topicCount: S.topics.length ? S.topics.length + ' selected' : 'Choose at least one',
      photo: S.photo || undefined,
      hasPhoto: !!S.photo,
      noPhoto: !S.photo,
      photoImg: S.photo
        ? React.createElement('img', {
            src: S.photo,
            alt: 'Your profile photo',
            style: {
              position: 'absolute',
              inset: 0,
              width: '100%',
              height: '100%',
              objectFit: 'cover',
              transform: 'scale(' + S.zoom / 100 + ')',
              transformOrigin: 'center',
              transition: 'transform 80ms linear',
            },
          })
        : null,
      zoom: S.zoom,
      onZoom: (e) => this.setState({ zoom: +e.target.value }),
      fileRef: (el) => {
        this.fileEl = el;
      },
      pickFile: () => this.fileEl && this.fileEl.click(),
      onFile: this.onFile,
      photoBtn: S.photo ? 'Replace photo' : 'Upload a photo',
      genderTiles: [
        ['Male', 'user-round'],
        ['Female', 'user-round'],
        ['Prefer to self-describe', 'circle-user'],
      ].map(([g, icon]) => {
        const on = S.gender === g;
        return {
          label: g,
          icon,
          on,
          pick: () => this.setState({ gender: on ? '' : g }),
          bd: on ? 'var(--neutral-900)' : 'var(--border-default)',
          bg: on ? 'var(--orange-50)' : 'var(--white)',
          ic: on ? 'var(--orange-700)' : 'var(--neutral-500)',
        };
      }),
      today,
      dob: S.dob,
      onDob: (e) => this.setState({ dob: e.target.value }),
      city: S.city,
      onCity: (e) => this.setState({ city: e.target.value, cityPicked: false }),
      citySugg: sugg.map((c) => ({ name: c, pick: () => this.setState({ city: c, cityPicked: true }) })),
      hasCitySugg: sugg.length > 0,
      kids: S.kids.map((k, i) => {
        const b = this.chip(k.gender === 'Boy'),
          g = this.chip(k.gender === 'Girl');
        return {
          heading: S.kids.length > 1 ? 'Child ' + (i + 1) : 'Your child',
          removable: i > 0,
          remove: () => this.setState((s) => ({ kids: s.kids.filter((_, j) => j !== i) })),
          name: k.name,
          dob: k.dob,
          onName: (e) => this.setKid(i, { name: e.target.value }),
          onDob: (e) => this.setKid(i, { dob: e.target.value }),
          boyOn: k.gender === 'Boy',
          girlOn: k.gender === 'Girl',
          boy: () => this.setKid(i, { gender: 'Boy' }),
          girl: () => this.setKid(i, { gender: 'Girl' }),
          boyBg: b.bg,
          boyFg: b.fg,
          boyBd: b.bd,
          girlBg: g.bg,
          girlFg: g.fg,
          girlBd: g.bd,
        };
      }),
      addKid: () => this.setState((s) => ({ kids: s.kids.concat({ name: '', gender: '', dob: '' }) })),
      picks: S.ages.concat(S.topics).slice(0, 8),
      hasPicks: S.ages.length + S.topics.length > 0,
    };
    return vals;
  }
}

export default PageLogic;
