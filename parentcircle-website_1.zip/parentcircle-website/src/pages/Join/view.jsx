import { Fragment } from 'react';
import { Avatar, Button, Icon, Input, Logo } from '../../components/ds';
import { toUrl } from '../../lib/paths';

/** Markup for the "Join" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Join"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      <header
        style={{
          height: '72px',
          flex: 'none',
          borderBottom: '1px solid var(--border-default)',
          background: 'var(--white)',
        }}
      >
        <div
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            height: '100%',
            padding: '0 24px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '16px',
            boxSizing: 'border-box',
          }}
        >
          <a href={toUrl('/')} aria-label="ParentCircle home" style={{ display: 'flex' }}>
            <Logo height={28} />
          </a>
          {v.showSigninLink ? (
            <span style={{ fontSize: '16px', color: 'var(--text-muted)' }}>
              {'Already a member? '}
              <a href={toUrl('/sign-in')} style={{ fontWeight: '700' }}>
                Sign in
              </a>
            </span>
          ) : null}
          {v.showWelcome ? (
            <span
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '10px',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
              }}
            >
              <span>
                {'Welcome, '}
                {v.firstName}
              </span>
              <Avatar name={v.name} src={toUrl(v.photo)} size={36} />
            </span>
          ) : null}
        </div>
      </header>
      <div style={{ flex: '1', display: 'flex', flexWrap: 'wrap', minHeight: '0' }}>
        <aside style={{ flex: '1 1 320px', minHeight: '220px', position: 'relative', background: 'var(--orange-50)' }}>
          <div style={{ position: 'absolute', inset: '0' }}>
            <image-slot id="join-photo" shape="rect" placeholder="Drop a family photo"></image-slot>
          </div>
        </aside>
        <main style={{ flex: '2.2 1 520px', minWidth: '0', display: 'flex', flexDirection: 'column' }}>
          <div
            style={{
              width: '100%',
              maxWidth: '600px',
              margin: '0 auto',
              padding: '40px 24px 56px',
              boxSizing: 'border-box',
              display: 'flex',
              flexDirection: 'column',
              flex: '1',
            }}
          >
            {v.inFlow ? (
              <Fragment>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: '12px',
                    marginBottom: '12px',
                  }}
                >
                  <span style={{ fontSize: '15px', fontWeight: '600', color: 'var(--text-muted)' }}>{v.stepLabel}</span>
                  {v.optional ? (
                    <button
                      className="hv-8"
                      type="button"
                      onClick={v.skip}
                      style={{
                        border: '0',
                        background: 'none',
                        padding: '8px 4px',
                        font: 'inherit',
                        fontSize: '16px',
                        fontWeight: '700',
                        color: 'var(--text-link)',
                        cursor: 'pointer',
                      }}
                    >
                      Skip for now
                    </button>
                  ) : null}
                </div>
                <div
                  role="progressbar"
                  aria-valuemin="1"
                  aria-valuemax="9"
                  aria-valuenow={v.step}
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(9,minmax(0,1fr))',
                    gap: '4px',
                    marginBottom: '36px',
                  }}
                >
                  {(v.bars ?? []).map((b, $i0) => (
                    <Fragment key={$i0}>
                      <span
                        style={{
                          height: '6px',
                          borderRadius: '999px',
                          background: b?.bg,
                          transition: 'background 250ms',
                        }}
                      ></span>
                    </Fragment>
                  ))}
                </div>
              </Fragment>
            ) : null}
            {v.s1 ? (
              <Fragment>
                <h1
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(30px,3.6vw,40px)',
                    lineHeight: '1.15',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0 0 8px',
                  }}
                >
                  Join ParentCircle
                </h1>
                <p style={{ fontSize: '19px', lineHeight: '1.5', color: 'var(--text-muted)', margin: '0 0 32px' }}>
                  Welcome to the world of new-age parenting.
                </p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
                  <Input label="Your name" icon="user-round" value={v.name} onChange={v.onName} error={v.err?.name} />
                  <Input
                    label="Email or mobile number"
                    icon="mail"
                    placeholder="you@example.com or 98765 43210"
                    value={v.id}
                    onChange={v.onId}
                    error={v.err?.id}
                  />
                  <Input
                    label="Create a password"
                    type={v.pwType}
                    icon="lock"
                    helper="At least 6 characters"
                    value={v.pw}
                    onChange={v.onPw}
                    error={v.err?.pw}
                  />
                  <label
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '10px',
                      minHeight: '32px',
                      cursor: 'pointer',
                      fontSize: '17px',
                      lineHeight: '1',
                      color: 'var(--text-body)',
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={v.showPw ?? false}
                      onChange={v.onShowPw}
                      style={{
                        width: '22px',
                        height: '22px',
                        margin: '0',
                        flex: 'none',
                        accentColor: 'var(--orange-700)',
                        cursor: 'pointer',
                      }}
                    />
                    Show password
                  </label>
                  <p style={{ fontSize: '15px', lineHeight: '1.5', color: 'var(--text-muted)', margin: '0' }}>
                    {'By joining, you agree to our '}
                    <a href={toUrl('/terms')}>Terms of use</a>
                    {' and '}
                    <a href={toUrl('/privacy')}>Privacy policy</a>.
                  </p>
                  <Button variant="primary" size="lg" fullWidth={true} disabled={v.busy} onClick={v.next}>
                    {v.nextLabel}
                  </Button>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '14px', margin: '28px 0 16px' }}>
                  <span style={{ flex: '1', height: '1px', background: 'var(--border-default)' }}></span>
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>or sign up with</span>
                  <span style={{ flex: '1', height: '1px', background: 'var(--border-default)' }}></span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'center', gap: '16px' }}>
                  <button
                    className="hv-l"
                    type="button"
                    aria-label="Sign up with Google"
                    onClick={v.socialJoin}
                    style={{
                      width: '56px',
                      height: '56px',
                      borderRadius: '50%',
                      border: '1px solid var(--border-default)',
                      background: 'var(--white)',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      padding: '0',
                      overflow: 'hidden',
                    }}
                  >
                    <img
                      src={toUrl('/images/social/google.png')}
                      alt=""
                      style={{ width: '100%', height: '100%', borderRadius: '50%', display: 'block' }}
                    />
                  </button>
                  <button
                    className="hv-l"
                    type="button"
                    aria-label="Sign up with Facebook"
                    onClick={v.socialJoin}
                    style={{
                      width: '56px',
                      height: '56px',
                      borderRadius: '50%',
                      border: '0',
                      background: '#3b5998',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      padding: '0',
                      overflow: 'hidden',
                    }}
                  >
                    <img
                      src={toUrl('/images/social/facebook.png')}
                      alt=""
                      style={{ width: '100%', height: '100%', borderRadius: '50%', display: 'block' }}
                    />
                  </button>
                  <button
                    className="hv-l"
                    type="button"
                    aria-label="Sign up with X (Twitter)"
                    onClick={v.socialJoin}
                    style={{
                      width: '56px',
                      height: '56px',
                      borderRadius: '50%',
                      border: '0',
                      background: '#55acee',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      padding: '0',
                      overflow: 'hidden',
                    }}
                  >
                    <img
                      src={toUrl('/images/social/twitter.png')}
                      alt=""
                      style={{ width: '100%', height: '100%', borderRadius: '50%', display: 'block' }}
                    />
                  </button>
                </div>
              </Fragment>
            ) : null}
            {v.s2 ? (
              <Fragment>
                <h1
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(30px,3.6vw,40px)',
                    lineHeight: '1.15',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0 0 8px',
                  }}
                >
                  {v.otpTitle}
                </h1>
                <p style={{ fontSize: '19px', lineHeight: '1.5', color: 'var(--text-muted)', margin: '0 0 32px' }}>
                  {'We’ve sent a 4-digit code to '}
                  <strong style={{ color: 'var(--text-strong)' }}>{v.id}</strong>
                  {'. '}
                  <button
                    className="hv-8"
                    type="button"
                    onClick={v.back}
                    style={{
                      border: '0',
                      background: 'none',
                      padding: '0',
                      font: 'inherit',
                      fontWeight: '700',
                      color: 'var(--text-link)',
                      cursor: 'pointer',
                    }}
                  >
                    Change
                  </button>
                </p>
                <div role="group" aria-label="4-digit code" style={{ display: 'flex', gap: '12px' }}>
                  {(v.otpBoxes ?? []).map((o, $i0) => (
                    <Fragment key={$i0}>
                      <input
                        ref={o?.ref}
                        value={o?.val ?? ''}
                        onChange={o?.onChange}
                        onKeyDown={o?.onKey}
                        onPaste={v.onOtpPaste}
                        inputMode="numeric"
                        autoComplete="one-time-code"
                        maxLength="1"
                        aria-label={o?.label}
                        style={{
                          width: '64px',
                          height: '72px',
                          boxSizing: 'border-box',
                          borderRadius: '12px',
                          border: `2px solid ${o?.bd ?? ''}`,
                          background: 'var(--white)',
                          textAlign: 'center',
                          fontFamily: 'var(--font-display)',
                          fontSize: '32px',
                          fontWeight: '700',
                          color: 'var(--text-strong)',
                          outline: 'none',
                        }}
                      />
                    </Fragment>
                  ))}
                </div>
                {v.err?.otp ? (
                  <p role="alert" style={{ fontSize: '16px', color: 'var(--blush-700)', margin: '12px 0 0' }}>
                    {v.err?.otp}
                  </p>
                ) : null}
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    marginTop: '20px',
                    fontSize: '16px',
                    color: 'var(--text-muted)',
                  }}
                >
                  {v.canResend ? (
                    <button
                      type="button"
                      onClick={v.resend}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        border: '0',
                        background: 'none',
                        padding: '8px 0',
                        font: 'inherit',
                        fontWeight: '700',
                        color: 'var(--text-link)',
                        cursor: 'pointer',
                      }}
                    >
                      <Icon name="rotate-ccw" size={18} />
                      Resend code
                    </button>
                  ) : null}
                  {v.waitResend ? (
                    <span>
                      {'Didn’t get it? You can resend in '}
                      {v.resendIn}s
                    </span>
                  ) : null}
                </div>
                <p style={{ fontSize: '14px', color: 'var(--text-muted)', margin: '8px 0 0' }}>
                  Prototype: any 4 digits will work.
                </p>
              </Fragment>
            ) : null}
            {v.s3 ? (
              <Fragment>
                <h1
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(30px,3.6vw,40px)',
                    lineHeight: '1.15',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0 0 8px',
                  }}
                >
                  Which ages are you interested in?
                </h1>
                <p style={{ fontSize: '19px', lineHeight: '1.5', color: 'var(--text-muted)', margin: '0 0 28px' }}>
                  Pick all that apply. We’ll shape your homepage around them.
                </p>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
                  {(v.ageChips ?? []).map((c, $i0) => (
                    <Fragment key={$i0}>
                      <button
                        type="button"
                        aria-pressed={c?.on}
                        onClick={c?.toggle}
                        style={{
                          height: '48px',
                          padding: '0 20px',
                          borderRadius: '999px',
                          border: `1.5px solid ${c?.bd ?? ''}`,
                          background: c?.bg,
                          color: c?.fg,
                          font: 'inherit',
                          fontSize: '17px',
                          fontWeight: '600',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '8px',
                          cursor: 'pointer',
                          transition: 'background 150ms',
                        }}
                      >
                        {c?.label}
                        <span style={{ fontSize: '14px', fontWeight: '500', opacity: '0.8' }}>{c?.hint}</span>
                      </button>
                    </Fragment>
                  ))}
                </div>
              </Fragment>
            ) : null}
            {v.s4 ? (
              <Fragment>
                <h1
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(30px,3.6vw,40px)',
                    lineHeight: '1.15',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0 0 8px',
                  }}
                >
                  What topics interest you?
                </h1>
                <p style={{ fontSize: '19px', lineHeight: '1.5', color: 'var(--text-muted)', margin: '0 0 28px' }}>
                  Pick a few. We’ll use them to recommend articles, tips, activities and discussions for you.
                </p>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
                  {(v.topicChips ?? []).map((c, $i0) => (
                    <Fragment key={$i0}>
                      <button
                        type="button"
                        aria-pressed={c?.on}
                        onClick={c?.toggle}
                        style={{
                          height: '44px',
                          padding: '0 18px',
                          borderRadius: '999px',
                          border: `1.5px solid ${c?.bd ?? ''}`,
                          background: c?.bg,
                          color: c?.fg,
                          font: 'inherit',
                          fontSize: '16px',
                          fontWeight: '600',
                          cursor: 'pointer',
                          transition: 'background 150ms',
                        }}
                      >
                        {c?.label}
                      </button>
                    </Fragment>
                  ))}
                </div>
                <p style={{ fontSize: '15px', color: 'var(--text-muted)', margin: '16px 0 0' }}>{v.topicCount}</p>
              </Fragment>
            ) : null}
            {v.s5 ? (
              <Fragment>
                <h1
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(30px,3.6vw,40px)',
                    lineHeight: '1.15',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0 0 8px',
                  }}
                >
                  Add a profile photo
                </h1>
                <p style={{ fontSize: '19px', lineHeight: '1.5', color: 'var(--text-muted)', margin: '0 0 28px' }}>
                  It will appear on your profile and next to your posts.
                </p>
                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '20px',
                    padding: '28px',
                    borderRadius: '24px',
                    background: 'var(--neutral-50)',
                  }}
                >
                  <div
                    style={{
                      width: '200px',
                      height: '200px',
                      borderRadius: '50%',
                      overflow: 'hidden',
                      background: 'var(--white)',
                      border: '4px solid var(--white)',
                      boxShadow: 'var(--shadow-md)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      position: 'relative',
                    }}
                  >
                    {v.photoImg}
                    {v.noPhoto ? <Icon name="camera" size={44} color="var(--neutral-400)" /> : null}
                  </div>
                  {v.hasPhoto ? (
                    <label
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '12px',
                        width: '100%',
                        maxWidth: '280px',
                        fontSize: '15px',
                        fontWeight: '600',
                        color: 'var(--text-muted)',
                      }}
                    >
                      <Icon name="zoom-out" size={18} />
                      <input
                        type="range"
                        min="100"
                        max="250"
                        value={v.zoom ?? ''}
                        onChange={v.onZoom}
                        aria-label="Zoom photo"
                        style={{ flex: '1', accentColor: 'var(--pc-orange)' }}
                      />
                      <Icon name="zoom-in" size={18} />
                    </label>
                  ) : null}
                  <input ref={v.fileRef} type="file" accept="image/*" onChange={v.onFile} style={{ display: 'none' }} />
                  <Button variant="secondary" icon="upload" onClick={v.pickFile}>
                    {v.photoBtn}
                  </Button>
                </div>
              </Fragment>
            ) : null}
            {v.s6 ? (
              <Fragment>
                <h1
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(30px,3.6vw,40px)',
                    lineHeight: '1.15',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0 0 28px',
                  }}
                >
                  How do you identify?
                </h1>
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,140px),1fr))',
                    gap: '12px',
                  }}
                >
                  {(v.genderTiles ?? []).map((g, $i0) => (
                    <Fragment key={$i0}>
                      <button
                        type="button"
                        aria-pressed={g?.on}
                        onClick={g?.pick}
                        style={{
                          minHeight: '88px',
                          borderRadius: '16px',
                          border: `2px solid ${g?.bd ?? ''}`,
                          background: g?.bg,
                          font: 'inherit',
                          display: 'flex',
                          flexDirection: 'column',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: '10px',
                          cursor: 'pointer',
                          color: 'var(--text-strong)',
                        }}
                      >
                        <span style={{ fontSize: '18px', fontWeight: '600' }}>{g?.label}</span>
                      </button>
                    </Fragment>
                  ))}
                </div>
              </Fragment>
            ) : null}
            {v.s7 ? (
              <Fragment>
                <h1
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(30px,3.6vw,40px)',
                    lineHeight: '1.15',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0 0 28px',
                  }}
                >
                  Your date of birth
                </h1>
                <Input
                  label="Date of birth"
                  type="date"
                  icon="calendar"
                  max={v.today}
                  value={v.dob}
                  onChange={v.onDob}
                  error={v.err?.dob}
                />
              </Fragment>
            ) : null}
            {v.s8 ? (
              <Fragment>
                <h1
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(30px,3.6vw,40px)',
                    lineHeight: '1.15',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0 0 8px',
                  }}
                >
                  Add your city
                </h1>
                <p style={{ fontSize: '19px', lineHeight: '1.5', color: 'var(--text-muted)', margin: '0 0 28px' }}>
                  We’ll use it to help you connect with other parents near you.
                </p>
                <Input
                  label="City"
                  icon="map-pin"
                  placeholder="Start typing, e.g. Chennai"
                  value={v.city}
                  onChange={v.onCity}
                />
                {v.hasCitySugg ? (
                  <div
                    role="listbox"
                    style={{
                      marginTop: '8px',
                      border: '1px solid var(--border-default)',
                      borderRadius: '12px',
                      overflow: 'hidden',
                      boxShadow: 'var(--shadow-sm)',
                    }}
                  >
                    {(v.citySugg ?? []).map((c, $i0) => (
                      <Fragment key={$i0}>
                        <button
                          className="hv-e"
                          type="button"
                          role="option"
                          onClick={c?.pick}
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '10px',
                            width: '100%',
                            padding: '14px 16px',
                            border: '0',
                            borderBottom: '1px solid var(--border-subtle)',
                            background: 'var(--white)',
                            font: 'inherit',
                            fontSize: '17px',
                            color: 'var(--text-strong)',
                            textAlign: 'left',
                            cursor: 'pointer',
                          }}
                        >
                          <Icon name="map-pin" size={18} color="var(--text-muted)" />
                          {c?.name}
                        </button>
                      </Fragment>
                    ))}
                  </div>
                ) : null}
              </Fragment>
            ) : null}
            {v.s9 ? (
              <Fragment>
                <h1
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(30px,3.6vw,40px)',
                    lineHeight: '1.15',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0 0 8px',
                  }}
                >
                  Tell us about your children
                </h1>
                <p style={{ fontSize: '19px', lineHeight: '1.5', color: 'var(--text-muted)', margin: '0 0 28px' }}>
                  Their date of birth helps us show you age-appropriate content.
                </p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  {(v.kids ?? []).map((k, $i0) => (
                    <Fragment key={$i0}>
                      <div
                        style={{
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '16px',
                          padding: '20px',
                          borderRadius: '20px',
                          border: '1px solid var(--border-default)',
                        }}
                      >
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            gap: '12px',
                          }}
                        >
                          <span
                            style={{
                              fontSize: '15px',
                              fontWeight: '700',
                              letterSpacing: '0.08em',
                              textTransform: 'uppercase',
                              color: 'var(--text-muted)',
                            }}
                          >
                            {k?.heading}
                          </span>
                          {k?.removable ? (
                            <button
                              className="hv-1"
                              type="button"
                              onClick={k?.remove}
                              style={{
                                border: '0',
                                background: 'none',
                                padding: '6px 0',
                                font: 'inherit',
                                fontSize: '15px',
                                fontWeight: '600',
                                color: 'var(--text-muted)',
                                cursor: 'pointer',
                              }}
                            >
                              Remove
                            </button>
                          ) : null}
                        </div>
                        <Input label="Child’s name" value={k?.name} onChange={k?.onName} />
                        <div
                          role="radiogroup"
                          aria-label="Child’s gender"
                          style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}
                        >
                          <button
                            type="button"
                            aria-pressed={k?.boyOn}
                            onClick={k?.boy}
                            style={{
                              height: '48px',
                              padding: '0 22px',
                              borderRadius: '999px',
                              border: `1.5px solid ${k?.boyBd ?? ''}`,
                              background: k?.boyBg,
                              color: k?.boyFg,
                              font: 'inherit',
                              fontSize: '17px',
                              fontWeight: '600',
                              cursor: 'pointer',
                            }}
                          >
                            Boy
                          </button>
                          <button
                            type="button"
                            aria-pressed={k?.girlOn}
                            onClick={k?.girl}
                            style={{
                              height: '48px',
                              padding: '0 22px',
                              borderRadius: '999px',
                              border: `1.5px solid ${k?.girlBd ?? ''}`,
                              background: k?.girlBg,
                              color: k?.girlFg,
                              font: 'inherit',
                              fontSize: '17px',
                              fontWeight: '600',
                              cursor: 'pointer',
                            }}
                          >
                            Girl
                          </button>
                        </div>
                        <Input label="Date of birth" type="date" max={v.today} value={k?.dob} onChange={k?.onDob} />
                      </div>
                    </Fragment>
                  ))}
                  <div>
                    <Button variant="ghost" icon="plus" onClick={v.addKid}>
                      Add another child
                    </Button>
                  </div>
                </div>
              </Fragment>
            ) : null}
            {v.showNav ? (
              <div
                style={{
                  display: 'flex',
                  gap: '12px',
                  justifyContent: 'flex-end',
                  flexWrap: 'wrap',
                  marginTop: '36px',
                  paddingTop: '24px',
                  borderTop: '1px solid var(--border-subtle)',
                }}
              >
                <Button variant="secondary" icon="arrow-left" onClick={v.back}>
                  Back
                </Button>
                <Button variant="primary" iconRight="arrow-right" disabled={v.nextDisabled} onClick={v.next}>
                  {v.nextLabel}
                </Button>
              </div>
            ) : null}
            {v.done ? (
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'flex-start',
                  gap: '18px',
                  paddingTop: '24px',
                }}
              >
                <span
                  style={{
                    width: '72px',
                    height: '72px',
                    borderRadius: '50%',
                    background: 'var(--sage-50)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="party-popper" size={36} color="var(--sage-700)" />
                </span>
                <h1
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(32px,4vw,44px)',
                    lineHeight: '1.15',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0',
                  }}
                >
                  {'You’re all set, '}
                  {v.firstName}!
                </h1>
                <p style={{ fontSize: '19px', lineHeight: '1.5', color: 'var(--text-muted)', margin: '0' }}>
                  Your homepage is ready, with stories picked for you.
                </p>
                {v.hasPicks ? (
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                    {(v.picks ?? []).map((p, $i0) => (
                      <Fragment key={$i0}>
                        <span
                          style={{
                            height: '36px',
                            padding: '0 14px',
                            borderRadius: '999px',
                            background: 'var(--orange-50)',
                            color: 'var(--orange-800)',
                            fontSize: '15px',
                            fontWeight: '600',
                            display: 'flex',
                            alignItems: 'center',
                          }}
                        >
                          {p}
                        </span>
                      </Fragment>
                    ))}
                  </div>
                ) : null}
                <a href={toUrl('/')} style={{ textDecoration: 'none', marginTop: '8px' }}>
                  <Button variant="primary" size="lg" iconRight="arrow-right">
                    Go to my homepage
                  </Button>
                </a>
              </div>
            ) : null}
          </div>
        </main>
      </div>
    </div>
  );
}
