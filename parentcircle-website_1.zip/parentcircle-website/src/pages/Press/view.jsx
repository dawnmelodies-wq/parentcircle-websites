import { Fragment } from 'react';
import { Button, Card, Icon, Tabs } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Press" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Press"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader communityHref="/#community" />
      <main>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '32px 24px 0', boxSizing: 'border-box' }}>
          <nav aria-label="Company" style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '40px' }}>
            <a
              className="hv-0"
              href={toUrl('/about')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              About us
            </a>
            <a
              href={toUrl('/press')}
              aria-current="page"
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                background: 'var(--neutral-900)',
                color: 'var(--text-inverse)',
                fontSize: '16px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Press releases
            </a>
            <a
              className="hv-0"
              href={toUrl('/guidelines')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Community guidelines
            </a>
            <a
              className="hv-0"
              href={toUrl('/community-help')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Community help
            </a>
            <a
              className="hv-0"
              href={toUrl('/terms')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Terms of use
            </a>
            <a
              className="hv-0"
              href={toUrl('/privacy')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Privacy policy
            </a>
            <a
              className="hv-0"
              href={toUrl('/contact')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Contact us
            </a>
          </nav>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '32px 56px', alignItems: 'center' }}>
            <div style={{ flex: '1 1 440px', minWidth: '0' }}>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-700)',
                  marginBottom: '12px',
                }}
              >
                Press
              </div>
              <h1
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(38px,5vw,60px)',
                  lineHeight: '1.08',
                  letterSpacing: '-0.015em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                  textWrap: 'balance',
                }}
              >
                ParentCircle in the news
              </h1>
              <p
                style={{
                  fontFamily: 'var(--font-serif)',
                  fontSize: '22px',
                  lineHeight: '1.55',
                  color: 'var(--text-body)',
                  margin: '18px 0 28px',
                  maxWidth: '560px',
                  textWrap: 'pretty',
                }}
              >
                When India’s leading publications write about children and families, they often turn to ParentCircle.
                Here’s a look at how they’ve covered our work.
              </p>
              <a href="#media" style={{ textDecoration: 'none' }}>
                <Button variant="primary" icon="mail">
                  Media enquiries
                </Button>
              </a>
            </div>
            <div
              style={{
                flex: '1 1 420px',
                minWidth: '0',
                aspectRatio: '16 / 9',
                position: 'relative',
                borderRadius: '24px',
                overflow: 'hidden',
                background: 'var(--neutral-900)',
                boxShadow: 'var(--shadow-md)',
              }}
            >
              {v.notPlaying ? (
                <button
                  type="button"
                  onClick={v.play}
                  aria-label="Play video: Should schools reopen?"
                  style={{
                    position: 'absolute',
                    inset: '0',
                    width: '100%',
                    height: '100%',
                    padding: '0',
                    border: '0',
                    cursor: 'pointer',
                    background: 'linear-gradient(135deg,var(--neutral-900),var(--neutral-700))',
                    display: 'block',
                  }}
                >
                  <img
                    src={toUrl('/images/press/video-thumb.png')}
                    alt=""
                    style={{ position: 'absolute', inset: '0', width: '100%', height: '100%', objectFit: 'cover' }}
                  />{' '}
                  <span
                    style={{
                      position: 'absolute',
                      left: '50%',
                      top: '50%',
                      transform: 'translate(-50%,-50%)',
                      width: '80px',
                      height: '80px',
                      borderRadius: '50%',
                      background: 'var(--action-primary)',
                      color: 'var(--white)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      boxShadow: 'var(--shadow-lg)',
                    }}
                  >
                    <Icon name="play" size={36} />
                  </span>{' '}
                  <span
                    style={{
                      position: 'absolute',
                      left: '16px',
                      bottom: '16px',
                      right: '16px',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      padding: '10px 14px',
                      borderRadius: '10px',
                      background: 'var(--white)',
                      color: 'var(--text-strong)',
                      fontFamily: 'var(--font-ui)',
                      fontSize: '16px',
                      fontWeight: '600',
                      textAlign: 'left',
                      boxShadow: 'var(--shadow-sm)',
                    }}
                  >
                    Should schools reopen? Parents speak during COVID-19
                  </span>
                </button>
              ) : null}
              {v.playing ? (
                <iframe
                  src={'https://www.youtube-nocookie.com/embed/gSs6y89rBKM?autoplay=1&rel=0'}
                  title="Should schools reopen?"
                  allow="autoplay; encrypted-media; picture-in-picture"
                  allowFullScreen={true}
                  style={{ position: 'absolute', inset: '0', width: '100%', height: '100%', border: '0' }}
                ></iframe>
              ) : null}
            </div>
          </div>
        </section>
        <section style={{ marginTop: '64px', background: 'var(--neutral-50)' }}>
          <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '40px 24px', boxSizing: 'border-box' }}>
            <div
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--text-muted)',
                marginBottom: '18px',
                textAlign: 'center',
              }}
            >
              As featured in
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '12px 28px' }}>
              {(v.outlets ?? []).map((o, $i0) => (
                <Fragment key={$i0}>
                  <span
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '20px',
                      fontWeight: '700',
                      color: 'var(--neutral-600)',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {o}
                  </span>
                </Fragment>
              ))}
            </div>
          </div>
        </section>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '72px 24px 0', boxSizing: 'border-box' }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'flex-end',
              justifyContent: 'space-between',
              gap: '20px',
              flexWrap: 'wrap',
              marginBottom: '28px',
            }}
          >
            <h2
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(30px,3.4vw,40px)',
                lineHeight: '1.15',
                letterSpacing: '-0.01em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0',
              }}
            >
              Coverage of our work
            </h2>
            <Tabs variant="pill" tabs={v.tabs} value={v.cat} onChange={v.setCat} />
          </div>
          <p
            style={{
              fontSize: '19px',
              lineHeight: '1.5',
              color: 'var(--text-muted)',
              margin: '-12px 0 28px',
              maxWidth: '720px',
            }}
          >
            {v.catBlurb}
          </p>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,300px),1fr))',
              gap: '28px 24px',
            }}
          >
            {(v.items ?? []).map((it, $i0) => (
              <Fragment key={$i0}>
                <a
                  className="hv-c"
                  href={toUrl(it?.url)}
                  target="_blank"
                  rel="noopener"
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '12px',
                    textDecoration: 'none',
                    color: 'inherit',
                  }}
                >
                  <div
                    style={{
                      position: 'relative',
                      width: '100%',
                      aspectRatio: '16 / 10',
                      borderRadius: '16px',
                      overflow: 'hidden',
                      background: 'var(--orange-50)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <span
                      style={{
                        position: 'absolute',
                        inset: '0',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Icon name="newspaper" size={36} color="var(--orange-300)" />
                    </span>
                    {it?.thumb}
                  </div>
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{it?.meta}</span>
                  <span
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '21px',
                      lineHeight: '1.3',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      textWrap: 'pretty',
                    }}
                  >
                    {it?.title}
                  </span>
                  <span
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '10px',
                      marginTop: 'auto',
                      paddingTop: '10px',
                      borderTop: '1px solid var(--border-subtle)',
                    }}
                  >
                    <span style={{ fontSize: '16px', fontWeight: '700', color: 'var(--text-strong)' }}>
                      {it?.source}
                    </span>
                    <span
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        fontSize: '15px',
                        fontWeight: '600',
                        color: 'var(--orange-700)',
                      }}
                    >
                      Read
                      <Icon name="external-link" size={16} />
                    </span>
                  </span>
                </a>
              </Fragment>
            ))}
          </div>
        </section>
        <section
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '80px 24px 0',
            boxSizing: 'border-box',
            display: 'flex',
            flexWrap: 'wrap',
            gap: '40px 56px',
            alignItems: 'flex-start',
          }}
        >
          <div style={{ flex: '999 1 560px', minWidth: '0' }}>
            <h2
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(28px,3vw,34px)',
                lineHeight: '1.2',
                letterSpacing: '-0.01em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              More mentions
            </h2>
            {(v.mentions ?? []).map((m, $i0) => (
              <Fragment key={$i0}>
                <a
                  className="hv-c"
                  href={toUrl(m?.url)}
                  target="_blank"
                  rel="noopener"
                  style={{
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: '16px',
                    padding: '18px 0',
                    borderBottom: '1px solid var(--border-subtle)',
                    textDecoration: 'none',
                    color: 'inherit',
                  }}
                >
                  <span style={{ flex: '1', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                    <span
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '19px',
                        lineHeight: '1.35',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        textWrap: 'pretty',
                      }}
                    >
                      {m?.title}
                    </span>
                    <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                      <span style={{ fontWeight: '600', color: 'var(--text-strong)' }}>{m?.source}</span>
                      {' · '}
                      {m?.meta}
                    </span>
                  </span>
                  <Icon name="external-link" size={20} color="var(--orange-600)" />
                </a>
              </Fragment>
            ))}
            {v.canMore ? (
              <div style={{ paddingTop: '24px' }}>
                <Button variant="secondary" icon="chevron-down" onClick={v.showMore}>
                  Show all
                </Button>
              </div>
            ) : null}
          </div>
          <aside id="media" style={{ flex: '1 1 300px', minWidth: '0', scrollMarginTop: '96px' }}>
            <Card tint="orange" padding={28}>
              <Icon name="mic" size={30} color="var(--orange-700)" />
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '24px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '12px 0 8px',
                }}
              >
                Media enquiries
              </div>
              <p style={{ fontSize: '17px', lineHeight: '1.55', color: 'var(--text-body)', margin: '0 0 20px' }}>
                For interviews and stories with our leadership team, advisory board or panel of experts, we’re happy to
                help.
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <a
                  className="hv-e"
                  href="mailto:contact@parentcircle.com"
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '8px',
                    padding: '16px 14px',
                    boxSizing: 'border-box',
                    borderRadius: '16px',
                    background: 'var(--white)',
                    border: '1px solid var(--border-strong)',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                    textAlign: 'center',
                  }}
                >
                  <Icon name="mail" size={20} color="currentColor" />
                  <span style={{ fontSize: '15px', fontWeight: '700', lineHeight: '1.3', whiteSpace: 'nowrap' }}>
                    contact@parentcircle.com
                  </span>
                </a>
                <a
                  className="hv-e"
                  href="tel:9791039335"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '10px',
                    minHeight: '52px',
                    padding: '0 20px',
                    boxSizing: 'border-box',
                    borderRadius: '16px',
                    background: 'var(--white)',
                    border: '1px solid var(--border-strong)',
                    color: 'var(--text-strong)',
                    fontSize: '17px',
                    fontWeight: '700',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="phone" size={20} color="currentColor" />
                  97910 39335
                </a>
              </div>
            </Card>
          </aside>
        </section>
      </main>
      <SiteFooter spaced />
    </div>
  );
}
