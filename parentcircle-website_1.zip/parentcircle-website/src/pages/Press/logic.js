import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = { cat: 'survey', more: false, playing: false };
  base = 'https://parentcircle.blob.core.windows.net/static/image/';
  LOCAL = {
    'times-of-india-news01.jpg': 'times-of-india-news01.jpg',
    'hindustan-times-news3.png': 'hindustan-times-news3.png',
    'IMG_6240.PNG': 'img-6240.png',
    'telungana-today-news.jpg': 'telungana-today-news.jpg',
    '01-zee-news.jpg': '01-zee-news.jpg',
    '08-business-line.jpg': '08-business-line.jpg',
    'the-economic-times-news01.jpg': 'the-economic-times-news01.jpg',
    'hindustan-times-news.jpg': 'hindustan-times-news.jpg',
    'dna-news.jpg': 'dna-news.jpg',
    'the-hindu-news.jfif': '13nov-th-gadgetfree.jpg',
    'Thirupparankundram%20Panchayat%20Union%20Elementary%20School_13112019_1.jpg': 'thirupparankundram.jpg',
    'india-today-news.jpg': 'india-today-news.jpg',
    'busines-line-news03.jpg': 'busines-line-news03.jpg',
    'business-standard-news.jpg': 'business-standard-news.jpg',
    'the-new-indian-express-news03.jpg': 'the-new-indian-express-news03.jpg',
    'pc-online-launch.png': 'pc-online-launch.png',
    'the-hindu-news02.jpg': 'the-hindu-news02.jpg',
    'freepress-news.jpg': 'freepress-news.jpg',
    'your-story-news01.jpg': 'your-story-news01.jpg',
    'content-advisory.png': 'content-advisory.png',
  };
  outlets = [
    'The Economic Times',
    'The Hindu',
    'Hindustan Times',
    'Times of India',
    'India Today',
    'Indian Express',
    'New Indian Express',
    'Business Standard',
    'Business Line',
    'Zee News',
    'DNA',
    'YourStory',
  ];
  cats = {
    survey: {
      label: 'Nationwide survey',
      blurb: 'In May 2020, our nationwide survey asked parents how they felt about schools reopening after lockdown.',
    },
    gfh: {
      label: '#GadgetFreeHour',
      blurb: 'Our yearly campaign asking families to put every gadget away for one hour on World Children’s Day.',
    },
    platform: {
      label: 'Website launch',
      blurb: 'In 2015, ParentCircle launched online as a place for parents and experts to share knowledge.',
    },
    magazine: { label: 'Magazine launch', blurb: 'In 2011, ParentCircle began as a print magazine in Chennai.' },
    general: { label: 'General', blurb: 'Other stories featuring ParentCircle and our team.' },
  };
  list = [
    [
      'survey',
      '13 May 2020',
      '',
      '92% of Indian parents unwilling to send their child back to school immediately',
      'The Economic Times',
      'the-economic-times-news01.jpg',
      'https://economictimes.indiatimes.com/magazines/panache/92-indian-parents-unwilling-to-send-their-child-back-to-school-immediately-upon-reopening/articleshow/75712766.cms',
    ],
    [
      'survey',
      '12 May 2020',
      'Mumbai',
      '54% of parents won’t send kids to school for a month after lockdown: survey',
      'Hindustan Times',
      'hindustan-times-news.jpg',
      'https://www.hindustantimes.com/mumbai-news/54-parents-won-t-send-kids-to-school-for-a-month-after-lockdown-is-lifted-survey/story-eFZXCVhhSs0W2bXb0mmKBI.html',
    ],
    [
      'survey',
      '13 May 2020',
      '',
      'Parents in India’s metros unwilling to send kids to school right after lockdown',
      'DNA',
      'dna-news.jpg',
      'https://www.dnaindia.com/india/report-parents-in-india-s-metros-unwilling-to-send-kids-to-school-immediately-after-lockdown-survey-2824683',
    ],
    [
      'survey',
      '12 May 2020',
      '',
      'Survey shows Indian parents not ready to send children back to school',
      'Times of India',
      'times-of-india-news01.jpg',
      'https://timesofindia.indiatimes.com/life-style/parenting/teen/coronavirus-fear-survey-shows-indian-parents-not-ready-to-send-children-back-to-school/articleshow/75690118.cms',
    ],
    [
      'survey',
      '11 May 2020',
      'Mumbai',
      'Most Mumbai parents will not send children to school when lockdown lifts',
      'Hindustan Times',
      'hindustan-times-news3.png',
      'https://www.hindustantimes.com/education/majority-of-parents-in-mumbai-will-not-send-children-to-school-when-lockdown-is-lifted-survey/story-IOXzjBou7gYWrqQUnTMmnL.html',
    ],
    [
      'gfh',
      '14 Nov 2019',
      'Chennai',
      'Drop the gadgets and spend time talking to your children, says parents’ organisation',
      'The Hindu',
      'the-hindu-news.jfif',
      'https://www.thehindu.com/news/cities/chennai/drop-the-gadgets-spend-time-to-talk-to-your-children-says-parents-organisation/article29962346.ece',
    ],
    [
      'gfh',
      '5 Nov 2019',
      'Chennai',
      'Tamil Nadu wants schools to join the gadget-free hour campaign',
      'Times of India',
      'Thirupparankundram%20Panchayat%20Union%20Elementary%20School_13112019_1.jpg',
      'https://timesofindia.indiatimes.com/city/chennai/childrens-day-tn-wants-schools-to-participate-in-gadget-free-hour-campaign/articleshow/71927133.cms',
    ],
    [
      'gfh',
      '13 Nov 2019',
      'Bengaluru',
      'Have a gadget-free Children’s Day in Bengaluru',
      'Indian Express',
      'IMG_6240.PNG',
      'https://www.newindianexpress.com/cities/bengaluru/2019/nov/13/have-a-gadget-free-childrens-day-in-bengaluru-2061307.html',
    ],
    [
      'gfh',
      '13 Nov 2019',
      'Hyderabad',
      'Time to converse with your kid',
      'Telangana Today',
      'telungana-today-news.jpg',
      'https://telanganatoday.com/time-to-converse-with-your-kid',
    ],
    [
      'gfh',
      '15 Nov 2021',
      '',
      '50 million Indians expected to observe Gadget Free Hour on 20 November',
      'Zee News',
      '01-zee-news.jpg',
      'https://zeenews.india.com/india/50-million-indians-expected-to-observe-gadget-free-hour-on-november-20-2410684.html',
    ],
    [
      'gfh',
      '15 Nov 2021',
      '',
      'ParentCircle to organise third edition of #GadgetFreeHour',
      'Business Line',
      '08-business-line.jpg',
      'https://www.thehindubusinessline.com/news/education/parentcircle-to-organise-third-edition-of-gadgetfreehour-campaign/article37502347.ece',
    ],
    [
      'platform',
      '2 Sep 2015',
      'Chennai',
      'Indian company creates social media for parenting',
      'India Today',
      'india-today-news.jpg',
      'https://www.indiatoday.in/technology/news/story/indian-company-creates-social-media-for-parenting-260924-2015-09-02',
    ],
    [
      'platform',
      '3 Sep 2015',
      'Chennai',
      'Online knowledge-sharing platform ParentCircle launched in Chennai',
      'Business Line',
      'busines-line-news03.jpg',
      'https://www.thehindubusinessline.com/info-tech/online-knowledgesharing-platform-parentcircle-launched-in-chennai/article7612286.ece',
    ],
    [
      'platform',
      '2 Sep 2015',
      'Chennai',
      'ParentCircle magazine launches online social platform for parenting',
      'Business Standard',
      'business-standard-news.jpg',
      'https://www.business-standard.com/article/companies/parent-circle-magazine-launches-online-social-platform-for-parenting-115090201190_1.html',
    ],
    [
      'magazine',
      '18 Apr 2011',
      'Chennai',
      'Chennai parents get a master guide',
      'New Indian Express',
      'the-new-indian-express-news03.jpg',
      'https://www.newindianexpress.com/cities/chennai/2011/apr/18/chennai-parents-gets-a-master-guide-245614.html',
    ],
    [
      'magazine',
      '16 Apr 2011',
      'Chennai',
      'Magazine to guide parents in all-round child development',
      'Business Line',
      'pc-online-launch.png',
      'https://www.thehindubusinessline.com/news/variety/Magazine-to-guide-parents-in-all-round-child-development/article20192208.ece',
    ],
    [
      'magazine',
      '14 Sep 2011',
      'Chennai',
      'Not a child’s play',
      'The Hindu',
      'the-hindu-news02.jpg',
      'https://www.thehindu.com/features/metroplus/society/not-a-childs-play/article2452953.ece',
    ],
    [
      'general',
      '10 May 2020',
      '',
      'Mother’s Day 2020: inspirational mums of the sporting world',
      'The Free Press Journal',
      'freepress-news.jpg',
      'https://www.freepressjournal.in/india/mothers-day-2020-from-serena-williams-to-mary-kom-inspirational-moms-of-the-sporting-world',
    ],
    [
      'general',
      '18 Jul 2015',
      'Chennai',
      'ParentCircle empowers parents to make informed choices',
      'YourStory',
      'your-story-news01.jpg',
      'https://yourstory.com/2015/07/parent-circle-nalina-ramalakshmi',
    ],
    [
      'general',
      '31 Jul 2015',
      'Chennai',
      'ParentCircle ropes in eminent personalities for content advisory',
      'BusinessWire India',
      'content-advisory.png',
      'https://www.businesswireindia.com/parentcircle-ropes-eminent-personalities-content-advisory-44684.html',
    ],
  ];
  mentionList = [
    [
      'Parents wary of sending children back to school',
      'Times of India',
      '15 May 2020 · Chennai',
      'https://timesofindia.indiatimes.com/city/chennai/chennai-parents-wary-of-sending-children-back-to-school/articleshow/75756835.cms',
    ],
    [
      'Home schooling is the new buzzword in parenting circles',
      'Times of India',
      '16 May 2020 · Bengaluru',
      'https://timesofindia.indiatimes.com/city/bengaluru/home-schooling-is-the-new-buzzword-in-parenting-circles/articleshow/75766849.cms',
    ],
    [
      'Parents in Hyderabad to “wait and watch” after schools reopen',
      'Telangana Today',
      '11 May 2020 · Hyderabad',
      'https://telanganatoday.com/parents-in-hyderabad-to-wait-and-watch-after-schools-reopen',
    ],
    [
      'Indian parents reluctant to send kids back to school after lockdown, survey reveals',
      'Indian Express',
      '11 May 2020 · New Delhi',
      'https://indianexpress.com/article/parenting/family/indian-parents-unwilling-to-send-kids-back-to-school-after-lockdown-survey-reveals-6404842/',
    ],
    [
      'A campaign to take a break from the relentless digital world',
      'DT Next',
      '19 Nov 2020 · Chennai',
      'https://www.dtnext.in/News/City/2020/11/19002121/1262735/A-campaign-to-take-a-break-from-the-relentless-digital-.vpf',
    ],
    [
      'Set aside time to spend with your family, free from gadgets, on 20 November',
      'The News Minute',
      '19 Nov 2020',
      'https://www.thenewsminute.com/article/set-aside-time-spend-your-family-free-gadgets-november-20-137975',
    ],
    [
      'ParentCircle.com aims to become a knowledge-sharing platform on parenting',
      'The Hindu',
      '3 Sep 2015 · Chennai',
      'https://www.thehindu.com/business/now-get-online-tips-on-parenting-with-local-flavour/article7608356.ece',
    ],
    [
      'Where parenting woes end',
      'New Indian Express',
      '29 Feb 2016',
      'https://www.newindianexpress.com/education/edex/2016/feb/29/Where-Parenting-Woes-End-898053.html',
    ],
    [
      'Magazine on parenting a big draw at book fair',
      'DT Next',
      '13 Jan 2019 · Chennai',
      'https://www.dtnext.in/News/City/2019/01/13041331/1102679/Magazine-on-parenting-big-draw-at-book-fair.vpf',
    ],
  ];
  renderVals() {
    const S = this.state;
    const items = this.list
      .filter((r) => r[0] === S.cat)
      .map(([c, date, city, title, source, img, url]) => ({
        title,
        source,
        url,
        meta: city ? date + ' · ' + city : date,
        thumb: img
          ? React.createElement('img', {
              src: this.LOCAL[img] ? 'images/press/' + this.LOCAL[img] : this.base + img,
              alt: '',
              style: { position: 'relative', width: '100%', height: '100%', objectFit: 'cover', display: 'block' },
            })
          : null,
        noImg: !img,
      }));
    const mentions = this.mentionList.map(([title, source, meta, url]) => ({ title, source, meta, url }));
    return {
      playing: S.playing,
      notPlaying: !S.playing,
      play: () => {
        try {
          window.open('https://www.youtube.com/watch?v=gSs6y89rBKM', '_blank', 'noopener');
        } catch (e) {}
      },
      outlets: this.outlets,
      tabs: Object.entries(this.cats).map(([value, c]) => ({ value, label: c.label })),
      cat: S.cat,
      setCat: (v) => this.setState({ cat: v }),
      catBlurb: this.cats[S.cat].blurb,
      items,
      mentions: S.more ? mentions : mentions.slice(0, 5),
      canMore: !S.more && mentions.length > 5,
      showMore: () => this.setState({ more: true }),
    };
  }
}

export default PageLogic;
