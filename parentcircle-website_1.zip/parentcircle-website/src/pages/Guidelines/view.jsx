import { Fragment } from 'react';
import { Button, Icon } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Guidelines" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Community guidelines"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader />
      <main>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '32px 24px 0', boxSizing: 'border-box' }}>
          <nav aria-label="Company" style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '48px' }}>
            <a
              className="hv-0"
              href={toUrl('/about')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              About us
            </a>
            <a
              className="hv-0"
              href={toUrl('/press')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Press releases
            </a>
            <a
              href={toUrl('/guidelines')}
              aria-current="page"
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                background: 'var(--neutral-900)',
                color: 'var(--text-inverse)',
                fontSize: '16px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Community guidelines
            </a>
            <a
              className="hv-0"
              href={toUrl('/community-help')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Community help
            </a>
            <a
              className="hv-0"
              href={toUrl('/terms')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Terms of use
            </a>
            <a
              className="hv-0"
              href={toUrl('/privacy')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Privacy policy
            </a>
            <a
              className="hv-0"
              href={toUrl('/contact')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Contact us
            </a>
          </nav>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '40px 56px', alignItems: 'flex-end' }}>
            <div style={{ flex: '1 1 460px', minWidth: '0' }}>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-700)',
                  marginBottom: '12px',
                }}
              >
                Community guidelines
              </div>
              <h1
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(38px,5vw,60px)',
                  lineHeight: '1.08',
                  letterSpacing: '-0.015em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                  textWrap: 'balance',
                }}
              >
                Five promises that keep our circles kind
              </h1>
              <p
                style={{
                  fontFamily: 'var(--font-serif)',
                  fontSize: '22px',
                  lineHeight: '1.55',
                  color: 'var(--text-body)',
                  margin: '18px 0 0',
                  maxWidth: '580px',
                  textWrap: 'pretty',
                }}
              >
                {
                  'Our community is only as safe and helpful as the people in it. These five agreements guide every post, reply and meet-up — together, they make us '
                }
                <strong style={{ color: 'var(--text-strong)' }}>SUPER</strong>.
              </p>
            </div>
            <nav
              aria-label="The five agreements"
              style={{
                flex: '1 1 380px',
                minWidth: '0',
                display: 'grid',
                gridTemplateColumns: 'repeat(5,minmax(0,1fr))',
                gap: '8px',
              }}
            >
              <a
                className="hv-d"
                href="#support"
                style={{
                  aspectRatio: '3 / 4',
                  borderRadius: '16px',
                  background: 'var(--orange-50)',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '4px',
                  textDecoration: 'none',
                  transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
                }}
              >
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(36px,4vw,52px)',
                    lineHeight: '1',
                    fontWeight: '700',
                    color: 'var(--orange-700)',
                  }}
                >
                  S
                </span>
                <span style={{ fontSize: '14px', fontWeight: '600', color: 'var(--text-strong)' }}>Support</span>
              </a>
              <a
                className="hv-d"
                href="#unique"
                style={{
                  aspectRatio: '3 / 4',
                  borderRadius: '16px',
                  background: 'var(--sky-50)',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '4px',
                  textDecoration: 'none',
                  transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
                }}
              >
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(36px,4vw,52px)',
                    lineHeight: '1',
                    fontWeight: '700',
                    color: 'var(--sky-700)',
                  }}
                >
                  U
                </span>
                <span style={{ fontSize: '14px', fontWeight: '600', color: 'var(--text-strong)' }}>Unique</span>
              </a>
              <a
                className="hv-d"
                href="#privacy"
                style={{
                  aspectRatio: '3 / 4',
                  borderRadius: '16px',
                  background: 'var(--sage-50)',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '4px',
                  textDecoration: 'none',
                  transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
                }}
              >
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(36px,4vw,52px)',
                    lineHeight: '1',
                    fontWeight: '700',
                    color: 'var(--sage-700)',
                  }}
                >
                  P
                </span>
                <span style={{ fontSize: '14px', fontWeight: '600', color: 'var(--text-strong)' }}>Privacy</span>
              </a>
              <a
                className="hv-d"
                href="#empower"
                style={{
                  aspectRatio: '3 / 4',
                  borderRadius: '16px',
                  background: 'var(--butter-50)',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '4px',
                  textDecoration: 'none',
                  transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
                }}
              >
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(36px,4vw,52px)',
                    lineHeight: '1',
                    fontWeight: '700',
                    color: 'var(--butter-700)',
                  }}
                >
                  E
                </span>
                <span style={{ fontSize: '14px', fontWeight: '600', color: 'var(--text-strong)' }}>Empower</span>
              </a>
              <a
                className="hv-d"
                href="#respect"
                style={{
                  aspectRatio: '3 / 4',
                  borderRadius: '16px',
                  background: 'var(--blush-50)',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '4px',
                  textDecoration: 'none',
                  transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
                }}
              >
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(36px,4vw,52px)',
                    lineHeight: '1',
                    fontWeight: '700',
                    color: 'var(--blush-700)',
                  }}
                >
                  R
                </span>
                <span style={{ fontSize: '14px', fontWeight: '600', color: 'var(--text-strong)' }}>Respect</span>
              </a>
            </nav>
          </div>
        </section>
        <section
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '72px 24px 0',
            boxSizing: 'border-box',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          <div
            id="support"
            style={{
              scrollMarginTop: '96px',
              display: 'flex',
              flexWrap: 'wrap',
              gap: '20px 48px',
              padding: '40px 0',
              borderTop: '1px solid var(--border-default)',
            }}
          >
            <div style={{ flex: '0 1 300px', minWidth: '0', display: 'flex', alignItems: 'center', gap: '18px' }}>
              <span
                style={{
                  width: '72px',
                  height: '72px',
                  flex: 'none',
                  borderRadius: '20px',
                  background: 'var(--orange-50)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontFamily: 'var(--font-display)',
                  fontSize: '40px',
                  fontWeight: '700',
                  color: 'var(--orange-700)',
                }}
              >
                S
              </span>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '32px',
                  lineHeight: '1.2',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                }}
              >
                Support
              </h2>
            </div>
            <div
              style={{
                flex: '1 1 480px',
                minWidth: '0',
                fontFamily: 'var(--font-reading)',
                fontSize: '20px',
                lineHeight: '1.7',
                color: 'var(--text-body)',
              }}
            >
              <p style={{ margin: '0 0 0.9em', textWrap: 'pretty' }}>
                We’re here to share what we know, what we’ve lived and what we’ve learned — and to stand by each other
                through the joys and the tough days.
              </p>
              <p style={{ margin: '0', textWrap: 'pretty' }}>
                Give support, and accept it too. Your story, in good times or hard ones, may be exactly what another
                parent needs to hear.
              </p>
            </div>
          </div>
          <div
            id="unique"
            style={{
              scrollMarginTop: '96px',
              display: 'flex',
              flexWrap: 'wrap',
              gap: '20px 48px',
              padding: '40px 0',
              borderTop: '1px solid var(--border-default)',
            }}
          >
            <div style={{ flex: '0 1 300px', minWidth: '0', display: 'flex', alignItems: 'center', gap: '18px' }}>
              <span
                style={{
                  width: '72px',
                  height: '72px',
                  flex: 'none',
                  borderRadius: '20px',
                  background: 'var(--sky-50)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontFamily: 'var(--font-display)',
                  fontSize: '40px',
                  fontWeight: '700',
                  color: 'var(--sky-700)',
                }}
              >
                U
              </span>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '32px',
                  lineHeight: '1.2',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                }}
              >
                Unique
              </h2>
            </div>
            <div
              style={{
                flex: '1 1 480px',
                minWidth: '0',
                fontFamily: 'var(--font-reading)',
                fontSize: '20px',
                lineHeight: '1.7',
                color: 'var(--text-body)',
              }}
            >
              <p style={{ margin: '0 0 0.9em', textWrap: 'pretty' }}>
                We value posts that come from your own experience, memories and point of view — not copied from
                elsewhere.
              </p>
              <p style={{ margin: '0', textWrap: 'pretty' }}>
                Listen to each other. Disagree kindly, debate healthily and respect opinions that differ from yours.
              </p>
            </div>
          </div>
          <div
            id="privacy"
            style={{
              scrollMarginTop: '96px',
              display: 'flex',
              flexWrap: 'wrap',
              gap: '20px 48px',
              padding: '40px 0',
              borderTop: '1px solid var(--border-default)',
            }}
          >
            <div style={{ flex: '0 1 300px', minWidth: '0', display: 'flex', alignItems: 'center', gap: '18px' }}>
              <span
                style={{
                  width: '72px',
                  height: '72px',
                  flex: 'none',
                  borderRadius: '20px',
                  background: 'var(--sage-50)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontFamily: 'var(--font-display)',
                  fontSize: '40px',
                  fontWeight: '700',
                  color: 'var(--sage-700)',
                }}
              >
                P
              </span>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '32px',
                  lineHeight: '1.2',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                }}
              >
                Privacy
              </h2>
            </div>
            <div style={{ flex: '1 1 480px', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,220px),1fr))',
                  gap: '12px',
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    gap: '12px',
                    alignItems: 'flex-start',
                    padding: '18px',
                    borderRadius: '16px',
                    background: 'var(--sage-50)',
                  }}
                >
                  <Icon name="lock" size={24} color="var(--sage-700)" />
                  <span style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-strong)' }}>
                    The contact details you give us when you sign up are never shared outside ParentCircle.
                  </span>
                </div>
                <div
                  style={{
                    display: 'flex',
                    gap: '12px',
                    alignItems: 'flex-start',
                    padding: '18px',
                    borderRadius: '16px',
                    background: 'var(--sage-50)',
                  }}
                >
                  <Icon name="video-off" size={24} color="var(--sage-700)" />
                  <span style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-strong)' }}>
                    We never record our online parent meet-ups, so you can speak freely.
                  </span>
                </div>
              </div>
              <div
                role="note"
                style={{
                  display: 'flex',
                  gap: '14px',
                  alignItems: 'flex-start',
                  padding: '18px 20px',
                  borderRadius: '16px',
                  background: 'var(--butter-50)',
                }}
              >
                <Icon name="eye" size={24} color="var(--butter-700)" />
                <div style={{ minWidth: '0' }}>
                  <div
                    style={{ fontSize: '18px', fontWeight: '700', color: 'var(--text-strong)', marginBottom: '4px' }}
                  >
                    Circles are public
                  </div>
                  <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                    Anyone can read posts in a circle, so please don’t share your phone number, address or other
                    personal details.
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div
            id="empower"
            style={{
              scrollMarginTop: '96px',
              display: 'flex',
              flexWrap: 'wrap',
              gap: '20px 48px',
              padding: '40px 0',
              borderTop: '1px solid var(--border-default)',
            }}
          >
            <div style={{ flex: '0 1 300px', minWidth: '0', display: 'flex', alignItems: 'center', gap: '18px' }}>
              <span
                style={{
                  width: '72px',
                  height: '72px',
                  flex: 'none',
                  borderRadius: '20px',
                  background: 'var(--butter-50)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontFamily: 'var(--font-display)',
                  fontSize: '40px',
                  fontWeight: '700',
                  color: 'var(--butter-700)',
                }}
              >
                E
              </span>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '32px',
                  lineHeight: '1.2',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                }}
              >
                Empower
              </h2>
            </div>
            <div
              style={{
                flex: '1 1 480px',
                minWidth: '0',
                fontFamily: 'var(--font-reading)',
                fontSize: '20px',
                lineHeight: '1.7',
                color: 'var(--text-body)',
              }}
            >
              <p style={{ margin: '0', textWrap: 'pretty' }}>
                We help parents raise happy, successful children through holistic parenting. Share what you know, too —
                it’s very likely someone will find it useful.
              </p>
            </div>
          </div>
          <div
            id="respect"
            style={{
              scrollMarginTop: '96px',
              display: 'flex',
              flexWrap: 'wrap',
              gap: '20px 48px',
              padding: '40px 0',
              borderTop: '1px solid var(--border-default)',
              borderBottom: '1px solid var(--border-default)',
            }}
          >
            <div style={{ flex: '0 1 300px', minWidth: '0', display: 'flex', alignItems: 'center', gap: '18px' }}>
              <span
                style={{
                  width: '72px',
                  height: '72px',
                  flex: 'none',
                  borderRadius: '20px',
                  background: 'var(--blush-50)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontFamily: 'var(--font-display)',
                  fontSize: '40px',
                  fontWeight: '700',
                  color: 'var(--blush-700)',
                }}
              >
                R
              </span>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '32px',
                  lineHeight: '1.2',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                }}
              >
                Respect
              </h2>
            </div>
            <div style={{ flex: '1 1 480px', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <p
                style={{
                  fontFamily: 'var(--font-reading)',
                  fontSize: '20px',
                  lineHeight: '1.7',
                  color: 'var(--text-body)',
                  margin: '0',
                  textWrap: 'pretty',
                }}
              >
                Every question deserves a respectful answer. When you join a discussion, please stay on topic.
              </p>
              <div
                style={{
                  display: 'flex',
                  gap: '14px',
                  alignItems: 'flex-start',
                  padding: '18px 20px',
                  borderRadius: '16px',
                  border: '1px solid var(--border-default)',
                }}
              >
                <Icon name="user-round" size={24} color="var(--blush-700)" />
                <div style={{ minWidth: '0' }}>
                  <div
                    style={{ fontSize: '18px', fontWeight: '700', color: 'var(--text-strong)', marginBottom: '4px' }}
                  >
                    One person, one account
                  </div>
                  <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                    {'Can’t get into your account? Email '}
                    <a href="mailto:community@parentcircle.in" style={{ fontWeight: '600' }}>
                      community@parentcircle.in
                    </a>
                    {' instead of making a new one.'}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '80px 24px 0',
            boxSizing: 'border-box',
            display: 'flex',
            flexWrap: 'wrap',
            gap: '32px 56px',
            alignItems: 'flex-start',
          }}
        >
          <div style={{ flex: '1 1 340px', minWidth: '0' }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '10px',
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--text-muted)',
                marginBottom: '12px',
              }}
            >
              <Icon name="shield-check" size={18} />
              Keeping circles safe
            </div>
            <h2
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(28px,3vw,36px)',
                lineHeight: '1.2',
                letterSpacing: '-0.01em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
                textWrap: 'balance',
              }}
            >
              When our team may edit or remove a post
            </h2>
            <p style={{ fontSize: '19px', lineHeight: '1.55', color: 'var(--text-body)', margin: '0' }}>
              Our community admins can edit, hide or decline any post that includes:
            </p>
          </div>
          <ul
            style={{
              flex: '1.4 1 480px',
              minWidth: '0',
              listStyle: 'none',
              margin: '0',
              padding: '0',
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,260px),1fr))',
              gap: '10px',
            }}
          >
            <li
              style={{
                display: 'flex',
                gap: '12px',
                alignItems: 'flex-start',
                padding: '16px 18px',
                borderRadius: '12px',
                background: 'var(--neutral-50)',
                fontSize: '17px',
                lineHeight: '1.45',
                color: 'var(--text-strong)',
              }}
            >
              <Icon name="circle-x" size={22} color="var(--neutral-500)" />
              Anything that could harm others
            </li>
            <li
              style={{
                display: 'flex',
                gap: '12px',
                alignItems: 'flex-start',
                padding: '16px 18px',
                borderRadius: '12px',
                background: 'var(--neutral-50)',
                fontSize: '17px',
                lineHeight: '1.45',
                color: 'var(--text-strong)',
              }}
            >
              <Icon name="circle-x" size={22} color="var(--neutral-500)" />
              Rude or hurtful remarks about another member
            </li>
            <li
              style={{
                display: 'flex',
                gap: '12px',
                alignItems: 'flex-start',
                padding: '16px 18px',
                borderRadius: '12px',
                background: 'var(--neutral-50)',
                fontSize: '17px',
                lineHeight: '1.45',
                color: 'var(--text-strong)',
              }}
            >
              <Icon name="circle-x" size={22} color="var(--neutral-500)" />
              Content that’s damaging or unhelpful
            </li>
            <li
              style={{
                display: 'flex',
                gap: '12px',
                alignItems: 'flex-start',
                padding: '16px 18px',
                borderRadius: '12px',
                background: 'var(--neutral-50)',
                fontSize: '17px',
                lineHeight: '1.45',
                color: 'var(--text-strong)',
              }}
            >
              <Icon name="circle-x" size={22} color="var(--neutral-500)" />
              Anything that invades someone’s privacy
            </li>
            <li
              style={{
                display: 'flex',
                gap: '12px',
                alignItems: 'flex-start',
                padding: '16px 18px',
                borderRadius: '12px',
                background: 'var(--neutral-50)',
                fontSize: '17px',
                lineHeight: '1.45',
                color: 'var(--text-strong)',
              }}
            >
              <Icon name="circle-x" size={22} color="var(--neutral-500)" />
              Adverts for products or services
            </li>
            <li
              style={{
                display: 'flex',
                gap: '12px',
                alignItems: 'flex-start',
                padding: '16px 18px',
                borderRadius: '12px',
                background: 'var(--neutral-50)',
                fontSize: '17px',
                lineHeight: '1.45',
                color: 'var(--text-strong)',
              }}
            >
              <Icon name="circle-x" size={22} color="var(--neutral-500)" />
              Phone numbers, addresses or emails — including in photos
            </li>
            <li
              style={{
                display: 'flex',
                gap: '12px',
                alignItems: 'flex-start',
                padding: '16px 18px',
                borderRadius: '12px',
                background: 'var(--neutral-50)',
                fontSize: '17px',
                lineHeight: '1.45',
                color: 'var(--text-strong)',
              }}
            >
              <Icon name="circle-x" size={22} color="var(--neutral-500)" />
              Details or methods of self-harm, suicide or sexual abuse
            </li>
            <li
              style={{
                display: 'flex',
                gap: '12px',
                alignItems: 'flex-start',
                padding: '16px 18px',
                borderRadius: '12px',
                background: 'var(--neutral-50)',
                fontSize: '17px',
                lineHeight: '1.45',
                color: 'var(--text-strong)',
              }}
            >
              <Icon name="circle-x" size={22} color="var(--neutral-500)" />
              The same post shared many times
            </li>
          </ul>
        </section>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '80px 24px 0', boxSizing: 'border-box' }}>
          <div
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '24px 40px',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: 'clamp(28px,4vw,48px)',
              borderRadius: '24px',
              background: 'var(--orange-50)',
            }}
          >
            <div style={{ flex: '1 1 420px', minWidth: '0' }}>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(28px,3vw,36px)',
                  lineHeight: '1.2',
                  letterSpacing: '-0.01em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0 0 8px',
                }}
              >
                Ready to join the circle?
              </h2>
              <p style={{ fontSize: '19px', lineHeight: '1.5', color: 'var(--text-body)', margin: '0' }}>
                Be part of one of India’s fastest-growing parenting communities.
              </p>
            </div>
            <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
              <a href={toUrl('/communities')} style={{ textDecoration: 'none' }}>
                <Button variant="primary" size="lg" iconRight="arrow-right">
                  Find a circle
                </Button>
              </a>
              <a href="mailto:community@parentcircle.in" style={{ textDecoration: 'none' }}>
                <Button variant="secondary" size="lg" icon="mail">
                  Contact the team
                </Button>
              </a>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter spaced />
    </div>
  );
}
