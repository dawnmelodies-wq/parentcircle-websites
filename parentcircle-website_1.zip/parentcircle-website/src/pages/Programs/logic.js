import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = { filter: 'all' };
  tabs = [
    { value: 'all', label: 'All programs' },
    { value: 'parents', label: 'For parents' },
    { value: 'children', label: 'For children' },
    { value: 'free', label: 'Free' },
  ];
  list = [
    {
      id: 'superstar',
      name: 'SuperStar Program',
      kind: 'Community',
      icon: 'star',
      hue: 'orange',
      badge: 'Free',
      tone: 'brand',
      tags: ['parents', 'free'],
      href: '/superstar',
      cta: 'Become a SuperStar',
      src: 'https://pcprd.azureedge.net/image/superstar_image/community-img.png',
      photo: 'SuperStar members together',
      desc: 'Share your ParentCircle story, inspire other parents, and get invited to exclusive meetups and events.',
    },
    {
      id: 'gfh',
      name: '#GadgetFreeHour',
      kind: 'Campaign',
      icon: 'smartphone',
      hue: 'lilac',
      badge: '20 Nov',
      tone: 'neutral',
      tags: ['parents', 'children', 'free'],
      href: '/video#pledge',
      cta: 'Take the pledge',
      src: '',
      photo: 'Family playing a board game, phones away',
      desc: 'One screen-free hour together as a family on World Children’s Day. Grandparents welcome.',
    },
    {
      id: 'dot',
      name: 'The Dot Learning Circle',
      kind: 'Early learning',
      icon: 'graduation-cap',
      hue: 'sky',
      badge: 'Ages 3–6',
      tone: 'info',
      tags: ['children'],
      href: 'https://www.dotlearningcircle.com/',
      cta: 'Explore the curriculum',
      src: '',
      photo: 'Kindergarten children learning together',
      desc: 'A complete kindergarten curriculum for pre-primary children, built by early-years educators.',
    },
    {
      id: 'little',
      name: 'Little Learners @Home',
      kind: 'Learning at home',
      icon: 'puzzle',
      hue: 'butter',
      badge: 'Ages 2–6',
      tone: 'warning',
      tags: ['children'],
      href: '#',
      cta: 'Start a free week',
      src: '',
      photo: 'Preschooler and parent doing an activity',
      desc: 'Play-based preschool learning you can do together at home, in about 20 minutes a day.',
    },
    {
      id: 'expert',
      name: 'Ask the Expert',
      kind: 'Expert help',
      icon: 'stethoscope',
      hue: 'sage',
      badge: 'Free',
      tone: 'success',
      tags: ['parents', 'free'],
      href: '/ask-the-expert',
      cta: 'Ask a question',
      src: '',
      photo: 'Paediatrician talking with a parent',
      desc: 'Send your question to paediatricians, psychologists and educators. Ask anonymously if you prefer.',
    },
    {
      id: 'live',
      name: 'Webinars and parent meetups',
      kind: 'Live events',
      icon: 'calendar',
      hue: 'blush',
      badge: 'Live',
      tone: 'neutral',
      tags: ['parents'],
      href: '#',
      cta: 'See what’s coming up',
      src: '',
      photo: 'Parents at a meetup',
      desc: 'Talks with experts and friendly meetups with other parents — online and in your city.',
    },
  ];
  renderVals() {
    const F = this.state.filter;
    return {
      tabs: this.tabs,
      filter: F,
      setFilter: (v) => this.setState({ filter: v }),
      programs: this.list
        .filter((p) => F === 'all' || p.tags.includes(F))
        .map((p) => ({
          ...p,
          bg: 'var(--' + p.hue + '-50)',
          tile: 'var(--' + p.hue + '-100)',
          fg: 'var(--' + p.hue + '-700)',
          src: p.src || undefined,
        })),
    };
  }
}

export default PageLogic;
