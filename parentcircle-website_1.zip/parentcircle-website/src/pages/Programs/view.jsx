import { Fragment } from 'react';
import { Badge, Button, Icon, Tabs } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Programs" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Programs"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader active="programs" communityHref="/#community" />
      <section style={{ background: 'var(--butter-50)' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '40px 24px 56px', boxSizing: 'border-box' }}>
          <nav
            aria-label="Breadcrumb"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              fontSize: '15px',
              color: 'var(--text-muted)',
              marginBottom: '24px',
            }}
          >
            <a
              className="hv-1"
              href={toUrl('/')}
              style={{ color: 'var(--text-muted)', textDecoration: 'none', fontWeight: '600' }}
            >
              Home
            </a>
            <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
            <span>Programs</span>
          </nav>
          <h1
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(36px,4.4vw,52px)',
              lineHeight: '1.1',
              letterSpacing: '-0.015em',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0',
              maxWidth: '760px',
              textWrap: 'balance',
            }}
          >
            Programs for parents and families
          </h1>
          <p
            style={{
              fontFamily: 'var(--font-serif)',
              fontSize: '22px',
              lineHeight: '1.55',
              color: 'var(--text-body)',
              margin: '16px 0 28px',
              maxWidth: '620px',
              textWrap: 'pretty',
            }}
          >
            Learn, connect and grow with ParentCircle — at your own pace, and alongside other families.
          </p>
          <Tabs variant="pill" tabs={v.tabs} value={v.filter} onChange={v.setFilter} />
        </div>
      </section>
      <main style={{ maxWidth: '1200px', margin: '0 auto', padding: '48px 24px 0', boxSizing: 'border-box' }}>
        <div
          style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,340px),1fr))', gap: '28px' }}
        >
          {(v.programs ?? []).map((p, $i0) => (
            <Fragment key={$i0}>
              <div
                className="hv-6"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  borderRadius: '16px',
                  overflow: 'hidden',
                  background: p?.bg,
                  color: 'inherit',
                  transition: 'transform 200ms cubic-bezier(.2,0,0,1), box-shadow 200ms cubic-bezier(.2,0,0,1)',
                }}
              >
                <div
                  style={{
                    width: '100%',
                    aspectRatio: '16 / 9',
                    position: 'relative',
                    background: p?.tile,
                    color: p?.fg,
                  }}
                >
                  <image-slot
                    id={`prog-${p?.id ?? ''}`}
                    shape="rect"
                    fit="cover"
                    src={toUrl(p?.src)}
                    placeholder={p?.photo}
                  ></image-slot>
                </div>
                <a
                  href={toUrl(p?.href)}
                  style={{
                    padding: '24px 24px 28px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '12px',
                    flex: '1',
                    textDecoration: 'none',
                    color: 'inherit',
                  }}
                >
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '12px',
                      flexWrap: 'wrap',
                    }}
                  >
                    <span
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        fontSize: '14px',
                        fontWeight: '700',
                        letterSpacing: '0.08em',
                        textTransform: 'uppercase',
                        color: p?.fg,
                      }}
                    >
                      <Icon name={p?.icon} size={18} />
                      {p?.kind}
                    </span>
                    <Badge tone={p?.tone}>{p?.badge}</Badge>
                  </div>
                  <span
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '26px',
                      lineHeight: '1.2',
                      fontWeight: '700',
                      letterSpacing: '-0.01em',
                      color: 'var(--text-strong)',
                    }}
                  >
                    {p?.name}
                  </span>
                  <span
                    style={{
                      fontFamily: 'var(--font-serif)',
                      fontSize: '19px',
                      lineHeight: '1.55',
                      color: 'var(--text-body)',
                      textWrap: 'pretty',
                    }}
                  >
                    {p?.desc}
                  </span>
                  <span
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      marginTop: 'auto',
                      paddingTop: '8px',
                      fontSize: '17px',
                      fontWeight: '600',
                      color: 'var(--orange-700)',
                    }}
                  >
                    {p?.cta}
                    <Icon name="arrow-right" size={20} />
                  </span>
                </a>
              </div>
            </Fragment>
          ))}
        </div>
        <section
          style={{
            marginTop: '72px',
            display: 'flex',
            flexWrap: 'wrap',
            gap: '24px 40px',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '32px',
            border: '1px solid var(--border-default)',
            borderRadius: '24px',
          }}
        >
          <div style={{ display: 'flex', gap: '18px', alignItems: 'center', flex: '1 1 420px', minWidth: '0' }}>
            <span
              style={{
                width: '60px',
                height: '60px',
                flex: 'none',
                borderRadius: '16px',
                background: 'var(--sage-50)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="message-circle" size={30} color="var(--sage-700)" />
            </span>
            <div>
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '24px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                }}
              >
                Not sure which program is right for you?
              </div>
              <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-muted)', marginTop: '4px' }}>
                Tell us your child’s age and what you’re looking for. Our team will suggest a place to start.
              </div>
            </div>
          </div>
          <Button variant="dark" icon="message-circle">
            Talk to our team
          </Button>
        </section>
      </main>
      <SiteFooter spaced />
    </div>
  );
}
