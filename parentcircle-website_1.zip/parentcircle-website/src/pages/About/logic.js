import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = { role: 'parents' };
  roles = {
    parents: {
      label: 'Parents',
      icon: 'heart',
      hue: 'orange',
      title: 'As a parent or grandparent',
      text: 'Read and share trusted guidance, connect with experts and other families, and help create content that helps others.',
      cta: 'Join free',
    },
    experts: {
      label: 'Experts',
      icon: 'stethoscope',
      hue: 'sage',
      title: 'As a child-development expert',
      text: 'Share what you know about raising children, and make a real difference to families across India.',
      cta: 'Write for us',
    },
    business: {
      label: 'Businesses',
      icon: 'briefcase',
      hue: 'butter',
      title: 'As a business',
      text: 'Reach a large, engaged audience of parents — and build lasting relationships with the families you serve.',
      cta: 'Partner with us',
    },
    schools: {
      label: 'Schools',
      icon: 'school',
      hue: 'sky',
      title: 'As a school or institute',
      text: 'Share parenting advice and learning resources with your parents — because strong school–home partnerships help children do better.',
      cta: 'Work with us',
    },
    employers: {
      label: 'Employers',
      icon: 'building-2',
      hue: 'lilac',
      title: 'As an employer',
      text: 'Set up a private parenting club for your team. Happier homes make for happier, more productive workplaces.',
      cta: 'Talk to us',
    },
  };
  renderVals() {
    const r = this.roles[this.state.role];
    return {
      roleTabs: Object.entries(this.roles).map(([value, x]) => ({ value, label: x.label })),
      role: this.state.role,
      setRole: (v) => this.setState({ role: v }),
      panel: { ...r, bg: 'var(--' + r.hue + '-50)', fg: 'var(--' + r.hue + '-700)' },
    };
  }
}

export default PageLogic;
