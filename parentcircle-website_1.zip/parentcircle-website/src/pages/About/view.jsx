import { Fragment } from 'react';
import { Button, Icon, Tabs, Tag } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "About" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="About"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader communityHref="/#community" />
      <main>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '32px 24px 0', boxSizing: 'border-box' }}>
          <nav aria-label="Company" style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '40px' }}>
            <a
              href={toUrl('/about')}
              aria-current="page"
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                background: 'var(--neutral-900)',
                color: 'var(--text-inverse)',
                fontSize: '16px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              About us
            </a>
            <a
              className="hv-0"
              href={toUrl('/press')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Press releases
            </a>
            <a
              className="hv-0"
              href={toUrl('/guidelines')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Community guidelines
            </a>
            <a
              className="hv-0"
              href={toUrl('/community-help')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Community help
            </a>
            <a
              className="hv-0"
              href={toUrl('/terms')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Terms of use
            </a>
            <a
              className="hv-0"
              href={toUrl('/privacy')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Privacy policy
            </a>
            <a
              className="hv-0"
              href={toUrl('/contact')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Contact us
            </a>
          </nav>
          <div style={{ maxWidth: '820px' }}>
            <div
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--orange-700)',
                marginBottom: '12px',
              }}
            >
              About ParentCircle
            </div>
            <h1
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(38px,5vw,60px)',
                lineHeight: '1.08',
                letterSpacing: '-0.015em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0',
                textWrap: 'balance',
              }}
            >
              We help parents raise happy, successful children
            </h1>
            <p
              style={{
                fontFamily: 'var(--font-serif)',
                fontSize: '23px',
                lineHeight: '1.55',
                color: 'var(--text-body)',
                margin: '20px 0 40px',
                textWrap: 'pretty',
              }}
            >
              Through holistic parenting — caring for a child’s body, mind, feelings and friendships, all at once.
            </p>
          </div>
          <div
            style={{
              position: 'relative',
              overflow: 'hidden',
              width: '100%',
              aspectRatio: '21 / 9',
              borderRadius: '24px',
              background: 'var(--orange-50)',
            }}
          >
            <image-slot
              id="about-hero"
              shape="rounded"
              radius="24"
              src={toUrl('/images/about-hero.png')}
              placeholder="Photo: parents and children from the ParentCircle community"
            ></image-slot>
          </div>
        </section>
        <section
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '80px 24px 0',
            boxSizing: 'border-box',
            display: 'flex',
            flexWrap: 'wrap',
            gap: '32px 64px',
          }}
        >
          <h2
            style={{
              flex: '1 1 300px',
              minWidth: '0',
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(30px,3.4vw,40px)',
              lineHeight: '1.15',
              letterSpacing: '-0.01em',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0',
              textWrap: 'balance',
            }}
          >
            Success looks different for every child
          </h2>
          <div
            style={{
              flex: '2 1 480px',
              minWidth: '0',
              fontFamily: 'var(--font-reading)',
              fontSize: '21px',
              lineHeight: '1.7',
              color: 'var(--text-body)',
            }}
          >
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              For one family it’s a good day at school. For another it’s a first goal on the football field, a confident
              teenager, or a fulfilling career years from now.
            </p>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              Whatever success means to you, our goal is the same: to stand beside you as you set your child up for it —
              and for the happiness that follows.
            </p>
          </div>
        </section>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '80px 24px 0', boxSizing: 'border-box' }}>
          <div style={{ maxWidth: '720px', marginBottom: '32px' }}>
            <div
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--orange-700)',
                marginBottom: '10px',
              }}
            >
              Our mission
            </div>
            <h2
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(30px,3.4vw,40px)',
                lineHeight: '1.15',
                letterSpacing: '-0.01em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 14px',
                textWrap: 'balance',
              }}
            >
              It takes a village to raise a child
            </h2>
            <p
              style={{
                fontFamily: 'var(--font-serif)',
                fontSize: '21px',
                lineHeight: '1.6',
                color: 'var(--text-body)',
                margin: '0',
                textWrap: 'pretty',
              }}
            >
              So we bring that village together — sharing what they know to support every part of a child’s growth.
            </p>
          </div>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,220px),1fr))',
              gap: '16px',
            }}
          >
            <div style={{ background: 'var(--orange-50)', borderRadius: '16px', padding: '24px' }}>
              <Icon name="users" size={30} color="var(--orange-600)" />
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '22px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  marginTop: '12px',
                }}
              >
                Parents and grandparents
              </div>
            </div>
            <div style={{ background: 'var(--sky-50)', borderRadius: '16px', padding: '24px' }}>
              <Icon name="graduation-cap" size={30} color="var(--sky-700)" />
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '22px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  marginTop: '12px',
                }}
              >
                Educators
              </div>
            </div>
            <div style={{ background: 'var(--sage-50)', borderRadius: '16px', padding: '24px' }}>
              <Icon name="stethoscope" size={30} color="var(--sage-700)" />
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '22px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  marginTop: '12px',
                }}
              >
                Health specialists
              </div>
            </div>
            <div style={{ background: 'var(--blush-50)', borderRadius: '16px', padding: '24px' }}>
              <Icon name="brain" size={30} color="var(--blush-700)" />
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '22px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  marginTop: '12px',
                }}
              >
                Child experts
              </div>
            </div>
          </div>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              flexWrap: 'wrap',
              marginTop: '20px',
              fontSize: '17px',
              color: 'var(--text-muted)',
            }}
          >
            <span>Supporting every side of growing up:</span>
            <Tag>Physical</Tag>
            <Tag>Emotional</Tag>
            <Tag>Social</Tag>
            <Tag>Intellectual</Tag>
          </div>
        </section>
        <section style={{ marginTop: '80px', background: 'var(--orange-50)' }}>
          <div
            style={{
              maxWidth: '1200px',
              margin: '0 auto',
              padding: '64px 24px',
              boxSizing: 'border-box',
              display: 'flex',
              flexWrap: 'wrap',
              gap: '32px 64px',
              alignItems: 'center',
            }}
          >
            <div style={{ flex: '1 1 400px', minWidth: '0' }}>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-700)',
                  marginBottom: '10px',
                }}
              >
                {'English and '}
                <span style={{ fontFamily: 'var(--font-tamil-sans)', letterSpacing: '0', textTransform: 'none' }}>
                  தமிழ்
                </span>
              </div>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(30px,3.4vw,40px)',
                  lineHeight: '1.15',
                  letterSpacing: '-0.01em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0 0 14px',
                  textWrap: 'balance',
                }}
              >
                Pioneers of holistic parenting in India
              </h2>
              <p
                style={{
                  fontFamily: 'var(--font-serif)',
                  fontSize: '21px',
                  lineHeight: '1.6',
                  color: 'var(--text-body)',
                  margin: '0',
                  textWrap: 'pretty',
                }}
              >
                We were among the first to offer holistic parenting content in English and in Tamil — for parents of
                infants all the way to parents of teens.
              </p>
            </div>
            <div
              style={{
                flex: '1 1 380px',
                minWidth: '0',
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,150px),1fr))',
                gap: '12px',
              }}
            >
              <div
                style={{
                  background: 'var(--white)',
                  borderRadius: '16px',
                  padding: '20px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '10px',
                }}
              >
                <Icon name="book-open" size={28} color="var(--orange-600)" />
                <span style={{ fontSize: '18px', fontWeight: '700', color: 'var(--text-strong)' }}>Magazines</span>
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>In print, every month</span>
              </div>
              <div
                style={{
                  background: 'var(--white)',
                  borderRadius: '16px',
                  padding: '20px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '10px',
                }}
              >
                <Icon name="globe" size={28} color="var(--orange-600)" />
                <span style={{ fontSize: '18px', fontWeight: '700', color: 'var(--text-strong)' }}>Website</span>
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>parentcircle.com</span>
              </div>
              <div
                style={{
                  background: 'var(--white)',
                  borderRadius: '16px',
                  padding: '20px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '10px',
                }}
              >
                <Icon name="smartphone" size={28} color="var(--orange-600)" />
                <span style={{ fontSize: '18px', fontWeight: '700', color: 'var(--text-strong)' }}>Apps</span>
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>On your phone</span>
              </div>
            </div>
          </div>
        </section>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '80px 24px 0', boxSizing: 'border-box' }}>
          <div
            style={{
              fontSize: '14px',
              fontWeight: '700',
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              color: 'var(--orange-700)',
              marginBottom: '10px',
            }}
          >
            How we help
          </div>
          <h2
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(30px,3.4vw,40px)',
              lineHeight: '1.15',
              letterSpacing: '-0.01em',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0 0 28px',
            }}
          >
            Four promises to parents
          </h2>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,260px),1fr))',
              gap: '4px 40px',
            }}
          >
            <div
              style={{
                display: 'flex',
                gap: '18px',
                alignItems: 'flex-start',
                padding: '22px 0',
                borderTop: '1px solid var(--border-default)',
              }}
            >
              <span
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '40px',
                  lineHeight: '1',
                  fontWeight: '700',
                  color: 'var(--pc-orange)',
                  flex: 'none',
                  width: '36px',
                }}
              >
                1
              </span>
              <div>
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    marginBottom: '6px',
                  }}
                >
                  Trusted, complete content
                </div>
                <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                  Articles, e-books, videos and more — covering every stage of childhood.
                </div>
              </div>
            </div>
            <div
              style={{
                display: 'flex',
                gap: '18px',
                alignItems: 'flex-start',
                padding: '22px 0',
                borderTop: '1px solid var(--border-default)',
              }}
            >
              <span
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '40px',
                  lineHeight: '1',
                  fontWeight: '700',
                  color: 'var(--pc-orange)',
                  flex: 'none',
                  width: '36px',
                }}
              >
                2
              </span>
              <div>
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    marginBottom: '6px',
                  }}
                >
                  Made for your family
                </div>
                <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                  Technology that brings you what’s relevant to your child’s age and needs.
                </div>
              </div>
            </div>
            <div
              style={{
                display: 'flex',
                gap: '18px',
                alignItems: 'flex-start',
                padding: '22px 0',
                borderTop: '1px solid var(--border-default)',
              }}
            >
              <span
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '40px',
                  lineHeight: '1',
                  fontWeight: '700',
                  color: 'var(--pc-orange)',
                  flex: 'none',
                  width: '36px',
                }}
              >
                3
              </span>
              <div>
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    marginBottom: '6px',
                  }}
                >
                  Parents and experts, together
                </div>
                <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                  Small online communities where parents, doctors, educators and counsellors share ideas.
                </div>
              </div>
            </div>
            <div
              style={{
                display: 'flex',
                gap: '18px',
                alignItems: 'flex-start',
                padding: '22px 0',
                borderTop: '1px solid var(--border-default)',
              }}
            >
              <span
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '40px',
                  lineHeight: '1',
                  fontWeight: '700',
                  color: 'var(--pc-orange)',
                  flex: 'none',
                  width: '36px',
                }}
              >
                4
              </span>
              <div>
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    marginBottom: '6px',
                  }}
                >
                  Helpful services
                </div>
                <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                  A place to find useful services for children — from music lessons to child health.
                </div>
              </div>
            </div>
          </div>
        </section>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '80px 24px 0', boxSizing: 'border-box' }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'flex-end',
              justifyContent: 'space-between',
              gap: '20px',
              flexWrap: 'wrap',
              marginBottom: '24px',
            }}
          >
            <div>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-700)',
                  marginBottom: '10px',
                }}
              >
                Join us
              </div>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(30px,3.4vw,40px)',
                  lineHeight: '1.15',
                  letterSpacing: '-0.01em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                }}
              >
                What you can do with ParentCircle
              </h2>
            </div>
            <Tabs variant="pill" tabs={v.roleTabs} value={v.role} onChange={v.setRole} />
          </div>
          <div
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '24px 40px',
              alignItems: 'center',
              background: v.panel?.bg,
              borderRadius: '24px',
              padding: 'clamp(24px,4vw,40px)',
            }}
          >
            <span
              style={{
                width: '88px',
                height: '88px',
                flex: 'none',
                borderRadius: '24px',
                background: 'var(--white)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name={v.panel?.icon} size={40} color={v.panel?.fg} />
            </span>
            <div style={{ flex: '1 1 420px', minWidth: '0' }}>
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '28px',
                  lineHeight: '1.25',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  marginBottom: '8px',
                }}
              >
                {v.panel?.title}
              </div>
              <p
                style={{
                  fontFamily: 'var(--font-serif)',
                  fontSize: '20px',
                  lineHeight: '1.6',
                  color: 'var(--text-body)',
                  margin: '0',
                  textWrap: 'pretty',
                }}
              >
                {v.panel?.text}
              </p>
            </div>
            <Button variant="dark" iconRight="arrow-right">
              {v.panel?.cta}
            </Button>
          </div>
        </section>
        <section
          id="contact"
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '80px 24px 0',
            boxSizing: 'border-box',
            scrollMarginTop: '88px',
          }}
        >
          <div
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '24px 40px',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '32px',
              border: '1px solid var(--border-default)',
              borderRadius: '24px',
            }}
          >
            <div style={{ flex: '1 1 420px', minWidth: '0' }}>
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '24px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  marginBottom: '6px',
                }}
              >
                A Ramco Group associate
              </div>
              <p style={{ fontSize: '17px', lineHeight: '1.55', color: 'var(--text-body)', margin: '0' }}>
                ParentCircle is published by Shri Harini Media Ltd., Chennai — part of the Ramco Group, an Indian
                conglomerate with interests in IT, cement and textiles.
              </p>
            </div>
            <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
              <a href={toUrl('/contact')} style={{ textDecoration: 'none' }}>
                <Button variant="primary" icon="mail">
                  Contact us
                </Button>
              </a>
              <a href={toUrl('/press')} style={{ textDecoration: 'none' }}>
                <Button variant="secondary" icon="newspaper">
                  Press releases
                </Button>
              </a>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter spaced />
    </div>
  );
}
