import React from 'react';
import { PageLogicBase } from '../../lib/createPage';
import { toUrl, pageLocation } from '../../lib/paths';

class PageLogic extends PageLogicBase {
  state = {
    tab: 'activities',
    readAll: false,
    readIds: [],
    left: [],
    removed: [],
    favRemoved: [],
    favKind: 'All',
    topics: ['Managing child behaviour', 'Health and fitness', 'Academics', 'Family life', 'Baby care'],
    kids: [
      ['Aadhya', '4 years', 'Pre-schooler'],
      ['Ved', '9 months', 'Infant'],
    ],
    f: {
      name: 'Priya Raman',
      city: 'Chennai',
      email: 'priya.raman@example.com',
      phone: '98400 12345',
      bio: 'Mother of two, Chennai. Learning to slow down — one bedtime story at a time.',
    },
    err: {},
    prefs: { digest: true, replies: true, experts: true, private: false },
    savedOk: false,
  };
  TABS = [
    ['activities', 'My profile', 'user-round'],
    ['notification', 'Notifications', 'bell'],
    ['communities', 'Communities', 'users'],
    ['discussions', 'Discussions', 'message-square'],
    ['bookmarks', 'Saved stories', 'bookmark'],
    ['favourites', 'Favourites', 'heart'],
    ['interests', 'Interests', 'sparkles'],
    ['comments', 'Comments', 'message-circle'],
    ['messages', 'Messages', 'mail'],
    ['settings', 'Settings', 'settings'],
  ];
  HUE = { emotions: 'blush', health: 'sage', learning: 'sky', play: 'butter', teens: 'lilac' };
  ICON = {
    comment: 'message-circle',
    save: 'bookmark',
    join: 'users',
    like: 'heart',
    ask: 'stethoscope',
    post: 'square-pen',
    video: 'circle-play',
  };
  ACT = [
    [
      'comment',
      'You commented on a story',
      'How and when to respond to your child’s tantrums',
      '/article',
      '2 hours ago',
      'emotions',
      'Naming the feeling first really works with my 4-year-old. Thank you for this.',
    ],
    [
      'save',
      'You saved a story',
      'How to keep your child healthy: 9 simple everyday habits',
      '/article',
      'Yesterday',
      'health',
    ],
    [
      'post',
      'You started a discussion in 3–6 Years',
      'My daughter won’t share her toys at playdates — what helped you?',
      '/communities',
      '2 days ago',
      'play',
    ],
    [
      'ask',
      'You asked an expert',
      'Is it normal for a 9-month-old to wake every two hours?',
      '/ask-the-expert',
      '3 days ago',
      'health',
    ],
    [
      'like',
      'You liked a quote',
      '“You can’t teach children to behave better by making them feel worse.” — Pam Leo',
      '/quotes',
      '4 days ago',
      'emotions',
    ],
    ['join', 'You joined a circle', 'Gadget Free Hour', '/communities', '1 week ago', 'teens'],
    ['video', 'You watched a video', 'Day 14: Wiggly-Giggly', '/challenge-video', '1 week ago', 'play'],
    [
      'comment',
      'You replied in Just for Parents',
      'When “calm down” makes it worse',
      '/communities',
      '2 weeks ago',
      'emotions',
      'I’ve started saying “I’m here” instead. It changes the whole moment.',
    ],
  ];
  NOTES = [
    ['n1', 'Dr. Meera Iyer', 'answered your question about night waking.', '1 hour ago'],
    ['n2', 'Kavya S', 'replied to your discussion “My daughter won’t share her toys…”', '3 hours ago'],
    ['n3', 'Arjun M', 'and 6 others liked your comment.', 'Yesterday'],
    ['n4', 'Team ParentCircle', 'picked 5 new stories for your toddler.', '2 days ago'],
    ['n5', 'Deepa R', 'mentioned you in Gadget Free Hour.', '4 days ago'],
    ['n6', 'Team ParentCircle', 'Your SuperStar Parenting entry has been received.', '1 week ago'],
  ];
  CIRCLES = [
    [
      'gfh',
      'Gadget Free Hour',
      '1.7K members · 68 discussions',
      'Raising children in the digital world.',
      'lilac',
      'Family playing a board game with phones put away',
    ],
    [
      '36',
      '3–6 Years',
      '2.5K members · 71 discussions',
      'Curiosity, tantrums and what not!',
      'butter',
      'Preschoolers playing together',
    ],
    [
      '02',
      '0–2 Years',
      '3.1K members · 112 discussions',
      'Sleep, feeds and first words.',
      'sage',
      'Baby crawling on a play mat',
    ],
    [
      'jfp',
      'Just for Parents',
      '4.1K members · 221 discussions',
      'Your own wellbeing matters too.',
      'blush',
      'Parents sharing tea on a balcony',
    ],
  ];
  DISC = [
    [
      'My daughter won’t share her toys at playdates — what helped you?',
      '3–6 Years',
      '12 replies',
      '210 views',
      '2 days ago',
      true,
    ],
    [
      'Screen-free evening ideas that actually work for a 4-year-old?',
      'Gadget Free Hour',
      '27 replies',
      '640 views',
      '3 weeks ago',
      false,
    ],
    ['Night waking at 9 months — anyone else?', '0–2 Years', '19 replies', '480 views', '1 month ago', true],
  ];
  SAVED = [
    [
      's1',
      'How to keep your child healthy: 9 simple everyday habits',
      'Health and fitness',
      'health',
      '6 min read',
      'Child brushing teeth beside a parent',
    ],
    [
      's2',
      'Why tantrums peak at age two — and the one thing that calms them',
      'Managing behaviour',
      'emotions',
      '6 min read',
      'Parent calming an upset toddler',
    ],
    [
      's3',
      'Night waking at 9 months: is it a sleep regression?',
      'Baby care',
      'health',
      '5 min read',
      'Baby asleep in a cradle',
    ],
    [
      's4',
      'How to choose the right pre-primary school',
      'Academics',
      'learning',
      '7 min read',
      'Parent and child at a school gate',
    ],
    [
      's5',
      'Games that build problem-solving skills in preschoolers',
      'Building skills',
      'play',
      '5 min read',
      'Preschooler solving a wooden puzzle',
    ],
    [
      's6',
      'Talking to your teenager about screen time',
      'Technology',
      'teens',
      '7 min read',
      'Teen and parent talking on a sofa',
    ],
  ];
  FAVS = [
    [
      'f1',
      'Story',
      'book-open',
      'Scolding children to discipline them: what parents need to know',
      '/article',
      'emotions',
      'Calm talk',
    ],
    [
      'f2',
      'Video',
      'circle-play',
      'Breaking gender stereotypes in parenting: Nalina Ramalakshmi with Jeo Baby',
      '/video',
      'learning',
      'Interview still',
    ],
    [
      'f3',
      'Quote',
      'quote',
      '“Your job isn’t to stop your child from feeling upset…” — Dr Becky Kennedy',
      '/quotes',
      'emotions',
      'Comforting hug',
    ],
    [
      'f4',
      'Recipe',
      'cooking-pot',
      '6 high-protein snacks for kids you can make in minutes',
      '/recipes',
      'play',
      'Ragi uthapam',
    ],
    [
      'f5',
      'Story',
      'book-open',
      'A mother’s NICU journey: a story of hope and love',
      '/parents-of-india',
      'health',
      'Tiny hand',
    ],
  ];
  TOPICS = [
    ['Managing child behaviour', 'heart'],
    ['Health and fitness', 'apple'],
    ['Academics', 'graduation-cap'],
    ['Family life', 'users'],
    ['Baby care', 'baby'],
    ['Mental health', 'brain'],
    ['Building skills', 'puzzle'],
    ['Technology', 'smartphone'],
    ['Recipes', 'cooking-pot'],
    ['Festivals and culture', 'sparkles'],
    ['Special needs', 'hand-heart'],
    ['Pregnancy care', 'flower-2'],
  ];
  COMMENTS = [
    [
      'How and when to respond to your child’s tantrums',
      '/article',
      '2 hours ago',
      'Naming the feeling first really works with my 4-year-old. Thank you for this.',
      4,
      1,
    ],
    [
      'When “calm down” makes it worse',
      '/communities',
      '2 weeks ago',
      'I’ve started saying “I’m here” instead. It changes the whole moment.',
      11,
      3,
    ],
    [
      'Day 14: Wiggly-Giggly',
      '/challenge-video',
      '1 week ago',
      'Paati won! She was the most focused of all of us — the children couldn’t stop laughing.',
      7,
      2,
    ],
  ];
  CHATS = [
    ['Kavya S', 'Thanks! I’ll try the sharing-timer idea tomorrow.', '10:24 am', true],
    ['Deepa R', 'Which preschool did you finally choose?', 'Yesterday', true],
    ['Arjun M', 'Sending you the link to that sleep story now.', 'Mon', false],
    ['Shalini M', 'See you at the Gadget Free Hour meetup!', '2 Oct', false],
  ];
  componentDidMount() {
    this._hash = () => {
      const h = (pageLocation().hash || '').slice(1);
      if (this.TABS.some((t) => t[0] === h)) {
        this.setState({ tab: h });
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    };
    this._hash();
    window.addEventListener('hashchange', this._hash);
    this._click = (e) => {
      const a = e.target && e.target.closest ? e.target.closest('a[href^="#"]') : null;
      if (!a) return;
      const h = (a.getAttribute('href') || '').slice(1);
      if (!this.TABS.some((t) => t[0] === h)) return;
      e.preventDefault();
      this.setState({ tab: h, savedOk: false });
      try {
        history.replaceState(null, '', toUrl(pageLocation().pathname + '#' + h));
      } catch (err) {}
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };
    document.addEventListener('click', this._click);
  }
  componentWillUnmount() {
    window.removeEventListener('hashchange', this._hash);
    document.removeEventListener('click', this._click);
    clearTimeout(this.st);
  }
  chip(on) {
    return on
      ? { bg: 'var(--neutral-900)', fg: 'var(--white)', bd: 'var(--neutral-900)' }
      : { bg: 'var(--white)', fg: 'var(--text-strong)', bd: 'var(--border-default)' };
  }
  setF(k, v) {
    this.setState((s) => ({ f: { ...s.f, [k]: v }, err: { ...s.err, [k]: undefined }, savedOk: false }));
  }
  plural(n, a, b) {
    return n === 1 ? '1 ' + a : n + ' ' + b;
  }
  renderVals() {
    const S = this.state,
      tab = S.tab;
    const unread = S.readAll ? 0 : this.NOTES.slice(0, 3).filter((n) => !S.readIds.includes(n[0])).length;
    const circles = this.CIRCLES.filter((c) => !S.left.includes(c[0]));
    const saved = this.SAVED.filter((s) => !S.removed.includes(s[0]));
    const favAll = this.FAVS.filter((f) => !S.favRemoved.includes(f[0]));
    const favs = favAll.filter((f) => S.favKind === 'All' || f[1] === S.favKind);
    const unreadChats = this.CHATS.filter((c) => c[3]).length;
    const counts = {
      notification: unread,
      communities: circles.length,
      bookmarks: saved.length,
      messages: unreadChats,
    };
    const hue = (k) => this.HUE[k] || 'neutral';
    const is = (id) => tab === id;
    return {
      name: S.f.name,
      bio: S.f.bio,
      city: S.f.city || 'India',
      hasUnread: unread > 0,
      stats: [
        [this.DISC.length, 'Discussions', '#discussions'],
        [this.COMMENTS.length, 'Comments', '#comments'],
        [saved.length, 'Saved', '#bookmarks'],
        [circles.length, 'Circles', '#communities'],
      ].map(([n, label, href]) => ({ n, label, href })),
      tabs: this.TABS.map(([id, label, icon]) => {
        const on = is(id),
          c = counts[id] || 0,
          hot = id === 'notification' || id === 'messages';
        return {
          href: '#' + id,
          label,
          icon,
          cur: on ? 'page' : 'false',
          bg: on ? 'var(--neutral-100)' : 'transparent',
          fg: on ? 'var(--text-strong)' : 'var(--text-body)',
          weight: on ? 700 : 600,
          hasCount: c > 0,
          count: c,
          countBg: hot ? 'var(--orange-600)' : 'var(--neutral-100)',
          countFg: hot ? 'var(--white)' : 'var(--text-strong)',
        };
      }),
      isActivities: is('activities'),
      isNotification: is('notification'),
      isCommunities: is('communities'),
      isDiscussions: is('discussions'),
      isBookmarks: is('bookmarks'),
      isFavourites: is('favourites'),
      isInterests: is('interests'),
      isComments: is('comments'),
      isMessages: is('messages'),
      isSettings: is('settings'),
      activity: this.ACT.map(([k, verb, title, href, when, h, quote]) => ({
        verb,
        title,
        href,
        when,
        icon: this.ICON[k],
        tint: 'var(--' + hue(h) + '-50)',
        ink: 'var(--' + hue(h) + '-700)',
        hasQuote: !!quote,
        quote: quote || '',
      })),
      unreadText: unread ? this.plural(unread, 'new notification', 'new notifications') : 'You’re all caught up.',
      markAll: () => this.setState({ readAll: true }),
      notes: this.NOTES.map(([id, who, text, when], i) => {
        const un = i < 3 && !S.readAll && !S.readIds.includes(id);
        return {
          who,
          text,
          when,
          unread: un,
          bg: un ? 'var(--orange-50)' : 'var(--white)',
          bd: un ? 'var(--orange-100)' : 'var(--border-subtle)',
          read: () => this.setState((s) => ({ readIds: s.readIds.concat(id) })),
        };
      }),
      circleText: this.plural(circles.length, 'circle', 'circles') + ' you’re part of',
      circles: circles.map(([id, name, meta, desc, h, ph]) => ({
        id,
        name,
        meta,
        desc,
        tint: 'var(--' + h + '-50)',
        photo: 'Photo: ' + ph,
        leave: () => this.setState((s) => ({ left: s.left.concat(id) })),
      })),
      noCircles: circles.length === 0,
      discussions: this.DISC.map(([title, circle, replies, views, when, expert]) => ({
        title,
        circle,
        replies,
        views,
        when,
        expert,
      })),
      savedText: this.plural(saved.length, 'story', 'stories') + ' to read later',
      saved: saved.map(([id, title, topic, h, mins, ph]) => ({
        id,
        title,
        topic,
        meta: mins,
        tint: 'var(--' + hue(h) + '-50)',
        ink: 'var(--' + hue(h) + '-700)',
        photo: 'Photo: ' + ph,
        remove: () => this.setState((s) => ({ removed: s.removed.concat(id) })),
      })),
      noSaved: saved.length === 0,
      favChips: ['All', 'Story', 'Video', 'Quote', 'Recipe'].map((k) => ({
        label: { All: 'All', Story: 'Stories', Video: 'Videos', Quote: 'Quotes', Recipe: 'Recipes' }[k],
        on: S.favKind === k,
        pick: () => this.setState({ favKind: k }),
        ...this.chip(S.favKind === k),
      })),
      favs: favs.map(([id, kind, icon, title, href, h, ph]) => ({
        id,
        kind,
        icon,
        title,
        href,
        tint: 'var(--' + hue(h) + '-50)',
        ink: 'var(--' + hue(h) + '-700)',
        photo: ph,
        remove: () => this.setState((s) => ({ favRemoved: s.favRemoved.concat(id) })),
      })),
      noFavs: favs.length === 0,
      kids: S.kids.map(([name, age, stage]) => ({
        name,
        age,
        icon: stage === 'Infant' ? 'baby' : 'smile',
        tint: stage === 'Infant' ? 'var(--sky-100)' : 'var(--butter-100)',
        ink: stage === 'Infant' ? 'var(--sky-700)' : 'var(--butter-700)',
      })),
      addChild: () => this.setState({ tab: 'settings' }),
      topicCount: this.plural(S.topics.length, 'topic chosen', 'topics chosen'),
      topicChips: this.TOPICS.map(([t, icon]) => {
        const on = S.topics.includes(t);
        return {
          label: t,
          icon: on ? 'check' : icon,
          on,
          toggle: () => this.setState((s) => ({ topics: on ? s.topics.filter((x) => x !== t) : s.topics.concat(t) })),
          ...this.chip(on),
        };
      }),
      comments: this.COMMENTS.map(([on, href, when, text, l, r]) => ({
        on,
        href,
        when,
        text,
        likes: this.plural(l, 'like', 'likes'),
        replies: this.plural(r, 'reply', 'replies'),
      })),
      chats: this.CHATS.map(([who, last, when, un]) => ({
        who,
        last,
        when,
        unread: un,
        bg: un ? 'var(--orange-50)' : 'var(--white)',
      })),
      fName: S.f.name,
      fCity: S.f.city,
      fEmail: S.f.email,
      fPhone: S.f.phone,
      fBio: S.f.bio,
      errName: S.err.name,
      errEmail: S.err.email,
      onFName: (e) => this.setF('name', e.target.value),
      onFCity: (e) => this.setF('city', e.target.value),
      onFEmail: (e) => this.setF('email', e.target.value),
      onFPhone: (e) => this.setF('phone', e.target.value),
      onFBio: (e) => this.setF('bio', e.target.value),
      prefs: [
        ['digest', 'Weekly story picks', 'A short email with stories for your children’s ages'],
        ['replies', 'Replies and mentions', 'When someone replies to you or mentions you'],
        ['experts', 'Expert answers', 'When an expert answers your question'],
        ['private', 'Keep my profile private', 'Only circle members can see your activity'],
      ].map(([k, label, sub]) => ({
        label,
        sub,
        on: S.prefs[k],
        toggle: (v) =>
          this.setState((s) => ({
            prefs: { ...s.prefs, [k]: typeof v === 'boolean' ? v : !s.prefs[k] },
            savedOk: false,
          })),
      })),
      savedOk: S.savedOk,
      saveSettings: () => {
        const e = {};
        if (!S.f.name.trim()) e.name = 'Please add your name.';
        if (!/\S+@\S+\.\S+/.test(S.f.email)) e.email = 'Please add a valid email so we can reach you.';
        if (Object.keys(e).length) return this.setState({ err: e });
        this.setState({ savedOk: true, err: {} });
        clearTimeout(this.st);
        this.st = setTimeout(() => this.setState({ savedOk: false }), 4000);
      },
    };
  }
}

export default PageLogic;
