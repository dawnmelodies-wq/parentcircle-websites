import { Fragment } from 'react';
import { Avatar, Badge, Button, Icon, IconButton, Input, Logo, Switch } from '../../components/ds';
import { SiteFooter } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Profile" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Profile"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <header
        style={{
          position: 'sticky',
          top: '0',
          zIndex: '20',
          background: 'rgba(255,255,255,0.94)',
          backdropFilter: 'blur(8px)',
          WebkitBackdropFilter: 'blur(8px)',
          borderBottom: '1px solid var(--border-default)',
        }}
      >
        <div
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '0 24px',
            height: '72px',
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
          }}
        >
          <a
            href={toUrl('/')}
            aria-label="ParentCircle home"
            style={{ flex: 'none', display: 'flex', marginRight: '20px' }}
          >
            <Logo height={28} />
          </a>
          <nav
            aria-label="Main"
            data-main-nav=""
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              height: '44px',
              gap: '4px',
              flex: '0 1 auto',
              minWidth: '0',
              overflow: 'hidden',
            }}
          >
            <a
              className="hv-3"
              href={toUrl('/')}
              style={{
                height: '44px',
                padding: '0 12px',
                borderRadius: '999px',
                color: 'var(--text-muted)',
                fontSize: '17px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
                whiteSpace: 'nowrap',
              }}
            >
              Read
            </a>
            <a
              className="hv-3"
              href={toUrl('/#watch')}
              style={{
                height: '44px',
                padding: '0 12px',
                borderRadius: '999px',
                color: 'var(--text-muted)',
                fontSize: '17px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
                whiteSpace: 'nowrap',
              }}
            >
              Watch
            </a>
            <a
              className="hv-3"
              href={toUrl('/communities')}
              style={{
                height: '44px',
                padding: '0 12px',
                borderRadius: '999px',
                color: 'var(--text-muted)',
                fontSize: '17px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
                whiteSpace: 'nowrap',
              }}
            >
              Community
            </a>
            <a
              className="hv-3"
              href={toUrl('/#programs')}
              style={{
                height: '44px',
                padding: '0 12px',
                borderRadius: '999px',
                color: 'var(--text-muted)',
                fontSize: '17px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
                whiteSpace: 'nowrap',
              }}
            >
              Programs
            </a>
          </nav>
          <details data-more-menu="" style={{ position: 'static', flex: 'none', marginLeft: '-8px' }}>
            <summary
              className="hv-3"
              style={{
                height: '44px',
                padding: '0 10px 0 12px',
                borderRadius: '999px',
                color: 'var(--text-muted)',
                fontSize: '17px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                cursor: 'pointer',
                listStyle: 'none',
                whiteSpace: 'nowrap',
                userSelect: 'none',
              }}
            >
              More
              <Icon name="chevron-down" size={16} />
            </summary>
            <div
              style={{
                position: 'absolute',
                top: 'calc(100% + 8px)',
                left: '50%',
                transform: 'translateX(-50%)',
                zIndex: '40',
                width: 'min(940px, calc(100% - 32px))',
                maxHeight: 'calc(100vh - 96px)',
                overflow: 'auto',
                padding: '16px',
                boxSizing: 'border-box',
                borderRadius: '20px',
                background: 'var(--white)',
                border: '1px solid var(--border-default)',
                boxShadow: 'var(--shadow-lg)',
                display: 'flex',
                flexDirection: 'column',
                gap: '8px',
              }}
            >
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,180px),1fr))',
                  gap: '8px 20px',
                }}
              >
                <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                  <div
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--text-muted)',
                      padding: '6px 10px 6px',
                    }}
                  >
                    Read
                  </div>
                  <a
                    className="hv-0"
                    href={toUrl('/search?query=')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="compass" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Explore</span>
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/stories')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="book-open" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Stories</span>
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/parents-of-india')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="map-pin" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Parents of India</span>
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/ask-the-expert')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="stethoscope" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Ask an expert</span>
                  </a>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                  <div
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--text-muted)',
                      padding: '6px 10px 6px',
                    }}
                  >
                    Community
                  </div>
                  <a
                    className="hv-0"
                    href={toUrl('/communities')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="users" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Community</span>
                    <span
                      style={{
                        height: '22px',
                        padding: '0 8px',
                        borderRadius: '999px',
                        background: 'var(--orange-600)',
                        color: 'var(--white)',
                        fontSize: '14px',
                        fontWeight: '700',
                        display: 'inline-flex',
                        alignItems: 'center',
                      }}
                    >
                      New
                    </span>
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/guidelines')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="shield-check" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Community guidelines</span>
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/community-help')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="life-buoy" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Community help</span>
                  </a>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                  <div
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--text-muted)',
                      padding: '6px 10px 6px',
                    }}
                  >
                    Initiatives
                  </div>
                  <a
                    className="hv-0"
                    href="https://www.parentcircle.com/gadget-free-hour/"
                    target="_blank"
                    rel="noopener"
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="hourglass" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Gadget Free Hour</span>
                    <Icon name="arrow-up-right" size={16} color="var(--neutral-400)" />
                  </a>
                  <a
                    className="hv-0"
                    href="https://www.dotlearningcircle.com/"
                    target="_blank"
                    rel="noopener"
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="graduation-cap" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>The Dot Learning Circle</span>
                    <Icon name="arrow-up-right" size={16} color="var(--neutral-400)" />
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/press')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="newspaper" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Press releases</span>
                  </a>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                  <div
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--text-muted)',
                      padding: '6px 10px 6px',
                    }}
                  >
                    About
                  </div>
                  <a
                    className="hv-0"
                    href={toUrl('/about')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="info" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>About us</span>
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/privacy')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="lock" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Privacy policy</span>
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/terms')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="file-text" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Terms of use</span>
                  </a>
                  <a
                    className="hv-0"
                    href={toUrl('/contact')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '44px',
                      padding: '8px 10px',
                      borderRadius: '10px',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="mail" size={20} color="var(--text-muted)" />
                    <span style={{ flex: '1', minWidth: '0' }}>Contact us</span>
                  </a>
                </div>
              </div>
            </div>
          </details>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 'none', marginLeft: 'auto' }}>
            <a href={toUrl('/search?query=')} aria-label="Search" style={{ display: 'flex' }}>
              <IconButton icon="search" label="Search" />
            </a>
            <a href="#notification" aria-label="Notifications" style={{ position: 'relative', display: 'flex' }}>
              <IconButton icon="bell" label="Notifications" />
              {v.hasUnread ? (
                <span
                  style={{
                    position: 'absolute',
                    top: '8px',
                    right: '8px',
                    width: '10px',
                    height: '10px',
                    borderRadius: '50%',
                    background: 'var(--pc-orange)',
                    boxShadow: '0 0 0 2px var(--white)',
                  }}
                ></span>
              ) : null}
            </a>
            <a
              className="hv-0"
              href="#activities"
              aria-label="Your profile"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                height: '44px',
                padding: '0 12px 0 4px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                textDecoration: 'none',
                color: 'var(--text-strong)',
              }}
            >
              <Avatar name="Priya Raman" size={36} />
              <span style={{ fontSize: '16px', fontWeight: '600' }}>Priya</span>
            </a>
          </div>
        </div>
      </header>
      <main style={{ maxWidth: '1200px', margin: '0 auto', padding: '28px 24px 0', boxSizing: 'border-box' }}>
        <section
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            gap: '24px 32px',
            alignItems: 'center',
            padding: 'clamp(24px,3vw,32px)',
            borderRadius: '24px',
            background: 'var(--sage-50)',
          }}
        >
          <div
            style={{
              width: '112px',
              height: '112px',
              flex: 'none',
              position: 'relative',
              borderRadius: '50%',
              overflow: 'hidden',
              background: 'var(--white)',
              boxShadow: '0 0 0 4px var(--white)',
            }}
          >
            <image-slot id="profile-photo" shape="circle" placeholder="Your photo"></image-slot>
          </div>
          <div style={{ flex: '1 1 320px', minWidth: '0' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
              <h1
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(30px,3.6vw,40px)',
                  lineHeight: '1.15',
                  letterSpacing: '-0.01em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                }}
              >
                {v.name}
              </h1>
              <Badge tone="success" icon="sparkles">
                Active member
              </Badge>
            </div>
            <p style={{ fontSize: '17px', color: 'var(--text-body)', margin: '8px 0 0' }}>{v.bio}</p>
            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: '6px 18px',
                marginTop: '10px',
                fontSize: '15px',
                color: 'var(--text-muted)',
              }}
            >
              <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <Icon name="map-pin" size={16} color="currentColor" />
                {v.city}
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <Icon name="calendar" size={16} color="currentColor" />
                Member since March 2023
              </span>
            </div>
          </div>
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
              flex: '1 1 360px',
              minWidth: '0',
              maxWidth: '480px',
            }}
          >
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(96px,1fr))', gap: '8px' }}>
              {(v.stats ?? []).map((s, $i0) => (
                <Fragment key={$i0}>
                  <a
                    className="hv-p"
                    href={toUrl(s?.href)}
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      gap: '2px',
                      padding: '12px 8px',
                      borderRadius: '14px',
                      background: 'var(--white)',
                      textDecoration: 'none',
                      color: 'inherit',
                    }}
                  >
                    <span
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '24px',
                        lineHeight: '1.1',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                      }}
                    >
                      {s?.n}
                    </span>
                    <span
                      style={{ fontSize: '14px', fontWeight: '600', color: 'var(--text-muted)', textAlign: 'center' }}
                    >
                      {s?.label}
                    </span>
                  </a>
                </Fragment>
              ))}
            </div>
            <a href="#settings" style={{ alignSelf: 'flex-start', textDecoration: 'none' }}>
              <Button variant="secondary" size="sm" icon="pencil">
                Edit profile
              </Button>
            </a>
          </div>
        </section>
        <div
          style={{ display: 'flex', flexWrap: 'wrap', gap: '32px 40px', alignItems: 'flex-start', paddingTop: '32px' }}
        >
          <aside style={{ flex: '1 1 240px', minWidth: '0', maxWidth: '100%', position: 'sticky', top: '96px' }}>
            <nav
              aria-label="Profile"
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '2px',
                padding: '10px',
                borderRadius: '20px',
                background: 'var(--white)',
                border: '1px solid var(--border-subtle)',
              }}
            >
              {(v.tabs ?? []).map((t, $i0) => (
                <Fragment key={$i0}>
                  <a
                    className="hv-0"
                    href={toUrl(t?.href)}
                    aria-current={t?.cur}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      minHeight: '48px',
                      padding: '8px 12px',
                      borderRadius: '12px',
                      background: t?.bg,
                      color: t?.fg,
                      fontSize: '16px',
                      fontWeight: t?.weight,
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name={t?.icon} size={20} color="currentColor" />
                    <span style={{ flex: '1', minWidth: '0' }}>{t?.label}</span>
                    {t?.hasCount ? (
                      <span
                        style={{
                          minWidth: '24px',
                          height: '24px',
                          padding: '0 7px',
                          boxSizing: 'border-box',
                          borderRadius: '999px',
                          background: t?.countBg,
                          color: t?.countFg,
                          fontSize: '14px',
                          fontWeight: '700',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}
                      >
                        {t?.count}
                      </span>
                    ) : null}
                  </a>
                </Fragment>
              ))}
              <div style={{ height: '1px', background: 'var(--border-subtle)', margin: '6px 8px' }}></div>
              <a
                className="hv-0"
                href={toUrl('/')}
                data-sign-out=""
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  minHeight: '48px',
                  padding: '8px 12px',
                  borderRadius: '12px',
                  color: 'var(--text-muted)',
                  fontSize: '16px',
                  fontWeight: '600',
                  textDecoration: 'none',
                }}
              >
                <Icon name="log-out" size={20} color="currentColor" />
                Log out
              </a>
            </nav>
          </aside>
          <section aria-live="polite" style={{ flex: '999 1 560px', minWidth: '0' }}>
            {v.isActivities ? (
              <Fragment>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'flex-end',
                    justifyContent: 'space-between',
                    gap: '12px 20px',
                    flexWrap: 'wrap',
                    marginBottom: '20px',
                  }}
                >
                  <div>
                    <h2
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: 'clamp(26px,3vw,32px)',
                        lineHeight: '1.2',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0',
                      }}
                    >
                      Your activity
                    </h2>
                    <p style={{ fontSize: '15px', color: 'var(--text-muted)', margin: '6px 0 0' }}>
                      Everything you’ve done on ParentCircle, most recent first.
                    </p>
                  </div>
                </div>
                <ol style={{ listStyle: 'none', margin: '0', padding: '0', display: 'flex', flexDirection: 'column' }}>
                  {(v.activity ?? []).map((a, $i0) => (
                    <Fragment key={$i0}>
                      <li
                        style={{
                          display: 'flex',
                          gap: '16px',
                          alignItems: 'flex-start',
                          padding: '16px 0',
                          borderBottom: '1px solid var(--border-subtle)',
                        }}
                      >
                        <span
                          style={{
                            width: '44px',
                            height: '44px',
                            flex: 'none',
                            borderRadius: '50%',
                            background: a?.tint,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}
                        >
                          <Icon name={a?.icon} size={20} color={a?.ink} />
                        </span>
                        <div style={{ flex: '1', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                          <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{a?.verb}</span>
                          <a
                            className="hv-5"
                            href={toUrl(a?.href)}
                            style={{
                              fontFamily: 'var(--font-display)',
                              fontSize: '19px',
                              lineHeight: '1.35',
                              fontWeight: '700',
                              color: 'var(--text-strong)',
                              textDecoration: 'none',
                              textWrap: 'pretty',
                            }}
                          >
                            {a?.title}
                          </a>
                          {a?.hasQuote ? (
                            <p
                              style={{
                                fontFamily: 'var(--font-serif)',
                                fontSize: '17px',
                                lineHeight: '1.55',
                                color: 'var(--text-body)',
                                margin: '4px 0 0',
                                paddingLeft: '14px',
                                borderLeft: '3px solid var(--border-default)',
                              }}
                            >
                              {a?.quote}
                            </p>
                          ) : null}
                        </div>
                        <span
                          style={{ flex: 'none', fontSize: '15px', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}
                        >
                          {a?.when}
                        </span>
                      </li>
                    </Fragment>
                  ))}
                </ol>
              </Fragment>
            ) : null}
            {v.isNotification ? (
              <Fragment>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'flex-end',
                    justifyContent: 'space-between',
                    gap: '12px 20px',
                    flexWrap: 'wrap',
                    marginBottom: '20px',
                  }}
                >
                  <div>
                    <h2
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: 'clamp(26px,3vw,32px)',
                        lineHeight: '1.2',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0',
                      }}
                    >
                      Notifications
                    </h2>
                    <p style={{ fontSize: '15px', color: 'var(--text-muted)', margin: '6px 0 0' }}>{v.unreadText}</p>
                  </div>
                  <Button variant="ghost" size="sm" icon="check-check" onClick={v.markAll}>
                    Mark all as read
                  </Button>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {(v.notes ?? []).map((n, $i0) => (
                    <Fragment key={$i0}>
                      <button
                        className="hv-q"
                        type="button"
                        onClick={n?.read}
                        style={{
                          display: 'flex',
                          gap: '14px',
                          alignItems: 'flex-start',
                          width: '100%',
                          padding: '16px',
                          borderRadius: '16px',
                          border: `1px solid ${n?.bd ?? ''}`,
                          background: n?.bg,
                          font: 'inherit',
                          textAlign: 'left',
                          cursor: 'pointer',
                        }}
                      >
                        <Avatar name={n?.who} size={44} />
                        <span
                          style={{ flex: '1', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '4px' }}
                        >
                          <span style={{ fontSize: '17px', lineHeight: '1.45', color: 'var(--text-strong)' }}>
                            <strong>{n?.who}</strong> {n?.text}
                          </span>
                          <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{n?.when}</span>
                        </span>
                        {n?.unread ? (
                          <span
                            aria-label="Unread"
                            style={{
                              width: '10px',
                              height: '10px',
                              flex: 'none',
                              marginTop: '8px',
                              borderRadius: '50%',
                              background: 'var(--pc-orange)',
                            }}
                          ></span>
                        ) : null}
                      </button>
                    </Fragment>
                  ))}
                </div>
              </Fragment>
            ) : null}
            {v.isCommunities ? (
              <Fragment>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'flex-end',
                    justifyContent: 'space-between',
                    gap: '12px 20px',
                    flexWrap: 'wrap',
                    marginBottom: '20px',
                  }}
                >
                  <div>
                    <h2
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: 'clamp(26px,3vw,32px)',
                        lineHeight: '1.2',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0',
                      }}
                    >
                      Your circles
                    </h2>
                    <p style={{ fontSize: '15px', color: 'var(--text-muted)', margin: '6px 0 0' }}>{v.circleText}</p>
                  </div>
                  <a href={toUrl('/communities')} style={{ textDecoration: 'none' }}>
                    <Button variant="secondary" size="sm" icon="compass">
                      Find more circles
                    </Button>
                  </a>
                </div>
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,260px),1fr))',
                    gap: '16px',
                  }}
                >
                  {(v.circles ?? []).map((c, $i0) => (
                    <Fragment key={$i0}>
                      <div
                        style={{
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '12px',
                          padding: '20px',
                          borderRadius: '16px',
                          background: 'var(--white)',
                          border: '1px solid var(--border-subtle)',
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                          <span
                            style={{
                              width: '52px',
                              height: '52px',
                              flex: 'none',
                              position: 'relative',
                              overflow: 'hidden',
                              borderRadius: '14px',
                              background: c?.tint,
                            }}
                          >
                            <image-slot
                              id={`profile-circle-${c?.id ?? ''}`}
                              shape="rounded"
                              radius="14"
                              placeholder={c?.photo}
                            ></image-slot>
                          </span>
                          <a
                            className="hv-r"
                            href={toUrl('/communities')}
                            style={{ minWidth: '0', textDecoration: 'none', color: 'inherit' }}
                          >
                            <div style={{ fontSize: '18px', fontWeight: '700', color: 'var(--text-strong)' }}>
                              {c?.name}
                            </div>
                            <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{c?.meta}</div>
                          </a>
                        </div>
                        <p
                          style={{
                            fontSize: '16px',
                            lineHeight: '1.5',
                            color: 'var(--text-body)',
                            margin: '0',
                            flex: '1',
                          }}
                        >
                          {c?.desc}
                        </p>
                        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                          <a href={toUrl('/communities')} style={{ textDecoration: 'none' }}>
                            <Button variant="dark" size="sm">
                              Visit
                            </Button>
                          </a>
                          <Button variant="ghost" size="sm" onClick={c?.leave}>
                            Leave
                          </Button>
                        </div>
                      </div>
                    </Fragment>
                  ))}
                </div>
                {v.noCircles ? (
                  <div
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'flex-start',
                      gap: '12px',
                      padding: '28px',
                      borderRadius: '20px',
                      background: 'var(--neutral-50)',
                    }}
                  >
                    <Icon name="users" size={28} color="var(--text-muted)" />
                    <div
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '22px',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                      }}
                    >
                      You haven’t joined any circles yet
                    </div>
                    <p style={{ fontSize: '17px', color: 'var(--text-body)', margin: '0' }}>
                      Circles are small groups of parents who share your interests.
                    </p>
                    <a href={toUrl('/communities')} style={{ textDecoration: 'none' }}>
                      <Button variant="primary" icon="compass">
                        Browse circles
                      </Button>
                    </a>
                  </div>
                ) : null}
              </Fragment>
            ) : null}
            {v.isDiscussions ? (
              <Fragment>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'flex-end',
                    justifyContent: 'space-between',
                    gap: '12px 20px',
                    flexWrap: 'wrap',
                    marginBottom: '20px',
                  }}
                >
                  <div>
                    <h2
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: 'clamp(26px,3vw,32px)',
                        lineHeight: '1.2',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0',
                      }}
                    >
                      Your discussions
                    </h2>
                    <p style={{ fontSize: '15px', color: 'var(--text-muted)', margin: '6px 0 0' }}>
                      Questions and ideas you’ve shared with other parents.
                    </p>
                  </div>
                  <a href={toUrl('/communities')} style={{ textDecoration: 'none' }}>
                    <Button variant="primary" size="sm" icon="square-pen">
                      Start a discussion
                    </Button>
                  </a>
                </div>
                {(v.discussions ?? []).map((d, $i0) => (
                  <Fragment key={$i0}>
                    <a
                      className="hv-c"
                      href={toUrl('/communities')}
                      style={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '8px',
                        padding: '18px 0',
                        borderBottom: '1px solid var(--border-subtle)',
                        textDecoration: 'none',
                        color: 'inherit',
                      }}
                    >
                      <span
                        style={{
                          fontSize: '14px',
                          fontWeight: '700',
                          letterSpacing: '0.08em',
                          textTransform: 'uppercase',
                          color: 'var(--sage-700)',
                        }}
                      >
                        {d?.circle}
                      </span>
                      <span
                        style={{
                          fontFamily: 'var(--font-display)',
                          fontSize: '20px',
                          lineHeight: '1.35',
                          fontWeight: '700',
                          color: 'var(--text-strong)',
                          textWrap: 'pretty',
                        }}
                      >
                        {d?.title}
                      </span>
                      <span
                        style={{
                          display: 'flex',
                          flexWrap: 'wrap',
                          alignItems: 'center',
                          gap: '6px 16px',
                          fontSize: '15px',
                          color: 'var(--text-muted)',
                        }}
                      >
                        <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <Icon name="message-circle" size={16} color="currentColor" />
                          {d?.replies}
                        </span>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <Icon name="eye" size={16} color="currentColor" />
                          {d?.views}
                        </span>
                        <span>{d?.when}</span>
                        {d?.expert ? (
                          <Badge tone="success" icon="shield-check">
                            Expert answer
                          </Badge>
                        ) : null}
                      </span>
                    </a>
                  </Fragment>
                ))}
              </Fragment>
            ) : null}
            {v.isBookmarks ? (
              <Fragment>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'flex-end',
                    justifyContent: 'space-between',
                    gap: '12px 20px',
                    flexWrap: 'wrap',
                    marginBottom: '20px',
                  }}
                >
                  <div>
                    <h2
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: 'clamp(26px,3vw,32px)',
                        lineHeight: '1.2',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0',
                      }}
                    >
                      Saved stories
                    </h2>
                    <p style={{ fontSize: '15px', color: 'var(--text-muted)', margin: '6px 0 0' }}>{v.savedText}</p>
                  </div>
                </div>
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,240px),1fr))',
                    gap: '32px 20px',
                  }}
                >
                  {(v.saved ?? []).map((s, $i0) => (
                    <Fragment key={$i0}>
                      <article style={{ display: 'flex', flexDirection: 'column', gap: '10px', minWidth: '0' }}>
                        <div
                          style={{
                            position: 'relative',
                            overflow: 'hidden',
                            aspectRatio: '16 / 10',
                            borderRadius: '16px',
                            background: s?.tint,
                          }}
                        >
                          <image-slot
                            id={`profile-saved-${s?.id ?? ''}`}
                            shape="rounded"
                            radius="16"
                            placeholder={s?.photo}
                          ></image-slot>
                        </div>
                        <span
                          style={{
                            fontSize: '14px',
                            fontWeight: '700',
                            letterSpacing: '0.08em',
                            textTransform: 'uppercase',
                            color: s?.ink,
                          }}
                        >
                          {s?.topic}
                        </span>
                        <a
                          className="hv-5"
                          href={toUrl('/article')}
                          style={{
                            fontFamily: 'var(--font-display)',
                            fontSize: '19px',
                            lineHeight: '1.3',
                            fontWeight: '700',
                            color: 'var(--text-strong)',
                            textDecoration: 'none',
                            textWrap: 'pretty',
                          }}
                        >
                          {s?.title}
                        </a>
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            gap: '8px',
                            marginTop: 'auto',
                          }}
                        >
                          <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{s?.meta}</span>
                          <IconButton icon="bookmark-x" label="Remove from saved" onClick={s?.remove} />
                        </div>
                      </article>
                    </Fragment>
                  ))}
                </div>
                {v.noSaved ? (
                  <div
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'flex-start',
                      gap: '12px',
                      padding: '28px',
                      borderRadius: '20px',
                      background: 'var(--neutral-50)',
                    }}
                  >
                    <Icon name="bookmark" size={28} color="var(--text-muted)" />
                    <div
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '22px',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                      }}
                    >
                      No saved stories yet
                    </div>
                    <p style={{ fontSize: '17px', color: 'var(--text-body)', margin: '0' }}>
                      Tap the bookmark on any story to read it later.
                    </p>
                    <a href={toUrl('/stories')} style={{ textDecoration: 'none' }}>
                      <Button variant="primary" icon="book-open">
                        Browse stories
                      </Button>
                    </a>
                  </div>
                ) : null}
              </Fragment>
            ) : null}
            {v.isFavourites ? (
              <Fragment>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'flex-end',
                    justifyContent: 'space-between',
                    gap: '12px 20px',
                    flexWrap: 'wrap',
                    marginBottom: '20px',
                  }}
                >
                  <div>
                    <h2
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: 'clamp(26px,3vw,32px)',
                        lineHeight: '1.2',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0',
                      }}
                    >
                      Favourites
                    </h2>
                    <p style={{ fontSize: '15px', color: 'var(--text-muted)', margin: '6px 0 0' }}>
                      Stories, videos and quotes you’ve loved.
                    </p>
                  </div>
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '20px' }}>
                  {(v.favChips ?? []).map((c, $i0) => (
                    <Fragment key={$i0}>
                      <button
                        type="button"
                        aria-pressed={c?.on}
                        onClick={c?.pick}
                        style={{
                          height: '40px',
                          padding: '0 14px',
                          borderRadius: '999px',
                          border: `1.5px solid ${c?.bd ?? ''}`,
                          background: c?.bg,
                          color: c?.fg,
                          font: 'inherit',
                          fontSize: '15px',
                          fontWeight: '600',
                          cursor: 'pointer',
                        }}
                      >
                        {c?.label}
                      </button>
                    </Fragment>
                  ))}
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  {(v.favs ?? []).map((f, $i0) => (
                    <Fragment key={$i0}>
                      <div
                        style={{
                          display: 'flex',
                          gap: '14px',
                          alignItems: 'center',
                          padding: '12px',
                          borderRadius: '16px',
                          border: '1px solid var(--border-subtle)',
                          background: 'var(--white)',
                        }}
                      >
                        <span
                          style={{
                            width: '112px',
                            height: '84px',
                            flex: 'none',
                            position: 'relative',
                            overflow: 'hidden',
                            borderRadius: '12px',
                            background: f?.tint,
                          }}
                        >
                          <image-slot
                            id={`profile-fav-${f?.id ?? ''}`}
                            shape="rounded"
                            radius="12"
                            placeholder={f?.photo}
                          ></image-slot>
                        </span>
                        <div style={{ flex: '1', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                          <span
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '6px',
                              fontSize: '14px',
                              fontWeight: '700',
                              letterSpacing: '0.08em',
                              textTransform: 'uppercase',
                              color: f?.ink,
                            }}
                          >
                            <Icon name={f?.icon} size={16} color="currentColor" />
                            {f?.kind}
                          </span>
                          <a
                            className="hv-5"
                            href={toUrl(f?.href)}
                            style={{
                              fontFamily: 'var(--font-display)',
                              fontSize: '18px',
                              lineHeight: '1.35',
                              fontWeight: '700',
                              color: 'var(--text-strong)',
                              textDecoration: 'none',
                              textWrap: 'pretty',
                            }}
                          >
                            {f?.title}
                          </a>
                        </div>
                        <button
                          type="button"
                          aria-label="Remove from favourites"
                          onClick={f?.remove}
                          style={{
                            width: '44px',
                            height: '44px',
                            flex: 'none',
                            borderRadius: '50%',
                            border: '0',
                            background: 'var(--blush-100)',
                            color: 'var(--blush-700)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            cursor: 'pointer',
                          }}
                        >
                          <Icon name="heart" size={20} color="currentColor" />
                        </button>
                      </div>
                    </Fragment>
                  ))}
                </div>
                {v.noFavs ? (
                  <div
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'flex-start',
                      gap: '12px',
                      padding: '28px',
                      borderRadius: '20px',
                      background: 'var(--neutral-50)',
                    }}
                  >
                    <Icon name="heart" size={28} color="var(--text-muted)" />
                    <div
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '22px',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                      }}
                    >
                      Nothing here yet
                    </div>
                    <p style={{ fontSize: '17px', color: 'var(--text-body)', margin: '0' }}>
                      Tap the heart on stories, videos and quotes to keep them here.
                    </p>
                  </div>
                ) : null}
              </Fragment>
            ) : null}
            {v.isInterests ? (
              <Fragment>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'flex-end',
                    justifyContent: 'space-between',
                    gap: '12px 20px',
                    flexWrap: 'wrap',
                    marginBottom: '20px',
                  }}
                >
                  <div>
                    <h2
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: 'clamp(26px,3vw,32px)',
                        lineHeight: '1.2',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0',
                      }}
                    >
                      Your interests
                    </h2>
                    <p style={{ fontSize: '15px', color: 'var(--text-muted)', margin: '6px 0 0' }}>
                      We use these to choose stories for your “Just for you” feed.
                    </p>
                  </div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
                  <div
                    style={{
                      padding: '24px',
                      borderRadius: '20px',
                      background: 'var(--white)',
                      border: '1px solid var(--border-subtle)',
                    }}
                  >
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: '12px',
                        flexWrap: 'wrap',
                        marginBottom: '14px',
                      }}
                    >
                      <h3
                        style={{
                          fontFamily: 'var(--font-display)',
                          fontSize: '21px',
                          fontWeight: '700',
                          color: 'var(--text-strong)',
                          margin: '0',
                        }}
                      >
                        Your children
                      </h3>
                      <Button variant="ghost" size="sm" icon="plus" onClick={v.addChild}>
                        Add a child
                      </Button>
                    </div>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
                      {(v.kids ?? []).map((k, $i0) => (
                        <Fragment key={$i0}>
                          <div
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '10px',
                              padding: '8px 14px 8px 8px',
                              borderRadius: '999px',
                              background: k?.tint,
                            }}
                          >
                            <span
                              style={{
                                width: '36px',
                                height: '36px',
                                borderRadius: '50%',
                                background: 'var(--white)',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                              }}
                            >
                              <Icon name={k?.icon} size={18} color={k?.ink} />
                            </span>
                            <span style={{ fontSize: '16px', fontWeight: '700', color: 'var(--text-strong)' }}>
                              {k?.name}
                            </span>
                            <span style={{ fontSize: '15px', color: 'var(--text-body)' }}>{k?.age}</span>
                          </div>
                        </Fragment>
                      ))}
                    </div>
                  </div>
                  <div>
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'baseline',
                        justifyContent: 'space-between',
                        gap: '12px',
                        marginBottom: '12px',
                      }}
                    >
                      <h3
                        style={{
                          fontFamily: 'var(--font-display)',
                          fontSize: '21px',
                          fontWeight: '700',
                          color: 'var(--text-strong)',
                          margin: '0',
                        }}
                      >
                        Topics
                      </h3>
                      <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{v.topicCount}</span>
                    </div>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                      {(v.topicChips ?? []).map((t, $i0) => (
                        <Fragment key={$i0}>
                          <button
                            type="button"
                            aria-pressed={t?.on}
                            onClick={t?.toggle}
                            style={{
                              height: '44px',
                              padding: '0 16px',
                              borderRadius: '999px',
                              border: `1.5px solid ${t?.bd ?? ''}`,
                              background: t?.bg,
                              color: t?.fg,
                              font: 'inherit',
                              fontSize: '15px',
                              fontWeight: '600',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '6px',
                              cursor: 'pointer',
                              transition: 'background 150ms',
                            }}
                          >
                            <Icon name={t?.icon} size={16} color="currentColor" />
                            {t?.label}
                          </button>
                        </Fragment>
                      ))}
                    </div>
                  </div>
                </div>
              </Fragment>
            ) : null}
            {v.isComments ? (
              <Fragment>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'flex-end',
                    justifyContent: 'space-between',
                    gap: '12px 20px',
                    flexWrap: 'wrap',
                    marginBottom: '20px',
                  }}
                >
                  <div>
                    <h2
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: 'clamp(26px,3vw,32px)',
                        lineHeight: '1.2',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0',
                      }}
                    >
                      Your comments
                    </h2>
                    <p style={{ fontSize: '15px', color: 'var(--text-muted)', margin: '6px 0 0' }}>
                      What you’ve said on stories and discussions.
                    </p>
                  </div>
                </div>
                {(v.comments ?? []).map((c, $i0) => (
                  <Fragment key={$i0}>
                    <div
                      style={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '8px',
                        padding: '18px 0',
                        borderBottom: '1px solid var(--border-subtle)',
                      }}
                    >
                      <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                        {'On '}
                        <a
                          className="hv-5"
                          href={toUrl(c?.href)}
                          style={{ fontWeight: '700', color: 'var(--text-strong)', textDecoration: 'none' }}
                        >
                          {c?.on}
                        </a>
                        {' · '}
                        {c?.when}
                      </span>
                      <p
                        style={{
                          fontFamily: 'var(--font-serif)',
                          fontSize: '18px',
                          lineHeight: '1.6',
                          color: 'var(--text-body)',
                          margin: '0',
                          textWrap: 'pretty',
                        }}
                      >
                        {c?.text}
                      </p>
                      <span
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '16px',
                          fontSize: '15px',
                          color: 'var(--text-muted)',
                        }}
                      >
                        <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <Icon name="heart" size={16} color="currentColor" />
                          {c?.likes}
                        </span>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <Icon name="message-circle" size={16} color="currentColor" />
                          {c?.replies}
                        </span>
                      </span>
                    </div>
                  </Fragment>
                ))}
              </Fragment>
            ) : null}
            {v.isMessages ? (
              <Fragment>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'flex-end',
                    justifyContent: 'space-between',
                    gap: '12px 20px',
                    flexWrap: 'wrap',
                    marginBottom: '20px',
                  }}
                >
                  <div>
                    <h2
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: 'clamp(26px,3vw,32px)',
                        lineHeight: '1.2',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0',
                      }}
                    >
                      Messages
                    </h2>
                    <p style={{ fontSize: '15px', color: 'var(--text-muted)', margin: '6px 0 0' }}>
                      Private conversations with other parents.
                    </p>
                  </div>
                </div>
                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    borderRadius: '20px',
                    border: '1px solid var(--border-subtle)',
                    overflow: 'hidden',
                  }}
                >
                  {(v.chats ?? []).map((m, $i0) => (
                    <Fragment key={$i0}>
                      <a
                        className="hv-f"
                        href="#messages"
                        style={{
                          display: 'flex',
                          gap: '14px',
                          alignItems: 'center',
                          padding: '16px',
                          borderBottom: '1px solid var(--border-subtle)',
                          background: m?.bg,
                          textDecoration: 'none',
                          color: 'inherit',
                        }}
                      >
                        <Avatar name={m?.who} size={48} />
                        <span
                          style={{ flex: '1', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '2px' }}
                        >
                          <span style={{ display: 'flex', justifyContent: 'space-between', gap: '8px' }}>
                            <span style={{ fontSize: '17px', fontWeight: '700', color: 'var(--text-strong)' }}>
                              {m?.who}
                            </span>
                            <span style={{ fontSize: '15px', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
                              {m?.when}
                            </span>
                          </span>
                          <span
                            style={{
                              fontSize: '16px',
                              color: 'var(--text-body)',
                              overflow: 'hidden',
                              textOverflow: 'ellipsis',
                              whiteSpace: 'nowrap',
                            }}
                          >
                            {m?.last}
                          </span>
                        </span>
                        {m?.unread ? (
                          <span
                            style={{
                              width: '10px',
                              height: '10px',
                              flex: 'none',
                              borderRadius: '50%',
                              background: 'var(--pc-orange)',
                            }}
                          ></span>
                        ) : null}
                      </a>
                    </Fragment>
                  ))}
                </div>
              </Fragment>
            ) : null}
            {v.isSettings ? (
              <Fragment>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'flex-end',
                    justifyContent: 'space-between',
                    gap: '12px 20px',
                    flexWrap: 'wrap',
                    marginBottom: '20px',
                  }}
                >
                  <div>
                    <h2
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: 'clamp(26px,3vw,32px)',
                        lineHeight: '1.2',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0',
                      }}
                    >
                      Settings
                    </h2>
                    <p style={{ fontSize: '15px', color: 'var(--text-muted)', margin: '6px 0 0' }}>
                      Update your details and choose what we send you.
                    </p>
                  </div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
                  <div
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '14px',
                      padding: '24px',
                      borderRadius: '20px',
                      background: 'var(--white)',
                      border: '1px solid var(--border-subtle)',
                    }}
                  >
                    <h3
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '21px',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0',
                      }}
                    >
                      Your details
                    </h3>
                    <div
                      style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,240px),1fr))',
                        gap: '14px',
                      }}
                    >
                      <Input label="Full name" value={v.fName} onChange={v.onFName} error={v.errName} />
                      <Input label="City" icon="map-pin" value={v.fCity} onChange={v.onFCity} />
                      <Input
                        label="Email"
                        type="email"
                        icon="mail"
                        value={v.fEmail}
                        onChange={v.onFEmail}
                        error={v.errEmail}
                      />
                      <Input label="Mobile number" type="tel" icon="phone" value={v.fPhone} onChange={v.onFPhone} />
                    </div>
                    <Input label="About you" multiline={true} rows={2} value={v.fBio} onChange={v.onFBio} />
                  </div>
                  <div
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '6px',
                      padding: '24px',
                      borderRadius: '20px',
                      background: 'var(--white)',
                      border: '1px solid var(--border-subtle)',
                    }}
                  >
                    <h3
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '21px',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0 0 8px',
                      }}
                    >
                      Notifications and privacy
                    </h3>
                    {(v.prefs ?? []).map((p, $i0) => (
                      <Fragment key={$i0}>
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            gap: '16px',
                            padding: '12px 0',
                            borderTop: '1px solid var(--border-subtle)',
                          }}
                        >
                          <span style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                            <span style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                              {p?.label}
                            </span>
                            <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{p?.sub}</span>
                          </span>
                          <Switch checked={p?.on} onChange={p?.toggle} aria-label={p?.label} />
                        </div>
                      </Fragment>
                    ))}
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px 16px', flexWrap: 'wrap' }}>
                    <Button variant="primary" icon="check" onClick={v.saveSettings}>
                      Save changes
                    </Button>
                    {v.savedOk ? (
                      <span
                        role="status"
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '8px',
                          fontSize: '16px',
                          fontWeight: '600',
                          color: 'var(--sage-700)',
                        }}
                      >
                        <Icon name="circle-check" size={20} color="var(--sage-700)" />
                        Your changes are saved
                      </span>
                    ) : null}
                    <a
                      className="hv-s"
                      href={toUrl('/community-help')}
                      style={{ marginLeft: 'auto', fontSize: '15px', fontWeight: '600', color: 'var(--text-muted)' }}
                    >
                      Delete my account
                    </a>
                  </div>
                </div>
              </Fragment>
            ) : null}
          </section>
        </div>
        <div style={{ height: '96px' }}></div>
      </main>
      <SiteFooter />
    </div>
  );
}
