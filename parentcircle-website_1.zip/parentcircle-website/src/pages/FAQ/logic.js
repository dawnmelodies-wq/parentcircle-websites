import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = { helpful: null, draft: '', sent: false };
  moreList = [
    {
      title: 'Board exams coming up? Tips to help your teen prepare',
      category: 'Exams',
      topic: 'learning',
      author: 'ParentCircle team',
      readTime: '8 min read',
    },
    {
      title: 'IB and Cambridge schools: a parent’s guide to academic support',
      category: 'School & learning',
      topic: 'learning',
      author: 'ParentCircle team',
      readTime: '7 min read',
    },
    {
      title: 'Why is your child losing interest in studies? 10 reasons and what helps',
      category: 'Learning',
      topic: 'learning',
      author: 'ParentCircle team',
      readTime: '11 min read',
    },
  ];
  renderVals() {
    const S = this.state;
    return {
      askHelpful: S.helpful === null,
      answered: S.helpful !== null,
      yes: () => this.setState({ helpful: 'yes' }),
      no: () => this.setState({ helpful: 'no' }),
      thanks: S.helpful === 'yes' ? 'Thank you — glad it helped.' : 'Thank you for telling us.',
      draft: S.draft,
      draftEmpty: !S.draft.trim(),
      onDraft: (e) => this.setState({ draft: e.target.value }),
      send: () => S.draft.trim() && this.setState({ sent: true, draft: '' }),
      sent: S.sent,
      notSent: !S.sent,
      more: this.moreList.map((a) => ({ ...a, onClick: () => window.scrollTo({ top: 0, behavior: 'smooth' }) })),
    };
  }
}

export default PageLogic;
