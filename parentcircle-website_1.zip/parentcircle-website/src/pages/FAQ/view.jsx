import { Fragment } from 'react';
import { ArticleCard, Avatar, Badge, Button, Card, Icon, Input, Tag } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "FAQ" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="FAQ detail"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader communityHref="/#community" />
      <section style={{ background: 'var(--sky-50)' }}>
        <div style={{ maxWidth: '1088px', margin: '0 auto', padding: '32px 24px 48px', boxSizing: 'border-box' }}>
          <nav
            aria-label="Breadcrumb"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              flexWrap: 'wrap',
              fontSize: '15px',
              color: 'var(--text-muted)',
              marginBottom: '28px',
            }}
          >
            <a
              className="hv-1"
              href={toUrl('/ask-the-expert')}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                color: 'var(--text-muted)',
                textDecoration: 'none',
                fontWeight: '600',
              }}
            >
              <Icon name="arrow-left" size={18} />
              Ask the Expert
            </a>
            <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
            <span>Learning</span>
          </nav>
          <div style={{ maxWidth: '800px' }}>
            <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap', marginBottom: '16px' }}>
              <Tag topic="learning">Learning</Tag>
              <Badge tone="neutral">Ages 15–18</Badge>
              <Badge tone="success">Expert answer</Badge>
            </div>
            <h1
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(32px,4vw,48px)',
                lineHeight: '1.12',
                letterSpacing: '-0.015em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0',
                textWrap: 'balance',
              }}
            >
              Helping teens with career decisions: how to guide them towards the right path
            </h1>
            <p
              style={{
                fontFamily: 'var(--font-serif)',
                fontSize: '21px',
                lineHeight: '1.6',
                color: 'var(--text-body)',
                margin: '16px 0 24px',
                textWrap: 'pretty',
              }}
            >
              Some teens know what they want early. Others change their minds every few months — and parents worry.
              Three parents asked; our counsellor answers.
            </p>
            <div style={{ display: 'flex', alignItems: 'center', gap: '14px', flexWrap: 'wrap' }}>
              <Avatar
                name="Arundhati Swamy"
                src="https://pcprd.azureedge.net/profile/full/20fb81f9-b905-40c0-a00c-9f8aba8589bb.png"
                size={56}
                ring={true}
              />
              <div style={{ flex: '1 1 240px', minWidth: '0' }}>
                <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Answered by</div>
                <div style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>Arundhati Swamy</div>
                <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                  Counsellor and Head of Parent Engagement Programs, ParentCircle · Updated 21 Nov 2025
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <main style={{ maxWidth: '1088px', margin: '0 auto', padding: '40px 24px 0', boxSizing: 'border-box' }}>
        <div
          style={{
            fontSize: '14px',
            fontWeight: '700',
            letterSpacing: '0.08em',
            textTransform: 'uppercase',
            color: 'var(--text-muted)',
            marginBottom: '14px',
          }}
        >
          Three parents asked
        </div>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,260px),1fr))',
            gap: '16px',
            marginBottom: '56px',
          }}
        >
          <a
            className="hv-6"
            href="#q1"
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '12px',
              padding: '20px',
              border: '1px solid var(--border-default)',
              borderRadius: '16px',
              textDecoration: 'none',
              color: 'inherit',
              transition: 'transform 200ms cubic-bezier(.2,0,0,1), box-shadow 200ms cubic-bezier(.2,0,0,1)',
            }}
          >
            <span style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <Avatar name="Raja" size={36} />
              <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                <span style={{ fontWeight: '600', color: 'var(--text-strong)' }}>Raja</span>
                {' · Bengaluru'}
              </span>
            </span>
            <span
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '19px',
                lineHeight: '1.35',
                fontWeight: '700',
                color: 'var(--text-strong)',
              }}
            >
              “My son wants to switch from commerce to journalism.”
            </span>
            <span
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                fontSize: '15px',
                fontWeight: '600',
                color: 'var(--orange-700)',
                marginTop: 'auto',
              }}
            >
              Read the answer
              <Icon name="arrow-down" size={18} />
            </span>
          </a>
          <a
            className="hv-6"
            href="#q2"
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '12px',
              padding: '20px',
              border: '1px solid var(--border-default)',
              borderRadius: '16px',
              textDecoration: 'none',
              color: 'inherit',
              transition: 'transform 200ms cubic-bezier(.2,0,0,1), box-shadow 200ms cubic-bezier(.2,0,0,1)',
            }}
          >
            <span style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <Avatar name="Malini" size={36} />
              <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                <span style={{ fontWeight: '600', color: 'var(--text-strong)' }}>Malini</span>
                {' · Chennai'}
              </span>
            </span>
            <span
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '19px',
                lineHeight: '1.35',
                fontWeight: '700',
                color: 'var(--text-strong)',
              }}
            >
              “My daughter wants engineering because her friends do.”
            </span>
            <span
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                fontSize: '15px',
                fontWeight: '600',
                color: 'var(--orange-700)',
                marginTop: 'auto',
              }}
            >
              Read the answer
              <Icon name="arrow-down" size={18} />
            </span>
          </a>
          <a
            className="hv-6"
            href="#q3"
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '12px',
              padding: '20px',
              border: '1px solid var(--border-default)',
              borderRadius: '16px',
              textDecoration: 'none',
              color: 'inherit',
              transition: 'transform 200ms cubic-bezier(.2,0,0,1), box-shadow 200ms cubic-bezier(.2,0,0,1)',
            }}
          >
            <span style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <Avatar name="Ashutosh" size={36} />
              <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                <span style={{ fontWeight: '600', color: 'var(--text-strong)' }}>Ashutosh</span>
                {' · Delhi'}
              </span>
            </span>
            <span
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '19px',
                lineHeight: '1.35',
                fontWeight: '700',
                color: 'var(--text-strong)',
              }}
            >
              “My daughter changes her career idea every month.”
            </span>
            <span
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                fontSize: '15px',
                fontWeight: '600',
                color: 'var(--orange-700)',
                marginTop: 'auto',
              }}
            >
              Read the answer
              <Icon name="arrow-down" size={18} />
            </span>
          </a>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '40px 56px', alignItems: 'flex-start' }}>
          <article
            style={{
              flex: '999 1 560px',
              minWidth: '0',
              maxWidth: '700px',
              fontFamily: 'var(--font-reading)',
              fontSize: '20px',
              lineHeight: '1.7',
              color: 'var(--text-body)',
            }}
          >
            <section id="q1" style={{ scrollMarginTop: '96px' }}>
              <div
                style={{
                  display: 'flex',
                  gap: '14px',
                  alignItems: 'flex-start',
                  background: 'var(--neutral-50)',
                  borderRadius: '16px',
                  padding: '20px 24px',
                  marginBottom: '24px',
                  fontFamily: 'var(--font-ui)',
                }}
              >
                <Avatar name="Raja" size={44} />
                <div style={{ minWidth: '0' }}>
                  <div style={{ fontSize: '15px', color: 'var(--text-muted)', marginBottom: '4px' }}>
                    <span style={{ fontWeight: '600', color: 'var(--text-strong)' }}>Raja</span>
                    {' · Bengaluru · Son in Class 12'}
                  </div>
                  <p style={{ fontSize: '18px', lineHeight: '1.6', color: 'var(--text-body)', margin: '0' }}>
                    Our family runs a chartered accountancy firm. My son chose commerce and seemed headed for CA — now
                    he wants to study journalism. I hoped he’d take over the firm. How do I make him understand?
                  </p>
                </div>
              </div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  fontFamily: 'var(--font-ui)',
                  fontSize: '15px',
                  fontWeight: '700',
                  color: 'var(--sage-700)',
                  marginBottom: '12px',
                }}
              >
                <Icon name="message-circle" size={20} />
                The expert’s answer
              </div>
              <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
                Raja, many parents feel exactly as you do. Our hopes for our children grow out of family values and what
                we’ve built — so when your son picked commerce, it must have felt like the plan was falling into place.
                Then journalism appeared.
              </p>
              <h3
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '24px',
                  lineHeight: '1.3',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '32px 0 8px',
                }}
              >
                Why teens change their minds
              </h3>
              <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
                In mid-adolescence, teens turn to friends for deep conversations, question the familiar and imagine
                paths their parents never pictured. Their minds change often. Pushing hard to change his mind may only
                lead to conflict. Instead, try this:
              </p>
              <h3
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '22px',
                  lineHeight: '1.3',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '28px 0 8px',
                }}
              >
                1. Accept your own feelings first
              </h3>
              <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
                It’s normal to feel upset. Tell yourself, “I’m disappointed, and that’s okay.” Wait until you feel calm
                before you talk to him.
              </p>
              <h3
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '22px',
                  lineHeight: '1.3',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '28px 0 8px',
                }}
              >
                2. Start a fresh conversation
              </h3>
              <div
                style={{ background: 'var(--sage-50)', borderRadius: '16px', padding: '16px 20px', margin: '0 0 1em' }}
              >
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    fontFamily: 'var(--font-ui)',
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--sage-700)',
                    marginBottom: '6px',
                  }}
                >
                  <Icon name="message-circle" size={18} />
                  Try saying
                </div>
                <p style={{ margin: '0', color: 'var(--text-strong)' }}>
                  “Journalism seems to matter to you. Tell me more about it.”
                </p>
              </div>
              <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
                Listen without judging. Encourage him to find out what the work really involves and list the pros and
                cons of each career, so his choice is an informed one.
              </p>
              <h3
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '22px',
                  lineHeight: '1.3',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '28px 0 8px',
                }}
              >
                3. Discuss, appreciate, step back
              </h3>
              <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
                Talk often about what he learns, and notice his effort. When he isn’t worried about your reaction, he’ll
                value your experience more. If the conflict continues, a career counsellor can help.
              </p>
            </section>
            <section
              id="q2"
              style={{
                scrollMarginTop: '96px',
                marginTop: '56px',
                paddingTop: '40px',
                borderTop: '1px solid var(--border-default)',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  gap: '14px',
                  alignItems: 'flex-start',
                  background: 'var(--neutral-50)',
                  borderRadius: '16px',
                  padding: '20px 24px',
                  marginBottom: '24px',
                  fontFamily: 'var(--font-ui)',
                }}
              >
                <Avatar name="Malini" size={44} />
                <div style={{ minWidth: '0' }}>
                  <div style={{ fontSize: '15px', color: 'var(--text-muted)', marginBottom: '4px' }}>
                    <span style={{ fontWeight: '600', color: 'var(--text-strong)' }}>Malini</span>
                    {' · Chennai · Daughter in Class 11'}
                  </div>
                  <p style={{ fontSize: '18px', lineHeight: '1.6', color: 'var(--text-body)', margin: '0' }}>
                    My daughter is gifted in art, writing and music, but wants engineering — I think only because her
                    friends are doing it. I don’t want her to spend four years on something she doesn’t enjoy.
                  </p>
                </div>
              </div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  fontFamily: 'var(--font-ui)',
                  fontSize: '15px',
                  fontWeight: '700',
                  color: 'var(--sage-700)',
                  marginBottom: '12px',
                }}
              >
                <Icon name="message-circle" size={20} />
                The expert’s answer
              </div>
              <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
                Malini, it’s worrying to think such a big decision rests on friends — but many teens are in the same
                place. The only way to know if peer influence is real is to talk with her.
              </p>
              <h3
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '22px',
                  lineHeight: '1.3',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '28px 0 8px',
                }}
              >
                1. Reflect, then clear your head
              </h3>
              <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
                Think back to how she made the decision. Were friends part of it? Were there arguments? Then set your
                own worries aside before you begin.
              </p>
              <h3
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '22px',
                  lineHeight: '1.3',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '28px 0 8px',
                }}
              >
                2. Gently open up the topic of friends
              </h3>
              <div
                style={{ background: 'var(--sage-50)', borderRadius: '16px', padding: '16px 20px', margin: '0 0 1em' }}
              >
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    fontFamily: 'var(--font-ui)',
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--sage-700)',
                    marginBottom: '8px',
                  }}
                >
                  <Icon name="message-circle" size={18} />
                  Conversation starters
                </div>
                <ul style={{ margin: '0', paddingLeft: '1.2em', color: 'var(--text-strong)' }}>
                  <li style={{ marginBottom: '6px' }}>“What would it feel like to be away from your friends?”</li>
                  <li style={{ marginBottom: '6px' }}>“I know your friends mean a lot to you.”</li>
                  <li>“How does it feel to be different from them?”</li>
                </ul>
              </div>
              <h3
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '22px',
                  lineHeight: '1.3',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '28px 0 8px',
                }}
              >
                3. Help her explore engineering honestly
              </h3>
              <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
                If she’s still keen, give it a fair chance. She could talk to engineering students about what they like
                and don’t, and look through the course content. Be her sounding board. She may choose a creative field —
                or something new entirely.
              </p>
            </section>
            <section
              id="q3"
              style={{
                scrollMarginTop: '96px',
                marginTop: '56px',
                paddingTop: '40px',
                borderTop: '1px solid var(--border-default)',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  gap: '14px',
                  alignItems: 'flex-start',
                  background: 'var(--neutral-50)',
                  borderRadius: '16px',
                  padding: '20px 24px',
                  marginBottom: '24px',
                  fontFamily: 'var(--font-ui)',
                }}
              >
                <Avatar name="Ashutosh" size={44} />
                <div style={{ minWidth: '0' }}>
                  <div style={{ fontSize: '15px', color: 'var(--text-muted)', marginBottom: '4px' }}>
                    <span style={{ fontWeight: '600', color: 'var(--text-strong)' }}>Ashutosh</span>
                    {' · Delhi · Daughter in Class 12'}
                  </div>
                  <p style={{ fontSize: '18px', lineHeight: '1.6', color: 'var(--text-body)', margin: '0' }}>
                    First economics, then psychology, now visual communication — my daughter has a new idea every month.
                    I’ve told her to do whatever she wants, but I still worry. How do I guide her?
                  </p>
                </div>
              </div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  fontFamily: 'var(--font-ui)',
                  fontSize: '15px',
                  fontWeight: '700',
                  color: 'var(--sage-700)',
                  marginBottom: '12px',
                }}
              >
                <Icon name="message-circle" size={20} />
                The expert’s answer
              </div>
              <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
                Ashutosh, it’s stressful — but take heart. Changing her mind may mean she’s curious and busy discovering
                new possibilities. A different approach can help you support her.
              </p>
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '12px',
                  margin: '24px 0',
                  fontFamily: 'var(--font-ui)',
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    gap: '16px',
                    alignItems: 'flex-start',
                    padding: '18px 20px',
                    border: '1px solid var(--border-default)',
                    borderRadius: '16px',
                  }}
                >
                  <span
                    style={{
                      width: '40px',
                      height: '40px',
                      flex: 'none',
                      borderRadius: '50%',
                      background: 'var(--neutral-900)',
                      color: 'var(--text-inverse)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontFamily: 'var(--font-display)',
                      fontSize: '18px',
                      fontWeight: '700',
                    }}
                  >
                    1
                  </span>
                  <div>
                    <div
                      style={{ fontSize: '18px', fontWeight: '700', color: 'var(--text-strong)', marginBottom: '4px' }}
                    >
                      Become her ally
                    </div>
                    <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                      She may feel alone. Try: “Let’s work this out together, as a team.”
                    </div>
                  </div>
                </div>
                <div
                  style={{
                    display: 'flex',
                    gap: '16px',
                    alignItems: 'flex-start',
                    padding: '18px 20px',
                    border: '1px solid var(--border-default)',
                    borderRadius: '16px',
                  }}
                >
                  <span
                    style={{
                      width: '40px',
                      height: '40px',
                      flex: 'none',
                      borderRadius: '50%',
                      background: 'var(--neutral-900)',
                      color: 'var(--text-inverse)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontFamily: 'var(--font-display)',
                      fontSize: '18px',
                      fontWeight: '700',
                    }}
                  >
                    2
                  </span>
                  <div>
                    <div
                      style={{ fontSize: '18px', fontWeight: '700', color: 'var(--text-strong)', marginBottom: '4px' }}
                    >
                      Find the common threads
                    </div>
                    <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                      Ask her to list what she enjoys about each field. Shared themes will appear — match them to
                      possible careers.
                    </div>
                  </div>
                </div>
                <div
                  style={{
                    display: 'flex',
                    gap: '16px',
                    alignItems: 'flex-start',
                    padding: '18px 20px',
                    border: '1px solid var(--border-default)',
                    borderRadius: '16px',
                  }}
                >
                  <span
                    style={{
                      width: '40px',
                      height: '40px',
                      flex: 'none',
                      borderRadius: '50%',
                      background: 'var(--neutral-900)',
                      color: 'var(--text-inverse)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontFamily: 'var(--font-display)',
                      fontSize: '18px',
                      fontWeight: '700',
                    }}
                  >
                    3
                  </span>
                  <div>
                    <div
                      style={{ fontSize: '18px', fontWeight: '700', color: 'var(--text-strong)', marginBottom: '4px' }}
                    >
                      Keep talking
                    </div>
                    <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                      Discuss what she learns about the world of work. With your support, she’ll decide with more
                      confidence.
                    </div>
                  </div>
                </div>
              </div>
              <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
                She may also be one of those children with many abilities, looking for a career that uses them all. A
                career counsellor could help her see the options.
              </p>
            </section>
            <div
              style={{ background: 'var(--sky-50)', borderRadius: '16px', padding: '24px 28px', margin: '48px 0 0' }}
            >
              <div
                style={{
                  fontFamily: 'var(--font-ui)',
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--sky-700)',
                  marginBottom: '8px',
                }}
              >
                A new trend
              </div>
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '24px',
                  lineHeight: '1.3',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  marginBottom: '8px',
                }}
              >
                Teens want purpose, not just a career
              </div>
              <p style={{ margin: '0', textWrap: 'pretty' }}>
                Many young people today want work that makes a difference — and are happy to carve out unusual paths to
                find it.
              </p>
            </div>
            <p
              style={{ fontFamily: 'var(--font-ui)', fontSize: '15px', color: 'var(--text-muted)', margin: '20px 0 0' }}
            >
              Featured in The Free Press Journal, 30 November 2025 · Last updated 21 November 2025
            </p>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '16px',
                flexWrap: 'wrap',
                padding: '24px 0',
                marginTop: '32px',
                borderTop: '1px solid var(--border-default)',
                borderBottom: '1px solid var(--border-default)',
                fontFamily: 'var(--font-ui)',
              }}
            >
              {v.askHelpful ? (
                <Fragment>
                  <span style={{ fontSize: '19px', fontWeight: '600', color: 'var(--text-strong)' }}>
                    Was this answer helpful?
                  </span>
                  <div style={{ display: 'flex', gap: '10px' }}>
                    <Button variant="secondary" icon="thumbs-up" onClick={v.yes}>
                      Yes
                    </Button>
                    <Button variant="secondary" icon="thumbs-down" onClick={v.no}>
                      Not really
                    </Button>
                  </div>
                </Fragment>
              ) : null}
              {v.answered ? (
                <span
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    fontSize: '19px',
                    color: 'var(--sage-700)',
                  }}
                >
                  <Icon name="circle-check" size={22} />
                  {v.thanks}
                </span>
              ) : null}
            </div>
            <div style={{ marginTop: '32px', fontFamily: 'var(--font-ui)' }}>
              <Card tint="sage" padding={24}>
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    marginBottom: '4px',
                  }}
                >
                  Have a question of your own?
                </div>
                <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)', marginBottom: '14px' }}>
                  An expert will answer soon. Include your child’s age.
                </div>
                {v.notSent ? (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    <Input
                      multiline={true}
                      rows={3}
                      placeholder="Type your question…"
                      value={v.draft}
                      onChange={v.onDraft}
                    />
                    <div>
                      <Button variant="dark" icon="send" disabled={v.draftEmpty} onClick={v.send}>
                        Send question
                      </Button>
                    </div>
                  </div>
                ) : null}
                {v.sent ? (
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '10px',
                      fontSize: '18px',
                      fontWeight: '600',
                      color: 'var(--sage-700)',
                    }}
                  >
                    <Icon name="circle-check" size={22} />
                    Thank you! The expert will answer your question soon.
                  </div>
                ) : null}
              </Card>
            </div>
          </article>
          <aside style={{ flex: '1 1 260px', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--text-muted)',
              }}
            >
              More questions answered
            </div>
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              <a
                className="hv-5"
                href="#"
                style={{
                  display: 'block',
                  padding: '14px 0',
                  borderBottom: '1px solid var(--border-subtle)',
                  fontFamily: 'var(--font-display)',
                  fontSize: '18px',
                  lineHeight: '1.4',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  textDecoration: 'none',
                }}
              >
                Child easily distracted while studying? Ways to improve focus
              </a>
              <a
                className="hv-5"
                href="#"
                style={{
                  display: 'block',
                  padding: '14px 0',
                  borderBottom: '1px solid var(--border-subtle)',
                  fontFamily: 'var(--font-display)',
                  fontSize: '18px',
                  lineHeight: '1.4',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  textDecoration: 'none',
                }}
              >
                How parents can manage their own exam stress
              </a>
              <a
                className="hv-5"
                href="#"
                style={{
                  display: 'block',
                  padding: '14px 0',
                  borderBottom: '1px solid var(--border-subtle)',
                  fontFamily: 'var(--font-display)',
                  fontSize: '18px',
                  lineHeight: '1.4',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  textDecoration: 'none',
                }}
              >
                When kids want to do what their friends do
              </a>
              <a
                className="hv-5"
                href="#"
                style={{
                  display: 'block',
                  padding: '14px 0',
                  borderBottom: '1px solid var(--border-subtle)',
                  fontFamily: 'var(--font-display)',
                  fontSize: '18px',
                  lineHeight: '1.4',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  textDecoration: 'none',
                }}
              >
                When plans get cancelled: handling disappointment
              </a>
              <a
                className="hv-5"
                href="#"
                style={{
                  display: 'block',
                  padding: '14px 0',
                  fontFamily: 'var(--font-display)',
                  fontSize: '18px',
                  lineHeight: '1.4',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  textDecoration: 'none',
                }}
              >
                Eye care tips to keep your child’s vision healthy
              </a>
            </div>
            <a href={toUrl('/ask-the-expert')} style={{ display: 'block', textDecoration: 'none' }}>
              <Button variant="secondary" iconRight="arrow-right" fullWidth={true}>
                All expert answers
              </Button>
            </a>
          </aside>
        </div>
      </main>
      <section style={{ marginTop: '96px', background: 'var(--neutral-50)' }}>
        <div style={{ maxWidth: '1088px', margin: '0 auto', padding: '64px 24px', boxSizing: 'border-box' }}>
          <h2
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(28px,3vw,34px)',
              lineHeight: '1.2',
              letterSpacing: '-0.01em',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0 0 28px',
            }}
          >
            Related reading
          </h2>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,260px),1fr))',
              gap: '40px 28px',
            }}
          >
            {(v.more ?? []).map((a, $i0) => (
              <Fragment key={$i0}>
                <ArticleCard layout="vertical" {...a} />
              </Fragment>
            ))}
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
