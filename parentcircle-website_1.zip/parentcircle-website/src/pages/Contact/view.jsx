import { Fragment } from 'react';
import { Button, Icon } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Contact" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      id="top"
      data-screen-label="Contact us"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader />
      <main>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '32px 24px 0', boxSizing: 'border-box' }}>
          <nav aria-label="Company" style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '48px' }}>
            <a
              className="hv-0"
              href={toUrl('/about')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              About us
            </a>
            <a
              className="hv-0"
              href={toUrl('/press')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Press releases
            </a>
            <a
              className="hv-0"
              href={toUrl('/guidelines')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Community guidelines
            </a>
            <a
              className="hv-0"
              href={toUrl('/community-help')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Community help
            </a>
            <a
              className="hv-0"
              href={toUrl('/terms')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Terms of use
            </a>
            <a
              className="hv-0"
              href={toUrl('/privacy')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Privacy policy
            </a>
            <a
              href={toUrl('/contact')}
              aria-current="page"
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                background: 'var(--neutral-900)',
                color: 'var(--text-inverse)',
                fontSize: '16px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Contact us
            </a>
          </nav>
          <div style={{ maxWidth: '760px' }}>
            <div
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--orange-700)',
                marginBottom: '12px',
              }}
            >
              Contact us
            </div>
            <h1
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(38px,5vw,60px)',
                lineHeight: '1.08',
                letterSpacing: '-0.015em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0',
                textWrap: 'balance',
              }}
            >
              We’d love to hear from you
            </h1>
            <p
              style={{
                fontFamily: 'var(--font-serif)',
                fontSize: '22px',
                lineHeight: '1.55',
                color: 'var(--text-body)',
                margin: '18px 0 0',
                textWrap: 'pretty',
              }}
            >
              Choose the team that fits your question, and we’ll get back to you as soon as we can.
            </p>
          </div>
        </section>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '48px 24px 0', boxSizing: 'border-box' }}>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,300px),1fr))',
              gap: '16px',
            }}
          >
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '14px',
                padding: '24px',
                borderRadius: '20px',
                border: '1px solid var(--border-default)',
                background: 'var(--white)',
              }}
            >
              <span
                style={{
                  width: '52px',
                  height: '52px',
                  borderRadius: '14px',
                  background: 'var(--orange-50)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Icon name="message-circle" size={26} color="var(--orange-700)" />
              </span>
              <div>
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    marginBottom: '4px',
                  }}
                >
                  General questions
                </div>
                <div style={{ fontSize: '16px', lineHeight: '1.5', color: 'var(--text-muted)' }}>
                  Feedback, suggestions or anything else about ParentCircle.
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: 'auto' }}>
                <a
                  className="hv-8"
                  href="mailto:contact@parentcircle.com"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    fontSize: '17px',
                    fontWeight: '600',
                    color: 'var(--text-link)',
                    textDecoration: 'none',
                    overflowWrap: 'break-word',
                    minWidth: '0',
                  }}
                >
                  <Icon name="mail" size={20} color="var(--text-muted)" />
                  contact@parentcircle.com
                </a>
                <a
                  className="hv-5"
                  href="tel:+914424466623"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    fontSize: '17px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="phone" size={20} color="var(--text-muted)" />
                  +91 44 2446 6623
                </a>
              </div>
            </div>
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '14px',
                padding: '24px',
                borderRadius: '20px',
                border: '1px solid var(--border-default)',
                background: 'var(--white)',
              }}
            >
              <span
                style={{
                  width: '52px',
                  height: '52px',
                  borderRadius: '14px',
                  background: 'var(--butter-50)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Icon name="megaphone" size={26} color="var(--butter-700)" />
              </span>
              <div>
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    marginBottom: '4px',
                  }}
                >
                  Advertising
                </div>
                <div style={{ fontSize: '16px', lineHeight: '1.5', color: 'var(--text-muted)' }}>
                  Reach parents across India through our website, apps and magazines.
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: 'auto' }}>
                <a
                  className="hv-8"
                  href="mailto:ads@parentcircle.in"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    fontSize: '17px',
                    fontWeight: '600',
                    color: 'var(--text-link)',
                    textDecoration: 'none',
                    overflowWrap: 'break-word',
                    minWidth: '0',
                  }}
                >
                  <Icon name="mail" size={20} color="var(--text-muted)" />
                  ads@parentcircle.in
                </a>
                <a
                  className="hv-5"
                  href="tel:+919003012104"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    fontSize: '17px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="phone" size={20} color="var(--text-muted)" />
                  +91 90030 12104
                </a>
              </div>
            </div>
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '14px',
                padding: '24px',
                borderRadius: '20px',
                border: '1px solid var(--border-default)',
                background: 'var(--white)',
              }}
            >
              <span
                style={{
                  width: '52px',
                  height: '52px',
                  borderRadius: '14px',
                  background: 'var(--sky-50)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Icon name="mic" size={26} color="var(--sky-700)" />
              </span>
              <div>
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    marginBottom: '4px',
                  }}
                >
                  Media and press
                </div>
                <div style={{ fontSize: '16px', lineHeight: '1.5', color: 'var(--text-muted)' }}>
                  Interviews and stories with our leaders, advisers and experts.
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: 'auto' }}>
                <a
                  className="hv-8"
                  href="mailto:contact@parentcircle.com"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    fontSize: '17px',
                    fontWeight: '600',
                    color: 'var(--text-link)',
                    textDecoration: 'none',
                    overflowWrap: 'break-word',
                    minWidth: '0',
                  }}
                >
                  <Icon name="mail" size={20} color="var(--text-muted)" />
                  contact@parentcircle.com
                </a>
                <a
                  className="hv-5"
                  href="tel:+919791039335"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    fontSize: '17px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="phone" size={20} color="var(--text-muted)" />
                  +91 97910 39335
                </a>
              </div>
            </div>
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '14px',
                padding: '24px',
                borderRadius: '20px',
                border: '1px solid var(--border-default)',
                background: 'var(--white)',
              }}
            >
              <span
                style={{
                  width: '52px',
                  height: '52px',
                  borderRadius: '14px',
                  background: 'var(--sage-50)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Icon name="users" size={26} color="var(--sage-700)" />
              </span>
              <div>
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    marginBottom: '4px',
                  }}
                >
                  Community and accounts
                </div>
                <div style={{ fontSize: '16px', lineHeight: '1.5', color: 'var(--text-muted)' }}>
                  Trouble signing in, or a question about a circle or post.
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: 'auto' }}>
                <a
                  className="hv-8"
                  href="mailto:community@parentcircle.in"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    fontSize: '17px',
                    fontWeight: '600',
                    color: 'var(--text-link)',
                    textDecoration: 'none',
                    overflowWrap: 'break-word',
                    minWidth: '0',
                  }}
                >
                  <Icon name="mail" size={20} color="var(--text-muted)" />
                  community@parentcircle.in
                </a>
              </div>
            </div>
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '14px',
                padding: '24px',
                borderRadius: '20px',
                border: '1px solid var(--border-default)',
                background: 'var(--white)',
              }}
            >
              <span
                style={{
                  width: '52px',
                  height: '52px',
                  borderRadius: '14px',
                  background: 'var(--blush-50)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Icon name="package" size={26} color="var(--blush-700)" />
              </span>
              <div>
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    marginBottom: '4px',
                  }}
                >
                  Orders and returns
                </div>
                <div style={{ fontSize: '16px', lineHeight: '1.5', color: 'var(--text-muted)' }}>
                  Received a wrong or damaged product? Write within 1 day with your order ID.
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: 'auto' }}>
                <a
                  className="hv-8"
                  href="mailto:learnathome@parentcircle.in"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    fontSize: '17px',
                    fontWeight: '600',
                    color: 'var(--text-link)',
                    textDecoration: 'none',
                    overflowWrap: 'break-word',
                    minWidth: '0',
                  }}
                >
                  <Icon name="mail" size={20} color="var(--text-muted)" />
                  learnathome@parentcircle.in
                </a>
              </div>
            </div>
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '14px',
                padding: '24px',
                borderRadius: '20px',
                border: '1px solid var(--border-default)',
                background: 'var(--white)',
              }}
            >
              <span
                style={{
                  width: '52px',
                  height: '52px',
                  borderRadius: '14px',
                  background: 'var(--lilac-50)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Icon name="briefcase" size={26} color="var(--lilac-700)" />
              </span>
              <div>
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    marginBottom: '4px',
                  }}
                >
                  Work with us
                </div>
                <div style={{ fontSize: '16px', lineHeight: '1.5', color: 'var(--text-muted)' }}>
                  We’re looking for bright, creative people. Send us your CV.
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: 'auto' }}>
                <a
                  className="hv-8"
                  href="mailto:corporate-hr@parentcircle.in"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    fontSize: '17px',
                    fontWeight: '600',
                    color: 'var(--text-link)',
                    textDecoration: 'none',
                    overflowWrap: 'break-word',
                    minWidth: '0',
                  }}
                >
                  <Icon name="mail" size={20} color="var(--text-muted)" />
                  corporate-hr@parentcircle.in
                </a>
              </div>
            </div>
          </div>
        </section>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '80px 24px 0', boxSizing: 'border-box' }}>
          <div
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              borderRadius: '24px',
              overflow: 'hidden',
              border: '1px solid var(--border-default)',
            }}
          >
            <div
              style={{
                flex: '1 1 340px',
                minWidth: '0',
                padding: 'clamp(24px,4vw,40px)',
                display: 'flex',
                flexDirection: 'column',
                gap: '18px',
                background: 'var(--neutral-50)',
              }}
            >
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-700)',
                }}
              >
                Visit us
              </div>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(28px,3vw,36px)',
                  lineHeight: '1.2',
                  letterSpacing: '-0.01em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                }}
              >
                Our office in Chennai
              </h2>
              <div style={{ display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
                <Icon name="map-pin" size={24} color="var(--orange-600)" />
                <address
                  style={{ fontStyle: 'normal', fontSize: '18px', lineHeight: '1.6', color: 'var(--text-strong)' }}
                >
                  Shri Harini Media Ltd.
                  <br />
                  No 8/14, Sri Renga Vihar, 3rd floor
                  <br />
                  Karpagam Garden 1st Cross Street
                  <br />
                  Adyar, Chennai 600 020, India
                </address>
              </div>
              <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                <Icon name="phone" size={24} color="var(--orange-600)" />
                <a
                  className="hv-5"
                  href="tel:+914424466623"
                  style={{ fontSize: '18px', fontWeight: '600', color: 'var(--text-strong)', textDecoration: 'none' }}
                >
                  +91 44 2446 6623
                </a>
              </div>
              <div style={{ marginTop: 'auto', paddingTop: '8px' }}>
                <a
                  href={
                    'https://www.google.com/maps/search/?api=1&query=Shri+Harini+Media+Ltd+Sri+Renga+Vihar+Adyar+Chennai+600020'
                  }
                  target="_blank"
                  rel="noopener"
                  style={{ textDecoration: 'none' }}
                >
                  <Button variant="dark" icon="navigation">
                    Get directions
                  </Button>
                </a>
              </div>
            </div>
            <div
              style={{
                flex: '1.4 1 420px',
                minWidth: '0',
                minHeight: '360px',
                position: 'relative',
                background: 'var(--neutral-100)',
              }}
            >
              <a
                href={
                  'https://www.google.com/maps/search/?api=1&query=Shri+Harini+Media+Ltd+Sri+Renga+Vihar+Adyar+Chennai+600020'
                }
                target="_blank"
                rel="noopener"
                aria-label="Open the ParentCircle office in Google Maps"
                style={{ position: 'absolute', inset: '0', display: 'block' }}
              >
                <img
                  src={toUrl('/images/office-map-3.png')}
                  alt="Map showing the ParentCircle office at Sri Renga Vihar, Adyar, Chennai"
                  style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
                />
              </a>
            </div>
          </div>
        </section>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '80px 24px 0', boxSizing: 'border-box' }}>
          <div
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '24px 40px',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: 'clamp(28px,4vw,40px)',
              borderRadius: '24px',
              background: 'var(--orange-50)',
            }}
          >
            <div style={{ flex: '1 1 320px', minWidth: '0' }}>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(26px,3vw,32px)',
                  lineHeight: '1.2',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0 0 6px',
                }}
              >
                Follow ParentCircle
              </h2>
              <p style={{ fontSize: '18px', lineHeight: '1.5', color: 'var(--text-body)', margin: '0' }}>
                Daily tips, videos and stories from our community.
              </p>
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
              <a
                className="hv-0"
                href="https://www.instagram.com/parentcircle/"
                target="_blank"
                rel="noopener"
                style={{
                  height: '48px',
                  padding: '0 20px',
                  borderRadius: '999px',
                  background: 'var(--white)',
                  border: '1px solid var(--border-default)',
                  color: 'var(--text-strong)',
                  fontSize: '17px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                Instagram
                <Icon name="arrow-up-right" size={18} color="var(--text-muted)" />
              </a>
              <a
                className="hv-0"
                href="https://www.facebook.com/ParentCirclemagazine/"
                target="_blank"
                rel="noopener"
                style={{
                  height: '48px',
                  padding: '0 20px',
                  borderRadius: '999px',
                  background: 'var(--white)',
                  border: '1px solid var(--border-default)',
                  color: 'var(--text-strong)',
                  fontSize: '17px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                Facebook
                <Icon name="arrow-up-right" size={18} color="var(--text-muted)" />
              </a>
              <a
                className="hv-0"
                href="https://www.youtube.com/user/parentcircleindia"
                target="_blank"
                rel="noopener"
                style={{
                  height: '48px',
                  padding: '0 20px',
                  borderRadius: '999px',
                  background: 'var(--white)',
                  border: '1px solid var(--border-default)',
                  color: 'var(--text-strong)',
                  fontSize: '17px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                YouTube
                <Icon name="arrow-up-right" size={18} color="var(--text-muted)" />
              </a>
              <a
                className="hv-0"
                href="https://twitter.com/Parent_Circle"
                target="_blank"
                rel="noopener"
                style={{
                  height: '48px',
                  padding: '0 20px',
                  borderRadius: '999px',
                  background: 'var(--white)',
                  border: '1px solid var(--border-default)',
                  color: 'var(--text-strong)',
                  fontSize: '17px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                X (Twitter)
                <Icon name="arrow-up-right" size={18} color="var(--text-muted)" />
              </a>
              <a
                className="hv-0"
                href="https://www.pinterest.com/parentcirclecom/"
                target="_blank"
                rel="noopener"
                style={{
                  height: '48px',
                  padding: '0 20px',
                  borderRadius: '999px',
                  background: 'var(--white)',
                  border: '1px solid var(--border-default)',
                  color: 'var(--text-strong)',
                  fontSize: '17px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                Pinterest
                <Icon name="arrow-up-right" size={18} color="var(--text-muted)" />
              </a>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter spaced />
    </div>
  );
}
