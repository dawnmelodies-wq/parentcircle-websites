import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  renderVals() {
    return {};
  }
}

export default PageLogic;
