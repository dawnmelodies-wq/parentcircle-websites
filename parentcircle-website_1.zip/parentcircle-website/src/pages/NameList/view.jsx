import { Fragment } from 'react';
import { Avatar, Button, Icon, Input, Tabs } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Name List" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Name list"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader active="read" />
      <main style={{ maxWidth: '1200px', margin: '0 auto', padding: '28px 24px 0', boxSizing: 'border-box' }}>
        <nav
          aria-label="Breadcrumb"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            flexWrap: 'wrap',
            fontSize: '15px',
            color: 'var(--text-muted)',
            marginBottom: '28px',
          }}
        >
          <a
            className="hv-1"
            href={toUrl('/')}
            style={{ color: 'var(--text-muted)', textDecoration: 'none', fontWeight: '600' }}
          >
            Home
          </a>
          <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
          <a
            className="hv-1"
            href={toUrl('/baby-names')}
            style={{ color: 'var(--text-muted)', textDecoration: 'none', fontWeight: '600' }}
          >
            Baby names
          </a>
          <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
          <span>{v.crumb}</span>
        </nav>
        <section
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            gap: '28px 48px',
            alignItems: 'center',
            padding: 'clamp(24px,4vw,40px)',
            borderRadius: '24px',
            background: v.tint,
          }}
        >
          <div style={{ flex: '1.2 1 420px', minWidth: '0' }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: v.ink,
                marginBottom: '12px',
              }}
            >
              <Icon name="baby" size={18} color="currentColor" />
              {v.eyebrow}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
              <span
                aria-hidden="true"
                style={{
                  width: '84px',
                  height: '84px',
                  flex: 'none',
                  borderRadius: '50%',
                  background: 'var(--white)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontFamily: 'var(--font-display)',
                  fontSize: '44px',
                  fontWeight: '700',
                  color: v.ink,
                  boxShadow: 'var(--shadow-sm)',
                }}
              >
                {v.letter}
              </span>
              <h1
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(32px,4.2vw,50px)',
                  lineHeight: '1.1',
                  letterSpacing: '-0.015em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                  textWrap: 'balance',
                }}
              >
                {v.title}
              </h1>
            </div>
            <p
              style={{
                fontFamily: 'var(--font-serif)',
                fontSize: '21px',
                lineHeight: '1.6',
                color: 'var(--text-body)',
                margin: '18px 0 20px',
                textWrap: 'pretty',
              }}
            >
              {v.dek}
            </p>
            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '12px 20px',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Avatar name="Team ParentCircle" size={40} />
                <div>
                  <div style={{ fontSize: '16px', fontWeight: '700', color: 'var(--text-strong)' }}>
                    Team ParentCircle
                  </div>
                  <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Infant to Parent · 4 min read</div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                <Button variant="secondary" size="sm" icon={v.saveIcon} onClick={v.toggleSave}>
                  {v.saveLabel}
                </Button>
                <Button variant="secondary" size="sm" icon={v.shareIcon} onClick={v.share}>
                  {v.shareLabel}
                </Button>
              </div>
            </div>
          </div>
          <div
            style={{
              flex: '1 1 300px',
              minWidth: '0',
              position: 'relative',
              aspectRatio: '4 / 3',
              borderRadius: '20px',
              overflow: 'hidden',
              background: 'var(--white)',
            }}
          >
            <image-slot
              id={`namelist-${v.gender ?? ''}-${v.letter ?? ''}-hero`}
              shape="rounded"
              radius="20"
              placeholder={v.heroPhoto}
            ></image-slot>
          </div>
        </section>
        <div
          style={{ display: 'flex', flexWrap: 'wrap', gap: '40px 48px', alignItems: 'flex-start', paddingTop: '40px' }}
        >
          <div style={{ flex: '999 1 560px', minWidth: '0' }}>
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '14px',
                paddingBottom: '20px',
                borderBottom: '1px solid var(--border-subtle)',
              }}
            >
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', alignItems: 'flex-start' }}>
                <div style={{ flex: '1 1 260px', minWidth: '0' }}>
                  <Input
                    icon="search"
                    placeholder="Search a name or meaning, e.g. sun"
                    aria-label="Search names"
                    value={v.q}
                    onChange={v.onQ}
                  />
                </div>
                <Tabs variant="pill" tabs={v.genderTabs} value={v.gender} onChange={v.setGender} />
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                {(v.originChips ?? []).map((c, $i0) => (
                  <Fragment key={$i0}>
                    <button
                      type="button"
                      aria-pressed={c?.on}
                      onClick={c?.toggle}
                      style={{
                        height: '40px',
                        padding: '0 14px',
                        borderRadius: '999px',
                        border: `1.5px solid ${c?.bd ?? ''}`,
                        background: c?.bg,
                        color: c?.fg,
                        font: 'inherit',
                        fontSize: '15px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        transition: 'background 150ms',
                      }}
                    >
                      {c?.label}
                    </button>
                  </Fragment>
                ))}
              </div>
              <span style={{ fontSize: '16px', fontWeight: '600', color: 'var(--text-strong)' }}>{v.countLabel}</span>
            </div>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,220px),1fr))',
                gap: '14px',
                paddingTop: '24px',
              }}
            >
              {(v.names ?? []).map((n, $i0) => (
                <Fragment key={$i0}>
                  <article
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '8px',
                      padding: '18px',
                      borderRadius: '16px',
                      background: 'var(--white)',
                      border: `1px solid ${n?.bd ?? ''}`,
                      boxShadow: n?.shadow,
                      transition: 'box-shadow 200ms, border-color 200ms',
                    }}
                  >
                    <div
                      style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '8px' }}
                    >
                      <span
                        style={{
                          fontFamily: 'var(--font-display)',
                          fontSize: '26px',
                          lineHeight: '1.15',
                          fontWeight: '700',
                          color: 'var(--text-strong)',
                        }}
                      >
                        {n?.name}
                      </span>
                      <button
                        type="button"
                        aria-pressed={n?.on}
                        aria-label={n?.likeLabel}
                        onClick={n?.toggle}
                        style={{
                          width: '44px',
                          height: '44px',
                          flex: 'none',
                          margin: '-8px -8px 0 0',
                          borderRadius: '50%',
                          border: '0',
                          background: n?.heartBg,
                          color: n?.heartFg,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          cursor: 'pointer',
                        }}
                      >
                        <Icon name="heart" size={20} color="currentColor" />
                      </button>
                    </div>
                    <p
                      style={{
                        fontFamily: 'var(--font-serif)',
                        fontSize: '17px',
                        lineHeight: '1.5',
                        color: 'var(--text-body)',
                        margin: '0',
                        textWrap: 'pretty',
                      }}
                    >
                      {n?.meaning}
                    </p>
                    <span
                      style={{
                        alignSelf: 'flex-start',
                        marginTop: 'auto',
                        height: '26px',
                        padding: '0 10px',
                        borderRadius: '6px',
                        background: n?.tagBg,
                        color: n?.tagFg,
                        fontSize: '14px',
                        fontWeight: '700',
                        display: 'flex',
                        alignItems: 'center',
                      }}
                    >
                      {n?.origin}
                    </span>
                  </article>
                </Fragment>
              ))}
            </div>
            {v.noNames ? (
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'flex-start',
                  gap: '12px',
                  marginTop: '24px',
                  padding: '28px',
                  borderRadius: '20px',
                  background: 'var(--neutral-50)',
                }}
              >
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                  }}
                >
                  {v.emptyTitle}
                </div>
                <p style={{ fontSize: '17px', color: 'var(--text-body)', margin: '0' }}>{v.emptyHint}</p>
                <Button variant="dark" icon="rotate-ccw" onClick={v.resetAll}>
                  Clear search
                </Button>
              </div>
            ) : null}
            <section
              style={{ marginTop: '48px', padding: '28px', borderRadius: '20px', background: 'var(--butter-50)' }}
            >
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(24px,2.8vw,30px)',
                  lineHeight: '1.2',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0 0 16px',
                }}
              >
                Choosing a name: what most families consider
              </h2>
              <ol
                style={{
                  listStyle: 'none',
                  margin: '0',
                  padding: '0',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '14px',
                }}
              >
                {(v.tips ?? []).map((t, $i0) => (
                  <Fragment key={$i0}>
                    <li style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                      <span
                        style={{
                          width: '32px',
                          height: '32px',
                          flex: 'none',
                          borderRadius: '50%',
                          background: 'var(--neutral-900)',
                          color: 'var(--white)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '15px',
                          fontWeight: '700',
                        }}
                      >
                        {t?.n}
                      </span>
                      <span
                        style={{
                          fontFamily: 'var(--font-reading)',
                          fontSize: '19px',
                          lineHeight: '1.6',
                          color: 'var(--text-body)',
                          paddingTop: '2px',
                        }}
                      >
                        <strong style={{ color: 'var(--text-strong)' }}>{t?.h}</strong> {t?.b}
                      </span>
                    </li>
                  </Fragment>
                ))}
              </ol>
            </section>
          </div>
          <aside
            style={{
              flex: '1 1 300px',
              minWidth: '0',
              display: 'flex',
              flexDirection: 'column',
              gap: '28px',
              position: 'sticky',
              top: '96px',
            }}
          >
            <div
              style={{
                padding: '22px',
                borderRadius: '20px',
                background: 'var(--white)',
                border: '1px solid var(--border-subtle)',
                boxShadow: 'var(--shadow-sm)',
                display: 'flex',
                flexDirection: 'column',
                gap: '14px',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' }}>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    fontFamily: 'var(--font-display)',
                    fontSize: '21px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                  }}
                >
                  <Icon name="heart" size={20} color="var(--blush-700)" />
                  Your shortlist
                </div>
                <span style={{ fontSize: '15px', fontWeight: '600', color: 'var(--text-muted)' }}>{v.shortCount}</span>
              </div>
              {v.noShort ? (
                <p style={{ fontSize: '16px', lineHeight: '1.5', color: 'var(--text-muted)', margin: '0' }}>
                  Tap the heart on any name to add it here.
                </p>
              ) : null}
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                {(v.shortlist ?? []).map((s, $i0) => (
                  <Fragment key={$i0}>
                    <button
                      className="hv-m"
                      type="button"
                      onClick={s?.remove}
                      aria-label={s?.label}
                      style={{
                        height: '40px',
                        padding: '0 10px 0 14px',
                        borderRadius: '999px',
                        border: '0',
                        background: 'var(--blush-50)',
                        color: 'var(--text-strong)',
                        font: 'inherit',
                        fontSize: '16px',
                        fontWeight: '700',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        cursor: 'pointer',
                      }}
                    >
                      {s?.name}
                      <Icon name="x" size={16} color="var(--text-muted)" />
                    </button>
                  </Fragment>
                ))}
              </div>
              {v.hasShort ? (
                <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                  <Button variant="dark" size="sm" icon={v.copyIcon} onClick={v.copyShort}>
                    {v.copyLabel}
                  </Button>
                  <Button variant="ghost" size="sm" onClick={v.clearShort}>
                    Clear
                  </Button>
                </div>
              ) : null}
            </div>
            <div>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                  marginBottom: '12px',
                }}
              >
                Browse another letter
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,minmax(0,1fr))', gap: '6px' }}>
                {(v.letters ?? []).map((l, $i0) => (
                  <Fragment key={$i0}>
                    <a
                      className="hv-n"
                      href={toUrl(l?.href)}
                      aria-current={l?.cur}
                      style={{
                        height: '44px',
                        borderRadius: '10px',
                        border: `1.5px solid ${l?.bd ?? ''}`,
                        background: l?.bg,
                        color: l?.fg,
                        fontFamily: 'var(--font-display)',
                        fontSize: '18px',
                        fontWeight: '700',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        textDecoration: 'none',
                      }}
                    >
                      {l?.ch}
                    </a>
                  </Fragment>
                ))}
              </div>
            </div>
          </aside>
        </div>
        <section style={{ marginTop: '72px', padding: '48px 0 72px', borderTop: '1px solid var(--border-subtle)' }}>
          <h2
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(24px,2.8vw,30px)',
              lineHeight: '1.2',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0 0 24px',
            }}
          >
            More name lists
          </h2>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,280px),1fr))',
              gap: '36px 24px',
            }}
          >
            {(v.more ?? []).map((m, $i0) => (
              <Fragment key={$i0}>
                <article style={{ display: 'flex', flexDirection: 'column', gap: '10px', minWidth: '0' }}>
                  <div
                    style={{
                      position: 'relative',
                      overflow: 'hidden',
                      aspectRatio: '16 / 10',
                      borderRadius: '16px',
                      background: m?.tint,
                    }}
                  >
                    <image-slot
                      id={`namelist-more-${m?.id ?? ''}`}
                      shape="rounded"
                      radius="16"
                      placeholder={m?.photo}
                    ></image-slot>
                  </div>
                  <span
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: m?.ink,
                    }}
                  >
                    {m?.cat}
                  </span>
                  <a
                    className="hv-5"
                    href={toUrl(m?.href)}
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '20px',
                      lineHeight: '1.3',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                      textWrap: 'pretty',
                    }}
                  >
                    {m?.title}
                  </a>
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{m?.meta}</span>
                </article>
              </Fragment>
            ))}
          </div>
        </section>
      </main>
      <section aria-labelledby="top-searches" style={{ background: 'var(--neutral-50)' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '48px 24px 56px', boxSizing: 'border-box' }}>
          <h2
            id="top-searches"
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(24px,2.6vw,30px)',
              lineHeight: '1.2',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0 0 18px',
            }}
          >
            Top searches
          </h2>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
            <a
              className="hv-3"
              href="https://www.dotlearningcircle.com/comprehensive-curriculum-for-pre-primary-children"
              target="_blank"
              rel="noopener"
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Kindergarten curriculum
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Pregnancy%20care')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Pregnancy care
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Preparing%20for%20baby')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Preparing for baby
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Birth%20and%20delivery')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Birth and delivery
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Parenting%20tips%20for%20infants')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parenting tips for infants
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Culture%20and%20tradition')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Culture and tradition
            </a>
            <a
              className="hv-3"
              href={toUrl('/parents-of-india')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parents of India
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Grandparent%20stories')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Grandparent stories
            </a>
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
