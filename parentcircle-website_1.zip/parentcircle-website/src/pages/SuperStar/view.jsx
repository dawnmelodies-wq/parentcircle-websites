import { Fragment } from 'react';
import { Badge, Button, Dialog, Icon, Input, Radio, Tag } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "SuperStar" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="SuperStar Program"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader active="programs" communityHref="/#community" />
      <section style={{ background: 'var(--orange-50)' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '40px 24px 72px', boxSizing: 'border-box' }}>
          <nav
            aria-label="Breadcrumb"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              flexWrap: 'wrap',
              fontSize: '15px',
              color: 'var(--text-muted)',
              marginBottom: '32px',
            }}
          >
            <a
              className="hv-1"
              href={toUrl('/')}
              style={{ color: 'var(--text-muted)', textDecoration: 'none', fontWeight: '600' }}
            >
              Home
            </a>
            <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
            <a
              className="hv-1"
              href={toUrl('/programs')}
              style={{ color: 'var(--text-muted)', textDecoration: 'none' }}
            >
              Programs
            </a>
            <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
            <span>SuperStar Program</span>
          </nav>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '48px 64px', alignItems: 'center' }}>
            <div style={{ flex: '1 1 440px', minWidth: '0' }}>
              <div
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '8px',
                  height: '36px',
                  padding: '0 14px',
                  borderRadius: '999px',
                  background: 'var(--white)',
                  color: 'var(--orange-700)',
                  fontSize: '15px',
                  fontWeight: '700',
                  marginBottom: '20px',
                  boxShadow: 'var(--shadow-xs)',
                }}
              >
                <Icon name="star" size={18} color="var(--pc-orange)" />
                ParentCircle SuperStar Program
              </div>
              <h1
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(38px,4.8vw,60px)',
                  lineHeight: '1.08',
                  letterSpacing: '-0.015em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                  textWrap: 'balance',
                }}
              >
                Share your story. Inspire another parent.
              </h1>
              <p
                style={{
                  fontFamily: 'var(--font-serif)',
                  fontSize: '22px',
                  lineHeight: '1.55',
                  color: 'var(--text-body)',
                  margin: '20px 0 32px',
                  maxWidth: '560px',
                  textWrap: 'pretty',
                }}
              >
                Has ParentCircle helped your family? Become a SuperStar — tell other parents what worked for you, and
                join a warm group of members who give back to the community.
              </p>
              <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                <Button variant="primary" size="lg" icon="star" onClick={v.openEnrol}>
                  Become a SuperStar
                </Button>
                <Button variant="secondary" size="lg" iconRight="arrow-down" onClick={v.goStories}>
                  Read their stories
                </Button>
              </div>
            </div>
            <div
              style={{
                flex: '1 1 400px',
                minWidth: '0',
                display: 'grid',
                gridTemplateColumns: 'repeat(3,minmax(0,1fr))',
                gap: '12px',
                alignItems: 'end',
              }}
            >
              <div
                style={{
                  position: 'relative',
                  overflow: 'hidden',
                  width: '100%',
                  aspectRatio: '3 / 4',
                  borderRadius: '24px',
                  background: 'var(--orange-100)',
                }}
              >
                <image-slot
                  id="superstar-hero-1"
                  shape="rounded"
                  radius="24"
                  placeholder="Photo: Roopa M., ParentCircle SuperStar"
                ></image-slot>
              </div>
              <div
                style={{
                  position: 'relative',
                  overflow: 'hidden',
                  width: '100%',
                  aspectRatio: '3 / 4',
                  borderRadius: '24px',
                  background: 'var(--blush-100)',
                  transform: 'translateY(-32px)',
                }}
              >
                <image-slot
                  id="superstar-hero-2"
                  shape="rounded"
                  radius="24"
                  placeholder="Photo: Arathi Vishwanath, ParentCircle SuperStar"
                ></image-slot>
              </div>
              <div
                style={{
                  position: 'relative',
                  overflow: 'hidden',
                  width: '100%',
                  aspectRatio: '3 / 4',
                  borderRadius: '24px',
                  background: 'var(--sage-100)',
                }}
              >
                <image-slot
                  id="superstar-hero-3"
                  shape="rounded"
                  radius="24"
                  placeholder="Photo: R. Kalaivani, ParentCircle SuperStar"
                ></image-slot>
              </div>
              <div
                style={{
                  position: 'relative',
                  overflow: 'hidden',
                  width: '100%',
                  aspectRatio: '3 / 4',
                  borderRadius: '24px',
                  background: 'var(--sky-100)',
                }}
              >
                <image-slot
                  id="superstar-hero-4"
                  shape="rounded"
                  radius="24"
                  placeholder="Photo: Shreya Suraj, ParentCircle SuperStar"
                ></image-slot>
              </div>
              <div
                style={{
                  position: 'relative',
                  overflow: 'hidden',
                  width: '100%',
                  aspectRatio: '3 / 4',
                  borderRadius: '24px',
                  background: 'var(--butter-100)',
                  transform: 'translateY(-32px)',
                }}
              >
                <image-slot
                  id="superstar-hero-5"
                  shape="rounded"
                  radius="24"
                  placeholder="Photo: Smitha Ravi Prashanth, ParentCircle SuperStar"
                ></image-slot>
              </div>
              <div
                style={{
                  position: 'relative',
                  overflow: 'hidden',
                  width: '100%',
                  aspectRatio: '3 / 4',
                  borderRadius: '24px',
                  background: 'var(--lilac-100)',
                }}
              >
                <image-slot
                  id="superstar-hero-6"
                  shape="rounded"
                  radius="24"
                  placeholder="Photo: Debojani Roy, ParentCircle SuperStar"
                ></image-slot>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '80px 24px 0', boxSizing: 'border-box' }}>
        <div style={{ maxWidth: '720px', marginBottom: '32px' }}>
          <div
            style={{
              fontSize: '14px',
              fontWeight: '700',
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              color: 'var(--orange-700)',
              marginBottom: '10px',
            }}
          >
            What is it?
          </div>
          <h2
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(30px,3.4vw,40px)',
              lineHeight: '1.15',
              letterSpacing: '-0.01em',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0',
              textWrap: 'balance',
            }}
          >
            A chance to pass on what helped you
          </h2>
        </div>
        <div
          style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,200px),1fr))', gap: '16px' }}
        >
          <div
            style={{
              border: '1px solid var(--border-default)',
              borderRadius: '16px',
              padding: '24px',
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
            }}
          >
            <span
              style={{
                width: '52px',
                height: '52px',
                borderRadius: '14px',
                background: 'var(--orange-50)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="heart-handshake" size={26} color="var(--orange-600)" />
            </span>
            <span style={{ fontSize: '18px', lineHeight: '1.4', fontWeight: '600', color: 'var(--text-strong)' }}>
              Tell people why you trust ParentCircle
            </span>
          </div>
          <div
            style={{
              border: '1px solid var(--border-default)',
              borderRadius: '16px',
              padding: '24px',
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
            }}
          >
            <span
              style={{
                width: '52px',
                height: '52px',
                borderRadius: '14px',
                background: 'var(--orange-50)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="compass" size={26} color="var(--orange-600)" />
            </span>
            <span style={{ fontSize: '18px', lineHeight: '1.4', fontWeight: '600', color: 'var(--text-strong)' }}>
              Help other parents find their way around
            </span>
          </div>
          <div
            style={{
              border: '1px solid var(--border-default)',
              borderRadius: '16px',
              padding: '24px',
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
            }}
          >
            <span
              style={{
                width: '52px',
                height: '52px',
                borderRadius: '14px',
                background: 'var(--orange-50)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="book-open" size={26} color="var(--orange-600)" />
            </span>
            <span style={{ fontSize: '18px', lineHeight: '1.4', fontWeight: '600', color: 'var(--text-strong)' }}>
              Inspire them with your own stories
            </span>
          </div>
          <div
            style={{
              border: '1px solid var(--border-default)',
              borderRadius: '16px',
              padding: '24px',
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
            }}
          >
            <span
              style={{
                width: '52px',
                height: '52px',
                borderRadius: '14px',
                background: 'var(--orange-50)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="sun" size={26} color="var(--orange-600)" />
            </span>
            <span style={{ fontSize: '18px', lineHeight: '1.4', fontWeight: '600', color: 'var(--text-strong)' }}>
              Spread positivity
            </span>
          </div>
          <div
            style={{
              border: '1px solid var(--border-default)',
              borderRadius: '16px',
              padding: '24px',
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
            }}
          >
            <span
              style={{
                width: '52px',
                height: '52px',
                borderRadius: '14px',
                background: 'var(--orange-50)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="sprout" size={26} color="var(--orange-600)" />
            </span>
            <span style={{ fontSize: '18px', lineHeight: '1.4', fontWeight: '600', color: 'var(--text-strong)' }}>
              Help the community grow stronger
            </span>
          </div>
        </div>
      </section>
      <section id="stories" style={{ marginTop: '80px', background: 'var(--neutral-50)', scrollMarginTop: '72px' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '72px 24px', boxSizing: 'border-box' }}>
          <div
            style={{
              fontSize: '14px',
              fontWeight: '700',
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              color: 'var(--text-muted)',
              marginBottom: '10px',
            }}
          >
            Meet our SuperStars
          </div>
          <h2
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(30px,3.4vw,40px)',
              lineHeight: '1.15',
              letterSpacing: '-0.01em',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0 0 32px',
              textWrap: 'balance',
            }}
          >
            In their own words
          </h2>
          <div
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '32px 48px',
              alignItems: 'center',
              background: 'var(--white)',
              borderRadius: '24px',
              padding: 'clamp(20px,3vw,32px)',
              boxShadow: 'var(--shadow-sm)',
              marginBottom: '32px',
            }}
          >
            <div
              style={{
                flex: '1 1 380px',
                minWidth: '0',
                aspectRatio: '16 / 10',
                borderRadius: '16px',
                overflow: 'hidden',
                background: 'var(--neutral-900)',
              }}
            >
              <video
                controls={true}
                preload="none"
                poster="https://parentcircle.blob.core.windows.net/prd/image/superstar_image/Preeti%20Agrawal.jpg"
                src="https://parentcircle.blob.core.windows.net/prd/image/superstar_image/Preethi.mp4"
                style={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'contain',
                  display: 'block',
                  background: 'var(--neutral-900)',
                }}
              ></video>
            </div>
            <div style={{ flex: '1 1 320px', minWidth: '0' }}>
              <Badge tone="brand">Video story</Badge>
              <h3
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(26px,2.6vw,32px)',
                  lineHeight: '1.2',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '14px 0 10px',
                  textWrap: 'balance',
                }}
              >
                The circle of encouragement and joy
              </h3>
              <p
                style={{
                  fontFamily: 'var(--font-serif)',
                  fontSize: '20px',
                  lineHeight: '1.6',
                  color: 'var(--text-body)',
                  margin: '0 0 20px',
                }}
              >
                Preeti shares, in her own voice, what being part of ParentCircle has meant for her and her family.
              </p>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <span
                  style={{
                    width: '56px',
                    height: '56px',
                    flex: 'none',
                    position: 'relative',
                    borderRadius: '50%',
                    overflow: 'hidden',
                    background: 'var(--orange-100)',
                  }}
                >
                  <image-slot id="superstar-avatar-preeti" shape="circle" placeholder="Add photo"></image-slot>
                </span>
                <div>
                  <div style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>Preeti Agrawal</div>
                  <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>@22younique</div>
                </div>
              </div>
            </div>
          </div>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,300px),1fr))',
              gap: '20px',
            }}
          >
            {(v.stories ?? []).map((s, $i0) => (
              <Fragment key={$i0}>
                <article
                  style={{
                    background: 'var(--white)',
                    borderRadius: '16px',
                    padding: '24px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '14px',
                    boxShadow: 'var(--shadow-xs)',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                    <span
                      style={{
                        width: '64px',
                        height: '64px',
                        flex: 'none',
                        position: 'relative',
                        borderRadius: '50%',
                        overflow: 'hidden',
                        background: 'var(--orange-100)',
                      }}
                    >
                      <image-slot
                        id={`superstar-avatar-${s?.slot ?? ''}`}
                        shape="circle"
                        placeholder="Add photo"
                      ></image-slot>
                    </span>
                    <div style={{ minWidth: '0' }}>
                      <div style={{ fontSize: '17px', fontWeight: '700', color: 'var(--text-strong)' }}>{s?.name}</div>
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px',
                          fontSize: '15px',
                          color: 'var(--orange-700)',
                          fontWeight: '600',
                        }}
                      >
                        <Icon name="star" size={16} />
                        {s?.handle}
                      </div>
                    </div>
                  </div>
                  <h3
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '21px',
                      lineHeight: '1.3',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      margin: '0',
                      textWrap: 'pretty',
                    }}
                  >
                    {s?.headline}
                  </h3>
                  <p
                    style={{
                      fontFamily: 'var(--font-serif)',
                      fontSize: '18px',
                      lineHeight: '1.6',
                      color: 'var(--text-body)',
                      margin: '0',
                      textWrap: 'pretty',
                    }}
                  >
                    {s?.summary}
                  </p>
                </article>
              </Fragment>
            ))}
          </div>
          {v.canShowAll ? (
            <div style={{ display: 'flex', justifyContent: 'center', paddingTop: '32px' }}>
              <Button variant="secondary" icon="chevron-down" onClick={v.showAll}>
                {v.showAllLabel}
              </Button>
            </div>
          ) : null}
        </div>
      </section>
      <section
        style={{
          maxWidth: '1200px',
          margin: '0 auto',
          padding: '80px 24px 0',
          boxSizing: 'border-box',
          display: 'flex',
          flexWrap: 'wrap',
          gap: '40px 64px',
          alignItems: 'flex-start',
        }}
      >
        <div style={{ flex: '1 1 320px', minWidth: '0' }}>
          <div
            style={{
              fontSize: '14px',
              fontWeight: '700',
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              color: 'var(--orange-700)',
              marginBottom: '10px',
            }}
          >
            What you get
          </div>
          <h2
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(30px,3.4vw,40px)',
              lineHeight: '1.15',
              letterSpacing: '-0.01em',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0 0 16px',
              textWrap: 'balance',
            }}
          >
            A two-way exchange
          </h2>
          <p
            style={{
              fontFamily: 'var(--font-serif)',
              fontSize: '21px',
              lineHeight: '1.6',
              color: 'var(--text-body)',
              margin: '0',
              textWrap: 'pretty',
            }}
          >
            We showcase your profile on ParentCircle. You give back to the community that helped you.
          </p>
        </div>
        <div
          style={{
            flex: '2 1 520px',
            minWidth: '0',
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,240px),1fr))',
            gap: '4px 32px',
          }}
        >
          <div
            style={{
              display: 'flex',
              gap: '14px',
              alignItems: 'center',
              padding: '14px 0',
              borderBottom: '1px solid var(--border-subtle)',
            }}
          >
            <span
              style={{
                width: '44px',
                height: '44px',
                flex: 'none',
                borderRadius: '12px',
                background: 'var(--orange-50)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="megaphone" size={22} color="var(--orange-600)" />
            </span>
            <span style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--text-strong)' }}>
              Wider reach and visibility
            </span>
          </div>
          <div
            style={{
              display: 'flex',
              gap: '14px',
              alignItems: 'center',
              padding: '14px 0',
              borderBottom: '1px solid var(--border-subtle)',
            }}
          >
            <span
              style={{
                width: '44px',
                height: '44px',
                flex: 'none',
                borderRadius: '12px',
                background: 'var(--orange-50)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="sparkles" size={22} color="var(--orange-600)" />
            </span>
            <span style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--text-strong)' }}>
              Make an impact with your story
            </span>
          </div>
          <div
            style={{
              display: 'flex',
              gap: '14px',
              alignItems: 'center',
              padding: '14px 0',
              borderBottom: '1px solid var(--border-subtle)',
            }}
          >
            <span
              style={{
                width: '44px',
                height: '44px',
                flex: 'none',
                borderRadius: '12px',
                background: 'var(--orange-50)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="star" size={22} color="var(--orange-600)" />
            </span>
            <span style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--text-strong)' }}>
              A featured profile on the website
            </span>
          </div>
          <div
            style={{
              display: 'flex',
              gap: '14px',
              alignItems: 'center',
              padding: '14px 0',
              borderBottom: '1px solid var(--border-subtle)',
            }}
          >
            <span
              style={{
                width: '44px',
                height: '44px',
                flex: 'none',
                borderRadius: '12px',
                background: 'var(--orange-50)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="file-text" size={22} color="var(--orange-600)" />
            </span>
            <span style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--text-strong)' }}>
              Your story could become a case study
            </span>
          </div>
          <div
            style={{
              display: 'flex',
              gap: '14px',
              alignItems: 'center',
              padding: '14px 0',
              borderBottom: '1px solid var(--border-subtle)',
            }}
          >
            <span
              style={{
                width: '44px',
                height: '44px',
                flex: 'none',
                borderRadius: '12px',
                background: 'var(--orange-50)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="quote" size={22} color="var(--orange-600)" />
            </span>
            <span style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--text-strong)' }}>
              Share quotes that inspire others
            </span>
          </div>
          <div
            style={{
              display: 'flex',
              gap: '14px',
              alignItems: 'center',
              padding: '14px 0',
              borderBottom: '1px solid var(--border-subtle)',
            }}
          >
            <span
              style={{
                width: '44px',
                height: '44px',
                flex: 'none',
                borderRadius: '12px',
                background: 'var(--orange-50)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="users" size={22} color="var(--orange-600)" />
            </span>
            <span style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--text-strong)' }}>
              Network with like-minded parents
            </span>
          </div>
          <div
            style={{
              display: 'flex',
              gap: '14px',
              alignItems: 'center',
              padding: '14px 0',
              borderBottom: '1px solid var(--border-subtle)',
            }}
          >
            <span
              style={{
                width: '44px',
                height: '44px',
                flex: 'none',
                borderRadius: '12px',
                background: 'var(--orange-50)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="calendar" size={22} color="var(--orange-600)" />
            </span>
            <span style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--text-strong)' }}>
              Invites to webinars and parent meetups
            </span>
          </div>
          <div
            style={{
              display: 'flex',
              gap: '14px',
              alignItems: 'center',
              padding: '14px 0',
              borderBottom: '1px solid var(--border-subtle)',
            }}
          >
            <span
              style={{
                width: '44px',
                height: '44px',
                flex: 'none',
                borderRadius: '12px',
                background: 'var(--orange-50)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="ticket" size={22} color="var(--orange-600)" />
            </span>
            <span style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--text-strong)' }}>
              Exclusive ParentCircle events
            </span>
          </div>
        </div>
      </section>
      <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '80px 24px 0', boxSizing: 'border-box' }}>
        <div
          style={{
            fontSize: '14px',
            fontWeight: '700',
            letterSpacing: '0.08em',
            textTransform: 'uppercase',
            color: 'var(--orange-700)',
            marginBottom: '10px',
          }}
        >
          What can I share?
        </div>
        <h2
          style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(30px,3.4vw,40px)',
            lineHeight: '1.15',
            letterSpacing: '-0.01em',
            fontWeight: '700',
            color: 'var(--text-strong)',
            margin: '0 0 28px',
            textWrap: 'balance',
          }}
        >
          Anything that helped you — in a way that suits you
        </h2>
        <div
          style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,260px),1fr))', gap: '16px' }}
        >
          <div style={{ background: 'var(--sage-50)', borderRadius: '16px', padding: '24px' }}>
            <Icon name="thumbs-up" size={28} color="var(--sage-700)" />
            <div
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '22px',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '12px 0 6px',
              }}
            >
              Recommendations
            </div>
            <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)' }}>
              Articles, videos or tips you found useful.
            </div>
          </div>
          <div style={{ background: 'var(--blush-50)', borderRadius: '16px', padding: '24px' }}>
            <Icon name="message-circle" size={28} color="var(--blush-700)" />
            <div
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '22px',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '12px 0 6px',
              }}
            >
              Personal stories
            </div>
            <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)' }}>
              How ParentCircle has made a difference to you.
            </div>
          </div>
          <div style={{ background: 'var(--butter-50)', borderRadius: '16px', padding: '24px' }}>
            <Icon name="star" size={28} color="var(--butter-700)" />
            <div
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '22px',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '12px 0 6px',
              }}
            >
              Your experiences
            </div>
            <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)' }}>
              A review of your time with ParentCircle.
            </div>
          </div>
        </div>
        <div
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            alignItems: 'center',
            gap: '12px 24px',
            marginTop: '20px',
            padding: '20px 24px',
            border: '1px solid var(--border-default)',
            borderRadius: '16px',
          }}
        >
          <span style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>Send it as:</span>
          <span
            style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '17px', color: 'var(--text-body)' }}
          >
            <Icon name="video" size={22} color="var(--orange-600)" />A video recording (MP4 preferred)
          </span>
          <span
            style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '17px', color: 'var(--text-body)' }}
          >
            <Icon name="pen-line" size={22} color="var(--orange-600)" />A written testimonial
          </span>
        </div>
      </section>
      <section style={{ maxWidth: '880px', margin: '0 auto', padding: '80px 24px 0', boxSizing: 'border-box' }}>
        <h2
          style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(30px,3.4vw,40px)',
            lineHeight: '1.15',
            letterSpacing: '-0.01em',
            fontWeight: '700',
            color: 'var(--text-strong)',
            margin: '0 0 20px',
          }}
        >
          Questions parents ask
        </h2>
        <div style={{ borderTop: '1px solid var(--border-default)' }}>
          {(v.faqs ?? []).map((q, $i0) => (
            <Fragment key={$i0}>
              <div style={{ borderBottom: '1px solid var(--border-default)' }}>
                <button
                  type="button"
                  aria-expanded={q?.expanded}
                  onClick={q?.onToggle}
                  style={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: '16px',
                    minHeight: '64px',
                    padding: '16px 0',
                    background: 'none',
                    border: '0',
                    cursor: 'pointer',
                    textAlign: 'left',
                    fontFamily: 'var(--font-ui)',
                    fontSize: '19px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                  }}
                >
                  <span>{q?.q}</span>
                  <span
                    style={{
                      flex: 'none',
                      width: '40px',
                      height: '40px',
                      borderRadius: '50%',
                      background: 'var(--neutral-100)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      transform: q?.rot,
                      transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
                    }}
                  >
                    <Icon name="chevron-down" size={20} />
                  </span>
                </button>
                {q?.open ? (
                  <p
                    style={{
                      fontFamily: 'var(--font-serif)',
                      fontSize: '19px',
                      lineHeight: '1.6',
                      color: 'var(--text-body)',
                      margin: '0',
                      padding: '0 56px 20px 0',
                    }}
                  >
                    {q?.a}
                  </p>
                ) : null}
              </div>
            </Fragment>
          ))}
        </div>
      </section>
      <section style={{ marginTop: '96px', background: 'var(--orange-50)' }}>
        <div
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '64px 24px',
            boxSizing: 'border-box',
            display: 'flex',
            flexWrap: 'wrap',
            gap: '24px 40px',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <div style={{ flex: '1 1 420px', minWidth: '0' }}>
            <h2
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(30px,3.4vw,40px)',
                lineHeight: '1.15',
                letterSpacing: '-0.01em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 10px',
              }}
            >
              Ready to become a SuperStar?
            </h2>
            <p style={{ fontSize: '19px', lineHeight: '1.5', color: 'var(--text-body)', margin: '0' }}>
              It takes about 5 minutes. We’ll be in touch to guide you through the rest.
            </p>
          </div>
          {v.notEnrolled ? (
            <Button variant="primary" size="lg" icon="star" onClick={v.openEnrol}>
              Become a SuperStar
            </Button>
          ) : null}
          {v.enrolled ? (
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '10px',
                padding: '14px 18px',
                borderRadius: '10px',
                background: 'var(--white)',
                color: 'var(--sage-700)',
                fontSize: '18px',
                fontWeight: '600',
                boxShadow: 'var(--shadow-sm)',
              }}
            >
              <Icon name="circle-check" size={24} />
              Thank you — we’ll be in touch soon.
            </div>
          ) : null}
        </div>
      </section>
      <SiteFooter />
      {v.enrolOpen ? (
        <Dialog title={v.dialogTitle} width={600} onClose={v.closeEnrol}>
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '16px',
              maxHeight: 'calc(100vh - 220px)',
              overflow: 'auto',
              padding: '4px',
              margin: '0 -4px',
            }}
          >
            {v.inForm ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <span style={{ fontSize: '15px', fontWeight: '600', color: 'var(--text-muted)' }}>{v.stepLabel}</span>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '6px' }}>
                  {(v.stepBars ?? []).map((b, $i0) => (
                    <Fragment key={$i0}>
                      <span style={{ height: '6px', borderRadius: '3px', background: b?.bg }}></span>
                    </Fragment>
                  ))}
                </div>
              </div>
            ) : null}
            {v.step1 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                <Input label="Full name" value={v.f?.name} onChange={v.on?.name} error={v.err?.name} />
                <Input
                  label="Email address"
                  type="email"
                  value={v.f?.email}
                  onChange={v.on?.email}
                  error={v.err?.email}
                />
                <Input label="Phone number (optional)" type="tel" value={v.f?.phone} onChange={v.on?.phone} />
                <Input
                  label="A little about you"
                  multiline={true}
                  rows={2}
                  placeholder="For example: Mother of two, teacher, Chennai"
                  value={v.f?.profile}
                  onChange={v.on?.profile}
                  error={v.err?.profile}
                />
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <span style={{ fontSize: '16px', fontWeight: '600', color: 'var(--text-strong)' }}>
                    May we feature your profile on ParentCircle?
                  </span>
                  <Radio
                    name="feature"
                    direction="row"
                    options={v.yesNo}
                    value={v.f?.feature}
                    onChange={v.on?.feature}
                  />
                </div>
              </div>
            ) : null}
            {v.step2 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                <span style={{ fontSize: '16px', fontWeight: '600', color: 'var(--text-strong)' }}>
                  How would you like to share your story?
                </span>
                <Radio name="format" direction="row" options={v.formats} value={v.f?.format} onChange={v.on?.format} />
                {v.isWrite ? (
                  <Input
                    label="Your testimonial"
                    multiline={true}
                    rows={5}
                    placeholder="What has ParentCircle meant for you and your family?"
                    value={v.f?.story}
                    onChange={v.on?.story}
                    error={v.err?.story}
                  />
                ) : null}
                {v.isVideo ? (
                  <div
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '10px',
                      alignItems: 'flex-start',
                      padding: '20px',
                      border: '1.5px dashed var(--border-strong)',
                      borderRadius: '10px',
                    }}
                  >
                    <input
                      type="file"
                      accept="video/mp4,video/*"
                      ref={v.fileRef}
                      onChange={v.onFile}
                      style={{ display: 'none' }}
                    />
                    <Button variant="secondary" icon="upload" onClick={v.pickFile}>
                      {v.fileButton}
                    </Button>
                    <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{v.fileHint}</span>
                    {v.err?.story ? (
                      <span style={{ fontSize: '15px', color: 'var(--danger)' }}>{v.err?.story}</span>
                    ) : null}
                  </div>
                ) : null}
              </div>
            ) : null}
            {v.step3 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                <span style={{ fontSize: '16px', fontWeight: '600', color: 'var(--text-strong)' }}>
                  {'Which activities interest you most? '}
                  <span style={{ fontWeight: '400', color: 'var(--text-muted)' }}>Pick at least 3.</span>
                </span>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  {(v.activityChips ?? []).map((c, $i0) => (
                    <Fragment key={$i0}>
                      <Tag selected={c?.selected} icon={c?.icon} onClick={c?.onClick}>
                        {c?.label}
                      </Tag>
                    </Fragment>
                  ))}
                </div>
                {v.err?.activities ? (
                  <span style={{ fontSize: '15px', color: 'var(--danger)' }}>{v.err?.activities}</span>
                ) : null}
                <span style={{ fontSize: '16px', fontWeight: '600', color: 'var(--text-strong)', marginTop: '8px' }}>
                  How often do you visit ParentCircle?
                </span>
                <Radio name="freq" direction="row" options={v.freqs} value={v.f?.freq} onChange={v.on?.freq} />
              </div>
            ) : null}
            {v.step4 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                <span style={{ fontSize: '16px', fontWeight: '600', color: 'var(--text-strong)' }}>
                  Your favourite ParentCircle features
                </span>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  {(v.featureChips ?? []).map((c, $i0) => (
                    <Fragment key={$i0}>
                      <Tag selected={c?.selected} icon={c?.icon} onClick={c?.onClick}>
                        {c?.label}
                      </Tag>
                    </Fragment>
                  ))}
                </div>
                {v.err?.features ? (
                  <span style={{ fontSize: '15px', color: 'var(--danger)' }}>{v.err?.features}</span>
                ) : null}
                <Input
                  label="Social media handle (optional)"
                  icon="at-sign"
                  value={v.f?.social}
                  onChange={v.on?.social}
                />
                <Input
                  label="Comments or suggestions (optional)"
                  multiline={true}
                  rows={2}
                  value={v.f?.comments}
                  onChange={v.on?.comments}
                />
              </div>
            ) : null}
            {v.done ? (
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  textAlign: 'center',
                  gap: '14px',
                  padding: '12px 0 4px',
                }}
              >
                <span
                  style={{
                    width: '72px',
                    height: '72px',
                    borderRadius: '50%',
                    background: 'var(--orange-50)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="star" size={36} color="var(--pc-orange)" />
                </span>
                <p
                  style={{
                    fontFamily: 'var(--font-serif)',
                    fontSize: '20px',
                    lineHeight: '1.55',
                    color: 'var(--text-body)',
                    margin: '0',
                    maxWidth: '420px',
                  }}
                >
                  {v.thanksText}
                </p>
                <Button variant="primary" onClick={v.closeEnrol}>
                  Done
                </Button>
              </div>
            ) : null}
            {v.inForm ? (
              <div
                style={{
                  display: 'flex',
                  gap: '12px',
                  justifyContent: 'space-between',
                  flexWrap: 'wrap',
                  marginTop: '4px',
                }}
              >
                <Button variant="ghost" icon={v.backIcon} onClick={v.back}>
                  {v.backLabel}
                </Button>
                <Button variant="primary" iconRight={v.nextIcon} onClick={v.next}>
                  {v.nextLabel}
                </Button>
              </div>
            ) : null}
          </div>
        </Dialog>
      ) : null}
    </div>
  );
}
