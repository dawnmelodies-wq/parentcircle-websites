import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = {
    all: false,
    faq: 0,
    enrolOpen: false,
    step: 1,
    enrolled: false,
    err: {},
    f: {
      name: '',
      email: '',
      phone: '',
      profile: '',
      feature: 'Yes',
      format: 'write',
      story: '',
      file: null,
      activities: [],
      freq: 'Weekly',
      features: [],
      social: '',
      comments: '',
    },
  };
  fileRef = React.createRef();
  img = (n) => 'https://parentcircle.blob.core.windows.net/prd/image/superstar_image/' + encodeURIComponent(n);
  storyList = [
    {
      name: 'Roopa M.',
      handle: 'SuperStar',
      photo: 'Roopa.jpg',
      headline: 'ParentCircle turned my parenting challenges into adventures',
      summary:
        'Roopa dips into the articles and discussions for fresh ideas, jumps in to answer other parents’ questions, and values having experts close at hand.',
    },
    {
      name: 'Arathi Vishwanath',
      handle: 'SuperStar',
      photo: 'Arathi.jpg',
      headline: 'The magical influence of ParentCircle',
      summary:
        'A children’s magic show drew Arathi and her daughter in. Later, in the Community, she became friends with the mother of a young rangoli artist she had admired years before.',
    },
    {
      name: 'R. Kalaivani',
      handle: 'SuperStar',
      photo: 'Kalaivani.jpg',
      headline: 'The beautiful chaos of motherhood, with ParentCircle by my side',
      summary:
        'For over a decade, the magazine and website have kept Kalaivani company — and taught her there is no single “perfect” way to parent.',
    },
    {
      name: 'Shreya Suraj',
      handle: '@shreyasurajabcd',
      photo: 'Shreya Suraj.jpg',
      headline: 'Engaging Thursdays and lasting bonds',
      summary:
        'It began with a prize in a 100-word blogging contest. Today, as part of the Think Tank group of parents, ParentCircle feels like a big family to her.',
    },
    {
      name: 'Smitha Ravi Prashanth',
      handle: 'SuperStar',
      photo: 'Smitha Ravi Prashanth.jpg',
      headline: 'Discovering hidden gems through ParentCircle',
      summary:
        'An article on India’s heritage sites inspired her family’s four-day trip to Badami, Pattadakal and Aihole.',
    },
    {
      name: 'Debojani Roy',
      handle: '@lets_eat_2021',
      photo: 'Debojani Roy.jpg',
      headline: 'From a one-liner to blogger and influencer',
      summary:
        'A winning one-liner led Debojani to the Think Tank — and, in time, to food blogging, with her recipes featured in the magazine.',
    },
    {
      name: 'Anita Kulkarni',
      handle: 'SuperStar',
      photo: 'Anitha Kulkarni.jpg',
      headline: 'Togetherness, growth and kindness',
      summary: 'Anita loves the Think Tank chats and family competitions — and the team’s spirit of kindness.',
    },
    {
      name: 'Ankita Pandey',
      handle: 'SuperStar',
      photo: 'ANKITA-PANDEY.jpg',
      headline: 'Learning to welcome imperfect moments',
      summary:
        'A post on real, imperfect parenting helped Ankita see her mistakes as chances to teach her children resilience.',
    },
    {
      name: 'Mumtaz Vinchu',
      handle: 'SuperStar',
      photo: 'MV.jpg',
      headline: 'Why ParentCircle feels meaningful to me',
      summary:
        'As a mother of an 8- and a 10-year-old, Mumtaz values how stories are organised by age — and feels calmer and more confident as a parent.',
    },
  ];
  faqList = [
    {
      q: 'How will my story be used?',
      a: 'We publish SuperStar stories on the ParentCircle website and our social media pages.',
    },
    {
      q: 'How do I send my story?',
      a: 'Fill in the short form. After our first conversation with you, we’ll guide you through the rest.',
    },
    { q: 'Will my personal details stay private?', a: 'Yes. We only share what you agree to share.' },
    {
      q: 'How do I stay involved afterwards?',
      a: 'We’ll keep you posted about new opportunities, events and other ways to take part.',
    },
  ];
  activities = [
    'Sharing feedback on website content',
    'Networking with other SuperStars',
    'Community events',
    'Providing original quotes',
    'ParentCircle events',
    'Leading workshops or webinars',
    'Sharing my expertise',
    'Something else',
  ];
  features = [
    'Articles',
    'Videos',
    'Community',
    'Ask the Expert',
    'Recipes',
    'Parent meetups',
    'Parents of India',
    'Webinars',
    'Social media',
  ];

  setF = (k, v) => this.setState((s) => ({ f: { ...s.f, [k]: v }, err: { ...s.err, [k]: undefined } }));
  toggleIn = (k, v) =>
    this.setState((s) => {
      const a = s.f[k];
      return {
        f: { ...s.f, [k]: a.includes(v) ? a.filter((x) => x !== v) : [...a, v] },
        err: { ...s.err, [k]: undefined },
      };
    });
  validate = (step) => {
    const f = this.state.f,
      e = {};
    if (step === 1) {
      if (!f.name.trim()) e.name = 'Please add your name.';
      if (!/\S+@\S+\.\S+/.test(f.email)) e.email = 'Please add an email address we can reach you on.';
      if (!f.profile.trim()) e.profile = 'Please tell us a little about yourself.';
    }
    if (step === 2) {
      if (f.format === 'write' && f.story.trim().length < 20)
        e.story = 'Please write a few sentences — a short story is perfect.';
      if (f.format === 'video' && !f.file) e.story = 'Please choose a video file to upload.';
    }
    if (step === 3 && f.activities.length < 3)
      e.activities = 'Please pick at least 3 so we can match you with the right activities.';
    if (step === 4 && !f.features.length) e.features = 'Please pick at least one feature you enjoy.';
    this.setState({ err: e });
    return !Object.keys(e).length;
  };
  next = () => {
    const s = this.state.step;
    if (!this.validate(s)) return;
    if (s < 4) this.setState({ step: s + 1 });
    else this.setState({ step: 5, enrolled: true });
  };

  renderVals() {
    const S = this.state,
      f = S.f,
      step = S.step;
    const list = this.storyList.map((s, i) => ({ ...s, slot: 'a' + i, photo: this.img(s.photo) }));
    const first = S.f.name.trim().split(' ')[0] || 'friend';
    return {
      openEnrol: () =>
        this.setState((s) => ({ enrolOpen: true, step: s.enrolled ? 5 : s.step === 5 ? 1 : s.step, err: {} })),
      closeEnrol: () => this.setState({ enrolOpen: false }),
      goStories: () => {
        const el = document.getElementById('stories');
        if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 72, behavior: 'smooth' });
      },
      stories: S.all ? list : list.slice(0, 6),
      canShowAll: !S.all && list.length > 6,
      showAll: () => this.setState({ all: true }),
      showAllLabel: 'Show all ' + list.length + ' stories',
      faqs: this.faqList.map((q, i) => ({
        ...q,
        open: S.faq === i,
        expanded: S.faq === i ? 'true' : 'false',
        rot: S.faq === i ? 'rotate(180deg)' : 'none',
        onToggle: () => this.setState({ faq: S.faq === i ? -1 : i }),
      })),
      enrolOpen: S.enrolOpen,
      enrolled: S.enrolled,
      notEnrolled: !S.enrolled,
      dialogTitle: step === 5 ? 'Thank you!' : 'Become a SuperStar',
      inForm: step < 5,
      done: step === 5,
      step1: step === 1,
      step2: step === 2,
      step3: step === 3,
      step4: step === 4,
      stepLabel: 'Step ' + step + ' of 4 · ' + ['About you', 'Your story', 'Your interests', 'Almost done'][step - 1],
      stepBars: [1, 2, 3, 4].map((n) => ({ bg: n <= step ? 'var(--action-primary)' : 'var(--neutral-200)' })),
      f,
      err: S.err,
      on: Object.fromEntries(
        ['name', 'email', 'phone', 'profile', 'story', 'social', 'comments']
          .map((k) => [k, (e) => this.setF(k, e.target.value)])
          .concat([
            ['feature', (v) => this.setF('feature', v)],
            ['format', (v) => this.setF('format', v)],
            ['freq', (v) => this.setF('freq', v)],
          ]),
      ),
      yesNo: ['Yes', 'No'],
      freqs: ['Daily', 'Weekly', 'Monthly'],
      formats: [
        { value: 'write', label: 'Write it' },
        { value: 'video', label: 'Upload a video' },
      ],
      isWrite: f.format === 'write',
      isVideo: f.format === 'video',
      fileRef: this.fileRef,
      pickFile: () => this.fileRef.current && this.fileRef.current.click(),
      onFile: (e) => {
        const file = e.target.files && e.target.files[0];
        if (file) this.setF('file', file.name);
        this.setState((s) => ({ err: { ...s.err, story: undefined } }));
      },
      fileButton: f.file ? 'Choose another' : 'Choose a video',
      fileHint: f.file ? 'Selected: ' + f.file : 'MP4 works best. A minute or two is plenty.',
      activityChips: this.activities.map((a) => ({
        label: a,
        selected: f.activities.includes(a),
        icon: f.activities.includes(a) ? 'check' : undefined,
        onClick: () => this.toggleIn('activities', a),
      })),
      featureChips: this.features.map((a) => ({
        label: a,
        selected: f.features.includes(a),
        icon: f.features.includes(a) ? 'check' : undefined,
        onClick: () => this.toggleIn('features', a),
      })),
      back: () => (step === 1 ? this.setState({ enrolOpen: false }) : this.setState({ step: step - 1, err: {} })),
      backLabel: step === 1 ? 'Cancel' : 'Back',
      backIcon: step === 1 ? undefined : 'arrow-left',
      next: this.next,
      nextLabel: step === 4 ? 'Submit' : 'Continue',
      nextIcon: step === 4 ? 'check' : 'arrow-right',
      thanksText:
        'Thank you, ' + first + '. We’ve received your details and will get back to you soon about the next steps.',
    };
  }
}

export default PageLogic;
