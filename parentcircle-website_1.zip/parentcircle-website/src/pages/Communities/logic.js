import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = {
    filter: 'all',
    joined: ['3-6'],
    tab: 'latest',
    query: '',
    more: false,
    dialogOpen: false,
    dCircle: '3-6',
    dTitle: '',
    dBody: '',
    dAnon: false,
    dError: '',
    posted: null,
    mine: [],
  };

  hues = { blush: 'emotions', butter: 'play', sky: 'learning', lilac: 'teens', sage: 'health', orange: undefined };
  circleList = [
    {
      id: '0-2',
      name: '0–2 years',
      tag: 'All about newborns and delightful toddlers',
      members: '1.7K',
      disc: 56,
      kind: 'By age',
      hue: 'blush',
      photo: 'Newborn asleep on a parent’s chest',
      faces: ['Anita K', 'Rahul S', 'Meena P', 'Kiran D'],
    },
    {
      id: '3-6',
      name: '3–6 years',
      tag: 'Curiosity, tantrums and everything in between',
      members: '2.5K',
      disc: 79,
      kind: 'By age',
      hue: 'butter',
      photo: 'Preschooler painting at the table',
      faces: ['Divya R', 'Sanjay M', 'Lata V', 'Farah N'],
    },
    {
      id: '7-10',
      name: '7–10 years',
      tag: 'The active, enthusiastic middle years',
      members: '1.9K',
      disc: 79,
      kind: 'By age',
      hue: 'sky',
      photo: 'Children cycling down a colony lane',
      faces: ['Gopal R', 'Uma S', 'Neha J', 'Arjun T'],
    },
    {
      id: '11-18',
      name: '11–18 years',
      tag: 'From self-conscious to self-confident',
      members: '1.8K',
      disc: 96,
      kind: 'By age',
      hue: 'lilac',
      photo: 'Teenager laughing with a parent',
      faces: ['Vivian', 'Pooja Y', 'Abhilasha S', 'Steve M'],
    },
    {
      id: 'parents',
      name: 'Just for Parents',
      tag: 'A “me” space to just be',
      members: '4.1K',
      disc: 220,
      kind: 'Interest',
      hue: 'sage',
      photo: 'Parent enjoying a quiet cup of tea',
      faces: ['Vijay', 'Ritu B', 'Hari K', 'Sowmya L'],
    },
    {
      id: 'celebration',
      name: 'Joy of Celebration',
      tag: 'Festivities that bring families together',
      members: '2.2K',
      disc: 139,
      kind: 'Interest',
      hue: 'orange',
      photo: 'Family lighting diyas together',
      faces: ['Dhivya P', 'Sarath', 'Priyanka B', 'Mumtaz V'],
    },
    {
      id: 'special',
      name: 'Special needs',
      tag: 'Feel supported in raising a child with special needs',
      members: '464',
      disc: 21,
      kind: 'Interest',
      hue: 'blush',
      photo: 'Parent and child reading together',
      faces: ['James T', 'Kavya S', 'Rohan G', 'Isha M'],
    },
    {
      id: 'gfh',
      name: 'Gadget Free Hour',
      tag: 'Raising children in a digital world',
      members: '1.7K',
      disc: 69,
      kind: 'Interest',
      hue: 'lilac',
      photo: 'Family playing a board game',
      faces: ['Mohan K', 'Ganesh D', 'Pragadeesh', 'Mumtaz V'],
    },
  ];
  latest = [
    {
      id: 'l1',
      title: 'Inspiring parenting quotes to keep you going',
      circle: 'parents',
      author: 'Team ParentCircle',
      when: '11 hours ago',
      comments: 114,
    },
    {
      id: 'l2',
      title: 'When “calm down” makes it worse',
      circle: 'parents',
      author: 'Vivian',
      when: '1 day ago',
      comments: 0,
    },
    {
      id: 'l3',
      title: 'Why do some hairbands hurt? How to choose one that doesn’t',
      circle: '0-2',
      author: 'Team Choko',
      when: '2 days ago',
      comments: 0,
    },
    {
      id: 'l4',
      title: 'A music video I made with my son',
      circle: 'special',
      author: 'Arvind',
      when: '2 days ago',
      comments: 2,
    },
    {
      id: 'l5',
      title: 'The phone in the bedroom is quieter than you think',
      circle: 'parents',
      author: 'Vivian',
      when: '3 days ago',
      comments: 0,
    },
    {
      id: 'l6',
      title: 'Your teen isn’t lazy — their brain is just full',
      circle: 'parents',
      author: 'Vivian',
      when: '5 days ago',
      comments: 0,
    },
    {
      id: 'l7',
      title: 'Healthy Twist: the secret ingredient contest',
      circle: 'parents',
      author: 'Vijay',
      when: '6 Oct',
      comments: 7,
    },
    {
      id: 'l8',
      title: 'Every parent has one trigger. What’s yours?',
      circle: 'parents',
      author: 'Vijay',
      when: '1 Oct',
      comments: 1,
    },
    {
      id: 'l9',
      title: 'Behaviour concerns with my 4-year-old',
      circle: '3-6',
      author: 'Deepika S',
      when: '29 Sep',
      comments: 1,
    },
    {
      id: 'l10',
      title: 'Which of grandma’s nutrition secrets still keeps you healthy?',
      circle: 'parents',
      author: 'Popup Kids',
      when: '28 Sep',
      comments: 4,
    },
  ];
  popular = [
    {
      id: 'p1',
      title: 'Healthy Twist: the secret ingredient contest',
      circle: 'parents',
      author: 'Vijay',
      when: '6 Oct',
      comments: 7,
      views: '4.5K views',
    },
    {
      id: 'p2',
      title: 'Inspiring parenting quotes to keep you going',
      circle: 'parents',
      author: 'Team ParentCircle',
      when: '11 hours ago',
      comments: 114,
      views: '31.7K views',
    },
    {
      id: 'p3',
      title: 'Behaviour concerns with my 4-year-old',
      circle: '3-6',
      author: 'Deepika S',
      when: '29 Sep',
      comments: 1,
      views: '1.4K views',
    },
    {
      id: 'p4',
      title: 'National Nutrition Week 2026: food facts, quizzes and word games',
      circle: 'parents',
      author: 'Vijay',
      when: '10 Sep',
      comments: 14,
      views: '518 views',
    },
    {
      id: 'p5',
      title: 'When parents disagree on screen time: getting on the same page',
      circle: '7-10',
      author: 'Vivian',
      when: '28 Sep',
      comments: 1,
      views: '186 views',
    },
  ];
  clipCard = {
    style: { overflow: 'hidden', height: '100%', boxSizing: 'border-box', display: 'flex', flexDirection: 'column' },
  };
  circleTabs = [
    { value: 'all', label: 'All circles' },
    { value: 'age', label: 'By child’s age' },
    { value: 'interest', label: 'Interests' },
  ];
  listTabs = [
    { value: 'latest', label: 'Latest' },
    { value: 'popular', label: 'Popular' },
  ];

  toggleJoin = (id) =>
    this.setState((s) => ({ joined: s.joined.includes(id) ? s.joined.filter((x) => x !== id) : [...s.joined, id] }));
  submitDialog = () => {
    const S = this.state,
      t = S.dTitle.trim();
    if (!t) {
      this.setState({ dError: 'Please add a question or topic so others know what to reply to.' });
      return;
    }
    const c = this.circleList.find((x) => x.id === S.dCircle);
    this.setState((s) => ({
      dialogOpen: false,
      dTitle: '',
      dBody: '',
      dError: '',
      tab: 'latest',
      query: '',
      mine: [
        {
          id: 'm' + Date.now(),
          title: t,
          circle: s.dCircle,
          author: s.dAnon ? 'Anonymous' : 'You',
          when: 'Just now',
          comments: 0,
        },
        ...s.mine,
      ],
      posted: 'Your discussion is live in ' + c.name + '.',
    }));
  };

  renderVals() {
    const S = this.state;
    const byId = Object.fromEntries(this.circleList.map((c) => [c.id, c]));
    const circles = this.circleList
      .filter((c) => S.filter === 'all' || (S.filter === 'age' ? c.kind === 'By age' : c.kind === 'Interest'))
      .map((c) => {
        const on = S.joined.includes(c.id);
        return {
          ...c,
          bg: 'var(--' + c.hue + '-100)',
          fg: 'var(--' + c.hue + '-700)',
          stats: c.members + ' members · ' + c.disc + ' discussions',
          faces: c.faces.map((name, i) => ({ name, ml: i ? '-8px' : '0' })),
          btn: on ? 'Joined' : 'Join circle',
          icon: on ? 'check' : 'plus',
          variant: on ? 'ghost' : 'secondary',
          onJoin: () => this.toggleJoin(c.id),
        };
      });
    const base = S.tab === 'latest' ? [...S.mine, ...this.latest] : this.popular;
    const q = S.query.trim().toLowerCase();
    const matched = base.filter(
      (t) => !q || t.title.toLowerCase().includes(q) || byId[t.circle].name.toLowerCase().includes(q),
    );
    const limit = S.more || q ? matched.length : 6;
    const threads = matched.slice(0, limit).map((t) => {
      const c = byId[t.circle];
      return {
        ...t,
        circle: c.name,
        topic: this.hues[c.hue],
        ink: 'var(--' + (c.hue || 'orange') + '-700)',
        extra: t.views || c.members + ' members',
        countLabel: t.comments === 0 ? 'Reply first' : String(t.comments),
        countColor: t.comments === 0 ? 'var(--orange-600)' : 'var(--text-muted)',
      };
    });
    return {
      circleTabs: this.circleTabs,
      filter: S.filter,
      setFilter: (v) => this.setState({ filter: v }),
      circles,
      clipCard: this.clipCard,
      listTabs: this.listTabs,
      tab: S.tab,
      setTab: (v) => this.setState({ tab: v, more: false }),
      query: S.query,
      onQuery: (e) => this.setState({ query: e.target.value }),
      threads,
      noResults: matched.length === 0,
      noResultsText: 'No discussions match “' + S.query.trim() + '” yet. Why not start one?',
      canShowMore: !S.more && !q && matched.length > 6,
      showMore: () => this.setState({ more: true }),
      dialogOpen: S.dialogOpen,
      openDialog: () => this.setState({ dialogOpen: true, posted: null }),
      closeDialog: () => this.setState({ dialogOpen: false, dError: '' }),
      circleOptions: this.circleList.map((c) => ({ value: c.id, label: c.name })),
      dCircle: S.dCircle,
      onDCircle: (e) => this.setState({ dCircle: e.target.value }),
      dTitle: S.dTitle,
      onDTitle: (e) => this.setState({ dTitle: e.target.value, dError: '' }),
      dBody: S.dBody,
      onDBody: (e) => this.setState({ dBody: e.target.value }),
      dAnon: S.dAnon,
      onDAnon: (v) => this.setState({ dAnon: v }),
      dError: S.dError || undefined,
      submitDialog: this.submitDialog,
      posted: !!S.posted,
      postedLabel: S.posted || '',
      goGuidelines: () => {
        const el = document.getElementById('guidelines');
        if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 96, behavior: 'smooth' });
      },
    };
  }
}

export default PageLogic;
