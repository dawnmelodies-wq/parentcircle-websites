import { Fragment } from 'react';
import { Avatar, Button, Card, Checkbox, Dialog, Icon, Input, Select, Tabs } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Communities" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Communities"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader active="community" communityHref="/#community" />
      <section style={{ background: 'var(--sage-50)' }}>
        <div
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '48px 24px 64px',
            boxSizing: 'border-box',
            display: 'flex',
            flexWrap: 'wrap',
            gap: '40px 56px',
            alignItems: 'center',
          }}
        >
          <div style={{ flex: '1 1 440px', minWidth: '0' }}>
            <nav
              aria-label="Breadcrumb"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                fontSize: '15px',
                color: 'var(--text-muted)',
                marginBottom: '20px',
              }}
            >
              <a
                className="hv-1"
                href={toUrl('/')}
                style={{ color: 'var(--text-muted)', textDecoration: 'none', fontWeight: '600' }}
              >
                Home
              </a>
              <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
              <span>Communities</span>
            </nav>
            <h1
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(36px,4.4vw,52px)',
                lineHeight: '1.1',
                letterSpacing: '-0.015em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0',
                textWrap: 'balance',
              }}
            >
              Community circles
            </h1>
            <p
              style={{
                fontFamily: 'var(--font-serif)',
                fontSize: '22px',
                lineHeight: '1.55',
                color: 'var(--text-body)',
                margin: '16px 0 28px',
                maxWidth: '560px',
                textWrap: 'pretty',
              }}
            >
              Real stories, honest opinions and warm conversations. A space for you as a parent — and as a person.
            </p>
            <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', marginBottom: '24px' }}>
              <Button variant="primary" size="lg" icon="plus" onClick={v.openDialog}>
                Start a discussion
              </Button>
              <a href={toUrl('/guidelines')} style={{ textDecoration: 'none', display: 'inline-flex' }}>
                <Button variant="secondary" size="lg" icon="shield-check">
                  Community guidelines
                </Button>
              </a>
            </div>
            {v.posted ? (
              <div
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '10px',
                  padding: '12px 16px',
                  borderRadius: '10px',
                  background: 'var(--white)',
                  color: 'var(--sage-700)',
                  fontSize: '17px',
                  fontWeight: '600',
                  boxShadow: 'var(--shadow-sm)',
                }}
              >
                <Icon name="circle-check" size={22} />
                {v.postedLabel}
              </div>
            ) : null}
          </div>
          <div
            style={{
              flex: '1 1 380px',
              minWidth: '0',
              display: 'grid',
              gridTemplateColumns: '1.3fr 1fr',
              gridTemplateRows: '1fr 1fr',
              gap: '12px',
              aspectRatio: '4 / 3',
            }}
          >
            <div
              style={{
                gridRow: 'span 2',
                position: 'relative',
                borderRadius: '24px',
                background: 'var(--sage-100)',
                color: 'var(--sage-700)',
                overflow: 'hidden',
              }}
            >
              <image-slot
                id="comm-hero-1"
                shape="rounded"
                radius="24"
                placeholder="Parents chatting on a park bench"
              ></image-slot>
            </div>
            <div
              style={{
                position: 'relative',
                borderRadius: '16px',
                background: 'var(--butter-100)',
                color: 'var(--butter-700)',
                overflow: 'hidden',
              }}
            >
              <image-slot
                id="comm-hero-2"
                shape="rounded"
                radius="16"
                placeholder="Grandparents with a toddler"
              ></image-slot>
            </div>
            <div
              style={{
                position: 'relative',
                borderRadius: '16px',
                background: 'var(--blush-100)',
                color: 'var(--blush-700)',
                overflow: 'hidden',
              }}
            >
              <image-slot
                id="comm-hero-3"
                shape="rounded"
                radius="16"
                placeholder="Mother on a video call"
              ></image-slot>
            </div>
          </div>
        </div>
      </section>
      <main>
        <section
          id="circles"
          style={{ maxWidth: '1200px', margin: '0 auto', padding: '64px 24px 0', boxSizing: 'border-box' }}
        >
          <div
            style={{
              display: 'flex',
              alignItems: 'flex-end',
              justifyContent: 'space-between',
              gap: '20px',
              flexWrap: 'wrap',
              marginBottom: '28px',
            }}
          >
            <div>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(28px,3vw,34px)',
                  lineHeight: '1.2',
                  letterSpacing: '-0.01em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                }}
              >
                Find your circle
              </h2>
              <p style={{ fontSize: '19px', color: 'var(--text-muted)', margin: '6px 0 0' }}>
                Join as many as you like. You can leave any time.
              </p>
            </div>
            <Tabs variant="pill" tabs={v.circleTabs} value={v.filter} onChange={v.setFilter} />
          </div>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,260px),1fr))',
              gap: '24px',
            }}
          >
            {(v.circles ?? []).map((c, $i0) => (
              <Fragment key={$i0}>
                <div style={{ height: '100%' }}>
                  <Card padding={0} interactive={true} {...v.clipCard}>
                    <div
                      style={{
                        width: '100%',
                        aspectRatio: '16 / 9',
                        position: 'relative',
                        background: c?.bg,
                        color: c?.fg,
                      }}
                    >
                      <image-slot id={`comm-${c?.id ?? ''}`} shape="rect" placeholder={c?.photo}></image-slot>
                    </div>
                    <div style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '10px', flex: '1' }}>
                      <span
                        style={{
                          fontSize: '14px',
                          fontWeight: '700',
                          letterSpacing: '0.08em',
                          textTransform: 'uppercase',
                          color: c?.fg,
                        }}
                      >
                        {c?.kind}
                      </span>
                      <span
                        style={{
                          fontFamily: 'var(--font-display)',
                          fontSize: '23px',
                          lineHeight: '1.25',
                          fontWeight: '700',
                          color: 'var(--text-strong)',
                        }}
                      >
                        {c?.name}
                      </span>
                      <span style={{ fontSize: '17px', lineHeight: '1.45', color: 'var(--text-body)' }}>{c?.tag}</span>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginTop: '4px' }}>
                        <span style={{ display: 'flex' }}>
                          {(c?.faces ?? []).map((f, $i1) => (
                            <Fragment key={$i1}>
                              <span
                                style={{
                                  display: 'inline-flex',
                                  marginLeft: f?.ml,
                                  borderRadius: '50%',
                                  boxShadow: '0 0 0 2px var(--white)',
                                }}
                              >
                                <Avatar name={f?.name} size={30} />
                              </span>
                            </Fragment>
                          ))}
                        </span>
                        <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{c?.stats}</span>
                      </div>
                      <div style={{ marginTop: 'auto', paddingTop: '8px' }}>
                        <Button size="sm" variant={c?.variant} icon={c?.icon} fullWidth={true} onClick={c?.onJoin}>
                          {c?.btn}
                        </Button>
                      </div>
                    </div>
                  </Card>
                </div>
              </Fragment>
            ))}
          </div>
        </section>
        <section
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '80px 24px 0',
            boxSizing: 'border-box',
            display: 'flex',
            flexWrap: 'wrap',
            gap: '40px',
            alignItems: 'flex-start',
          }}
        >
          <div style={{ flex: '999 1 560px', minWidth: '0' }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'flex-end',
                justifyContent: 'space-between',
                gap: '16px',
                flexWrap: 'wrap',
                marginBottom: '16px',
              }}
            >
              <div>
                <h2
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(28px,3vw,34px)',
                    lineHeight: '1.2',
                    letterSpacing: '-0.01em',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0',
                  }}
                >
                  Discussions
                </h2>
                <p style={{ fontSize: '19px', color: 'var(--text-muted)', margin: '6px 0 0' }}>
                  See what other families are talking about.
                </p>
              </div>
              <div style={{ flex: '0 1 300px', minWidth: '220px' }}>
                <Input icon="search" placeholder="Search discussions" value={v.query} onChange={v.onQuery} />
              </div>
            </div>
            <div style={{ paddingBottom: '4px' }}>
              <Tabs variant="pill" tabs={v.listTabs} value={v.tab} onChange={v.setTab} />
            </div>
            {(v.threads ?? []).map((t, $i0) => (
              <Fragment key={$i0}>
                <a
                  className="hv-c"
                  href="#"
                  style={{
                    display: 'flex',
                    gap: '16px',
                    alignItems: 'flex-start',
                    padding: '22px 0',
                    borderBottom: '1px solid var(--border-subtle)',
                    textDecoration: 'none',
                    color: 'inherit',
                  }}
                >
                  <div style={{ flex: '1', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '10px' }}>
                    <div>
                      <span
                        style={{
                          fontSize: '14px',
                          fontWeight: '700',
                          letterSpacing: '0.08em',
                          textTransform: 'uppercase',
                          color: t?.ink,
                        }}
                      >
                        {t?.circle}
                      </span>
                    </div>
                    <span
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '21px',
                        lineHeight: '1.35',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        textWrap: 'pretty',
                      }}
                    >
                      {t?.title}
                    </span>
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        flexWrap: 'wrap',
                        fontSize: '15px',
                        color: 'var(--text-muted)',
                      }}
                    >
                      <Avatar name={t?.author} size={28} />
                      <span style={{ color: 'var(--text-strong)', fontWeight: '600' }}>{t?.author}</span>
                      <span>
                        {'· '}
                        {t?.when}
                      </span>
                      <span>
                        {'· '}
                        {t?.extra}
                      </span>
                    </div>
                  </div>
                  <div
                    style={{
                      flex: 'none',
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      gap: '2px',
                      minWidth: '64px',
                      paddingTop: '44px',
                      color: t?.countColor,
                    }}
                  >
                    <Icon name="message-circle" size={22} />
                    <span style={{ fontSize: '15px', fontWeight: '600', textAlign: 'center', lineHeight: '1.25' }}>
                      {t?.countLabel}
                    </span>
                  </div>
                </a>
              </Fragment>
            ))}
            {v.noResults ? (
              <div
                style={{
                  padding: '32px 0',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'flex-start',
                  gap: '16px',
                }}
              >
                <p
                  style={{
                    fontFamily: 'var(--font-serif)',
                    fontSize: '20px',
                    lineHeight: '1.5',
                    color: 'var(--text-body)',
                    margin: '0',
                  }}
                >
                  {v.noResultsText}
                </p>
                <Button variant="primary" icon="plus" onClick={v.openDialog}>
                  Start a discussion
                </Button>
              </div>
            ) : null}
            {v.canShowMore ? (
              <div style={{ paddingTop: '24px' }}>
                <Button variant="secondary" icon="chevron-down" onClick={v.showMore}>
                  Show more
                </Button>
              </div>
            ) : null}
          </div>
          <aside style={{ flex: '1 1 240px', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '32px' }}>
            <div>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                  marginBottom: '8px',
                }}
              >
                Trending topics
              </div>
              <a
                className="hv-c"
                href="#"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '14px',
                  padding: '12px 0',
                  borderBottom: '1px solid var(--border-subtle)',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <span
                  style={{
                    width: '48px',
                    height: '48px',
                    flex: 'none',
                    borderRadius: '14px',
                    background: 'var(--sage-50)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="apple" size={24} color="var(--sage-700)" />
                </span>
                <span style={{ flex: '1', minWidth: '0' }}>
                  <span style={{ display: 'block', fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                    Health, fitness and nutrition
                  </span>
                  <span style={{ display: 'block', fontSize: '15px', color: 'var(--text-muted)' }}>
                    64 discussions · Just for Parents
                  </span>
                </span>
              </a>{' '}
              <a
                className="hv-c"
                href="#"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '14px',
                  padding: '12px 0',
                  borderBottom: '1px solid var(--border-subtle)',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <span
                  style={{
                    width: '48px',
                    height: '48px',
                    flex: 'none',
                    borderRadius: '14px',
                    background: 'var(--sky-50)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="graduation-cap" size={24} color="var(--sky-700)" />
                </span>
                <span style={{ flex: '1', minWidth: '0' }}>
                  <span style={{ display: 'block', fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                    Early years schooling
                  </span>
                  <span style={{ display: 'block', fontSize: '15px', color: 'var(--text-muted)' }}>
                    9 discussions · 3–6 years
                  </span>
                </span>
              </a>{' '}
              <a
                className="hv-c"
                href="#"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '14px',
                  padding: '12px 0',
                  borderBottom: '1px solid var(--border-subtle)',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <span
                  style={{
                    width: '48px',
                    height: '48px',
                    flex: 'none',
                    borderRadius: '14px',
                    background: 'var(--lilac-50)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="brain" size={24} color="var(--lilac-700)" />
                </span>
                <span style={{ flex: '1', minWidth: '0' }}>
                  <span style={{ display: 'block', fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                    Mental health
                  </span>
                  <span style={{ display: 'block', fontSize: '15px', color: 'var(--text-muted)' }}>
                    5 discussions · 11–18 years
                  </span>
                </span>
              </a>{' '}
              <a
                className="hv-c"
                href="#"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '14px',
                  padding: '12px 0',
                  borderBottom: '1px solid var(--border-subtle)',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <span
                  style={{
                    width: '48px',
                    height: '48px',
                    flex: 'none',
                    borderRadius: '14px',
                    background: 'var(--orange-50)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="sparkles" size={24} color="var(--orange-700)" />
                </span>
                <span style={{ flex: '1', minWidth: '0' }}>
                  <span style={{ display: 'block', fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                    Ganesh Chaturthi
                  </span>
                  <span style={{ display: 'block', fontSize: '15px', color: 'var(--text-muted)' }}>
                    2 discussions · Joy of Celebration
                  </span>
                </span>
              </a>{' '}
              <a
                className="hv-c"
                href="#"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '14px',
                  padding: '12px 0',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <span
                  style={{
                    width: '48px',
                    height: '48px',
                    flex: 'none',
                    borderRadius: '14px',
                    background: 'var(--orange-50)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="sparkles" size={24} color="var(--orange-700)" />
                </span>
                <span style={{ flex: '1', minWidth: '0' }}>
                  <span style={{ display: 'block', fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                    Janmashtami
                  </span>
                  <span style={{ display: 'block', fontSize: '15px', color: 'var(--text-muted)' }}>
                    1 discussion · Joy of Celebration
                  </span>
                </span>
              </a>
            </div>
            <div id="guidelines" style={{ scrollMarginTop: '96px' }}>
              <Card tint="sky" padding={24}>
                <Icon name="shield-check" size={28} color="var(--sky-700)" />
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '10px 0 14px',
                  }}
                >
                  Kind, safe and respectful
                </div>
                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '12px',
                    fontSize: '17px',
                    lineHeight: '1.45',
                    color: 'var(--text-body)',
                    marginBottom: '18px',
                  }}
                >
                  <span style={{ display: 'flex', gap: '10px', alignItems: 'flex-start' }}>
                    <Icon name="heart" size={20} color="var(--sky-700)" />
                    Be kind. Every family is different.
                  </span>
                  <span style={{ display: 'flex', gap: '10px', alignItems: 'flex-start' }}>
                    <Icon name="lock" size={20} color="var(--sky-700)" />
                    Keep your child’s full name and school private.
                  </span>
                  <span style={{ display: 'flex', gap: '10px', alignItems: 'flex-start' }}>
                    <Icon name="stethoscope" size={20} color="var(--sky-700)" />
                    For medical worries, please see your doctor.
                  </span>
                </div>
                <Button variant="dark" fullWidth={true}>
                  Read the guidelines
                </Button>
              </Card>
            </div>
            <Card padding={24}>
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '22px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0 0 6px',
                }}
              >
                New to the community?
              </div>
              <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-muted)', marginBottom: '16px' }}>
                Say hello, tell us your child’s age, and we’ll suggest circles for you.
              </div>
              <Button variant="secondary" fullWidth={true} icon="hand" onClick={v.openDialog}>
                Introduce yourself
              </Button>
            </Card>
          </aside>
        </section>
      </main>
      <SiteFooter spaced />
      {v.dialogOpen ? (
        <Dialog title="Start a discussion" width={560} onClose={v.closeDialog}>
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
              maxHeight: 'calc(100vh - 200px)',
              overflow: 'auto',
              padding: '4px 4px 2px',
              margin: '0 -4px',
            }}
          >
            <Select label="Which circle?" options={v.circleOptions} value={v.dCircle} onChange={v.onDCircle} />
            <Input
              label="Your question or topic"
              placeholder="For example: How do you handle bedtime battles?"
              value={v.dTitle}
              onChange={v.onDTitle}
              error={v.dError}
            />
            <Input
              label="Tell us more (optional)"
              multiline={true}
              rows={2}
              placeholder="Include your child’s age so others can help."
              value={v.dBody}
              onChange={v.onDBody}
            />
            <Checkbox label="Post anonymously" checked={v.dAnon} onChange={v.onDAnon} />
            <div
              style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end', flexWrap: 'wrap', marginTop: '6px' }}
            >
              <Button variant="ghost" onClick={v.closeDialog}>
                Cancel
              </Button>
              <Button variant="primary" onClick={v.submitDialog}>
                Post
              </Button>
            </div>
          </div>
        </Dialog>
      ) : null}
    </div>
  );
}
