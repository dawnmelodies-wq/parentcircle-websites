import { Fragment } from 'react';
import { Avatar, Button, Card, Checkbox, Dialog, Icon, Input, Select, Tabs } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Ask the Expert" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Ask the Expert"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader communityHref="/#community" />
      <section style={{ background: 'var(--sage-50)' }}>
        <div
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '40px 24px 64px',
            boxSizing: 'border-box',
            display: 'flex',
            flexWrap: 'wrap',
            gap: '40px 64px',
            alignItems: 'center',
          }}
        >
          <div style={{ flex: '1.3 1 480px', minWidth: '0' }}>
            <nav
              aria-label="Breadcrumb"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                fontSize: '15px',
                color: 'var(--text-muted)',
                marginBottom: '24px',
              }}
            >
              <a
                className="hv-1"
                href={toUrl('/')}
                style={{ color: 'var(--text-muted)', textDecoration: 'none', fontWeight: '600' }}
              >
                Home
              </a>
              <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
              <span>Ask the Expert</span>
            </nav>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--sage-700)',
                marginBottom: '12px',
              }}
            >
              <Icon name="stethoscope" size={18} />
              Ask the Expert
            </div>
            <h1
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(36px,4.4vw,52px)',
                lineHeight: '1.1',
                letterSpacing: '-0.015em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0',
                textWrap: 'balance',
              }}
            >
              Answers from people who know children best
            </h1>
            <p
              style={{
                fontFamily: 'var(--font-serif)',
                fontSize: '22px',
                lineHeight: '1.55',
                color: 'var(--text-body)',
                margin: '16px 0 28px',
                maxWidth: '600px',
                textWrap: 'pretty',
              }}
            >
              Our experts answer the questions parents and grandparents ask most — to help you feel confident, and raise
              a confident child.
            </p>
            <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', alignItems: 'flex-start' }}>
              <div style={{ flex: '1 1 320px', minWidth: '0', maxWidth: '460px' }}>
                <Input
                  icon="search"
                  placeholder="Search: sleep, exams, siblings…"
                  value={v.query}
                  onChange={v.onQuery}
                />
              </div>
              <Button variant="primary" icon="message-circle" onClick={v.openAsk}>
                Ask your own question
              </Button>
            </div>
          </div>
          <div style={{ flex: '1 1 340px', minWidth: '0' }}>
            <Card padding={28}>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                  marginBottom: '6px',
                }}
              >
                Who answers
              </div>
              {(v.experts ?? []).map((e, $i0) => (
                <Fragment key={$i0}>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '14px',
                      padding: '12px 0',
                      borderBottom: '1px solid var(--border-subtle)',
                    }}
                  >
                    <Avatar name={e?.name} size={48} ring={true} />
                    <div style={{ minWidth: '0' }}>
                      <div style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>{e?.name}</div>
                      <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{e?.role}</div>
                    </div>
                  </div>
                </Fragment>
              ))}
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  fontSize: '15px',
                  color: 'var(--sage-700)',
                  fontWeight: '600',
                  marginTop: '14px',
                }}
              >
                <Icon name="shield-check" size={20} />
                Every answer is reviewed before it’s published
              </div>
            </Card>
          </div>
        </div>
      </section>
      <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '64px 24px 0', boxSizing: 'border-box' }}>
        <div
          style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,260px),1fr))', gap: '16px' }}
        >
          <div
            style={{
              display: 'flex',
              gap: '16px',
              alignItems: 'flex-start',
              padding: '24px',
              border: '1px solid var(--border-default)',
              borderRadius: '16px',
            }}
          >
            <span
              style={{
                width: '44px',
                height: '44px',
                flex: 'none',
                borderRadius: '50%',
                background: 'var(--neutral-900)',
                color: 'var(--text-inverse)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontFamily: 'var(--font-display)',
                fontSize: '20px',
                fontWeight: '700',
              }}
            >
              1
            </span>
            <div>
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '21px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  marginBottom: '4px',
                }}
              >
                Ask your question
              </div>
              <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                Include your child’s age. You can ask anonymously.
              </div>
            </div>
          </div>
          <div
            style={{
              display: 'flex',
              gap: '16px',
              alignItems: 'flex-start',
              padding: '24px',
              border: '1px solid var(--border-default)',
              borderRadius: '16px',
            }}
          >
            <span
              style={{
                width: '44px',
                height: '44px',
                flex: 'none',
                borderRadius: '50%',
                background: 'var(--neutral-900)',
                color: 'var(--text-inverse)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontFamily: 'var(--font-display)',
                fontSize: '20px',
                fontWeight: '700',
              }}
            >
              2
            </span>
            <div>
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '21px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  marginBottom: '4px',
                }}
              >
                An expert reads it
              </div>
              <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                We match it with a paediatrician, psychologist or educator.
              </div>
            </div>
          </div>
          <div
            style={{
              display: 'flex',
              gap: '16px',
              alignItems: 'flex-start',
              padding: '24px',
              border: '1px solid var(--border-default)',
              borderRadius: '16px',
            }}
          >
            <span
              style={{
                width: '44px',
                height: '44px',
                flex: 'none',
                borderRadius: '50%',
                background: 'var(--neutral-900)',
                color: 'var(--text-inverse)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontFamily: 'var(--font-display)',
                fontSize: '20px',
                fontWeight: '700',
              }}
            >
              3
            </span>
            <div>
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '21px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  marginBottom: '4px',
                }}
              >
                You get an answer
              </div>
              <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                Usually within 48 hours, sent to your email.
              </div>
            </div>
          </div>
        </div>
      </section>
      <main id="faqs" style={{ maxWidth: '1200px', margin: '0 auto', padding: '72px 24px 0', boxSizing: 'border-box' }}>
        <div
          style={{
            display: 'flex',
            alignItems: 'flex-end',
            justifyContent: 'space-between',
            gap: '20px',
            flexWrap: 'wrap',
            marginBottom: '24px',
          }}
        >
          <div>
            <h2
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(28px,3vw,36px)',
                lineHeight: '1.2',
                letterSpacing: '-0.01em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0',
              }}
            >
              Questions parents ask
            </h2>
            <p style={{ fontSize: '17px', color: 'var(--text-muted)', margin: '6px 0 0' }}>{v.countLabel}</p>
          </div>
          <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', alignItems: 'center' }}>
            <Tabs variant="pill" tabs={v.topicTabs} value={v.topic} onChange={v.setTopic} />
            <div style={{ width: '190px' }}>
              <Select options={v.ageOptions} value={v.age} onChange={v.onAge} />
            </div>
          </div>
        </div>
        <div
          style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,320px),1fr))', gap: '20px' }}
        >
          {(v.faqs ?? []).map((q, $i0) => (
            <Fragment key={$i0}>
              <a
                className="hv-6"
                href={toUrl('/faq')}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '14px',
                  padding: '24px',
                  border: '1px solid var(--border-default)',
                  borderRadius: '16px',
                  background: 'var(--white)',
                  textDecoration: 'none',
                  color: 'inherit',
                  transition: 'transform 200ms cubic-bezier(.2,0,0,1), box-shadow 200ms cubic-bezier(.2,0,0,1)',
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: '10px',
                    flexWrap: 'wrap',
                  }}
                >
                  <span
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: q?.ink,
                    }}
                  >
                    {q?.topicLabel}
                  </span>
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{q?.ageLabel}</span>
                </div>
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '21px',
                    lineHeight: '1.35',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    textWrap: 'pretty',
                  }}
                >
                  {q?.title}
                </span>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    marginTop: 'auto',
                    paddingTop: '14px',
                    borderTop: '1px solid var(--border-subtle)',
                  }}
                >
                  <Avatar name={q?.expert} size={36} />
                  <div style={{ flex: '1', minWidth: '0' }}>
                    <div style={{ fontSize: '15px', fontWeight: '600', color: 'var(--text-strong)' }}>{q?.expert}</div>
                    <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{q?.role}</div>
                  </div>
                  <Icon name="arrow-right" size={22} color="var(--orange-600)" />
                </div>
              </a>
            </Fragment>
          ))}
        </div>
        {v.noResults ? (
          <div
            style={{
              padding: '40px',
              border: '1px dashed var(--border-strong)',
              borderRadius: '16px',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'flex-start',
              gap: '14px',
            }}
          >
            <p
              style={{
                fontFamily: 'var(--font-serif)',
                fontSize: '20px',
                lineHeight: '1.5',
                color: 'var(--text-body)',
                margin: '0',
              }}
            >
              We haven’t answered that one yet — but an expert can. Send us your question.
            </p>
            <Button variant="primary" icon="message-circle" onClick={v.openAsk}>
              Ask your own question
            </Button>
          </div>
        ) : null}
        {v.canMore ? (
          <div style={{ display: 'flex', justifyContent: 'center', paddingTop: '32px' }}>
            <Button variant="secondary" icon="chevron-down" onClick={v.showMore}>
              View more questions
            </Button>
          </div>
        ) : null}
      </main>
      <section style={{ marginTop: '96px', paddingBottom: '96px' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 24px', boxSizing: 'border-box' }}>
          <div
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '24px 40px',
              alignItems: 'center',
              background: 'var(--orange-50)',
              borderRadius: '24px',
              padding: 'clamp(24px,4vw,40px)',
            }}
          >
            <span
              style={{
                width: '88px',
                height: '88px',
                flex: 'none',
                borderRadius: '24px',
                background: 'var(--white)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="message-circle" size={40} color="var(--orange-700)" />
            </span>
            <div style={{ flex: '1 1 420px', minWidth: '0' }}>
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '28px',
                  lineHeight: '1.25',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  marginBottom: '8px',
                }}
              >
                Can’t find your question?
              </div>
              <p
                style={{
                  fontFamily: 'var(--font-serif)',
                  fontSize: '20px',
                  lineHeight: '1.6',
                  color: 'var(--text-body)',
                  margin: '0',
                  textWrap: 'pretty',
                }}
              >
                No question is too small. Ask, and an expert will get back to you.
              </p>
            </div>
            {v.notAsked ? (
              <Button variant="dark" iconRight="arrow-right" onClick={v.openAsk}>
                Ask an expert
              </Button>
            ) : null}
            {v.asked ? (
              <div
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '10px',
                  padding: '14px 18px',
                  borderRadius: '10px',
                  background: 'var(--white)',
                  color: 'var(--sage-700)',
                  fontSize: '18px',
                  fontWeight: '600',
                  boxShadow: 'var(--shadow-sm)',
                }}
              >
                <Icon name="circle-check" size={24} />
                Sent. An expert will reply within 48 hours.
              </div>
            ) : null}
          </div>
        </div>
      </section>
      <SiteFooter />
      {v.askOpen ? (
        <Dialog title="Ask an expert" width={560} onClose={v.closeAsk}>
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
              maxHeight: 'calc(100vh - 200px)',
              overflow: 'auto',
              padding: '4px',
              margin: '0 -4px',
            }}
          >
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,180px),1fr))',
                gap: '12px',
              }}
            >
              <Select label="Topic" options={v.topicOptions} value={v.aTopic} onChange={v.onATopic} />
              <Select
                label="Your child’s age"
                placeholder="Choose an age"
                options={v.ageAsk}
                value={v.aAge}
                onChange={v.onAAge}
                error={v.aErr?.age}
              />
            </div>
            <Input
              label="Your question"
              multiline={true}
              rows={4}
              placeholder="Describe what’s happening. The more you share, the better we can help."
              value={v.aText}
              onChange={v.onAText}
              error={v.aErr?.text}
            />
            <Input
              label="Email for the answer"
              type="email"
              icon="mail"
              value={v.aEmail}
              onChange={v.onAEmail}
              error={v.aErr?.email}
            />
            <Checkbox label="Keep my name private" checked={v.aAnon} onChange={v.onAAnon} />
            <div
              style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end', flexWrap: 'wrap', marginTop: '4px' }}
            >
              <Button variant="ghost" onClick={v.closeAsk}>
                Cancel
              </Button>
              <Button variant="primary" icon="send" onClick={v.submitAsk}>
                Send question
              </Button>
            </div>
          </div>
        </Dialog>
      ) : null}
    </div>
  );
}
