import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = {
    topic: 'all',
    age: 'all',
    query: '',
    more: false,
    askOpen: false,
    asked: false,
    aTopic: 'Parenting',
    aAge: '',
    aText: '',
    aEmail: '',
    aAnon: true,
    aErr: {},
  };
  hue = { Parenting: 'emotions', Learning: 'learning', Wellness: 'health', Lifestyle: 'play' };
  ex = {
    psych: { expert: 'Dr. Meera Iyer', role: 'Child psychologist' },
    sk: { expert: 'Saakshi Kapoor Kumar', role: 'Psychologist & educator' },
    paed: { expert: 'Dr. S. Raman', role: 'Paediatrician' },
    edu: { expert: 'Lakshmi Venkat', role: 'Early-years educator' },
    as: { expert: 'Arundhati Swamy', role: 'Counsellor, ParentCircle' },
  };
  list = [
    ['Learning', '11-18', 'as', 'Helping teens with career decisions: how to guide them towards the right path'],
    ['Learning', '7-10', 'edu', 'Child easily distracted while studying? Practical ways to improve focus'],
    ['Parenting', '11-18', 'psych', 'How parents can manage their own exam stress — and support children calmly'],
    ['Parenting', '7-10', 'sk', 'When kids want to do what their friends do, and how to respond'],
    ['Parenting', '3-6', 'sk', 'When plans get cancelled: helping your child with disappointment, the SIFT way'],
    ['Parenting', '3-6', 'psych', 'Why some children worry about germs — and how to guide them'],
    ['Wellness', '7-10', 'paed', 'Eye care tips to keep your child’s vision healthy'],
    ['Parenting', '3-6', 'sk', 'How to say no without guilt: handling pester power'],
    ['Wellness', '0-2', 'paed', 'A paediatrician’s guide to baby sleep, first foods and nappy rash'],
    ['Parenting', '3-6', 'psych', 'How to stop siblings from fighting: peace-making ideas that work'],
    ['Wellness', '7-10', 'paed', 'Is your child sleep-deprived? Signs to look for'],
    ['Parenting', 'all', 'psych', 'Nature or nurture: how genes and surroundings shape personality'],
    ['Parenting', '7-10', 'psych', 'Is your child quiet and shy? Ways to embrace who they are'],
    ['Parenting', '3-6', 'sk', '“Mummy thinks I can’t do anything well”: building a 6-year-old’s confidence'],
    ['Lifestyle', '7-10', 'edu', 'Making the school year count: tips for parents'],
    ['Lifestyle', '3-6', 'edu', 'The art of storytelling: how to captivate and inspire little listeners'],
    ['Wellness', 'all', 'paed', 'Cuts, colds and sprains: first aid for children at home'],
    ['Learning', '3-6', 'edu', 'Early childhood learning: expert tips for a strong start'],
  ];
  ages = { all: 'All ages', '0-2': '0–2 years', '3-6': '3–6 years', '7-10': '7–10 years', '11-18': '11–18 years' };
  topicTabs = [{ value: 'all', label: 'All topics' }, 'Parenting', 'Learning', 'Wellness', 'Lifestyle'].map((t) =>
    typeof t === 'string' ? { value: t, label: t } : t,
  );

  submitAsk = () => {
    const S = this.state,
      e = {};
    if (!S.aAge) e.age = 'Please add your child’s age so the expert can help.';
    if (S.aText.trim().length < 15) e.text = 'Please describe your question in a sentence or two.';
    if (!/\S+@\S+\.\S+/.test(S.aEmail)) e.email = 'Please add an email so we can send the answer.';
    if (Object.keys(e).length) {
      this.setState({ aErr: e });
      return;
    }
    this.setState({ askOpen: false, asked: true, aText: '', aErr: {} });
  };

  renderVals() {
    const S = this.state,
      q = S.query.trim().toLowerCase();
    const all = this.list.map(([topic, age, ex, title], i) => ({ id: i, topic, age, title, ...this.ex[ex] }));
    const matched = all.filter(
      (f) =>
        (S.topic === 'all' || f.topic === S.topic) &&
        (S.age === 'all' || f.age === S.age || f.age === 'all') &&
        (!q || f.title.toLowerCase().includes(q) || f.topic.toLowerCase().includes(q)),
    );
    const shown = S.more || q ? matched : matched.slice(0, 9);
    const err = (k) => S.aErr[k] || undefined;
    return {
      query: S.query,
      onQuery: (e) => this.setState({ query: e.target.value }),
      experts: Object.values(this.ex).map((e) => ({ name: e.expert, role: e.role })),
      topicTabs: this.topicTabs,
      topic: S.topic,
      setTopic: (v) => this.setState({ topic: v, more: false }),
      ageOptions: Object.entries(this.ages).map(([value, label]) => ({ value, label })),
      age: S.age,
      onAge: (e) => this.setState({ age: e.target.value, more: false }),
      faqs: shown.map((f) => ({
        ...f,
        ink:
          'var(--' +
          ({ emotions: 'blush', learning: 'sky', health: 'sage', play: 'butter' }[this.hue[f.topic]] || 'neutral') +
          '-700)',
        tagTopic: this.hue[f.topic],
        topicLabel: f.topic,
        ageLabel: this.ages[f.age],
      })),
      countLabel: matched.length === 1 ? '1 answered question' : matched.length + ' answered questions',
      noResults: matched.length === 0,
      canMore: !S.more && !q && matched.length > 9,
      showMore: () => this.setState({ more: true }),
      askOpen: S.askOpen,
      asked: S.asked,
      notAsked: !S.asked,
      openAsk: () => this.setState({ askOpen: true, aErr: {} }),
      closeAsk: () => this.setState({ askOpen: false }),
      topicOptions: ['Parenting', 'Learning', 'Wellness', 'Lifestyle'],
      ageAsk: Object.entries(this.ages)
        .filter(([v]) => v !== 'all')
        .map(([value, label]) => ({ value, label })),
      aTopic: S.aTopic,
      onATopic: (e) => this.setState({ aTopic: e.target.value }),
      aAge: S.aAge,
      onAAge: (e) => this.setState((s) => ({ aAge: e.target.value, aErr: { ...s.aErr, age: undefined } })),
      aText: S.aText,
      onAText: (e) => this.setState((s) => ({ aText: e.target.value, aErr: { ...s.aErr, text: undefined } })),
      aEmail: S.aEmail,
      onAEmail: (e) => this.setState((s) => ({ aEmail: e.target.value, aErr: { ...s.aErr, email: undefined } })),
      aAnon: S.aAnon,
      onAAnon: (v) => this.setState({ aAnon: v }),
      aErr: { age: err('age'), text: err('text'), email: err('email') },
      submitAsk: this.submitAsk,
    };
  }
}

export default PageLogic;
