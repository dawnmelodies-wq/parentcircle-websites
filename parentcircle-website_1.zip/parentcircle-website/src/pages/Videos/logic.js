import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = { series: 'all', ages: [], saved: [] };
  AGES = ['Infant', 'Toddler', 'Pre-schooler', 'Primary', 'Pre-teen', 'Teen', '18+', 'Parent'];
  EXPERT = [
    [
      'Breaking gender stereotypes in parenting: Nalina Ramalakshmi in conversation with Jeo Baby',
      'ParentCircle’s founder talks to the director of The Great Indian Kitchen about raising children without gender bias.',
      'Parent',
      'Parent',
      28000,
      'Nalina Ramalakshmi and Jeo Baby in conversation in a studio',
    ],
    [
      'Parenting across cultures: blending science with family traditions',
      'How modern science and family traditions can work together to support children’s growth.',
      'Infant',
      'Parent',
      1100,
      'Dr Rocío Zunini speaking to camera in a warm living room',
    ],
    [
      'Baby stress explained: what infant stress looks like and how parents can help',
      'The signs, the common causes, and gentle ways to soothe your baby and build security.',
      'Infant',
      'Parent',
      938,
      'Parent soothing a crying baby against their shoulder',
    ],
    [
      'The parent brain explained: how parenting changes your brain',
      'Simple, parent-friendly neuroscience on how nurturing and connecting strengthen you both.',
      'Infant',
      'Parent',
      1000,
      'Parent cradling a newborn, close-up',
    ],
    [
      'Mindful parenting for teens: a simple meditation to reduce stress and reconnect',
      'Coach and author Wynn Burkett on responding to teens with more calm, clarity and compassion.',
      'Teen',
      'Parent',
      2300,
      'Parent and teen sitting quietly together, eyes closed',
    ],
  ];
  DAYS = [
    [
      1,
      'Go Fish, I Wish',
      'A card game with a twist — share a wish with every match.',
      4400,
      'Family playing a card game on the floor',
    ],
    [
      2,
      'Love is in the air',
      'Tell each person what makes them so lovable.',
      3600,
      'Family writing kind notes to each other',
    ],
    [
      3,
      'Incredi-BOWL',
      'Aim, roll, smash — bowling with things from your kitchen.',
      3700,
      'Child rolling a ball at paper-cup pins',
    ],
    [
      4,
      'Fun family facts',
      'A day to discover a little family history together.',
      3700,
      'Grandparent showing old family photos',
    ],
    [
      5,
      'Family harmony',
      'Sing together and set yourselves free.',
      3600,
      'Family singing together in the living room',
      'Teen',
    ],
    [6, 'Kopy kat', 'Copy each other’s moves and face some fun truths.', 3400, 'Child copying a parent’s funny pose'],
    [
      7,
      'Move with groove',
      'Make it a moving, grooving day for the whole family.',
      3400,
      'Family dancing in the kitchen',
    ],
    [
      8,
      'Let’s be sense-ible',
      'Guess by smell, touch and taste — and laugh a lot.',
      3300,
      'Blindfolded child guessing a fruit by smell',
    ],
    [
      9,
      'Science smart',
      'A day to experiment together at home.',
      2700,
      'Parent and child doing a baking-soda experiment',
    ],
    [
      10,
      'Spill the beans',
      'Share the secrets hidden deep inside each of you.',
      2900,
      'Family sharing stories around a bowl of beans',
    ],
    [11, 'Sherlock-in-home', 'Discover the detective in your family.', 1800, 'Child searching with a magnifying glass'],
    [
      12,
      'Emotional connect',
      'Share how you feel, without holding back.',
      1700,
      'Parent and child drawing feelings faces',
    ],
    [
      13,
      'Family keepsake',
      'Create a work of art that celebrates being together.',
      2000,
      'Family painting a keepsake together',
    ],
  ];
  chip(on) {
    return on
      ? { bg: 'var(--neutral-900)', fg: 'var(--white)', bd: 'var(--neutral-900)' }
      : { bg: 'var(--white)', fg: 'var(--text-strong)', bd: 'var(--border-default)' };
  }
  views(n) {
    return n >= 1000 ? (Math.round(n / 100) / 10).toString().replace(/\.0$/, '') + 'K views' : n + ' views';
  }
  span(a0, a1) {
    return this.AGES.slice(this.AGES.indexOf(a0), this.AGES.indexOf(a1) + 1);
  }
  all() {
    const e = this.EXPERT.map(([title, dek, a0, a1, v, photo], i) => ({
      key: 'e' + i,
      kind: 'expert',
      title,
      dek,
      a0,
      a1,
      v,
      photo,
    }));
    const d = this.DAYS.map(([n, t, dek, v, photo, a1]) => ({
      key: 'd' + n,
      kind: 'challenge',
      day: 'Day ' + n,
      title: 'Day ' + n + ': ' + t,
      dek,
      a0: 'Toddler',
      a1: a1 || 'Parent',
      v,
      photo,
    }));
    return e.concat(d);
  }
  shape(x) {
    const on = this.state.saved.includes(x.key),
      ex = x.kind === 'expert';
    return {
      href: ex ? '/video' : '/challenge-video',
      slot: x.key,
      title: x.title,
      dek: x.dek,
      photo: 'Video still: ' + x.photo,
      day: x.day || '',
      series: ex ? 'Expert conversation' : '14-day challenge',
      tint: ex ? 'var(--sky-50)' : 'var(--white)',
      ink: ex ? 'var(--sky-700)' : 'var(--butter-700)',
      meta: (x.a0 === x.a1 ? x.a0 : x.a0 + ' to ' + x.a1) + ' · ' + this.views(x.v),
      saveIcon: on ? 'bookmark-check' : 'bookmark',
      saveLabel: on ? 'Saved' : 'Save video',
      saveText: on ? 'Saved' : 'Save',
      toggleSave: () =>
        this.setState((s) => ({
          saved: s.saved.includes(x.key) ? s.saved.filter((k) => k !== x.key) : s.saved.concat(x.key),
        })),
    };
  }
  renderVals() {
    const S = this.state,
      items = this.all();
    const nf = (S.series !== 'all' ? 1 : 0) + S.ages.length;
    const res = items.filter(
      (x) =>
        (S.series === 'all' || x.kind === S.series) &&
        (!S.ages.length || this.span(x.a0, x.a1).some((a) => S.ages.includes(a))),
    );
    return {
      seriesChips: [
        ['all', 'All videos'],
        ['expert', 'Expert conversations'],
        ['challenge', '14-day family challenge'],
      ].map(([v, l]) => ({
        label: l,
        on: S.series === v,
        toggle: () => this.setState({ series: v }),
        ...this.chip(S.series === v),
      })),
      ageChips: this.AGES.map((a) => ({
        label: a,
        on: S.ages.includes(a),
        toggle: () =>
          this.setState((s) => ({ ages: s.ages.includes(a) ? s.ages.filter((x) => x !== a) : s.ages.concat(a) })),
        ...this.chip(S.ages.includes(a)),
      })),
      countLabel: res.length === 1 ? '1 video' : res.length + ' videos',
      hasFilters: nf > 0,
      clearFilters: () => this.setState({ series: 'all', ages: [] }),
      browse: nf === 0,
      filtering: nf > 0,
      lead: this.shape(items[0]),
      experts: items
        .filter((x) => x.kind === 'expert')
        .slice(1)
        .map((x) => this.shape(x)),
      days: items.filter((x) => x.kind === 'challenge').map((x) => this.shape(x)),
      challengeCount: this.DAYS.length + ' videos',
      results: res.map((x) => this.shape(x)),
      empty: res.length === 0,
    };
  }
}

export default PageLogic;
