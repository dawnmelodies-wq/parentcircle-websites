import { Fragment } from 'react';
import { Button, Icon, IconButton } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Videos" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Videos"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader active="watch" />
      <main>
        <section style={{ background: 'var(--neutral-50)', borderBottom: '1px solid var(--border-subtle)' }}>
          <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '28px 24px 36px', boxSizing: 'border-box' }}>
            <nav
              aria-label="Breadcrumb"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                fontSize: '15px',
                color: 'var(--text-muted)',
                marginBottom: '24px',
              }}
            >
              <a
                className="hv-1"
                href={toUrl('/')}
                style={{ color: 'var(--text-muted)', textDecoration: 'none', fontWeight: '600' }}
              >
                Home
              </a>
              <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
              <span>Videos</span>
            </nav>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--orange-700)',
                marginBottom: '12px',
              }}
            >
              <Icon name="circle-play" size={18} color="var(--orange-700)" />
              Watch
            </div>
            <h1
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(36px,4.6vw,56px)',
                lineHeight: '1.08',
                letterSpacing: '-0.015em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0',
                textWrap: 'balance',
              }}
            >
              Videos on parenting
            </h1>
            <p
              style={{
                fontFamily: 'var(--font-serif)',
                fontSize: '21px',
                lineHeight: '1.6',
                color: 'var(--text-body)',
                margin: '14px 0 28px',
                maxWidth: '680px',
                textWrap: 'pretty',
              }}
            >
              Doctors, psychologists, educators, storytellers and parents share what they’ve learned about raising
              healthy, confident children. You’ll find a tip or two here.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div style={{ display: 'flex', gap: '10px 16px', flexWrap: 'wrap', alignItems: 'flex-start' }}>
                <span
                  style={{
                    flex: 'none',
                    width: '92px',
                    fontSize: '15px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    lineHeight: '40px',
                  }}
                >
                  Series
                </span>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', flex: '1', minWidth: '0' }}>
                  {(v.seriesChips ?? []).map((c, $i0) => (
                    <Fragment key={$i0}>
                      <button
                        type="button"
                        aria-pressed={c?.on}
                        onClick={c?.toggle}
                        style={{
                          height: '40px',
                          padding: '0 14px',
                          borderRadius: '999px',
                          border: `1.5px solid ${c?.bd ?? ''}`,
                          background: c?.bg,
                          color: c?.fg,
                          font: 'inherit',
                          fontSize: '15px',
                          fontWeight: '600',
                          cursor: 'pointer',
                          transition: 'background 150ms',
                        }}
                      >
                        {c?.label}
                      </button>
                    </Fragment>
                  ))}
                </div>
              </div>
              <div style={{ display: 'flex', gap: '10px 16px', flexWrap: 'wrap', alignItems: 'flex-start' }}>
                <span
                  style={{
                    flex: 'none',
                    width: '92px',
                    fontSize: '15px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    lineHeight: '40px',
                  }}
                >
                  Age group
                </span>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', flex: '1', minWidth: '0' }}>
                  {(v.ageChips ?? []).map((a, $i0) => (
                    <Fragment key={$i0}>
                      <button
                        type="button"
                        aria-pressed={a?.on}
                        onClick={a?.toggle}
                        style={{
                          height: '40px',
                          padding: '0 14px',
                          borderRadius: '999px',
                          border: `1.5px solid ${a?.bd ?? ''}`,
                          background: a?.bg,
                          color: a?.fg,
                          font: 'inherit',
                          fontSize: '15px',
                          fontWeight: '600',
                          cursor: 'pointer',
                          transition: 'background 150ms',
                        }}
                      >
                        {a?.label}
                      </button>
                    </Fragment>
                  ))}
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
                <span style={{ fontSize: '16px', fontWeight: '600', color: 'var(--text-strong)' }}>{v.countLabel}</span>
                {v.hasFilters ? (
                  <button
                    className="hv-8"
                    type="button"
                    onClick={v.clearFilters}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px',
                      border: '0',
                      background: 'none',
                      padding: '6px 0',
                      font: 'inherit',
                      fontSize: '15px',
                      fontWeight: '700',
                      color: 'var(--text-link)',
                      cursor: 'pointer',
                    }}
                  >
                    <Icon name="x" size={16} color="currentColor" />
                    Clear filters
                  </button>
                ) : null}
              </div>
            </div>
          </div>
        </section>
        {v.browse ? (
          <Fragment>
            <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '40px 24px 0', boxSizing: 'border-box' }}>
              <article
                style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '24px 40px',
                  alignItems: 'center',
                  paddingBottom: '48px',
                  borderBottom: '1px solid var(--border-subtle)',
                }}
              >
                <div
                  style={{
                    flex: '1.4 1 440px',
                    minWidth: '0',
                    position: 'relative',
                    overflow: 'hidden',
                    aspectRatio: '16 / 9',
                    borderRadius: '24px',
                    background: 'var(--sky-50)',
                  }}
                >
                  <image-slot id="videos-featured" shape="rounded" radius="24" placeholder={v.lead?.photo}></image-slot>{' '}
                  <a
                    className="hv-9"
                    href={toUrl('/video')}
                    aria-label="Play video"
                    style={{
                      position: 'absolute',
                      top: '16px',
                      right: '16px',
                      zIndex: '1',
                      width: '56px',
                      height: '56px',
                      borderRadius: '50%',
                      background: 'var(--action-primary)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      boxShadow: 'var(--shadow-lg)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="play" size={26} color="var(--white)" />
                  </a>
                </div>
                <div
                  style={{ flex: '1 1 320px', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '12px' }}
                >
                  <span
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--sky-700)',
                    }}
                  >
                    Featured · Expert conversation
                  </span>
                  <a
                    className="hv-5"
                    href={toUrl('/video')}
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: 'clamp(26px,3vw,34px)',
                      lineHeight: '1.2',
                      letterSpacing: '-0.01em',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                      textWrap: 'balance',
                    }}
                  >
                    {v.lead?.title}
                  </a>
                  <p
                    style={{
                      fontFamily: 'var(--font-serif)',
                      fontSize: '19px',
                      lineHeight: '1.6',
                      color: 'var(--text-body)',
                      margin: '0',
                      textWrap: 'pretty',
                    }}
                  >
                    {v.lead?.dek}
                  </p>
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{v.lead?.meta}</span>
                  <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginTop: '4px' }}>
                    <a href={toUrl('/video')} style={{ textDecoration: 'none' }}>
                      <Button variant="primary" icon="play">
                        Watch video
                      </Button>
                    </a>
                    <Button variant="secondary" icon={v.lead?.saveIcon} onClick={v.lead?.toggleSave}>
                      {v.lead?.saveText}
                    </Button>
                  </div>
                </div>
              </article>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'baseline',
                  justifyContent: 'space-between',
                  gap: '12px',
                  flexWrap: 'wrap',
                  margin: '40px 0 24px',
                }}
              >
                <h2
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(26px,3vw,32px)',
                    lineHeight: '1.2',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0',
                  }}
                >
                  Expert conversations
                </h2>
                <span style={{ fontSize: '16px', color: 'var(--text-muted)' }}>
                  Interviews with doctors, coaches and storytellers
                </span>
              </div>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,260px),1fr))',
                  gap: '36px 24px',
                }}
              >
                {(v.experts ?? []).map((v, $i0) => (
                  <Fragment key={$i0}>
                    <article style={{ display: 'flex', flexDirection: 'column', gap: '10px', minWidth: '0' }}>
                      <div
                        style={{
                          position: 'relative',
                          overflow: 'hidden',
                          aspectRatio: '16 / 9',
                          borderRadius: '16px',
                          background: v?.tint,
                        }}
                      >
                        <image-slot
                          id={`videos-${v?.slot ?? ''}`}
                          shape="rounded"
                          radius="16"
                          placeholder={v?.photo}
                        ></image-slot>{' '}
                        <a
                          className="hv-9"
                          href={toUrl(v?.href)}
                          aria-label="Play video"
                          style={{
                            position: 'absolute',
                            top: '12px',
                            right: '12px',
                            zIndex: '1',
                            width: '44px',
                            height: '44px',
                            borderRadius: '50%',
                            background: 'var(--action-primary)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            boxShadow: 'var(--shadow-md)',
                            textDecoration: 'none',
                          }}
                        >
                          <Icon name="play" size={20} color="var(--white)" />
                        </a>
                        {v?.day ? (
                          <span
                            style={{
                              position: 'absolute',
                              top: '12px',
                              left: '12px',
                              zIndex: '1',
                              height: '28px',
                              padding: '0 10px',
                              borderRadius: '999px',
                              background: 'var(--white)',
                              color: 'var(--text-strong)',
                              fontSize: '14px',
                              fontWeight: '700',
                              display: 'flex',
                              alignItems: 'center',
                              boxShadow: 'var(--shadow-xs)',
                            }}
                          >
                            {v?.day}
                          </span>
                        ) : null}
                      </div>
                      <span
                        style={{
                          fontSize: '14px',
                          fontWeight: '700',
                          letterSpacing: '0.08em',
                          textTransform: 'uppercase',
                          color: v?.ink,
                        }}
                      >
                        {v?.series}
                      </span>
                      <a
                        className="hv-5"
                        href={toUrl(v?.href)}
                        style={{
                          fontFamily: 'var(--font-display)',
                          fontSize: '20px',
                          lineHeight: '1.3',
                          fontWeight: '700',
                          color: 'var(--text-strong)',
                          textDecoration: 'none',
                          textWrap: 'pretty',
                        }}
                      >
                        {v?.title}
                      </a>
                      <p
                        style={{
                          fontFamily: 'var(--font-serif)',
                          fontSize: '17px',
                          lineHeight: '1.5',
                          color: 'var(--text-body)',
                          margin: '0',
                          display: '-webkit-box',
                          WebkitLineClamp: '2',
                          WebkitBoxOrient: 'vertical',
                          overflow: 'hidden',
                        }}
                      >
                        {v?.dek}
                      </p>
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          gap: '8px',
                          marginTop: 'auto',
                        }}
                      >
                        <span style={{ fontSize: '15px', lineHeight: '1.4', color: 'var(--text-muted)' }}>
                          {v?.meta}
                        </span>
                        <IconButton icon={v?.saveIcon} label={v?.saveLabel} onClick={v?.toggleSave} />
                      </div>
                    </article>
                  </Fragment>
                ))}
              </div>
            </section>
            <section style={{ marginTop: '72px', background: 'var(--butter-50)' }}>
              <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '56px 24px 64px', boxSizing: 'border-box' }}>
                <div
                  style={{
                    display: 'flex',
                    flexWrap: 'wrap',
                    gap: '16px 40px',
                    alignItems: 'flex-end',
                    justifyContent: 'space-between',
                    marginBottom: '28px',
                  }}
                >
                  <div style={{ flex: '1 1 420px', minWidth: '0' }}>
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        fontSize: '14px',
                        fontWeight: '700',
                        letterSpacing: '0.08em',
                        textTransform: 'uppercase',
                        color: 'var(--butter-700)',
                        marginBottom: '10px',
                      }}
                    >
                      <Icon name="calendar-heart" size={18} color="var(--butter-700)" />
                      Video series
                    </div>
                    <h2
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: 'clamp(26px,3vw,32px)',
                        lineHeight: '1.2',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0',
                      }}
                    >
                      The 14-day family challenge
                    </h2>
                    <p style={{ fontSize: '18px', lineHeight: '1.55', color: 'var(--text-body)', margin: '8px 0 0' }}>
                      One short, playful activity a day to help your family connect — no screens needed.
                    </p>
                  </div>
                  <span style={{ fontSize: '16px', fontWeight: '600', color: 'var(--text-strong)' }}>
                    {v.challengeCount}
                  </span>
                </div>
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,260px),1fr))',
                    gap: '36px 24px',
                  }}
                >
                  {(v.days ?? []).map((d, $i0) => (
                    <Fragment key={$i0}>
                      <article style={{ display: 'flex', flexDirection: 'column', gap: '10px', minWidth: '0' }}>
                        <div
                          style={{
                            position: 'relative',
                            overflow: 'hidden',
                            aspectRatio: '16 / 9',
                            borderRadius: '16px',
                            background: d?.tint,
                          }}
                        >
                          <image-slot
                            id={`videos-${d?.slot ?? ''}`}
                            shape="rounded"
                            radius="16"
                            placeholder={d?.photo}
                          ></image-slot>{' '}
                          <a
                            className="hv-9"
                            href={toUrl(d?.href)}
                            aria-label="Play video"
                            style={{
                              position: 'absolute',
                              top: '12px',
                              right: '12px',
                              zIndex: '1',
                              width: '44px',
                              height: '44px',
                              borderRadius: '50%',
                              background: 'var(--action-primary)',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              boxShadow: 'var(--shadow-md)',
                              textDecoration: 'none',
                            }}
                          >
                            <Icon name="play" size={20} color="var(--white)" />
                          </a>
                          {d?.day ? (
                            <span
                              style={{
                                position: 'absolute',
                                top: '12px',
                                left: '12px',
                                zIndex: '1',
                                height: '28px',
                                padding: '0 10px',
                                borderRadius: '999px',
                                background: 'var(--white)',
                                color: 'var(--text-strong)',
                                fontSize: '14px',
                                fontWeight: '700',
                                display: 'flex',
                                alignItems: 'center',
                                boxShadow: 'var(--shadow-xs)',
                              }}
                            >
                              {d?.day}
                            </span>
                          ) : null}
                        </div>
                        <span
                          style={{
                            fontSize: '14px',
                            fontWeight: '700',
                            letterSpacing: '0.08em',
                            textTransform: 'uppercase',
                            color: d?.ink,
                          }}
                        >
                          {d?.series}
                        </span>
                        <a
                          className="hv-5"
                          href={toUrl(d?.href)}
                          style={{
                            fontFamily: 'var(--font-display)',
                            fontSize: '20px',
                            lineHeight: '1.3',
                            fontWeight: '700',
                            color: 'var(--text-strong)',
                            textDecoration: 'none',
                            textWrap: 'pretty',
                          }}
                        >
                          {d?.title}
                        </a>
                        <p
                          style={{
                            fontFamily: 'var(--font-serif)',
                            fontSize: '17px',
                            lineHeight: '1.5',
                            color: 'var(--text-body)',
                            margin: '0',
                            display: '-webkit-box',
                            WebkitLineClamp: '2',
                            WebkitBoxOrient: 'vertical',
                            overflow: 'hidden',
                          }}
                        >
                          {d?.dek}
                        </p>
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            gap: '8px',
                            marginTop: 'auto',
                          }}
                        >
                          <span style={{ fontSize: '15px', lineHeight: '1.4', color: 'var(--text-muted)' }}>
                            {d?.meta}
                          </span>
                          <IconButton icon={d?.saveIcon} label={d?.saveLabel} onClick={d?.toggleSave} />
                        </div>
                      </article>
                    </Fragment>
                  ))}
                </div>
              </div>
            </section>
          </Fragment>
        ) : null}
        {v.filtering ? (
          <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '40px 24px 0', boxSizing: 'border-box' }}>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,260px),1fr))',
                gap: '36px 24px',
              }}
            >
              {(v.results ?? []).map((r, $i0) => (
                <Fragment key={$i0}>
                  <article style={{ display: 'flex', flexDirection: 'column', gap: '10px', minWidth: '0' }}>
                    <div
                      style={{
                        position: 'relative',
                        overflow: 'hidden',
                        aspectRatio: '16 / 9',
                        borderRadius: '16px',
                        background: r?.tint,
                      }}
                    >
                      <image-slot
                        id={`videos-${r?.slot ?? ''}`}
                        shape="rounded"
                        radius="16"
                        placeholder={r?.photo}
                      ></image-slot>{' '}
                      <a
                        className="hv-9"
                        href={toUrl(r?.href)}
                        aria-label="Play video"
                        style={{
                          position: 'absolute',
                          top: '12px',
                          right: '12px',
                          zIndex: '1',
                          width: '44px',
                          height: '44px',
                          borderRadius: '50%',
                          background: 'var(--action-primary)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          boxShadow: 'var(--shadow-md)',
                          textDecoration: 'none',
                        }}
                      >
                        <Icon name="play" size={20} color="var(--white)" />
                      </a>
                      {r?.day ? (
                        <span
                          style={{
                            position: 'absolute',
                            top: '12px',
                            left: '12px',
                            zIndex: '1',
                            height: '28px',
                            padding: '0 10px',
                            borderRadius: '999px',
                            background: 'var(--white)',
                            color: 'var(--text-strong)',
                            fontSize: '14px',
                            fontWeight: '700',
                            display: 'flex',
                            alignItems: 'center',
                            boxShadow: 'var(--shadow-xs)',
                          }}
                        >
                          {r?.day}
                        </span>
                      ) : null}
                    </div>
                    <span
                      style={{
                        fontSize: '14px',
                        fontWeight: '700',
                        letterSpacing: '0.08em',
                        textTransform: 'uppercase',
                        color: r?.ink,
                      }}
                    >
                      {r?.series}
                    </span>
                    <a
                      className="hv-5"
                      href={toUrl(r?.href)}
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '20px',
                        lineHeight: '1.3',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        textDecoration: 'none',
                        textWrap: 'pretty',
                      }}
                    >
                      {r?.title}
                    </a>
                    <p
                      style={{
                        fontFamily: 'var(--font-serif)',
                        fontSize: '17px',
                        lineHeight: '1.5',
                        color: 'var(--text-body)',
                        margin: '0',
                        display: '-webkit-box',
                        WebkitLineClamp: '2',
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden',
                      }}
                    >
                      {r?.dek}
                    </p>
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: '8px',
                        marginTop: 'auto',
                      }}
                    >
                      <span style={{ fontSize: '15px', lineHeight: '1.4', color: 'var(--text-muted)' }}>{r?.meta}</span>
                      <IconButton icon={r?.saveIcon} label={r?.saveLabel} onClick={r?.toggleSave} />
                    </div>
                  </article>
                </Fragment>
              ))}
            </div>
            {v.empty ? (
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'flex-start',
                  gap: '12px',
                  padding: '28px',
                  borderRadius: '20px',
                  background: 'var(--neutral-50)',
                }}
              >
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                  }}
                >
                  No videos match these filters
                </div>
                <p style={{ fontSize: '17px', color: 'var(--text-body)', margin: '0' }}>
                  Try another series or age group.
                </p>
                <Button variant="dark" icon="x" onClick={v.clearFilters}>
                  Clear filters
                </Button>
              </div>
            ) : null}
          </section>
        ) : null}
      </main>
      <SiteFooter />
    </div>
  );
}
