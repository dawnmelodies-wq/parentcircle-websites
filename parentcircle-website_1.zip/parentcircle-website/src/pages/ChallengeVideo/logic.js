import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = {
    playing: false,
    liked: false,
    saved: false,
    copied: false,
    have: [],
    running: false,
    elapsed: 0,
    player: '',
    playerErr: '',
    scores: [],
    joined: [],
  };
  NEEDS = ['A few straws, pencils or pens', 'A ball of string', 'An empty bottle with a narrow mouth'];
  STEPS = [
    'Family members take turns to do the challenge.',
    'Measure a length of string long enough to tie around the waist and hang down to the knees.',
    'Tie a straw or pencil to the loose end of the string.',
    'Place the bottle on the floor.',
    'Without using your hands, bend forward and try to lower the straw into the bottle.',
    'For more fun, time each turn — everyone yells “Go!” together. The quickest player is the most focused!',
  ];
  DAYS = [
    'Go Fish, I Wish',
    'Love is in the air',
    'Incredi-BOWL',
    'Fun family facts',
    'Family harmony',
    'Kopy kat',
    'Move with groove',
    'Let’s be sense-ible',
    'Science smart',
    'Spill the beans',
    'Sherlock-in-home',
    'Emotional connect',
    'Family keepsake',
    'Wiggly-Giggly',
  ];
  CIRCLES = [
    ['3–6 years', '2.5K members · 79 discussions', 'butter'],
    ['7–10 years', '1.9K members · 79 discussions', 'sky'],
    ['11–18 years', '1.8K members · 96 discussions', 'lilac'],
    ['Just for parents', '4.1K members · 221 discussions', 'blush'],
  ];
  MORE = [
    [
      'grit',
      '#IAmGrit: how Asha Roy sprinted her way to records against all odds',
      'Teen to 18+ · 7 min read',
      'Sports',
      'lilac',
      'A young sprinter on a running track at dawn',
    ],
    [
      'party',
      'A parent’s guide to birthday party rules: useful tips to get started',
      'Pre-schooler to Primary · 6 min read',
      'Family life',
      'butter',
      'Children at a birthday party with balloons',
    ],
    [
      'games',
      'Games that build problem-solving skills in preschoolers',
      'Pre-schooler · 5 min read',
      'Building skills',
      'sky',
      'Preschooler solving a simple wooden puzzle',
    ],
  ];
  componentWillUnmount() {
    clearInterval(this.t);
    clearTimeout(this.ct);
  }
  fmt(ms) {
    const s = Math.floor(ms / 1000),
      m = Math.floor(s / 60),
      cs = Math.floor((ms % 1000) / 10);
    return String(m).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0') + '.' + String(cs).padStart(2, '0');
  }
  toggleRun = () => {
    if (this.state.running) {
      clearInterval(this.t);
      this.setState({ running: false, elapsed: Date.now() - this.t0 });
      return;
    }
    this.t0 = Date.now() - this.state.elapsed;
    this.setState({ running: true });
    this.t = setInterval(() => this.setState({ elapsed: Date.now() - this.t0 }), 50);
  };
  reset = () => {
    clearInterval(this.t);
    this.setState({ running: false, elapsed: 0 });
  };
  saveTime = () => {
    const S = this.state,
      name = S.player.trim();
    if (!name) return this.setState({ playerErr: 'Add a name for this turn.' });
    if (!S.elapsed) return this.setState({ playerErr: 'Start the stopwatch first.' });
    clearInterval(this.t);
    const ms = S.running ? Date.now() - this.t0 : S.elapsed;
    this.setState((s) => ({
      scores: s.scores.concat({ name, ms }),
      player: '',
      playerErr: '',
      running: false,
      elapsed: 0,
    }));
  };
  share = () => {
    try {
      navigator.clipboard && navigator.clipboard.writeText(location.href);
    } catch (e) {}
    this.setState({ copied: true });
    clearTimeout(this.ct);
    this.ct = setTimeout(() => this.setState({ copied: false }), 2500);
  };
  renderVals() {
    const S = this.state,
      ready = S.have.length === this.NEEDS.length;
    const sorted = S.scores.slice().sort((a, b) => a.ms - b.ms);
    return {
      playing: S.playing,
      notPlaying: !S.playing,
      play: () => this.setState({ playing: true }),
      likeLabel: S.liked ? 'Liked' : 'Like',
      likeVariant: S.liked ? 'soft' : 'secondary',
      toggleLike: () => this.setState({ liked: !S.liked }),
      saveLabel: S.saved ? 'Saved' : 'Save',
      saveIcon: S.saved ? 'bookmark-check' : 'bookmark',
      toggleSave: () => this.setState({ saved: !S.saved }),
      shareLabel: S.copied ? 'Link copied' : 'Share',
      shareIcon: S.copied ? 'check' : 'share-2',
      share: this.share,
      needs: this.NEEDS.map((l, i) => ({
        label: l,
        on: S.have.includes(i),
        toggle: () =>
          this.setState((s) => ({ have: s.have.includes(i) ? s.have.filter((x) => x !== i) : s.have.concat(i) })),
      })),
      readyLabel: ready ? 'All set — let’s play!' : S.have.length + ' of ' + this.NEEDS.length + ' ready',
      readyInk: ready ? 'var(--sage-700)' : 'var(--text-muted)',
      steps: this.STEPS.map((t, i) => ({ n: i + 1, t })),
      clock: this.fmt(S.elapsed),
      runLabel: S.running ? 'Stop' : S.elapsed ? 'Resume' : 'Start',
      runIcon: S.running ? 'pause' : 'play',
      runVariant: S.running ? 'dark' : 'primary',
      toggleRun: this.toggleRun,
      reset: this.reset,
      player: S.player,
      onPlayer: (e) => this.setState({ player: e.target.value, playerErr: '' }),
      playerErr: S.playerErr || undefined,
      saveTime: this.saveTime,
      hasScores: sorted.length > 0,
      scores: sorted.map((r, i) => ({
        name: r.name,
        time: this.fmt(r.ms),
        rank: i + 1,
        top: i === 0,
        bg: i === 0 ? 'var(--orange-600)' : 'var(--neutral-100)',
        fg: i === 0 ? 'var(--white)' : 'var(--text-strong)',
      })),
      days: this.DAYS.map((t, i) => {
        const cur = i === 13;
        return {
          n: i + 1,
          title: t,
          current: cur ? 'page' : 'false',
          bg: cur ? 'var(--white)' : 'transparent',
          dotBg: cur ? 'var(--orange-600)' : 'var(--white)',
          dotFg: cur ? 'var(--white)' : 'var(--text-strong)',
          weight: cur ? 700 : 500,
        };
      }),
      circles: this.CIRCLES.map(([name, meta, hue]) => {
        const on = S.joined.includes(name);
        return {
          name,
          meta,
          tint: 'var(--' + hue + '-50)',
          ink: 'var(--' + hue + '-700)',
          label: on ? 'Joined' : 'Join',
          variant: on ? 'ghost' : 'secondary',
          toggle: () =>
            this.setState((s) => ({
              joined: s.joined.includes(name) ? s.joined.filter((x) => x !== name) : s.joined.concat(name),
            })),
        };
      }),
      more: this.MORE.map(([id, title, meta, cat, hue, ph]) => ({
        id,
        title,
        meta,
        cat,
        tint: 'var(--' + hue + '-50)',
        ink: 'var(--' + hue + '-700)',
        photo: 'Photo: ' + ph,
      })),
    };
  }
}

export default PageLogic;
