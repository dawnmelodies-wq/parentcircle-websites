import { Fragment } from 'react';
import { Avatar, Badge, Button, Checkbox, Icon, Input } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Challenge Video" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Challenge video"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader active="watch" />
      <main style={{ maxWidth: '1200px', margin: '0 auto', padding: '28px 24px 0', boxSizing: 'border-box' }}>
        <nav
          aria-label="Breadcrumb"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            flexWrap: 'wrap',
            fontSize: '15px',
            color: 'var(--text-muted)',
            marginBottom: '28px',
          }}
        >
          <a
            className="hv-1"
            href={toUrl('/')}
            style={{ color: 'var(--text-muted)', textDecoration: 'none', fontWeight: '600' }}
          >
            Home
          </a>
          <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
          <a
            className="hv-1"
            href={toUrl('/videos')}
            style={{ color: 'var(--text-muted)', textDecoration: 'none', fontWeight: '600' }}
          >
            Videos
          </a>
          <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
          <span>14-day family challenge</span>
        </nav>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '48px 56px', alignItems: 'flex-start' }}>
          <article style={{ flex: '999 1 560px', minWidth: '0', maxWidth: '780px' }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--butter-700)',
                marginBottom: '12px',
              }}
            >
              <Icon name="calendar-heart" size={18} color="var(--butter-700)" />
              14-day family challenge · Day 14
            </div>
            <h1
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(34px,4.4vw,52px)',
                lineHeight: '1.1',
                letterSpacing: '-0.015em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0',
                textWrap: 'balance',
              }}
            >
              Day 14: Wiggly-Giggly
            </h1>
            <p
              style={{
                fontFamily: 'var(--font-serif)',
                fontSize: '22px',
                lineHeight: '1.55',
                color: 'var(--text-body)',
                margin: '14px 0 22px',
                textWrap: 'pretty',
              }}
            >
              The final day! A playful challenge to test your family’s flexibility, focus — and fun quotient.
            </p>
            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '14px 20px',
                padding: '14px 0',
                borderTop: '1px solid var(--border-subtle)',
                borderBottom: '1px solid var(--border-subtle)',
                marginBottom: '24px',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <Avatar name="Team ParentCircle" size={44} />
                <div>
                  <div style={{ fontSize: '16px', fontWeight: '700', color: 'var(--text-strong)' }}>
                    Team ParentCircle
                  </div>
                  <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Toddler to Parent · 1.6K views</div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                <Button variant={v.likeVariant} size="sm" icon="heart" onClick={v.toggleLike}>
                  {v.likeLabel}
                </Button>
                <Button variant="secondary" size="sm" icon={v.saveIcon} onClick={v.toggleSave}>
                  {v.saveLabel}
                </Button>
                <Button variant="secondary" size="sm" icon={v.shareIcon} onClick={v.share}>
                  {v.shareLabel}
                </Button>
              </div>
            </div>
            <div
              style={{
                position: 'relative',
                aspectRatio: '16 / 9',
                borderRadius: '24px',
                overflow: 'hidden',
                background: 'var(--butter-50)',
              }}
            >
              {v.notPlaying ? (
                <Fragment>
                  <image-slot
                    id="challenge-14-video"
                    shape="rounded"
                    radius="24"
                    placeholder="Video still: a parent bending to drop a dangling pencil into a bottle while the family cheers"
                  ></image-slot>{' '}
                  <button
                    className="hv-9"
                    type="button"
                    onClick={v.play}
                    aria-label="Play video"
                    style={{
                      position: 'absolute',
                      top: '16px',
                      right: '16px',
                      zIndex: '1',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      height: '52px',
                      padding: '0 20px 0 16px',
                      border: '0',
                      borderRadius: '999px',
                      background: 'var(--action-primary)',
                      color: 'var(--white)',
                      font: 'inherit',
                      fontSize: '17px',
                      fontWeight: '700',
                      cursor: 'pointer',
                      boxShadow: 'var(--shadow-lg)',
                    }}
                  >
                    <Icon name="play" size={22} color="var(--white)" />
                    Play video
                  </button>
                </Fragment>
              ) : null}
              {v.playing ? (
                <iframe
                  src={'https://www.youtube-nocookie.com/embed/t1qX69ukZF4?autoplay=1&rel=0'}
                  title="Day 14: Wiggly-Giggly"
                  allow="autoplay; encrypted-media; picture-in-picture"
                  allowFullScreen={true}
                  style={{ position: 'absolute', inset: '0', width: '100%', height: '100%', border: '0' }}
                ></iframe>
              ) : null}
            </div>
            <p
              style={{
                fontFamily: 'var(--font-reading)',
                fontSize: '21px',
                lineHeight: '1.7',
                color: 'var(--text-body)',
                margin: '32px 0 0',
                textWrap: 'pretty',
              }}
            >
              Remember the impossible twists and turns you could do so easily as a child? Today, you can impress
              everyone with your moves once again. As you all wiggle and giggle your way through, cheer loudly for every
              effort.
            </p>
            <section
              style={{ marginTop: '40px', padding: '28px', borderRadius: '20px', background: 'var(--butter-50)' }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'baseline',
                  justifyContent: 'space-between',
                  gap: '12px',
                  flexWrap: 'wrap',
                }}
              >
                <h2
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(24px,2.8vw,30px)',
                    lineHeight: '1.2',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0 0 16px',
                  }}
                >
                  What you will need
                </h2>
                <span style={{ fontSize: '15px', fontWeight: '600', color: v.readyInk }}>{v.readyLabel}</span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                {(v.needs ?? []).map((n, $i0) => (
                  <Fragment key={$i0}>
                    <div style={{ padding: '10px 14px', borderRadius: '12px', background: 'var(--white)' }}>
                      <Checkbox label={n?.label} checked={n?.on} onChange={n?.toggle} />
                    </div>
                  </Fragment>
                ))}
              </div>
            </section>
            <section style={{ marginTop: '40px' }}>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(24px,2.8vw,30px)',
                  lineHeight: '1.2',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0 0 16px',
                }}
              >
                What you will do
              </h2>
              <ol
                style={{
                  listStyle: 'none',
                  margin: '0',
                  padding: '0',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '16px',
                }}
              >
                {(v.steps ?? []).map((s, $i0) => (
                  <Fragment key={$i0}>
                    <li style={{ display: 'flex', gap: '16px', alignItems: 'flex-start' }}>
                      <span
                        style={{
                          width: '36px',
                          height: '36px',
                          flex: 'none',
                          borderRadius: '50%',
                          background: 'var(--neutral-900)',
                          color: 'var(--white)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '16px',
                          fontWeight: '700',
                        }}
                      >
                        {s?.n}
                      </span>
                      <span
                        style={{
                          fontFamily: 'var(--font-reading)',
                          fontSize: '19px',
                          lineHeight: '1.6',
                          color: 'var(--text-body)',
                          paddingTop: '4px',
                        }}
                      >
                        {s?.t}
                      </span>
                    </li>
                  </Fragment>
                ))}
              </ol>
            </section>
            <section
              style={{
                marginTop: '40px',
                padding: '28px',
                borderRadius: '20px',
                border: '1px solid var(--border-default)',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--sky-700)',
                  marginBottom: '10px',
                }}
              >
                <Icon name="timer" size={18} color="var(--sky-700)" />
                Family stopwatch
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '16px 24px' }}>
                <span
                  role="timer"
                  aria-live="off"
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '56px',
                    lineHeight: '1',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    fontVariantNumeric: 'tabular-nums',
                    minWidth: '200px',
                  }}
                >
                  {v.clock}
                </span>
                <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                  <Button variant={v.runVariant} icon={v.runIcon} onClick={v.toggleRun}>
                    {v.runLabel}
                  </Button>
                  <Button variant="ghost" icon="rotate-ccw" onClick={v.reset}>
                    Reset
                  </Button>
                </div>
              </div>
              <div
                style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', alignItems: 'flex-start', marginTop: '20px' }}
              >
                <div style={{ flex: '1 1 220px', minWidth: '0' }}>
                  <Input
                    placeholder="Who just played? e.g. Paati"
                    value={v.player}
                    onChange={v.onPlayer}
                    error={v.playerErr}
                    aria-label="Player name"
                  />
                </div>
                <Button variant="secondary" icon="plus" onClick={v.saveTime}>
                  Save time
                </Button>
              </div>
              {v.hasScores ? (
                <ol
                  style={{
                    listStyle: 'none',
                    margin: '20px 0 0',
                    padding: '0',
                    display: 'flex',
                    flexDirection: 'column',
                  }}
                >
                  {(v.scores ?? []).map((r, $i0) => (
                    <Fragment key={$i0}>
                      <li
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '14px',
                          padding: '12px 0',
                          borderTop: '1px solid var(--border-subtle)',
                        }}
                      >
                        <span
                          style={{
                            width: '32px',
                            height: '32px',
                            flex: 'none',
                            borderRadius: '50%',
                            background: r?.bg,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '15px',
                            fontWeight: '700',
                            color: r?.fg,
                          }}
                        >
                          {r?.rank}
                        </span>
                        <span
                          style={{
                            flex: '1',
                            minWidth: '0',
                            fontSize: '17px',
                            fontWeight: '600',
                            color: 'var(--text-strong)',
                          }}
                        >
                          {r?.name}
                        </span>
                        {r?.top ? (
                          <Badge tone="success" icon="trophy">
                            Most focused
                          </Badge>
                        ) : null}
                        <span
                          style={{
                            fontSize: '17px',
                            fontWeight: '700',
                            color: 'var(--text-strong)',
                            fontVariantNumeric: 'tabular-nums',
                          }}
                        >
                          {r?.time}
                        </span>
                      </li>
                    </Fragment>
                  ))}
                </ol>
              ) : null}
            </section>
            <section
              style={{
                marginTop: '40px',
                display: 'flex',
                flexWrap: 'wrap',
                gap: '20px 28px',
                alignItems: 'center',
                padding: '28px',
                borderRadius: '20px',
                background: 'var(--orange-50)',
              }}
            >
              <div
                style={{
                  flex: 'none',
                  width: '120px',
                  height: '120px',
                  position: 'relative',
                  borderRadius: '16px',
                  overflow: 'hidden',
                  background: 'var(--white)',
                }}
              >
                <image-slot
                  id="challenge-14-share"
                  shape="rounded"
                  radius="16"
                  placeholder="Photo: your family mid-wiggle"
                ></image-slot>
              </div>
              <div style={{ flex: '1 1 280px', minWidth: '0' }}>
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    marginBottom: '6px',
                  }}
                >
                  One last thing
                </div>
                <p style={{ fontSize: '17px', lineHeight: '1.55', color: 'var(--text-body)', margin: '0 0 14px' }}>
                  Click a Wiggly-Giggly picture of your family and share it with other parents in the community.
                </p>
                <a href={toUrl('/communities')} style={{ textDecoration: 'none' }}>
                  <Button variant="primary" icon="camera">
                    Share your photo
                  </Button>
                </a>
              </div>
            </section>
          </article>
          <aside style={{ flex: '1 1 300px', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '32px' }}>
            <div style={{ padding: '20px', borderRadius: '20px', background: 'var(--neutral-50)' }}>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                  marginBottom: '12px',
                }}
              >
                All 14 days
              </div>
              <div
                style={{
                  height: '8px',
                  borderRadius: '999px',
                  background: 'var(--neutral-200)',
                  overflow: 'hidden',
                  marginBottom: '14px',
                }}
              >
                <div style={{ width: '100%', height: '100%', background: 'var(--pc-orange)' }}></div>
              </div>
              <ol
                style={{
                  listStyle: 'none',
                  margin: '0',
                  padding: '0',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '2px',
                }}
              >
                {(v.days ?? []).map((d, $i0) => (
                  <Fragment key={$i0}>
                    <li>
                      <a
                        className="hv-a"
                        href={toUrl('/challenge-video')}
                        aria-current={d?.current}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          minHeight: '44px',
                          padding: '6px 10px',
                          borderRadius: '10px',
                          background: d?.bg,
                          textDecoration: 'none',
                          color: 'var(--text-strong)',
                        }}
                      >
                        <span
                          style={{
                            width: '28px',
                            height: '28px',
                            flex: 'none',
                            borderRadius: '50%',
                            background: d?.dotBg,
                            color: d?.dotFg,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '14px',
                            fontWeight: '700',
                          }}
                        >
                          {d?.n}
                        </span>
                        <span style={{ fontSize: '16px', fontWeight: d?.weight, lineHeight: '1.3' }}>{d?.title}</span>
                      </a>
                    </li>
                  </Fragment>
                ))}
              </ol>
            </div>
            <div>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                  marginBottom: '12px',
                }}
              >
                Circles to join
              </div>
              {(v.circles ?? []).map((c, $i0) => (
                <Fragment key={$i0}>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      padding: '12px 0',
                      borderTop: '1px solid var(--border-subtle)',
                    }}
                  >
                    <span
                      style={{
                        width: '44px',
                        height: '44px',
                        flex: 'none',
                        borderRadius: '12px',
                        background: c?.tint,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Icon name="users" size={22} color={c?.ink} />
                    </span>
                    <a
                      className="hv-b"
                      href={toUrl('/communities')}
                      style={{ flex: '1', minWidth: '0', textDecoration: 'none', color: 'inherit' }}
                    >
                      <div style={{ fontSize: '16px', fontWeight: '700', color: 'var(--text-strong)' }}>{c?.name}</div>
                      <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{c?.meta}</div>
                    </a>
                    <Button variant={c?.variant} size="sm" onClick={c?.toggle}>
                      {c?.label}
                    </Button>
                  </div>
                </Fragment>
              ))}
            </div>
          </aside>
        </div>
        <section style={{ marginTop: '80px', padding: '48px 0 72px', borderTop: '1px solid var(--border-subtle)' }}>
          <h2
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(24px,2.8vw,30px)',
              lineHeight: '1.2',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0 0 16px',
            }}
          >
            More for you
          </h2>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,280px),1fr))',
              gap: '36px 24px',
            }}
          >
            {(v.more ?? []).map((m, $i0) => (
              <Fragment key={$i0}>
                <article style={{ display: 'flex', flexDirection: 'column', gap: '10px', minWidth: '0' }}>
                  <div
                    style={{
                      position: 'relative',
                      overflow: 'hidden',
                      aspectRatio: '16 / 10',
                      borderRadius: '16px',
                      background: m?.tint,
                    }}
                  >
                    <image-slot
                      id={`challenge-more-${m?.id ?? ''}`}
                      shape="rounded"
                      radius="16"
                      placeholder={m?.photo}
                    ></image-slot>
                  </div>
                  <span
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: m?.ink,
                    }}
                  >
                    {m?.cat}
                  </span>
                  <a
                    className="hv-5"
                    href={toUrl('/article')}
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '20px',
                      lineHeight: '1.3',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                      textWrap: 'pretty',
                    }}
                  >
                    {m?.title}
                  </a>
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{m?.meta}</span>
                </article>
              </Fragment>
            ))}
          </div>
        </section>
      </main>
      <section aria-labelledby="top-searches" style={{ background: 'var(--neutral-50)' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '48px 24px 56px', boxSizing: 'border-box' }}>
          <h2
            id="top-searches"
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(24px,2.6vw,30px)',
              lineHeight: '1.2',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0 0 18px',
            }}
          >
            Top searches
          </h2>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
            <a
              className="hv-3"
              href="https://www.dotlearningcircle.com/comprehensive-curriculum-for-pre-primary-children"
              target="_blank"
              rel="noopener"
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Kindergarten curriculum
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Parenting%20tips%20for%20infants')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parenting tips for infants
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Parenting%20tips%20for%20toddlers')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parenting tips for toddlers
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Parenting%20tips%20for%20preschoolers')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parenting tips for preschoolers
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Parenting%20tips%20for%20primary%20school%20children')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parenting tips for primary school children
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Parenting%20tips%20for%20pre-teens')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parenting tips for pre-teens
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Parenting%20tips%20for%20teens')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parenting tips for teens
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Parenting%20tips%20for%20parents%20of%20adults')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parenting tips for parents of adults
            </a>
            <a
              className="hv-3"
              href={toUrl('/search?query=Parenting%20tips%20for%20parents')}
              style={{
                height: '44px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1.5px solid var(--border-default)',
                background: 'var(--white)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-strong)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
              Parenting tips for parents
            </a>
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
