import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = {
    theme: '',
    ages: [],
    more: false,
    saved: [],
    joined: false,
    shareOpen: false,
    shared: false,
    f: { name: '', city: '', title: '', story: '', email: '', ok: true },
    err: {},
  };
  AGES = ['Infant', 'Toddler', 'Pre-schooler', 'Primary', 'Pre-teen', 'Teen', '18+', 'Parent'];
  THEMES = {
    'Work and family': ['sky', 'briefcase'],
    'Family life': ['blush', 'users'],
    'Culture and travel': ['butter', 'map'],
    'Health and healing': ['sage', 'heart-pulse'],
    'Learning and growth': ['lilac', 'sprout'],
  };
  LIST = [
    [
      'Working mother and career: finding a healthy balance between work and family',
      'Handling the daily juggle of job and family — and building a fulfilling career after motherhood.',
      'Work and family',
      'Parent',
      'Parent',
      4,
      259,
    ],
    [
      'Moving back to India: how one family rediscovered their roots and belonging',
      'Helping children settle into a new country, a new routine and new friendships.',
      'Culture and travel',
      'Parent',
      'Parent',
      5,
      317,
    ],
    [
      'Family farming and reconnecting with nature: a pandemic story',
      'When life changed, one family found hope in farming, village life and time together.',
      'Family life',
      'Parent',
      'Parent',
      4,
      379,
    ],
    [
      'Family separation challenges: a mother’s journey through loss and healing',
      'Parenting through relocation and uncertainty — and creating stability for the family.',
      'Health and healing',
      'Parent',
      'Parent',
      3,
      358,
    ],
    [
      'Interfaith parenting: raising an empowered daughter across cultures and beliefs',
      'Letting go of expectations and choosing intentional, empowering parenting at every step.',
      'Culture and travel',
      'Parent',
      'Parent',
      3,
      419,
    ],
    [
      'Why self-care matters for working mothers — and happier families',
      'A working mother of two shares honest, practical self-care tips for busy days.',
      'Work and family',
      'Parent',
      'Parent',
      2,
      280,
    ],
    [
      'A mother’s NICU journey: a premature baby’s story of hope and love',
      'Told in a baby’s voice — a story of faith, strength and a mother’s love.',
      'Health and healing',
      'Infant',
      'Parent',
      5,
      918,
    ],
    [
      'Breaking gender stereotypes at home: one Indian parent’s everyday story',
      'Small, conscious choices that help raise a confident, empathetic child free of labels.',
      'Family life',
      'Infant',
      'Parent',
      8,
      4900,
    ],
    [
      'A real motherhood journey and honest conversations about modern parenting',
      'How becoming a mother reshaped one woman’s priorities and built a supportive community.',
      'Family life',
      'Parent',
      'Parent',
      3,
      451,
    ],
    [
      'A family’s journey through heritage travel: history, faith and togetherness',
      'From Hampi and Badami to Tanjore — temple journeys that became family memories.',
      'Culture and travel',
      'Parent',
      'Parent',
      7,
      888,
    ],
    [
      'Why I chose adoption: a mother’s journey into parenthood beyond biology',
      'On identity, bonding and the misconceptions — and why love defines a parent.',
      'Family life',
      'Parent',
      'Parent',
      7,
      847,
    ],
    [
      'Tracking emotional development in children: a new parenting approach',
      'Why feelings deserve the same attention as physical milestones.',
      'Learning and growth',
      'Parent',
      'Parent',
      1,
      549,
    ],
    [
      'Children’s education and exam success: lessons from a mother’s journey',
      'A mother of two on guiding her daughters through board exams with balance and encouragement.',
      'Learning and growth',
      'Parent',
      'Parent',
      4,
      671,
    ],
    [
      'How a mother redefined recovery after childbirth: a postpartum travel story',
      'Gentle travel after a C-section helped with healing, wellbeing and a sense of self.',
      'Health and healing',
      'Infant',
      'Parent',
      3,
      591,
    ],
    [
      'Single dad raising twin daughters: parenting and entrepreneurship',
      'A fashion entrepreneur on raising twins while building a brand.',
      'Work and family',
      'Parent',
      'Parent',
      3,
      4900,
    ],
    [
      '“I fought cancer with my daughter”: a father’s story of love and resilience',
      'A single father on battling cancer while raising his daughter — and the healing power of presence.',
      'Health and healing',
      'Parent',
      'Parent',
      3,
      8500,
    ],
    [
      'A mother’s journey through the pandemic: online teaching, art and beach clean-ups',
      'How one mother found resilience through creativity and community service.',
      'Work and family',
      'Parent',
      'Parent',
      3,
      8500,
    ],
    [
      '“After several failed attempts, I successfully breastfed my baby”',
      'Breastfeeding her first child was hard; the second time was easier. One mother’s story.',
      'Health and healing',
      'Infant',
      'Parent',
      2,
      9000,
    ],
  ];
  POPULAR = [
    ['A mother’s NICU journey: a premature baby’s story of hope and love', 5, 918],
    ['Here’s what I did when my son snapped at me for the first time', 2, 8300],
    ['Heavy snowfall, no power, stuck in a Himachal hotel with a child', 3, 2900],
    ['How fatherhood reframed my life', 2, 8100],
    ['Breastfeeding stories: four mothers share their honest experiences', 15, 9600],
    ['“I use technology for family communication, and balance it with outdoor time”', 4, 8200],
  ];
  DISC = [
    ['Navratri trivia', '9 comments'],
    ['Valentine’s Day special: parent–child role-swap photo contest', '7 comments'],
    ['Christmas and New Year decor contest', '100 comments'],
    ['Festive family recipe and photo contest', '14 comments'],
  ];
  TOP = [
    'Parent stories',
    'Grandparent stories',
    'Joint families',
    'Single parent families',
    'Adoptive families',
    'Festivals and celebrations',
    'Culture and tradition',
    'Families with pets',
    'Baby names',
    'Parenting styles',
    'Managing emotions',
    'Family relationships',
  ];
  chip(on) {
    return on
      ? { bg: 'var(--neutral-900)', fg: 'var(--white)', bd: 'var(--neutral-900)' }
      : { bg: 'var(--white)', fg: 'var(--text-strong)', bd: 'var(--border-default)' };
  }
  views(n) {
    return n >= 1000 ? (Math.round(n / 100) / 10).toString().replace(/\.0$/, '') + 'K views' : n + ' views';
  }
  shape(r) {
    const [title, dek, theme, a0, a1, min, v] = r,
      [hue, icon] = this.THEMES[theme],
      on = this.state.saved.includes(title);
    const idx = this.LIST.indexOf(r);
    return {
      slot: 's' + idx,
      img: idx < 4 ? 'images/poi-' + idx + '.png' : '',
      photo:
        'Photo: ' +
        ([
          'Working mother hugging her child before leaving for office',
          'Family unpacking boxes in their new home in India',
          'Children and grandparents planting seedlings in a field',
          'Mother and child sitting together by a window',
          'Mother and daughter at a festival from two traditions',
          'Mother enjoying a quiet cup of tea at home',
          'Premature baby in the NICU holding a mother’s finger',
          'Father and daughter cooking together in the kitchen',
          'New mother chatting with other parents at a meetup',
          'Family exploring the temples at Hampi',
          'Mother holding her adopted child close',
          'Parent and child drawing a feelings chart together',
          'Mother helping her daughter prepare for board exams',
          'Mother with her baby on a gentle hill-station walk',
          'Single father walking his twin daughters to school',
          'Father and daughter smiling together at home',
          'Mother and child collecting litter on a beach',
          'Mother feeding her newborn in a calm room',
        ][idx] || title),
      title,
      dek,
      theme,
      icon,
      tint: 'var(--' + hue + '-50)',
      ink: 'var(--' + hue + '-700)',
      meta: (a0 === a1 ? a0 : a0 + ' to ' + a1) + ' · ' + min + ' min read · ' + this.views(v),
      saveIcon: on ? 'bookmark-check' : 'bookmark',
      saveLabel: on ? 'Saved' : 'Save story',
      saveText: on ? 'Saved' : 'Save',
      toggleSave: () =>
        this.setState((s) => ({
          saved: s.saved.includes(title) ? s.saved.filter((x) => x !== title) : s.saved.concat(title),
        })),
    };
  }
  setF(k, v) {
    this.setState((s) => ({ f: { ...s.f, [k]: v }, err: { ...s.err, [k]: undefined } }));
  }
  submitShare = () => {
    const f = this.state.f,
      e = {};
    if (!f.name.trim()) e.name = 'Please add your name.';
    if (!f.title.trim()) e.title = 'Please add a short title.';
    if (f.story.trim().length < 40) e.story = 'Please tell us a little more — a few sentences is perfect.';
    if (!/\S+@\S+\.\S+/.test(f.email)) e.email = 'Please add an email so our editors can reach you.';
    if (Object.keys(e).length) return this.setState({ err: e });
    this.setState({
      shareOpen: false,
      shared: true,
      err: {},
      f: { name: '', city: '', title: '', story: '', email: '', ok: true },
    });
  };
  renderVals() {
    const S = this.state;
    const span = (a0, a1) => this.AGES.slice(this.AGES.indexOf(a0), this.AGES.indexOf(a1) + 1);
    const rows = this.LIST.filter(
      (r) => (!S.theme || r[2] === S.theme) && (!S.ages.length || span(r[3], r[4]).some((a) => S.ages.includes(a))),
    );
    const nf = (S.theme ? 1 : 0) + S.ages.length;
    const showLead = nf === 0;
    const rest = showLead ? rows.slice(1) : rows;
    const lim = S.more ? rest : rest.slice(0, 8);
    return {
      themeChips: ['']
        .concat(Object.keys(this.THEMES))
        .map((t) => ({
          label: t || 'All',
          on: S.theme === t,
          toggle: () => this.setState({ theme: t, more: false }),
          ...this.chip(S.theme === t),
        })),
      ageChips: this.AGES.map((a) => ({
        label: a,
        on: S.ages.includes(a),
        toggle: () =>
          this.setState((s) => ({
            ages: s.ages.includes(a) ? s.ages.filter((x) => x !== a) : s.ages.concat(a),
            more: false,
          })),
        ...this.chip(S.ages.includes(a)),
      })),
      countLabel: rows.length === 1 ? '1 story' : rows.length + ' stories',
      hasFilters: nf > 0,
      clearFilters: () => this.setState({ theme: '', ages: [], more: false }),
      showLead,
      lead: this.shape(this.LIST[0]),
      stories: lim.map((r) => this.shape(r)),
      empty: rows.length === 0,
      canMore: !S.more && rest.length > 8,
      showMore: () => this.setState({ more: true }),
      popular: this.POPULAR.map(([title, min, v], i) => ({
        n: i + 1,
        title,
        meta: min + ' min read · ' + this.views(v),
      })),
      discussions: this.DISC.map(([title, meta]) => ({ title, meta: meta + ' · Joy of Celebration' })),
      joinLabel: S.joined ? 'Joined' : 'Join circle',
      joinVariant: S.joined ? 'secondary' : 'dark',
      joinIcon: S.joined ? 'check' : 'plus',
      toggleJoin: () => this.setState((s) => ({ joined: !s.joined })),
      topSearches: this.TOP.map((t) => ({ label: t, href: '/search?query=' + encodeURIComponent(t) })),
      shareOpen: S.shareOpen,
      shared: S.shared,
      openShare: () => this.setState({ shareOpen: true, err: {} }),
      closeShare: () => this.setState({ shareOpen: false }),
      fName: S.f.name,
      fCity: S.f.city,
      fTitle: S.f.title,
      fStory: S.f.story,
      fEmail: S.f.email,
      fOk: S.f.ok,
      notOk: !S.f.ok,
      onFName: (e) => this.setF('name', e.target.value),
      onFCity: (e) => this.setF('city', e.target.value),
      onFTitle: (e) => this.setF('title', e.target.value),
      onFStory: (e) => this.setF('story', e.target.value),
      onFEmail: (e) => this.setF('email', e.target.value),
      onFOk: (v) => this.setF('ok', typeof v === 'boolean' ? v : !S.f.ok),
      err: { name: S.err.name, title: S.err.title, story: S.err.story, email: S.err.email },
      submitShare: this.submitShare,
    };
  }
}

export default PageLogic;
