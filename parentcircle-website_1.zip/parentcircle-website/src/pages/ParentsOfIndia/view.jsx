import { Fragment } from 'react';
import { Button, Checkbox, Dialog, Icon, IconButton, Input } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Parents of India" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Parents of India"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader active="read" />
      <main>
        <section style={{ background: 'var(--blush-50)' }}>
          <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '28px 24px 56px', boxSizing: 'border-box' }}>
            <nav
              aria-label="Breadcrumb"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                flexWrap: 'wrap',
                fontSize: '15px',
                color: 'var(--text-muted)',
                marginBottom: '28px',
              }}
            >
              <a
                className="hv-1"
                href={toUrl('/')}
                style={{ color: 'var(--text-muted)', textDecoration: 'none', fontWeight: '600' }}
              >
                Home
              </a>
              <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
              <span>Parents of India</span>
            </nav>
            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: '28px 56px',
                alignItems: 'flex-end',
                justifyContent: 'space-between',
              }}
            >
              <div style={{ flex: '1 1 520px', minWidth: '0' }}>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--blush-700)',
                    marginBottom: '12px',
                  }}
                >
                  <Icon name="map-pin" size={18} color="var(--blush-700)" />
                  #ParentsOfIndia
                </div>
                <h1
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: 'clamp(38px,5vw,60px)',
                    lineHeight: '1.08',
                    letterSpacing: '-0.015em',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0',
                    textWrap: 'balance',
                  }}
                >
                  Parents of India
                </h1>
                <p
                  style={{
                    fontFamily: 'var(--font-serif)',
                    fontSize: '22px',
                    lineHeight: '1.55',
                    color: 'var(--text-body)',
                    margin: '16px 0 0',
                    maxWidth: '600px',
                    textWrap: 'pretty',
                  }}
                >
                  Every Indian parent has a story to tell. Real stories from families across the country — told in their
                  own words.
                </p>
              </div>
              <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                <Button variant="primary" size="lg" icon="pen-line" onClick={v.openShare}>
                  Share your story
                </Button>
                <a href={toUrl('/communities')} style={{ textDecoration: 'none' }}>
                  <Button variant="secondary" size="lg" icon="users">
                    Join the community
                  </Button>
                </a>
              </div>
            </div>
            <div
              style={{
                marginTop: '32px',
                position: 'relative',
                aspectRatio: '21 / 7',
                borderRadius: '24px',
                overflow: 'hidden',
                background: 'var(--white)',
              }}
            >
              <image-slot
                id="poi-hero"
                shape="rounded"
                radius="24"
                placeholder="Photo: a collage of real families from across India — parents, grandparents and children"
              ></image-slot>
            </div>
            {v.shared ? (
              <div
                role="status"
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '10px',
                  marginTop: '20px',
                  padding: '12px 16px',
                  borderRadius: '12px',
                  background: 'var(--white)',
                  color: 'var(--sage-700)',
                  fontSize: '17px',
                  fontWeight: '600',
                  boxShadow: 'var(--shadow-sm)',
                }}
              >
                <Icon name="circle-check" size={22} color="var(--sage-700)" />
                Thank you! Our editors will read your story and get in touch.
              </div>
            ) : null}
          </div>
        </section>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '32px 24px 0', boxSizing: 'border-box' }}>
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
              padding: '28px',
              borderRadius: '24px',
              background: 'var(--neutral-50)',
            }}
          >
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '12px',
                flexWrap: 'wrap',
                marginBottom: '2px',
              }}
            >
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                }}
              >
                Filter stories
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                {v.hasFilters ? (
                  <button
                    className="hv-8"
                    type="button"
                    onClick={v.clearFilters}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px',
                      border: '0',
                      background: 'none',
                      padding: '6px 0',
                      font: 'inherit',
                      fontSize: '15px',
                      fontWeight: '700',
                      color: 'var(--text-link)',
                      cursor: 'pointer',
                    }}
                  >
                    <Icon name="x" size={16} color="currentColor" />
                    Clear filters
                  </button>
                ) : null}
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{v.countLabel}</span>
              </div>
            </div>
            <div style={{ display: 'flex', gap: '10px 16px', flexWrap: 'wrap', alignItems: 'center' }}>
              <span
                style={{
                  flex: 'none',
                  width: '92px',
                  fontSize: '15px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                }}
              >
                Theme
              </span>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', flex: '1', minWidth: '0' }}>
                {(v.themeChips ?? []).map((t, $i0) => (
                  <Fragment key={$i0}>
                    <button
                      type="button"
                      aria-pressed={t?.on}
                      onClick={t?.toggle}
                      style={{
                        height: '40px',
                        padding: '0 14px',
                        borderRadius: '999px',
                        border: `1.5px solid ${t?.bd ?? ''}`,
                        background: t?.bg,
                        color: t?.fg,
                        font: 'inherit',
                        fontSize: '15px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        transition: 'background 150ms',
                      }}
                    >
                      {t?.label}
                    </button>
                  </Fragment>
                ))}
              </div>
            </div>
            <div style={{ display: 'flex', gap: '10px 16px', flexWrap: 'wrap', alignItems: 'center' }}>
              <span
                style={{
                  flex: 'none',
                  width: '92px',
                  fontSize: '15px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                }}
              >
                Age group
              </span>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', flex: '1', minWidth: '0' }}>
                {(v.ageChips ?? []).map((a, $i0) => (
                  <Fragment key={$i0}>
                    <button
                      type="button"
                      aria-pressed={a?.on}
                      onClick={a?.toggle}
                      style={{
                        height: '40px',
                        padding: '0 14px',
                        borderRadius: '999px',
                        border: `1.5px solid ${a?.bd ?? ''}`,
                        background: a?.bg,
                        color: a?.fg,
                        font: 'inherit',
                        fontSize: '15px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        transition: 'background 150ms',
                      }}
                    >
                      {a?.label}
                    </button>
                  </Fragment>
                ))}
              </div>
            </div>
          </div>
        </section>
        <section
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '32px 24px 0',
            boxSizing: 'border-box',
            display: 'flex',
            flexWrap: 'wrap',
            gap: '48px 56px',
            alignItems: 'flex-start',
          }}
        >
          <div style={{ flex: '999 1 560px', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '40px' }}>
            {v.showLead ? (
              <article
                style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '20px 32px',
                  alignItems: 'flex-start',
                  paddingBottom: '40px',
                  borderBottom: '1px solid var(--border-subtle)',
                }}
              >
                <div
                  className="hv-o"
                  style={{
                    flex: '1 1 300px',
                    minWidth: '0',
                    position: 'relative',
                    overflow: 'hidden',
                    aspectRatio: '4 / 3',
                    borderRadius: '24px',
                    background: v.lead?.tint,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    transition: 'transform 200ms cubic-bezier(.2,0,0,1), box-shadow 200ms cubic-bezier(.2,0,0,1)',
                  }}
                >
                  <image-slot
                    id={`poi-${v.lead?.slot ?? ''}`}
                    shape="rounded"
                    radius="24"
                    src={toUrl(v.lead?.img)}
                    placeholder={v.lead?.photo}
                  ></image-slot>
                </div>
                <div
                  style={{ flex: '1.2 1 300px', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '12px' }}
                >
                  <span
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: v.lead?.ink,
                    }}
                  >
                    {'Latest · '}
                    {v.lead?.theme}
                  </span>
                  <a
                    className="hv-5"
                    href={toUrl('/article')}
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: 'clamp(26px,3vw,34px)',
                      lineHeight: '1.2',
                      letterSpacing: '-0.01em',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                      textWrap: 'balance',
                    }}
                  >
                    {v.lead?.title}
                  </a>
                  <p
                    style={{
                      fontFamily: 'var(--font-serif)',
                      fontSize: '19px',
                      lineHeight: '1.6',
                      color: 'var(--text-body)',
                      margin: '0',
                      textWrap: 'pretty',
                    }}
                  >
                    {v.lead?.dek}
                  </p>
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{v.lead?.meta}</span>
                  <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginTop: '4px' }}>
                    <a href={toUrl('/article')} style={{ textDecoration: 'none' }}>
                      <Button variant="primary" iconRight="arrow-right">
                        Read story
                      </Button>
                    </a>
                    <Button variant="secondary" icon={v.lead?.saveIcon} onClick={v.lead?.toggleSave}>
                      {v.lead?.saveText}
                    </Button>
                  </div>
                </div>
              </article>
            ) : null}
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,260px),1fr))',
                gap: '36px 24px',
              }}
            >
              {(v.stories ?? []).map((s, $i0) => (
                <Fragment key={$i0}>
                  <article style={{ display: 'flex', flexDirection: 'column', gap: '10px', minWidth: '0' }}>
                    <div
                      className="hv-o"
                      style={{
                        position: 'relative',
                        overflow: 'hidden',
                        aspectRatio: '16 / 10',
                        borderRadius: '16px',
                        background: s?.tint,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        transition: 'transform 200ms cubic-bezier(.2,0,0,1), box-shadow 200ms cubic-bezier(.2,0,0,1)',
                      }}
                    >
                      <image-slot
                        id={`poi-${s?.slot ?? ''}`}
                        shape="rounded"
                        radius="16"
                        src={toUrl(s?.img)}
                        placeholder={s?.photo}
                      ></image-slot>
                    </div>
                    <span
                      style={{
                        fontSize: '14px',
                        fontWeight: '700',
                        letterSpacing: '0.08em',
                        textTransform: 'uppercase',
                        color: s?.ink,
                      }}
                    >
                      {s?.theme}
                    </span>
                    <a
                      className="hv-5"
                      href={toUrl('/article')}
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '20px',
                        lineHeight: '1.3',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        textDecoration: 'none',
                        textWrap: 'pretty',
                      }}
                    >
                      {s?.title}
                    </a>
                    <p
                      style={{
                        fontFamily: 'var(--font-serif)',
                        fontSize: '17px',
                        lineHeight: '1.5',
                        color: 'var(--text-body)',
                        margin: '0',
                        display: '-webkit-box',
                        WebkitLineClamp: '3',
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden',
                      }}
                    >
                      {s?.dek}
                    </p>
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: '8px',
                        marginTop: 'auto',
                        paddingTop: '4px',
                      }}
                    >
                      <span style={{ fontSize: '15px', lineHeight: '1.4', color: 'var(--text-muted)' }}>{s?.meta}</span>
                      <IconButton icon={s?.saveIcon} label={s?.saveLabel} onClick={s?.toggleSave} />
                    </div>
                  </article>
                </Fragment>
              ))}
            </div>
            {v.empty ? (
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'flex-start',
                  gap: '12px',
                  padding: '28px',
                  borderRadius: '20px',
                  background: 'var(--neutral-50)',
                }}
              >
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                  }}
                >
                  No stories match these filters yet
                </div>
                <p style={{ fontSize: '17px', color: 'var(--text-body)', margin: '0' }}>
                  Try another theme or age — or be the first to share one.
                </p>
                <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                  <Button variant="dark" icon="x" onClick={v.clearFilters}>
                    Clear filters
                  </Button>
                  <Button variant="secondary" icon="pen-line" onClick={v.openShare}>
                    Share your story
                  </Button>
                </div>
              </div>
            ) : null}
            {v.canMore ? (
              <div style={{ display: 'flex', justifyContent: 'center' }}>
                <Button variant="secondary" icon="chevron-down" onClick={v.showMore}>
                  Load more stories
                </Button>
              </div>
            ) : null}
          </div>
          <aside style={{ flex: '1 1 300px', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '32px' }}>
            <div>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                  marginBottom: '12px',
                }}
              >
                Most read
              </div>
              <ol style={{ listStyle: 'none', margin: '0', padding: '0', display: 'flex', flexDirection: 'column' }}>
                {(v.popular ?? []).map((p, $i0) => (
                  <Fragment key={$i0}>
                    <li style={{ borderTop: '1px solid var(--border-subtle)' }}>
                      <a
                        className="hv-c"
                        href={toUrl('/article')}
                        style={{
                          display: 'flex',
                          gap: '14px',
                          alignItems: 'flex-start',
                          padding: '14px 0',
                          textDecoration: 'none',
                          color: 'inherit',
                        }}
                      >
                        <span
                          style={{
                            fontFamily: 'var(--font-display)',
                            fontSize: '28px',
                            lineHeight: '1',
                            fontWeight: '700',
                            color: 'var(--pc-orange)',
                            width: '24px',
                            flex: 'none',
                          }}
                        >
                          {p?.n}
                        </span>
                        <span style={{ display: 'flex', flexDirection: 'column', gap: '4px', minWidth: '0' }}>
                          <span
                            style={{
                              fontFamily: 'var(--font-display)',
                              fontSize: '17px',
                              lineHeight: '1.35',
                              fontWeight: '700',
                              color: 'var(--text-strong)',
                              textWrap: 'pretty',
                            }}
                          >
                            {p?.title}
                          </span>
                          <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{p?.meta}</span>
                        </span>
                      </a>
                    </li>
                  </Fragment>
                ))}
              </ol>
            </div>
            <div
              style={{
                padding: '24px',
                borderRadius: '16px',
                background: 'var(--butter-50)',
                display: 'flex',
                flexDirection: 'column',
                gap: '14px',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <span
                  style={{
                    width: '56px',
                    height: '56px',
                    flex: 'none',
                    position: 'relative',
                    overflow: 'hidden',
                    borderRadius: '50%',
                    background: 'var(--white)',
                  }}
                >
                  <image-slot
                    id="poi-circle-joy"
                    shape="circle"
                    placeholder="Photo: families celebrating a festival together"
                  ></image-slot>
                </span>
                <div>
                  <div
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '20px',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                    }}
                  >
                    Joy of Celebration
                  </div>
                  <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>2.2K members</div>
                </div>
              </div>
              <p style={{ fontSize: '16px', lineHeight: '1.5', color: 'var(--text-body)', margin: '0' }}>
                Festivals, family traditions and contests — share yours with parents across India.
              </p>
              <Button variant={v.joinVariant} icon={v.joinIcon} fullWidth={true} onClick={v.toggleJoin}>
                {v.joinLabel}
              </Button>
            </div>
            <div>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                  marginBottom: '12px',
                }}
              >
                Discussions
              </div>
              {(v.discussions ?? []).map((d, $i0) => (
                <Fragment key={$i0}>
                  <a
                    className="hv-c"
                    href={toUrl('/communities')}
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '4px',
                      padding: '14px 0',
                      borderTop: '1px solid var(--border-subtle)',
                      textDecoration: 'none',
                      color: 'inherit',
                    }}
                  >
                    <span
                      style={{
                        fontSize: '17px',
                        lineHeight: '1.4',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        textWrap: 'pretty',
                      }}
                    >
                      {d?.title}
                    </span>
                    <span
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        fontSize: '15px',
                        color: 'var(--text-muted)',
                      }}
                    >
                      <Icon name="message-circle" size={16} color="currentColor" />
                      {d?.meta}
                    </span>
                  </a>
                </Fragment>
              ))}
            </div>
          </aside>
        </section>
        <section style={{ marginTop: '80px', background: 'var(--neutral-50)' }}>
          <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '48px 24px 56px', boxSizing: 'border-box' }}>
            <h2
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(24px,2.6vw,30px)',
                lineHeight: '1.2',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 18px',
              }}
            >
              Top searches
            </h2>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
              {(v.topSearches ?? []).map((t, $i0) => (
                <Fragment key={$i0}>
                  <a
                    className="hv-3"
                    href={toUrl(t?.href)}
                    style={{
                      height: '44px',
                      padding: '0 16px',
                      borderRadius: '999px',
                      border: '1.5px solid var(--border-default)',
                      background: 'var(--white)',
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-strong)',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="arrow-up-right" size={16} color="var(--text-muted)" />
                    {t?.label}
                  </a>
                </Fragment>
              ))}
            </div>
          </div>
        </section>
      </main>
      {v.shareOpen ? (
        <Dialog title="Share your story" width={600} onClose={v.closeShare}>
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
              maxHeight: 'calc(100vh - 200px)',
              overflow: 'auto',
              padding: '4px',
              margin: '0 -4px',
            }}
          >
            <p style={{ fontSize: '16px', lineHeight: '1.5', color: 'var(--text-muted)', margin: '0' }}>
              A moment that changed you, a lesson you learned, a tradition you love — we’d love to hear it.
            </p>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,200px),1fr))',
                gap: '12px',
              }}
            >
              <Input label="Your name" value={v.fName} onChange={v.onFName} error={v.err?.name} />
              <Input label="City" icon="map-pin" value={v.fCity} onChange={v.onFCity} />
            </div>
            <Input label="Give your story a title" value={v.fTitle} onChange={v.onFTitle} error={v.err?.title} />
            <Input
              label="Your story"
              multiline={true}
              rows={6}
              placeholder="Tell it the way you would to a friend."
              value={v.fStory}
              onChange={v.onFStory}
              error={v.err?.story}
            />
            <Input label="Email" type="email" icon="mail" value={v.fEmail} onChange={v.onFEmail} error={v.err?.email} />
            <Checkbox label="ParentCircle may edit and publish my story" checked={v.fOk} onChange={v.onFOk} />
            <div
              style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end', flexWrap: 'wrap', marginTop: '4px' }}
            >
              <Button variant="ghost" onClick={v.closeShare}>
                Cancel
              </Button>
              <Button variant="primary" icon="send" disabled={v.notOk} onClick={v.submitShare}>
                Send my story
              </Button>
            </div>
          </div>
        </Dialog>
      ) : null}
      <SiteFooter />
    </div>
  );
}
