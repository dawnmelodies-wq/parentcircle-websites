import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = {
    rs: 21,
    liked: false,
    saved: false,
    copied: false,
    listening: false,
    lang: null,
    progress: 0,
    active: 'what',
    helpful: null,
    draft: '',
    following: false,
    joined: false,
    done: [],
    comments: [
      {
        id: 'c1',
        name: 'Divya R',
        when: '2 days ago',
        text: 'The “name the feeling” step changed bedtime for us. My 3-year-old now says “I’m cross” instead of throwing her pillow. Not every night — but most nights!',
      },
      {
        id: 'c2',
        name: 'Mohan Krishnan',
        when: '1 week ago',
        text: 'As a grandfather, the part about everyone handling it the same way hit home. We sat down as a family after reading this.',
      },
    ],
  };

  bodyRef = React.createRef();
  asideRef = React.createRef();
  checkWrap = () => {
    const a = this.asideRef.current,
      b = this.bodyRef.current;
    if (!a || !b) return;
    const wrapped = Math.abs(a.offsetTop - b.offsetTop) > 10;
    if (wrapped !== !!this.state.wrapped) this.setState({ wrapped });
  };
  tocList = [
    { id: 'what', label: 'What is a tantrum?' },
    { id: 'why', label: 'Two kinds of tantrum' },
    { id: 'emotional', label: 'Emotional tantrums' },
    { id: 'peace', label: 'The P.E.A.C.E. method' },
    { id: 'intentional', label: 'Intentional tantrums' },
    { id: 'nutshell', label: 'In a nutshell' },
    { id: 'today', label: 'Try this week' },
  ];
  checks = [
    'Note what sets off each tantrum, and how your child reacts.',
    'Decide if a tantrum is emotional or intentional — then respond to match.',
    'Talk about feelings on calm days too, and practise feeling words together.',
  ];
  moreList = [
    {
      id: 'calm',
      photo: 'Photo: a mother holding her toddler close after a meltdown',
      title: 'Taming toddler tantrums: practical ways to calm big emotions',
      category: 'Emotional wellness',
      topic: 'emotions',
      author: 'ParentCircle team',
      readTime: '6 min read',
    },
    {
      id: 'behaviour',
      photo: 'Photo: a preschooler and father talking at eye level',
      title: '5 common behaviour problems in preschoolers — and what helps',
      category: 'Behaviour',
      topic: 'emotions',
      author: 'Dr. Meera Iyer',
      readTime: '7 min read',
    },
    {
      id: 'school',
      photo: 'Photo: a child in uniform holding a parent’s hand at the school gate',
      title: '7 ways to ease back-to-school worries',
      category: 'School & learning',
      topic: 'learning',
      author: 'Lakshmi Venkat',
      readTime: '5 min read',
    },
  ];
  toTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });

  componentDidMount() {
    this._onScroll = () => {
      if (this._raf) return;
      this._raf = requestAnimationFrame(() => {
        this._raf = null;
        const el = this.bodyRef.current;
        if (!el) return;
        const r = el.getBoundingClientRect();
        const p = Math.min(
          1,
          Math.max(0, (window.innerHeight * 0.3 - r.top) / Math.max(1, r.height - window.innerHeight * 0.5)),
        );
        let active = this.tocList[0].id;
        for (const t of this.tocList) {
          const h = document.getElementById(t.id);
          if (h && h.getBoundingClientRect().top < 140) active = t.id;
        }
        if (Math.abs(p - this.state.progress) > 0.004 || active !== this.state.active)
          this.setState({ progress: p, active });
      });
    };
    window.addEventListener('scroll', this._onScroll, { passive: true });
    window.addEventListener('resize', this.checkWrap);
    this._ro = window.ResizeObserver ? new ResizeObserver(this.checkWrap) : null;
    if (this._ro && this.bodyRef.current) this._ro.observe(this.bodyRef.current.parentNode);
    setTimeout(this.checkWrap, 50);
  }
  componentWillUnmount() {
    window.removeEventListener('scroll', this._onScroll);
    window.removeEventListener('resize', this.checkWrap);
    if (this._ro) this._ro.disconnect();
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    clearTimeout(this._copyT);
  }

  toggleListen = () => {
    const ss = window.speechSynthesis;
    if (!ss) return;
    if (this.state.listening) {
      ss.cancel();
      this.setState({ listening: false });
      return;
    }
    const u = new SpeechSynthesisUtterance((this.bodyRef.current && this.bodyRef.current.innerText) || '');
    u.lang = 'en-IN';
    u.rate = 0.95;
    u.onend = () => this.setState({ listening: false });
    ss.cancel();
    ss.speak(u);
    this.setState({ listening: true });
  };
  share = () => {
    try {
      navigator.clipboard && navigator.clipboard.writeText(window.location.href);
    } catch (e) {}
    this.setState({ copied: true });
    clearTimeout(this._copyT);
    this._copyT = setTimeout(() => this.setState({ copied: false }), 2500);
  };
  postComment = () => {
    const t = this.state.draft.trim();
    if (!t) return;
    this.setState((s) => ({
      draft: '',
      comments: [{ id: 'n' + Date.now(), name: 'You', when: 'Just now', text: t }, ...s.comments],
    }));
  };

  renderVals() {
    const S = this.state;
    const lang = S.lang ?? 'en';
    const n = S.comments.length;
    const doneCount = S.done.length;
    return {
      isEn: true,
      isTa: false,
      progressPct: Math.round(S.progress * 1000) / 10 + '%',
      bodyRef: this.bodyRef,
      asideRef: this.asideRef,
      asidePos: S.wrapped ? 'static' : 'sticky',
      rs: S.rs + 'px',
      smaller: () => this.setState((s) => ({ rs: Math.max(18, s.rs - 2) })),
      larger: () => this.setState((s) => ({ rs: Math.min(27, s.rs + 2) })),
      liked: S.liked,
      likeCount: S.liked ? '5,601' : '5,600',
      toggleLike: () => this.setState((s) => ({ liked: !s.liked })),
      commentCount: String(n),
      commentHeading: n === 1 ? '1 comment' : n + ' comments',
      goComments: () => {
        const el = document.getElementById('comments');
        if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 88, behavior: 'smooth' });
      },
      saved: S.saved,
      saveIcon: S.saved ? 'bookmark-check' : 'bookmark',
      toggleSave: () => this.setState((s) => ({ saved: !s.saved })),
      share: this.share,
      shareLabel: S.copied ? 'Link copied' : 'Share',
      toggleListen: this.toggleListen,
      listenLabel: S.listening ? 'Stop' : 'Listen',
      listenIcon: S.listening ? 'square' : 'volume-2',
      listenVariant: S.listening ? 'soft' : 'secondary',
      followLabel: S.following ? 'Following' : 'Follow',
      followIcon: S.following ? 'check' : 'user-plus',
      followVariant: S.following ? 'ghost' : 'secondary',
      toggleFollow: () => this.setState((s) => ({ following: !s.following })),
      joinLabel: S.joined ? 'Joined' : 'Join circle',
      joinIcon: S.joined ? 'check' : 'plus',
      joinVariant: S.joined ? 'secondary' : 'dark',
      toggleJoin: () => this.setState((s) => ({ joined: !s.joined })),
      toc: this.tocList.map((t) => {
        const on = S.active === t.id;
        return {
          ...t,
          href: '#' + t.id,
          fg: on ? 'var(--text-strong)' : 'var(--text-muted)',
          bg: on ? 'var(--neutral-100)' : 'transparent',
          fw: on ? 600 : 400,
        };
      }),
      checklist: this.checks.map((label, i) => ({
        label,
        checked: S.done.includes(i),
        onChange: () =>
          this.setState((s) => ({ done: s.done.includes(i) ? s.done.filter((x) => x !== i) : [...s.done, i] })),
      })),
      doneLabel:
        doneCount === this.checks.length ? 'All done — well done!' : doneCount + ' of ' + this.checks.length + ' done',
      askHelpful: S.helpful === null,
      answeredHelpful: S.helpful !== null,
      helpfulYes: () => this.setState({ helpful: 'yes' }),
      helpfulNo: () => this.setState({ helpful: 'no' }),
      helpfulThanks:
        S.helpful === 'yes'
          ? 'Thank you — we’re glad it helped.'
          : 'Thank you for telling us. We’ll use this to improve.',
      draft: S.draft,
      draftEmpty: !S.draft.trim(),
      onDraft: (e) => this.setState({ draft: e.target.value }),
      postComment: this.postComment,
      comments: S.comments,
      more: this.moreList.map((a) => {
        const hue =
          { health: 'sage', learning: 'sky', emotions: 'blush', play: 'butter', teens: 'lilac' }[a.topic] || 'neutral';
        return {
          ...a,
          tint: 'var(--' + hue + '-50)',
          ink: 'var(--' + hue + '-700)',
          meta: a.author + ' · ' + a.readTime,
          onClick: this.toTop,
        };
      }),
    };
  }
}

export default PageLogic;
