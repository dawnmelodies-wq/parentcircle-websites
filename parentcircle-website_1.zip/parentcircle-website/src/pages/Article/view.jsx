import { Fragment } from 'react';
import { Avatar, Badge, Button, Card, Checkbox, Icon, IconButton, Input, Tag } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Article" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Article"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader active="read" />
      <main style={{ maxWidth: '1088px', margin: '0 auto', padding: '28px 24px 0', boxSizing: 'border-box' }}>
        <nav
          aria-label="Breadcrumb"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            flexWrap: 'wrap',
            fontSize: '15px',
            color: 'var(--text-muted)',
            marginBottom: '28px',
          }}
        >
          <a
            className="hv-1"
            href={toUrl('/')}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              color: 'var(--text-muted)',
              textDecoration: 'none',
              fontWeight: '600',
            }}
          >
            <Icon name="arrow-left" size={18} />
            Home
          </a>
          <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
          <a className="hv-1" href="#" style={{ color: 'var(--text-muted)', textDecoration: 'none' }}>
            Parenting
          </a>
          <Icon name="chevron-right" size={16} color="var(--neutral-400)" />
          <a className="hv-1" href="#" style={{ color: 'var(--text-muted)', textDecoration: 'none' }}>
            Managing child behaviour
          </a>
        </nav>
        <div style={{ maxWidth: '780px' }}>
          <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap', marginBottom: '18px' }}>
            <span
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--blush-700)',
              }}
            >
              Managing behaviour
            </span>
            <Badge tone="success">Expert verified</Badge>
            <Badge tone="neutral">Ages 1–6</Badge>
          </div>
          {v.isEn ? (
            <Fragment>
              <h1
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(34px,4.4vw,52px)',
                  lineHeight: '1.12',
                  letterSpacing: '-0.015em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                  textWrap: 'balance',
                }}
              >
                How and when to respond to your child’s tantrums: a complete guide for parents
              </h1>
              <p
                style={{
                  fontFamily: 'var(--font-serif)',
                  fontSize: '23px',
                  lineHeight: '1.5',
                  color: 'var(--text-muted)',
                  margin: '18px 0 28px',
                  textWrap: 'pretty',
                }}
              >
                Is it a call for help, or a bid to get their way? A psychologist explains how to tell the difference —
                and a five-step way to calm both.
              </p>
            </Fragment>
          ) : null}
          {v.isTa ? (
            <Fragment>
              <h1
                style={{
                  fontFamily: 'var(--font-tamil-serif)',
                  fontSize: 'clamp(28px,3.6vw,42px)',
                  lineHeight: '1.4',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                  textWrap: 'balance',
                }}
              >
                குழந்தையின் அடத்துக்கு எப்போது, எப்படிப் பதில் அளிப்பது: பெற்றோருக்கான முழு வழிகாட்டி
              </h1>
              <p
                style={{
                  fontFamily: 'var(--font-tamil-serif)',
                  fontSize: '20px',
                  lineHeight: '1.85',
                  color: 'var(--text-muted)',
                  margin: '18px 0 28px',
                  textWrap: 'pretty',
                }}
              >
                இது உதவிக்கான அழைப்பா, அல்லது விரும்பியதைப் பெறும் வழியா? வேறுபாட்டையும், இரண்டையும் தணிக்கும் ஐந்து படிகளையும் ஒரு
                உளவியலாளர் விளக்குகிறார்.
              </p>
            </Fragment>
          ) : null}
          <div style={{ display: 'flex', alignItems: 'center', gap: '14px', flexWrap: 'wrap', paddingBottom: '20px' }}>
            <Avatar name="Saakshi Kapoor Kumar" size={52} ring={true} />
            <div style={{ flex: '1 1 220px', minWidth: '0' }}>
              <div style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                Saakshi Kapoor Kumar
              </div>
              <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                {'Psychologist & educator · 11 min read · Updated 20 Nov 2025'}
              </div>
            </div>
            <Button size="sm" variant={v.followVariant} icon={v.followIcon} onClick={v.toggleFollow}>
              {v.followLabel}
            </Button>
          </div>
        </div>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '4px 8px',
            flexWrap: 'wrap',
            borderTop: '1px solid var(--border-default)',
            borderBottom: '1px solid var(--border-default)',
            padding: '6px 0',
            marginBottom: '32px',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '2px' }}>
            <IconButton icon="heart" label="Helpful" active={v.liked} onClick={v.toggleLike} />
            <span style={{ fontSize: '15px', color: 'var(--text-muted)', marginRight: '10px' }}>
              {v.likeCount}
              {' found this helpful'}
            </span>
            <IconButton icon="message-circle" label="Comments" onClick={v.goComments} />
            <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{v.commentCount}</span>
          </div>
          <div style={{ flex: '1' }}></div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
            <Button size="sm" variant={v.listenVariant} icon={v.listenIcon} onClick={v.toggleListen}>
              {v.listenLabel}
            </Button>
            <div
              role="group"
              aria-label="Text size"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '2px',
                background: 'var(--neutral-100)',
                borderRadius: '999px',
                padding: '2px',
              }}
            >
              <button
                className="hv-2"
                type="button"
                aria-label="Smaller text"
                onClick={v.smaller}
                style={{
                  width: '48px',
                  height: '40px',
                  border: '0',
                  borderRadius: '999px',
                  background: 'none',
                  cursor: 'pointer',
                  fontFamily: 'var(--font-serif)',
                  fontSize: '16px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                }}
              >
                A−
              </button>
              <button
                className="hv-2"
                type="button"
                aria-label="Larger text"
                onClick={v.larger}
                style={{
                  width: '48px',
                  height: '40px',
                  border: '0',
                  borderRadius: '999px',
                  background: 'none',
                  cursor: 'pointer',
                  fontFamily: 'var(--font-serif)',
                  fontSize: '21px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                }}
              >
                A+
              </button>
            </div>
            <IconButton icon={v.saveIcon} label="Save" active={v.saved} onClick={v.toggleSave} />
            <Button size="sm" variant="ghost" icon="share-2" onClick={v.share}>
              {v.shareLabel}
            </Button>
          </div>
        </div>
        <figure style={{ margin: '0 0 56px' }}>
          <div
            style={{
              width: '100%',
              aspectRatio: '2 / 1',
              position: 'relative',
              borderRadius: '24px',
              background: 'var(--blush-100)',
              color: 'var(--blush-700)',
              overflow: 'hidden',
            }}
          >
            <image-slot
              id="article-hero"
              shape="rounded"
              radius="24"
              placeholder="Photo: a parent kneeling beside a crying 2-year-old"
            ></image-slot>
          </div>
          <figcaption style={{ fontSize: '15px', color: 'var(--text-muted)', marginTop: '12px' }}>
            Big feelings need a calm adult nearby.
          </figcaption>
        </figure>
        <div
          style={{
            display: 'flex',
            flexDirection: 'row-reverse',
            flexWrap: 'wrap',
            gap: '40px 48px',
            alignItems: 'flex-start',
          }}
        >
          <aside
            ref={v.asideRef}
            style={{
              flex: '1 1 220px',
              minWidth: '0',
              position: v.asidePos,
              top: '96px',
              alignSelf: 'flex-start',
              display: 'flex',
              flexDirection: 'column',
              gap: '32px',
            }}
          >
            <nav aria-label="In this article">
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                  marginBottom: '10px',
                }}
              >
                In this article
              </div>
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                {(v.toc ?? []).map((t, $i0) => (
                  <Fragment key={$i0}>
                    <a
                      className="hv-3"
                      href={toUrl(t?.href)}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        minHeight: '44px',
                        padding: '4px 14px',
                        borderRadius: '10px',
                        fontSize: '16px',
                        lineHeight: '1.35',
                        textDecoration: 'none',
                        color: t?.fg,
                        background: t?.bg,
                        fontWeight: t?.fw,
                      }}
                    >
                      {t?.label}
                    </a>
                  </Fragment>
                ))}
              </div>
            </nav>
            <Card tint="blush" padding={24}>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--blush-700)',
                  marginBottom: '8px',
                }}
              >
                Related circle
              </div>
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '22px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                }}
              >
                Parents of Preschoolers
              </div>
              <div style={{ fontSize: '15px', color: 'var(--text-muted)', margin: '4px 0 10px' }}>
                3–6 years · 2,500 members
              </div>
              <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)', marginBottom: '16px' }}>
                Curiosity, tantrums and everything in between.
              </div>
              <Button variant={v.joinVariant} icon={v.joinIcon} fullWidth={true} onClick={v.toggleJoin}>
                {v.joinLabel}
              </Button>
            </Card>
          </aside>
          <article
            ref={v.bodyRef}
            style={{
              flex: '999 1 560px',
              minWidth: '0',
              maxWidth: '680px',
              fontFamily: 'var(--font-reading)',
              fontSize: v.rs,
              lineHeight: '1.7',
              color: 'var(--text-body)',
            }}
          >
            <div
              style={{ background: 'var(--blush-50)', borderRadius: '16px', padding: '24px 28px', margin: '0 0 1.4em' }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  fontFamily: 'var(--font-ui)',
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--blush-700)',
                  marginBottom: '10px',
                }}
              >
                <Icon name="book-open" size={18} />A familiar scene
              </div>
              <p style={{ margin: '0', textWrap: 'pretty', fontStyle: 'italic' }}>
                Seema hands her 2-year-old, Shanaya, an evening snack and turns back to her laptop. A minute later,
                Shanaya is screaming. Seema rushes over, but Shanaya is crying too hard to speak — and Seema, tired and
                worried, snaps: “Why are you screaming? Stop it!” Shanaya curls up on the floor. Eventually, between
                sobs, the reason comes out. She doesn’t like the crust on her sandwich.
              </p>
            </div>
            <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
              If this sounds like your home, you’re in good company. Almost every parent and grandparent of a little one
              has a story just like it.
            </p>
            <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
              Tantrums come in every shape and size. Your child might shout and hit out in a shop because you said no to
              a red toy car, or roll on the floor at bedtime because storytime was too much fun to stop. Almost anything
              can set one off — which is exactly why it’s so hard to know how to respond.
            </p>
            <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
              Should you ignore it? Give in? In this guide, we look at why tantrums happen, the two very different kinds
              you’ll see, and what to do in the moment.
            </p>
            <h2
              id="what"
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '30px',
                lineHeight: '1.25',
                letterSpacing: '-0.01em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '56px 0 16px',
                scrollMarginTop: '96px',
              }}
            >
              What is a tantrum?
            </h2>
            <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
              A tantrum is an outburst of anger, frustration or another big feeling, usually when a child’s need or wish
              isn’t being met. It can look like crying, screaming, kicking, arching the back, throwing things — even
              holding their breath.
            </p>
            <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
              Most children between 1 and 3 years have tantrums. They are still building their social and emotional
              skills, and — just as importantly — still learning the words to explain how they feel.
            </p>
            <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
              Not every tantrum is about temper. Children feel just as much as adults do, but they can’t yet sort those
              feelings out or put them into words. So they act them out instead.
            </p>
            <blockquote
              style={{
                margin: '1.6em 0',
                padding: '4px 0 4px 24px',
                borderLeft: '3px solid var(--pc-orange)',
                fontFamily: 'var(--font-serif)',
                fontStyle: 'italic',
                fontSize: '1.2em',
                lineHeight: '1.5',
                color: 'var(--text-strong)',
              }}
            >
              Behind most tantrums is a feeling your child can’t yet put into words.
            </blockquote>
            <h2
              id="why"
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '30px',
                lineHeight: '1.25',
                letterSpacing: '-0.01em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '56px 0 16px',
                scrollMarginTop: '96px',
              }}
            >
              Two kinds of tantrum
            </h2>
            <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
              Every child is different, so every child’s tantrums are different too. Most seem to come out of nowhere.
              But nearly all of them fall into one of two types — and each needs a different response.
            </p>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,260px),1fr))',
                gap: '16px',
                margin: '1.4em 0 0',
                fontFamily: 'var(--font-ui)',
              }}
            >
              <div style={{ background: 'var(--blush-50)', borderRadius: '16px', padding: '24px' }}>
                <Icon name="heart-crack" size={28} color="var(--blush-700)" />
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '12px 0 6px',
                  }}
                >
                  Emotional tantrum
                </div>
                <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                  A call for help. Your child is overwhelmed by a feeling they can’t name or manage.
                </div>
                <div
                  style={{
                    fontSize: '17px',
                    lineHeight: '1.5',
                    color: 'var(--blush-700)',
                    fontWeight: '700',
                    marginTop: '12px',
                  }}
                >
                  What helps: comfort first, logic later.
                </div>
              </div>
              <div style={{ background: 'var(--butter-50)', borderRadius: '16px', padding: '24px' }}>
                <Icon name="target" size={28} color="var(--butter-700)" />
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '12px 0 6px',
                  }}
                >
                  Intentional tantrum
                </div>
                <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                  A tactic. Your child has learnt that crying gets them what they want.
                </div>
                <div
                  style={{
                    fontSize: '17px',
                    lineHeight: '1.5',
                    color: 'var(--butter-700)',
                    fontWeight: '700',
                    marginTop: '12px',
                  }}
                >
                  What helps: stay kind, stay firm.
                </div>
              </div>
            </div>
            <h2
              id="emotional"
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '30px',
                lineHeight: '1.25',
                letterSpacing: '-0.01em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '56px 0 16px',
                scrollMarginTop: '96px',
              }}
            >
              Emotional tantrums: when feelings get too big
            </h2>
            <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
              An emotional tantrum may look unreasonable from the outside, but for your child the struggle is very real.
              Often, the tantrum is their way of telling you they are:
            </p>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,190px),1fr))',
                gap: '12px',
                margin: '0 0 1.4em',
                fontFamily: 'var(--font-ui)',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '12px 14px',
                  border: '1px solid var(--border-default)',
                  borderRadius: '16px',
                }}
              >
                <span
                  style={{
                    width: '44px',
                    height: '44px',
                    flex: 'none',
                    borderRadius: '12px',
                    background: 'var(--blush-50)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="moon" size={22} color="var(--blush-700)" />
                </span>
                <span style={{ fontSize: '17px', color: 'var(--text-strong)', lineHeight: '1.3' }}>Tired</span>
              </div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '12px 14px',
                  border: '1px solid var(--border-default)',
                  borderRadius: '16px',
                }}
              >
                <span
                  style={{
                    width: '44px',
                    height: '44px',
                    flex: 'none',
                    borderRadius: '12px',
                    background: 'var(--blush-50)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="utensils" size={22} color="var(--blush-700)" />
                </span>
                <span style={{ fontSize: '17px', color: 'var(--text-strong)', lineHeight: '1.3' }}>Hungry</span>
              </div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '12px 14px',
                  border: '1px solid var(--border-default)',
                  borderRadius: '16px',
                }}
              >
                <span
                  style={{
                    width: '44px',
                    height: '44px',
                    flex: 'none',
                    borderRadius: '12px',
                    background: 'var(--blush-50)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="hand-heart" size={22} color="var(--blush-700)" />
                </span>
                <span style={{ fontSize: '17px', color: 'var(--text-strong)', lineHeight: '1.3' }}>
                  Wanting your attention
                </span>
              </div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '12px 14px',
                  border: '1px solid var(--border-default)',
                  borderRadius: '16px',
                }}
              >
                <span
                  style={{
                    width: '44px',
                    height: '44px',
                    flex: 'none',
                    borderRadius: '12px',
                    background: 'var(--blush-50)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="arrow-left-right" size={22} color="var(--blush-700)" />
                </span>
                <span style={{ fontSize: '17px', color: 'var(--text-strong)', lineHeight: '1.3' }}>
                  Finding a change hard
                </span>
              </div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '12px 14px',
                  border: '1px solid var(--border-default)',
                  borderRadius: '16px',
                }}
              >
                <span
                  style={{
                    width: '44px',
                    height: '44px',
                    flex: 'none',
                    borderRadius: '12px',
                    background: 'var(--blush-50)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="cloud-rain" size={22} color="var(--blush-700)" />
                </span>
                <span style={{ fontSize: '17px', color: 'var(--text-strong)', lineHeight: '1.3' }}>Sad or worried</span>
              </div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '12px 14px',
                  border: '1px solid var(--border-default)',
                  borderRadius: '16px',
                }}
              >
                <span
                  style={{
                    width: '44px',
                    height: '44px',
                    flex: 'none',
                    borderRadius: '12px',
                    background: 'var(--blush-50)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="flame" size={22} color="var(--blush-700)" />
                </span>
                <span style={{ fontSize: '17px', color: 'var(--text-strong)', lineHeight: '1.3' }}>
                  Angry or frustrated
                </span>
              </div>
            </div>
            <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
              Tantrums also flare up when children are learning a new skill. If the square block just won’t go into the
              round hole of a new shape sorter, expect tears.
            </p>
            <div
              style={{ background: 'var(--blush-50)', borderRadius: '16px', padding: '24px 28px', margin: '1.4em 0' }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  fontFamily: 'var(--font-ui)',
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--blush-700)',
                  marginBottom: '10px',
                }}
              >
                <Icon name="book-open" size={18} />
                Aira’s story
              </div>
              <p style={{ margin: '0 0 0.8em', textWrap: 'pretty', fontStyle: 'italic' }}>
                Aira has just come home after a few days at her grandparents’ house. Since then, her tantrums have
                grown. Asked to do something as simple as brushing her teeth, she shouts and hits out at her parents.
              </p>
              <p style={{ margin: '0', textWrap: 'pretty' }}>
                <strong style={{ color: 'var(--text-strong)' }}>Why it’s happening:</strong>
                {
                  ' Aira is most likely missing her grandparents and all the attention she enjoyed on holiday. She can’t say so in words — so she says it with a tantrum.'
                }
              </p>
            </div>
            <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
              In an emotional tantrum, reasons and rules rarely help. Your child is caught up in feelings they don’t
              fully understand themselves. Start by staying calm and working out what’s behind it. If it’s close to
              mealtime or nap time, a snack or a quiet cuddle may be all that’s needed.
            </p>
            <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
              For everything else, try ParentCircle’s P.E.A.C.E. method.
            </p>
            <h2
              id="peace"
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '30px',
                lineHeight: '1.25',
                letterSpacing: '-0.01em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '56px 0 20px',
                scrollMarginTop: '96px',
              }}
            >
              The P.E.A.C.E. method, step by step
            </h2>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(5,minmax(0,1fr))',
                gap: '8px',
                margin: '0 0 32px',
                fontFamily: 'var(--font-ui)',
              }}
            >
              <a
                className="hv-4"
                href="#step-pause"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '4px',
                  padding: '16px 4px',
                  borderRadius: '16px',
                  background: 'var(--orange-50)',
                  textDecoration: 'none',
                  transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
                }}
              >
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '40px',
                    lineHeight: '1',
                    fontWeight: '700',
                    color: 'var(--orange-600)',
                  }}
                >
                  P
                </span>
                <span style={{ fontSize: '15px', fontWeight: '600', color: 'var(--text-strong)' }}>Pause</span>
              </a>
              <a
                className="hv-4"
                href="#step-empathise"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '4px',
                  padding: '16px 4px',
                  borderRadius: '16px',
                  background: 'var(--orange-50)',
                  textDecoration: 'none',
                  transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
                }}
              >
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '40px',
                    lineHeight: '1',
                    fontWeight: '700',
                    color: 'var(--orange-600)',
                  }}
                >
                  E
                </span>
                <span style={{ fontSize: '15px', fontWeight: '600', color: 'var(--text-strong)' }}>Empathise</span>
              </a>
              <a
                className="hv-4"
                href="#step-await"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '4px',
                  padding: '16px 4px',
                  borderRadius: '16px',
                  background: 'var(--orange-50)',
                  textDecoration: 'none',
                  transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
                }}
              >
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '40px',
                    lineHeight: '1',
                    fontWeight: '700',
                    color: 'var(--orange-600)',
                  }}
                >
                  A
                </span>
                <span style={{ fontSize: '15px', fontWeight: '600', color: 'var(--text-strong)' }}>Await</span>
              </a>
              <a
                className="hv-4"
                href="#step-communicate"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '4px',
                  padding: '16px 4px',
                  borderRadius: '16px',
                  background: 'var(--orange-50)',
                  textDecoration: 'none',
                  transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
                }}
              >
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '40px',
                    lineHeight: '1',
                    fontWeight: '700',
                    color: 'var(--orange-600)',
                  }}
                >
                  C
                </span>
                <span
                  style={{
                    fontSize: '15px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textAlign: 'center',
                    overflowWrap: 'anywhere',
                  }}
                >
                  Communicate
                </span>
              </a>
              <a
                className="hv-4"
                href="#step-engage"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '4px',
                  padding: '16px 4px',
                  borderRadius: '16px',
                  background: 'var(--orange-50)',
                  textDecoration: 'none',
                  transition: 'transform 200ms cubic-bezier(.2,0,0,1)',
                }}
              >
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '40px',
                    lineHeight: '1',
                    fontWeight: '700',
                    color: 'var(--orange-600)',
                  }}
                >
                  E
                </span>
                <span style={{ fontSize: '15px', fontWeight: '600', color: 'var(--text-strong)' }}>Engage</span>
              </a>
            </div>
            <div
              id="step-pause"
              style={{
                display: 'flex',
                gap: '20px',
                padding: '24px 0',
                borderTop: '1px solid var(--border-default)',
                scrollMarginTop: '96px',
              }}
            >
              <span
                style={{
                  width: '52px',
                  height: '52px',
                  flex: 'none',
                  borderRadius: '50%',
                  background: 'var(--neutral-900)',
                  color: 'var(--text-inverse)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontFamily: 'var(--font-display)',
                  fontSize: '24px',
                  fontWeight: '700',
                }}
              >
                P
              </span>
              <div style={{ flex: '1', minWidth: '0' }}>
                <h3
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '24px',
                    lineHeight: '1.3',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '8px 0 8px',
                  }}
                >
                  Pause
                </h3>
                <p style={{ margin: '0', textWrap: 'pretty' }}>
                  Take a breath and steady yourself first. A tantrum won’t end because you’re angry, and you can’t help
                  your child calm down while your own feelings are running high.
                </p>
              </div>
            </div>
            <div
              id="step-empathise"
              style={{
                display: 'flex',
                gap: '20px',
                padding: '24px 0',
                borderTop: '1px solid var(--border-default)',
                scrollMarginTop: '96px',
              }}
            >
              <span
                style={{
                  width: '52px',
                  height: '52px',
                  flex: 'none',
                  borderRadius: '50%',
                  background: 'var(--neutral-900)',
                  color: 'var(--text-inverse)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontFamily: 'var(--font-display)',
                  fontSize: '24px',
                  fontWeight: '700',
                }}
              >
                E
              </span>
              <div style={{ flex: '1', minWidth: '0' }}>
                <h3
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '24px',
                    lineHeight: '1.3',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '8px 0 8px',
                  }}
                >
                  Empathise
                </h3>
                <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
                  Look for the feeling behind the outburst. Aira is sad that the holiday is over and misses the time
                  with her grandparents. Name that feeling before you reach for logic.
                </p>
                <div
                  style={{
                    background: 'var(--sage-50)',
                    borderRadius: '16px',
                    padding: '16px 20px',
                    margin: '0 0 1em',
                  }}
                >
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      fontFamily: 'var(--font-ui)',
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--sage-700)',
                      marginBottom: '6px',
                    }}
                  >
                    <Icon name="message-circle" size={18} />
                    Try saying
                  </div>
                  <p style={{ margin: '0', color: 'var(--text-strong)', textWrap: 'pretty' }}>
                    “I know you’re missing Nana and Nani. We had such a lovely time with them.”
                  </p>
                </div>
                <p style={{ margin: '0', textWrap: 'pretty' }}>
                  When you name a feeling, your child learns its name too — and starts to settle, because they know you
                  understand.
                </p>
              </div>
            </div>
            <div
              id="step-await"
              style={{
                display: 'flex',
                gap: '20px',
                padding: '24px 0',
                borderTop: '1px solid var(--border-default)',
                scrollMarginTop: '96px',
              }}
            >
              <span
                style={{
                  width: '52px',
                  height: '52px',
                  flex: 'none',
                  borderRadius: '50%',
                  background: 'var(--neutral-900)',
                  color: 'var(--text-inverse)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontFamily: 'var(--font-display)',
                  fontSize: '24px',
                  fontWeight: '700',
                }}
              >
                A
              </span>
              <div style={{ flex: '1', minWidth: '0' }}>
                <h3
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '24px',
                    lineHeight: '1.3',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '8px 0 8px',
                  }}
                >
                  Await
                </h3>
                <p style={{ margin: '0', textWrap: 'pretty' }}>
                  Think about what you need when you’re upset: a lecture, or someone who says “I’m here”? Hold your
                  child’s hand or give them a hug, sit beside them, and wait for the storm to pass.
                </p>
              </div>
            </div>
            <div
              id="step-communicate"
              style={{
                display: 'flex',
                gap: '20px',
                padding: '24px 0',
                borderTop: '1px solid var(--border-default)',
                scrollMarginTop: '96px',
              }}
            >
              <span
                style={{
                  width: '52px',
                  height: '52px',
                  flex: 'none',
                  borderRadius: '50%',
                  background: 'var(--neutral-900)',
                  color: 'var(--text-inverse)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontFamily: 'var(--font-display)',
                  fontSize: '24px',
                  fontWeight: '700',
                }}
              >
                C
              </span>
              <div style={{ flex: '1', minWidth: '0' }}>
                <h3
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '24px',
                    lineHeight: '1.3',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '8px 0 8px',
                  }}
                >
                  Communicate
                </h3>
                <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
                  Once your child is calm, talk. Share what you noticed and how you felt, and ask for their side of the
                  story. This is a moment for listening more than speaking.
                </p>
                <div
                  style={{
                    background: 'var(--sage-50)',
                    borderRadius: '16px',
                    padding: '16px 20px',
                    margin: '0 0 1em',
                  }}
                >
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      fontFamily: 'var(--font-ui)',
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--sage-700)',
                      marginBottom: '6px',
                    }}
                  >
                    <Icon name="message-circle" size={18} />
                    Try saying
                  </div>
                  <p style={{ margin: '0', color: 'var(--text-strong)', textWrap: 'pretty' }}>
                    “We’re feeling a bit sad too, now that the holiday is over.”
                  </p>
                </div>
                <p style={{ margin: '0', textWrap: 'pretty' }}>
                  Notice the word “sad”. Giving children feeling words — happy, sad, angry, disappointed, confused —
                  helps them say what they feel instead of showing it.
                </p>
              </div>
            </div>
            <div
              id="step-engage"
              style={{
                display: 'flex',
                gap: '20px',
                padding: '24px 0',
                borderTop: '1px solid var(--border-default)',
                borderBottom: '1px solid var(--border-default)',
                scrollMarginTop: '96px',
              }}
            >
              <span
                style={{
                  width: '52px',
                  height: '52px',
                  flex: 'none',
                  borderRadius: '50%',
                  background: 'var(--neutral-900)',
                  color: 'var(--text-inverse)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontFamily: 'var(--font-display)',
                  fontSize: '24px',
                  fontWeight: '700',
                }}
              >
                E
              </span>
              <div style={{ flex: '1', minWidth: '0' }}>
                <h3
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '24px',
                    lineHeight: '1.3',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '8px 0 8px',
                  }}
                >
                  Engage
                </h3>
                <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
                  Now think together about what might help next time.
                </p>
                <div
                  style={{
                    background: 'var(--sage-50)',
                    borderRadius: '16px',
                    padding: '16px 20px',
                    margin: '0 0 1em',
                  }}
                >
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      fontFamily: 'var(--font-ui)',
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--sage-700)',
                      marginBottom: '6px',
                    }}
                  >
                    <Icon name="message-circle" size={18} />
                    Try saying
                  </div>
                  <p style={{ margin: '0', color: 'var(--text-strong)', textWrap: 'pretty' }}>
                    “Shall we call Nana and Nani? I’m sure they miss us too. What else would help you feel better?”
                  </p>
                </div>
                <p style={{ margin: '0', textWrap: 'pretty' }}>
                  Small things go a long way: ten extra minutes together at breakfast and bedtime, or a video call with
                  the grandparents for the first few days back.
                </p>
              </div>
            </div>
            <figure style={{ margin: '2em 0' }}>
              <div
                style={{
                  width: '100%',
                  aspectRatio: '3 / 2',
                  position: 'relative',
                  borderRadius: '16px',
                  background: 'var(--blush-100)',
                  color: 'var(--blush-700)',
                  overflow: 'hidden',
                }}
              >
                <image-slot
                  id="article-inline-1"
                  shape="rounded"
                  radius="16"
                  placeholder="Photo: grandmother hugging a calm child after a tantrum"
                ></image-slot>
              </div>
              <figcaption
                style={{
                  fontFamily: 'var(--font-ui)',
                  fontSize: '15px',
                  color: 'var(--text-muted)',
                  marginTop: '10px',
                }}
              >
                Comfort first. The talking can wait until the storm has passed.
              </figcaption>
            </figure>
            <h2
              id="intentional"
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '30px',
                lineHeight: '1.25',
                letterSpacing: '-0.01em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '56px 0 16px',
                scrollMarginTop: '96px',
              }}
            >
              Intentional tantrums: when crying is a strategy
            </h2>
            <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
              Sometimes a tantrum is a plan. Your child has worked out that crying gets results, and they’re using their
              “thinking brain” to get their way.
            </p>
            <div
              style={{ background: 'var(--butter-50)', borderRadius: '16px', padding: '24px 28px', margin: '1.4em 0' }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  fontFamily: 'var(--font-ui)',
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--butter-700)',
                  marginBottom: '10px',
                }}
              >
                <Icon name="book-open" size={18} />
                Aarav’s story
              </div>
              <p style={{ margin: '0 0 0.8em', textWrap: 'pretty', fontStyle: 'italic' }}>
                Three-year-old Aarav cries at every meal until the TV goes on. He has learnt that if he cries long
                enough, the screen always appears.
              </p>
              <p style={{ margin: '0', textWrap: 'pretty' }}>
                <strong style={{ color: 'var(--text-strong)' }}>Why it’s happening:</strong>
                {
                  ' each time his parents give in to stop the crying, Aarav learns that tears work. So the tantrums come more often.'
                }
              </p>
            </div>
            <h3
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '24px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '32px 0 8px',
              }}
            >
              1. Use P.E.A.C.E. anyway
            </h3>
            <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
              Whatever the type of tantrum, begin by managing your own feelings. The method helps turn a moment of
              conflict into a moment of connection — even when your child’s behaviour feels unfair.
            </p>
            <h3
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '24px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '32px 0 8px',
              }}
            >
              2. Be kind, and be firm
            </h3>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              Don’t give in just because your child is crying. Acknowledge the wish, hold the rule, then gently
              redirect.
            </p>
            <div
              style={{ background: 'var(--sage-50)', borderRadius: '16px', padding: '16px 20px', margin: '0 0 1.1em' }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  fontFamily: 'var(--font-ui)',
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--sage-700)',
                  marginBottom: '6px',
                }}
              >
                <Icon name="message-circle" size={18} />
                Try saying
              </div>
              <p style={{ margin: '0 0 0.6em', color: 'var(--text-strong)', textWrap: 'pretty' }}>
                “I know you’d really like to watch TV while you eat. But in our home, there’s no TV at mealtimes.”
              </p>
              <p style={{ margin: '0', color: 'var(--text-strong)', textWrap: 'pretty' }}>
                “Look at all the colours on your plate — orange carrots, green peas, yellow corn. Shall I tell you a
                story about how they got their colours?”
              </p>
            </div>
            <h3
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '24px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '32px 0 8px',
              }}
            >
              3. Be patient
            </h3>
            <p style={{ margin: '0 0 1.1em', textWrap: 'pretty' }}>
              Tantrums don’t vanish overnight, especially if they’ve worked before. It may take many tries before things
              change. Stay consistent — and make sure both parents, and grandparents, handle it the same way, or your
              child will soon learn who’s more likely to give in.
            </p>
            <div
              id="nutshell"
              style={{
                background: 'var(--sky-50)',
                borderRadius: '16px',
                padding: '28px 32px',
                margin: '56px 0 0',
                scrollMarginTop: '96px',
                fontFamily: 'var(--font-ui)',
              }}
            >
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '27px',
                  lineHeight: '1.25',
                  letterSpacing: '-0.01em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0 0 20px',
                }}
              >
                In a nutshell
              </h2>
              <ol
                style={{
                  listStyle: 'none',
                  margin: '0',
                  padding: '0',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '16px',
                }}
              >
                <li style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                  <span
                    style={{
                      width: '32px',
                      height: '32px',
                      flex: 'none',
                      borderRadius: '50%',
                      background: 'var(--white)',
                      color: 'var(--sky-700)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '16px',
                      fontWeight: '700',
                    }}
                  >
                    1
                  </span>
                  <span style={{ fontSize: '18px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                    Most tantrums are a feeling your child is struggling to express. They are a normal part of growing
                    up.
                  </span>
                </li>
                <li style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                  <span
                    style={{
                      width: '32px',
                      height: '32px',
                      flex: 'none',
                      borderRadius: '50%',
                      background: 'var(--white)',
                      color: 'var(--sky-700)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '16px',
                      fontWeight: '700',
                    }}
                  >
                    2
                  </span>
                  <span style={{ fontSize: '18px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                    If you feel overwhelmed, remember your child does too. Comfort first; save the reasoning for later.
                  </span>
                </li>
                <li style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                  <span
                    style={{
                      width: '32px',
                      height: '32px',
                      flex: 'none',
                      borderRadius: '50%',
                      background: 'var(--white)',
                      color: 'var(--sky-700)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '16px',
                      fontWeight: '700',
                    }}
                  >
                    3
                  </span>
                  <span style={{ fontSize: '18px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                    With an intentional tantrum, don’t give in and don’t bargain.
                  </span>
                </li>
                <li style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                  <span
                    style={{
                      width: '32px',
                      height: '32px',
                      flex: 'none',
                      borderRadius: '50%',
                      background: 'var(--white)',
                      color: 'var(--sky-700)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '16px',
                      fontWeight: '700',
                    }}
                  >
                    4
                  </span>
                  <span style={{ fontSize: '18px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                    With an emotional tantrum, connect with the feeling and meet the need. Try P.E.A.C.E.
                  </span>
                </li>
                <li style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                  <span
                    style={{
                      width: '32px',
                      height: '32px',
                      flex: 'none',
                      borderRadius: '50%',
                      background: 'var(--white)',
                      color: 'var(--sky-700)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '16px',
                      fontWeight: '700',
                    }}
                  >
                    5
                  </span>
                  <span style={{ fontSize: '18px', lineHeight: '1.5', color: 'var(--text-body)' }}>
                    The best time to step in is while a tantrum is building — not at its peak.
                  </span>
                </li>
              </ol>
            </div>
            <div
              id="today"
              style={{
                border: '1px solid var(--border-default)',
                borderRadius: '16px',
                padding: '28px 32px',
                margin: '24px 0 0',
                scrollMarginTop: '96px',
                fontFamily: 'var(--font-ui)',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'baseline',
                  justifyContent: 'space-between',
                  gap: '12px',
                  flexWrap: 'wrap',
                  marginBottom: '18px',
                }}
              >
                <h2
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '27px',
                    lineHeight: '1.25',
                    letterSpacing: '-0.01em',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0',
                  }}
                >
                  Try this week
                </h2>
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{v.doneLabel}</span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                {(v.checklist ?? []).map((c, $i0) => (
                  <Fragment key={$i0}>
                    <Checkbox label={c?.label} checked={c?.checked} onChange={c?.onChange} />
                  </Fragment>
                ))}
              </div>
            </div>
            <div
              style={{
                display: 'flex',
                gap: '18px',
                alignItems: 'flex-start',
                flexWrap: 'wrap',
                background: 'var(--sage-50)',
                borderRadius: '16px',
                padding: '28px 32px',
                margin: '24px 0 0',
                fontFamily: 'var(--font-ui)',
              }}
            >
              <Avatar name="Saakshi Kapoor Kumar" size={64} ring={true} />
              <div style={{ flex: '1 1 260px', minWidth: '0' }}>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    fontSize: '15px',
                    fontWeight: '700',
                    color: 'var(--sage-700)',
                    marginBottom: '6px',
                  }}
                >
                  <Icon name="shield-check" size={20} />
                  Written by an expert
                </div>
                <div
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '22px',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                  }}
                >
                  Saakshi Kapoor Kumar
                </div>
                <p
                  style={{
                    fontSize: '17px',
                    lineHeight: '1.55',
                    color: 'var(--text-body)',
                    margin: '6px 0 16px',
                    textWrap: 'pretty',
                  }}
                >
                  Psychologist, educator and Head of The Dot Learning Experience, an early-childhood education
                  ecosystem. She trains teachers and helps schools build joyful, child-centred classrooms, with a focus
                  on social-emotional learning.
                </p>
                <Button size="sm" variant={v.followVariant} icon={v.followIcon} onClick={v.toggleFollow}>
                  {v.followLabel}
                </Button>
              </div>
            </div>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '16px',
                flexWrap: 'wrap',
                padding: '28px 0',
                marginTop: '32px',
                borderTop: '1px solid var(--border-default)',
                borderBottom: '1px solid var(--border-default)',
                fontFamily: 'var(--font-ui)',
              }}
            >
              {v.askHelpful ? (
                <Fragment>
                  <span style={{ fontSize: '19px', fontWeight: '600', color: 'var(--text-strong)' }}>
                    Was this article helpful?
                  </span>
                  <div style={{ display: 'flex', gap: '10px' }}>
                    <Button variant="secondary" icon="thumbs-up" onClick={v.helpfulYes}>
                      Yes
                    </Button>
                    <Button variant="secondary" icon="thumbs-down" onClick={v.helpfulNo}>
                      Not really
                    </Button>
                  </div>
                </Fragment>
              ) : null}
              {v.answeredHelpful ? (
                <span
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    fontSize: '19px',
                    color: 'var(--sage-700)',
                  }}
                >
                  <Icon name="circle-check" size={22} />
                  {v.helpfulThanks}
                </span>
              ) : null}
            </div>
            <div style={{ padding: '28px 0 0', fontFamily: 'var(--font-ui)' }}>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                  marginBottom: '14px',
                }}
              >
                Related topics
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                <Tag topic="emotions">Managing child behaviour</Tag>
                <Tag topic="emotions">Managing emotions</Tag>
                <Tag>Parenting styles</Tag>
                <Tag>Raising a responsible child</Tag>
                <Tag topic="teens">Screen time</Tag>
              </div>
            </div>
            <section
              id="comments"
              style={{ padding: '56px 0 0', scrollMarginTop: '96px', fontFamily: 'var(--font-ui)' }}
            >
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '27px',
                  lineHeight: '1.25',
                  letterSpacing: '-0.01em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0 0 20px',
                }}
              >
                {v.commentHeading}
              </h2>
              <Card padding={20}>
                <div style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                  <Avatar name="You" size={44} />
                  <div style={{ flex: '1', minWidth: '0' }}>
                    <Input
                      multiline={true}
                      rows={2}
                      placeholder="Share what has worked in your family…"
                      value={v.draft}
                      onChange={v.onDraft}
                    />
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: '12px',
                        flexWrap: 'wrap',
                        marginTop: '12px',
                      }}
                    >
                      <span
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px',
                          fontSize: '15px',
                          color: 'var(--text-muted)',
                        }}
                      >
                        <Icon name="lock" size={16} />
                        Be kind. Every family is different.
                      </span>
                      <Button size="sm" disabled={v.draftEmpty} onClick={v.postComment}>
                        Post comment
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
              {(v.comments ?? []).map((m, $i0) => (
                <Fragment key={$i0}>
                  <article style={{ padding: '24px 0', borderBottom: '1px solid var(--border-subtle)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                      <Avatar name={m?.name} size={36} />
                      <span style={{ fontSize: '16px', fontWeight: '600', color: 'var(--text-strong)' }}>
                        {m?.name}
                      </span>
                      <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                        {'· '}
                        {m?.when}
                      </span>
                    </div>
                    <p
                      style={{
                        fontFamily: 'var(--font-serif)',
                        fontSize: '19px',
                        lineHeight: '1.6',
                        color: 'var(--text-body)',
                        margin: '0',
                        textWrap: 'pretty',
                      }}
                    >
                      {m?.text}
                    </p>
                  </article>
                </Fragment>
              ))}
            </section>
          </article>
        </div>
      </main>
      <section style={{ marginTop: '96px', background: 'var(--neutral-50)' }}>
        <div style={{ maxWidth: '1088px', margin: '0 auto', padding: '64px 24px', boxSizing: 'border-box' }}>
          <h2
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(28px,3vw,34px)',
              lineHeight: '1.2',
              letterSpacing: '-0.01em',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0 0 28px',
            }}
          >
            Keep reading
          </h2>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,260px),1fr))',
              gap: '40px 28px',
            }}
          >
            {(v.more ?? []).map((a, $i0) => (
              <Fragment key={$i0}>
                <article style={{ display: 'flex', flexDirection: 'column', gap: '10px', minWidth: '0' }}>
                  <div
                    style={{
                      position: 'relative',
                      aspectRatio: '16 / 10',
                      borderRadius: '16px',
                      overflow: 'hidden',
                      background: a?.tint,
                    }}
                  >
                    <image-slot
                      id={`article-more-${a?.id ?? ''}`}
                      shape="rounded"
                      radius="16"
                      placeholder={a?.photo}
                    ></image-slot>
                  </div>
                  <span
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: a?.ink,
                    }}
                  >
                    {a?.category}
                  </span>
                  <a
                    className="hv-5"
                    href={toUrl('/article')}
                    onClick={a?.onClick}
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '20px',
                      lineHeight: '1.3',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                      textWrap: 'pretty',
                    }}
                  >
                    {a?.title}
                  </a>
                  <span style={{ fontSize: '15px', lineHeight: '1.4', color: 'var(--text-muted)' }}>{a?.meta}</span>
                </article>
              </Fragment>
            ))}
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
