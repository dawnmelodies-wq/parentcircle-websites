import { Fragment } from 'react';
import { ArticleCard, Avatar, Badge, Button, Card, Icon, IconButton, Input, Logo, Tag } from '../../components/ds';
import { toUrl } from '../../lib/paths';

/** Markup for the "Home" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      data-screen-label="Home"
      style={{
        minHeight: '100vh',
        background: 'var(--paper)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <header
        style={{
          position: 'sticky',
          top: '0',
          zIndex: '20',
          background: 'rgba(252,249,244,0.94)',
          backdropFilter: 'blur(8px)',
          WebkitBackdropFilter: 'blur(8px)',
          borderBottom: '1px solid var(--border-default)',
        }}
      >
        <div
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '0 24px',
            height: '72px',
            display: 'flex',
            alignItems: 'center',
            gap: '28px',
          }}
        >
          <a href="#read" aria-label="ParentCircle home" style={{ flex: 'none', display: 'flex', marginRight: '20px' }}>
            <Logo height={28} />
          </a>
          {v.isEn ? (
            <nav
              aria-label="Main"
              data-main-nav=""
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                height: '44px',
                gap: '4px',
                flex: '1 1 auto',
                minWidth: '0',
                overflow: 'hidden',
              }}
            >
              <a
                href="#read"
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  background: 'var(--neutral-100)',
                  color: 'var(--text-strong)',
                  fontSize: '17px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  textDecoration: 'none',
                  whiteSpace: 'nowrap',
                }}
              >
                Read
              </a>
              <a
                className="hv-3"
                href="#community"
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  color: 'var(--text-muted)',
                  fontSize: '17px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  textDecoration: 'none',
                  whiteSpace: 'nowrap',
                }}
              >
                Community
              </a>
              <a
                className="hv-3"
                href="#programs"
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  color: 'var(--text-muted)',
                  fontSize: '17px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  textDecoration: 'none',
                  whiteSpace: 'nowrap',
                }}
              >
                Programs
              </a>
              <a
                className="hv-3"
                href="#magazine"
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  color: 'var(--text-muted)',
                  fontSize: '17px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  textDecoration: 'none',
                  whiteSpace: 'nowrap',
                }}
              >
                Magazine
              </a>
            </nav>
          ) : null}
          {v.isTa ? (
            <nav
              aria-label="Main"
              data-main-nav=""
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                height: '44px',
                gap: '4px',
                flex: '1 1 auto',
                minWidth: '0',
                overflow: 'hidden',
                fontFamily: 'var(--font-tamil-sans)',
              }}
            >
              <a
                href="#read"
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  background: 'var(--neutral-100)',
                  color: 'var(--text-strong)',
                  fontSize: '16px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  textDecoration: 'none',
                  whiteSpace: 'nowrap',
                }}
              >
                படிக்க
              </a>
              <a
                className="hv-3"
                href="#community"
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  color: 'var(--text-muted)',
                  fontSize: '16px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  textDecoration: 'none',
                  whiteSpace: 'nowrap',
                }}
              >
                சமூகம்
              </a>
              <a
                className="hv-3"
                href="#programs"
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  color: 'var(--text-muted)',
                  fontSize: '16px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  textDecoration: 'none',
                  whiteSpace: 'nowrap',
                }}
              >
                திட்டங்கள்
              </a>
              <a
                className="hv-3"
                href="#magazine"
                style={{
                  height: '44px',
                  padding: '0 16px',
                  borderRadius: '999px',
                  color: 'var(--text-muted)',
                  fontSize: '16px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  textDecoration: 'none',
                  whiteSpace: 'nowrap',
                }}
              >
                இதழ்
              </a>
            </nav>
          ) : null}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 'none', marginLeft: 'auto' }}>
            <button
              className="hv-3"
              type="button"
              onClick={v.toggleLang}
              aria-label="Switch language"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                height: '44px',
                padding: '0 12px',
                borderRadius: '999px',
                background: 'none',
                border: '0',
                cursor: 'pointer',
                fontFamily: 'var(--font-ui)',
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-muted)',
              }}
            >
              <Icon name="globe" size={20} />
              <span>{v.langLabel}</span>
            </button>
            <a href={toUrl('/search?query=')} aria-label="Search" style={{ display: 'flex' }}>
              <IconButton icon="search" label="Search" />
            </a>
            {v.isEn ? (
              <div style={{ display: 'flex', gap: '8px' }}>
                <span data-auth="out" style={{ display: 'contents' }}>
                  <a href={toUrl('/sign-in')} style={{ display: 'flex', textDecoration: 'none' }}>
                    <Button variant="ghost" size="sm">
                      Sign in
                    </Button>
                  </a>{' '}
                  <a href={toUrl('/join')} style={{ display: 'flex', textDecoration: 'none' }}>
                    <Button variant="primary" size="sm">
                      Join free
                    </Button>
                  </a>
                </span>
                <span data-auth="in" style={{ display: 'none', alignItems: 'center', gap: '8px' }}>
                  <a
                    className="hv-3"
                    href={toUrl('/profile#notification')}
                    aria-label="Notifications, 3 new"
                    style={{
                      position: 'relative',
                      width: '48px',
                      height: '48px',
                      borderRadius: '999px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: 'var(--text-strong)',
                      textDecoration: 'none',
                    }}
                  >
                    <Icon name="bell" size={22} />
                    <span
                      style={{
                        position: 'absolute',
                        top: '6px',
                        right: '6px',
                        minWidth: '18px',
                        height: '18px',
                        padding: '0 5px',
                        boxSizing: 'border-box',
                        borderRadius: '999px',
                        background: 'var(--orange-600)',
                        color: 'var(--white)',
                        fontSize: '12px',
                        fontWeight: '700',
                        lineHeight: '18px',
                        textAlign: 'center',
                        boxShadow: '0 0 0 2px var(--white)',
                      }}
                    >
                      3
                    </span>
                  </a>{' '}
                  <a
                    className="hv-0"
                    href={toUrl('/profile#activities')}
                    aria-label="Your profile"
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      height: '44px',
                      padding: '0 14px 0 4px',
                      borderRadius: '999px',
                      border: '1px solid var(--border-default)',
                      textDecoration: 'none',
                      color: 'var(--text-strong)',
                    }}
                  >
                    <Avatar name="Priya Raman" size={36} />
                    <span data-auth-name="" style={{ fontSize: '16px', fontWeight: '600' }}>
                      Priya
                    </span>
                  </a>
                </span>
              </div>
            ) : null}
            {v.isTa ? (
              <div style={{ display: 'flex', gap: '8px' }}>
                <Button variant="ghost" size="sm">
                  உள்நுழைக
                </Button>
                <Button variant="primary" size="sm">
                  இணையுங்கள்
                </Button>
              </div>
            ) : null}
          </div>
        </div>
      </header>
      <main>
        <section
          id="read"
          style={{ maxWidth: '1200px', margin: '0 auto', padding: '48px 24px 0', scrollMarginTop: '88px' }}
        >
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '48px', alignItems: 'center' }}>
            <div style={{ flex: '1 1 440px', minWidth: '0' }}>
              {v.isEn ? (
                <Fragment>
                  <div
                    style={{
                      display: 'flex',
                      gap: '12px',
                      alignItems: 'center',
                      flexWrap: 'wrap',
                      marginBottom: '18px',
                    }}
                  >
                    <span
                      style={{
                        fontSize: '14px',
                        fontWeight: '700',
                        letterSpacing: '0.08em',
                        textTransform: 'uppercase',
                        color: 'var(--blush-700)',
                      }}
                    >
                      Emotional wellness
                    </span>
                    <Badge tone="success">Expert verified</Badge>
                  </div>
                  <h1
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: 'clamp(36px,4.6vw,56px)',
                      lineHeight: '1.1',
                      letterSpacing: '-0.015em',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      margin: '0',
                      textWrap: 'balance',
                    }}
                  >
                    Why tantrums peak at age two — and the one thing that calms them
                  </h1>
                  <p
                    style={{
                      fontFamily: 'var(--font-serif)',
                      fontSize: '22px',
                      lineHeight: '1.5',
                      color: 'var(--text-muted)',
                      margin: '18px 0 28px',
                      textWrap: 'pretty',
                      maxWidth: '560px',
                    }}
                  >
                    A child psychologist explains what’s happening in your toddler’s brain, and how to respond without
                    losing your own cool.
                  </p>
                </Fragment>
              ) : null}
              {v.isTa ? (
                <Fragment>
                  <div
                    style={{
                      display: 'flex',
                      gap: '12px',
                      alignItems: 'center',
                      flexWrap: 'wrap',
                      marginBottom: '18px',
                      fontFamily: 'var(--font-tamil-sans)',
                    }}
                  >
                    <span style={{ fontSize: '15px', fontWeight: '700', color: 'var(--blush-700)' }}>உணர்ச்சி நலம்</span>
                    <Badge tone="success">நிபுணர் சரிபார்த்தது</Badge>
                  </div>
                  <h1
                    style={{
                      fontFamily: 'var(--font-tamil-serif)',
                      fontSize: 'clamp(30px,3.8vw,46px)',
                      lineHeight: '1.4',
                      fontWeight: '700',
                      color: 'var(--text-strong)',
                      margin: '0',
                      textWrap: 'balance',
                    }}
                  >
                    இரண்டு வயதில் அடம் ஏன் அதிகரிக்கிறது — அதைத் தணிக்கும் ஒரு எளிய வழி
                  </h1>
                  <p
                    style={{
                      fontFamily: 'var(--font-tamil-serif)',
                      fontSize: '20px',
                      lineHeight: '1.85',
                      color: 'var(--text-muted)',
                      margin: '18px 0 28px',
                      textWrap: 'pretty',
                      maxWidth: '560px',
                    }}
                  >
                    உங்கள் குழந்தையின் மூளையில் என்ன நடக்கிறது, பொறுமை இழக்காமல் எப்படி அணுகுவது என்பதை ஒரு குழந்தை உளவியலாளர்
                    விளக்குகிறார்.
                  </p>
                </Fragment>
              ) : null}
              <div style={{ display: 'flex', alignItems: 'center', gap: '14px', marginBottom: '28px' }}>
                <Avatar name="Meera Iyer" size={48} ring={true} />
                <div>
                  <div style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>Dr. Meera Iyer</div>
                  <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                    Child psychologist, Chennai · 6 min read
                  </div>
                </div>
              </div>
              {v.isEn ? (
                <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                  <Button variant="primary" size="lg" iconRight="arrow-right">
                    Read the story
                  </Button>
                  <Button variant="ghost" size="lg" icon={v.heroSaveIcon} onClick={v.toggleHeroSave}>
                    {v.heroSaveLabel}
                  </Button>
                </div>
              ) : null}
              {v.isTa ? (
                <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                  <Button variant="primary" size="lg" iconRight="arrow-right">
                    முழுக் கட்டுரை
                  </Button>
                  <Button variant="ghost" size="lg" icon={v.heroSaveIcon} onClick={v.toggleHeroSave}>
                    சேமி
                  </Button>
                </div>
              ) : null}
            </div>
            <div
              style={{
                flex: '1 1 420px',
                minWidth: '0',
                aspectRatio: '4 / 3',
                position: 'relative',
                borderRadius: '24px',
                background: 'var(--blush-100)',
                overflow: 'hidden',
              }}
            >
              <image-slot
                id="hero-photo"
                shape="rounded"
                radius="24"
                placeholder="Photo: parent calming a toddler, warm daylight"
              ></image-slot>
            </div>
          </div>
          <div style={{ marginTop: '56px', paddingTop: '28px', borderTop: '1px solid var(--border-default)' }}>
            <div
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--text-muted)',
                marginBottom: '20px',
              }}
            >
              Most read today
            </div>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,300px),1fr))',
                gap: '32px',
              }}
            >
              <a
                className="hv-c"
                href="#"
                style={{ display: 'flex', gap: '18px', textDecoration: 'none', color: 'inherit' }}
              >
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '44px',
                    lineHeight: '0.9',
                    fontWeight: '700',
                    color: 'var(--pc-orange)',
                    flex: 'none',
                    width: '44px',
                  }}
                >
                  1
                </span>
                <span style={{ display: 'flex', flexDirection: 'column', gap: '6px', minWidth: '0' }}>
                  <span
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--sage-700)',
                    }}
                  >
                    Child health
                  </span>
                  <span
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '21px',
                      lineHeight: '1.3',
                      fontWeight: '700',
                      letterSpacing: '-0.01em',
                      color: 'var(--text-strong)',
                      textWrap: 'pretty',
                    }}
                  >
                    Fever in babies: when to wait and when to call the doctor
                  </span>
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Dr. S. Raman · 6 min read</span>
                </span>
              </a>
              <a
                className="hv-c"
                href="#"
                style={{ display: 'flex', gap: '18px', textDecoration: 'none', color: 'inherit' }}
              >
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '44px',
                    lineHeight: '0.9',
                    fontWeight: '700',
                    color: 'var(--pc-orange)',
                    flex: 'none',
                    width: '44px',
                  }}
                >
                  2
                </span>
                <span style={{ display: 'flex', flexDirection: 'column', gap: '6px', minWidth: '0' }}>
                  <span
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--sky-700)',
                    }}
                  >
                    {'School & learning'}
                  </span>
                  <span
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '21px',
                      lineHeight: '1.3',
                      fontWeight: '700',
                      letterSpacing: '-0.01em',
                      color: 'var(--text-strong)',
                      textWrap: 'pretty',
                    }}
                  >
                    Is my child ready for Class 1? A gentle checklist
                  </span>
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Lakshmi Venkat · 8 min read</span>
                </span>
              </a>
              <a
                className="hv-c"
                href="#"
                style={{ display: 'flex', gap: '18px', textDecoration: 'none', color: 'inherit' }}
              >
                <span
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '44px',
                    lineHeight: '0.9',
                    fontWeight: '700',
                    color: 'var(--pc-orange)',
                    flex: 'none',
                    width: '44px',
                  }}
                >
                  3
                </span>
                <span style={{ display: 'flex', flexDirection: 'column', gap: '6px', minWidth: '0' }}>
                  <span
                    style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      letterSpacing: '0.08em',
                      textTransform: 'uppercase',
                      color: 'var(--butter-700)',
                    }}
                  >
                    Activities
                  </span>
                  <span
                    style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '21px',
                      lineHeight: '1.3',
                      fontWeight: '700',
                      letterSpacing: '-0.01em',
                      color: 'var(--text-strong)',
                      textWrap: 'pretty',
                    }}
                  >
                    10 rainy-day games using things already in your kitchen
                  </span>
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Priya Nair · 4 min read</span>
                </span>
              </a>
            </div>
          </div>
        </section>
        <section aria-labelledby="age-h" style={{ maxWidth: '1200px', margin: '0 auto', padding: '80px 24px 0' }}>
          <h2
            id="age-h"
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: '34px',
              lineHeight: '1.2',
              letterSpacing: '-0.01em',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0',
            }}
          >
            How old is your child?
          </h2>
          <p style={{ fontSize: '19px', lineHeight: '1.45', color: 'var(--text-muted)', margin: '8px 0 24px' }}>
            Pick an age and we’ll tailor the stories below. Tap again to see every age.
          </p>
          <div
            role="group"
            aria-label="Child's age"
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,160px),1fr))',
              gap: '12px',
            }}
          >
            {(v.stages ?? []).map((s, $i0) => (
              <Fragment key={$i0}>
                <button
                  className="hv-k hv-h"
                  type="button"
                  aria-pressed={s?.pressed}
                  onClick={s?.onClick}
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'flex-start',
                    gap: '16px',
                    padding: '20px',
                    minHeight: '132px',
                    boxSizing: 'border-box',
                    borderRadius: '16px',
                    border: `1.5px solid ${s?.bd ?? ''}`,
                    background: s?.bg,
                    color: s?.fg,
                    cursor: 'pointer',
                    textAlign: 'left',
                    fontFamily: 'var(--font-ui)',
                    transition:
                      'background 200ms cubic-bezier(.2,0,0,1), box-shadow 200ms cubic-bezier(.2,0,0,1), transform 200ms cubic-bezier(.2,0,0,1)',
                  }}
                >
                  <Icon name={s?.icon} size={30} color={s?.ic} />
                  <span style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                    <span style={{ fontSize: '19px', fontWeight: '700' }}>{s?.label}</span>
                    <span style={{ fontSize: '15px', color: s?.sub }}>{s?.age}</span>
                  </span>
                </button>
              </Fragment>
            ))}
          </div>
        </section>
        <section
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '56px 24px 0',
            display: 'flex',
            flexWrap: 'wrap',
            gap: '64px',
            alignItems: 'flex-start',
          }}
        >
          <div style={{ flex: '999 1 560px', minWidth: '0' }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'baseline',
                justifyContent: 'space-between',
                gap: '16px',
                flexWrap: 'wrap',
                paddingBottom: '20px',
                borderBottom: '1px solid var(--border-default)',
              }}
            >
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '27px',
                  lineHeight: '1.25',
                  letterSpacing: '-0.01em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                }}
              >
                {v.feedTitle}
              </h2>
              <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{v.feedSub}</span>
            </div>
            <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', margin: '20px 0 4px' }}>
              {(v.topics ?? []).map((t, $i0) => (
                <Fragment key={$i0}>
                  <Tag selected={t?.selected} onClick={t?.onClick}>
                    {t?.label}
                  </Tag>
                </Fragment>
              ))}
            </div>
            {v.showList ? (
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                {(v.feed ?? []).map((a, $i0) => (
                  <Fragment key={$i0}>
                    <div style={{ padding: '28px 0', borderBottom: '1px solid var(--border-subtle)' }}>
                      <ArticleCard layout="row" {...a?.card} />
                    </div>
                  </Fragment>
                ))}
              </div>
            ) : null}
            {v.showGrid ? (
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,250px),1fr))',
                  gap: '40px 28px',
                  paddingTop: '28px',
                }}
              >
                {(v.feed ?? []).map((a, $i0) => (
                  <Fragment key={$i0}>
                    <ArticleCard layout="vertical" {...a?.card} />
                  </Fragment>
                ))}
              </div>
            ) : null}
            {v.isEmpty ? (
              <div
                style={{
                  padding: '40px 0',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'flex-start',
                  gap: '16px',
                }}
              >
                <p
                  style={{
                    fontFamily: 'var(--font-serif)',
                    fontSize: '20px',
                    lineHeight: '1.5',
                    color: 'var(--text-body)',
                    margin: '0',
                  }}
                >
                  We don’t have stories on this topic for this age yet. Try another topic, or see every age.
                </p>
                <Button variant="secondary" onClick={v.showAllAges}>
                  Show all ages
                </Button>
              </div>
            ) : null}
            <div style={{ paddingTop: '28px' }}>
              <Button variant="secondary" iconRight="arrow-right">
                See all stories
              </Button>
            </div>
          </div>
          <aside style={{ flex: '1 1 300px', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '40px' }}>
            <Card tint="sage" padding={24}>
              <Icon name="stethoscope" size={28} color="var(--sage-700)" />
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '22px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '12px 0 6px',
                }}
              >
                Ask an expert
              </div>
              <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-body)', marginBottom: '18px' }}>
                Paediatricians, psychologists and educators answer within 48 hours. You can ask anonymously.
              </div>
              <a href={toUrl('/ask-the-expert')} style={{ display: 'block', textDecoration: 'none' }}>
                <Button variant="dark" fullWidth={true}>
                  Ask a question
                </Button>
              </a>
            </Card>
            <div>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                  marginBottom: '8px',
                }}
              >
                Circles to join
              </div>
              {(v.circles ?? []).map((c, $i0) => (
                <Fragment key={$i0}>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      padding: '12px 0',
                      borderBottom: '1px solid var(--border-subtle)',
                    }}
                  >
                    <Avatar name={c?.name} size={44} />
                    <div style={{ flex: '1', minWidth: '0' }}>
                      <div style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>{c?.name}</div>
                      <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>{c?.members}</div>
                    </div>
                    <Button size="sm" variant={c?.variant} icon={c?.icon} onClick={c?.onClick}>
                      {c?.btn}
                    </Button>
                  </div>
                </Fragment>
              ))}
            </div>
            <Card padding={24}>
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '22px',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0 0 6px',
                }}
              >
                The Sunday letter
              </div>
              <div style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-muted)', marginBottom: '18px' }}>
                One calm email a week, matched to your child’s age. No spam, ever.
              </div>
              {v.notSubscribed ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <Input
                    type="email"
                    placeholder="Your email"
                    icon="mail"
                    value={v.email}
                    onChange={v.onEmail}
                    error={v.emailError}
                  />
                  <Button variant="primary" fullWidth={true} onClick={v.onSubscribe}>
                    Sign me up
                  </Button>
                </div>
              ) : null}
              {v.subscribed ? (
                <div
                  style={{
                    display: 'flex',
                    gap: '10px',
                    alignItems: 'flex-start',
                    padding: '14px 16px',
                    borderRadius: '10px',
                    background: 'var(--sage-50)',
                    color: 'var(--sage-700)',
                    fontSize: '17px',
                    lineHeight: '1.45',
                  }}
                >
                  <Icon name="circle-check" size={22} />
                  <span>Thank you. Your first letter arrives this Sunday.</span>
                </div>
              ) : null}
            </Card>
          </aside>
        </section>
        <section
          id="community"
          style={{ maxWidth: '1200px', margin: '0 auto', padding: '96px 24px 0', scrollMarginTop: '88px' }}
        >
          <div
            style={{
              display: 'flex',
              alignItems: 'flex-end',
              justifyContent: 'space-between',
              gap: '20px',
              flexWrap: 'wrap',
              marginBottom: '32px',
            }}
          >
            <div>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                  marginBottom: '10px',
                }}
              >
                Community
              </div>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(30px,3.4vw,40px)',
                  lineHeight: '1.15',
                  letterSpacing: '-0.01em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                  textWrap: 'balance',
                }}
              >
                Parents and grandparents, helping each other
              </h2>
            </div>
            <a href={toUrl('/communities')} style={{ textDecoration: 'none', flex: 'none' }}>
              <Button variant="secondary" iconRight="arrow-right">
                Visit the community
              </Button>
            </a>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '48px', alignItems: 'flex-start' }}>
            <article
              style={{
                flex: '1 1 460px',
                minWidth: '0',
                background: 'var(--sage-50)',
                borderRadius: '24px',
                padding: 'clamp(24px,4vw,40px)',
                boxSizing: 'border-box',
              }}
            >
              <div
                style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap', marginBottom: '16px' }}
              >
                <Badge tone="success">Expert answer</Badge>
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                  in Toddler Parents · Kavya S asked 2 hours ago
                </span>
              </div>
              <h3
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '24px',
                  lineHeight: '1.3',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                  textWrap: 'pretty',
                }}
              >
                “My 2-year-old refuses to sleep without the phone. How did you stop it?”
              </h3>
              <div
                style={{
                  width: '48px',
                  height: '3px',
                  borderRadius: '2px',
                  background: 'var(--pc-orange)',
                  margin: '24px 0 20px',
                }}
              ></div>
              <p
                style={{
                  fontFamily: 'var(--font-serif)',
                  fontSize: '22px',
                  lineHeight: '1.6',
                  color: 'var(--text-body)',
                  margin: '0 0 24px',
                  textWrap: 'pretty',
                }}
              >
                You’re not doing anything wrong — you’re teaching a new habit. Swap the phone for a short, predictable
                routine: bath, two books, one song. Expect three or four hard nights. Then it gets easier.
              </p>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
                <Avatar name="Meera Iyer" size={40} ring={true} />
                <div style={{ flex: '1 1 auto' }}>
                  <div style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>Dr. Meera Iyer</div>
                  <div style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Child psychologist, Chennai</div>
                </div>
                <div style={{ display: 'flex', gap: '20px', fontSize: '16px', color: 'var(--text-muted)' }}>
                  <span style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
                    <Icon name="heart" size={20} />
                    58 found helpful
                  </span>
                  <span style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
                    <Icon name="message-circle" size={20} />
                    34 replies
                  </span>
                </div>
              </div>
            </article>
            <div style={{ flex: '1 1 360px', minWidth: '0' }}>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                  marginBottom: '4px',
                }}
              >
                Waiting for your answer
              </div>
              <article style={{ padding: '20px 0', borderBottom: '1px solid var(--border-default)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                  <Avatar name="Bala Narayanan" size={32} />
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                    <span style={{ fontWeight: '600', color: 'var(--text-strong)' }}>Bala Narayanan</span>
                    {' · Grandparents Corner'}
                  </span>
                </div>
                <h3
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '20px',
                    lineHeight: '1.35',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0',
                    textWrap: 'pretty',
                  }}
                >
                  Grandfather here — how do I help my grandson with homework without confusing him?
                </h3>
                <div
                  style={{
                    display: 'flex',
                    gap: '6px',
                    alignItems: 'center',
                    marginTop: '10px',
                    fontSize: '15px',
                    color: 'var(--text-muted)',
                  }}
                >
                  <Icon name="message-circle" size={18} />
                  21 replies · 5 hours ago
                </div>
              </article>
              <article style={{ padding: '20px 0', borderBottom: '1px solid var(--border-default)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                  <Avatar name="Shalini M" size={32} />
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                    <span style={{ fontWeight: '600', color: 'var(--text-strong)' }}>Shalini M</span>
                    {' · Picky Eaters'}
                  </span>
                </div>
                <h3
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '20px',
                    lineHeight: '1.35',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0',
                    textWrap: 'pretty',
                  }}
                >
                  Tiffin ideas that actually come back empty? My 5-year-old is so picky.
                </h3>
                <div
                  style={{
                    display: 'flex',
                    gap: '6px',
                    alignItems: 'center',
                    marginTop: '10px',
                    fontSize: '15px',
                    color: 'var(--text-muted)',
                  }}
                >
                  <Icon name="message-circle" size={18} />
                  62 replies · Yesterday
                </div>
              </article>
              <article style={{ padding: '20px 0', borderBottom: '1px solid var(--border-default)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                  <Avatar name="Arun P" size={32} />
                  <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>
                    <span style={{ fontWeight: '600', color: 'var(--text-strong)' }}>Arun P</span>
                    {' · Parents of Teens'}
                  </span>
                </div>
                <h3
                  style={{
                    fontFamily: 'var(--font-display)',
                    fontSize: '20px',
                    lineHeight: '1.35',
                    fontWeight: '700',
                    color: 'var(--text-strong)',
                    margin: '0',
                    textWrap: 'pretty',
                  }}
                >
                  My 14-year-old wants to stop tuition classes. Should I let her decide?
                </h3>
                <div
                  style={{
                    display: 'flex',
                    gap: '6px',
                    alignItems: 'center',
                    marginTop: '10px',
                    fontSize: '15px',
                    color: 'var(--text-muted)',
                  }}
                >
                  <Icon name="message-circle" size={18} />
                  18 replies · Yesterday
                </div>
              </article>
              <div style={{ paddingTop: '20px' }}>
                <Button variant="primary" icon="message-circle">
                  Ask the community
                </Button>
              </div>
            </div>
          </div>
        </section>
        <section
          id="programs"
          style={{ maxWidth: '1200px', margin: '0 auto', padding: '96px 24px 0', scrollMarginTop: '88px' }}
        >
          <div
            style={{
              fontSize: '14px',
              fontWeight: '700',
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              color: 'var(--text-muted)',
              marginBottom: '10px',
            }}
          >
            Programs
          </div>
          <h2
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(30px,3.4vw,40px)',
              lineHeight: '1.15',
              letterSpacing: '-0.01em',
              fontWeight: '700',
              color: 'var(--text-strong)',
              margin: '0 0 32px',
              textWrap: 'balance',
            }}
          >
            Learn alongside your child
          </h2>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,420px),1fr))',
              gap: '24px',
            }}
          >
            <div style={{ height: '100%' }}>
              <Card tint="butter" padding={32} {...v.fullHeight}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', height: '100%' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '12px' }}>
                    <div
                      style={{
                        width: '64px',
                        height: '64px',
                        borderRadius: '16px',
                        background: 'var(--butter-100)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-around',
                      }}
                    >
                      <Icon name="puzzle" size={32} color="var(--butter-700)" />
                    </div>
                    <Badge tone="warning">Ages 2–6</Badge>
                  </div>
                  <div>
                    <h3
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '27px',
                        lineHeight: '1.25',
                        letterSpacing: '-0.01em',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0 0 8px',
                      }}
                    >
                      Little Learners @Home
                    </h3>
                    <p
                      style={{
                        fontFamily: 'var(--font-serif)',
                        fontSize: '19px',
                        lineHeight: '1.55',
                        color: 'var(--text-body)',
                        margin: '0',
                        textWrap: 'pretty',
                      }}
                    >
                      Play-based preschool learning you can do together at home, in about 20 minutes a day.
                    </p>
                  </div>
                  <div
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '10px',
                      fontSize: '17px',
                      color: 'var(--text-body)',
                    }}
                  >
                    <span style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                      <Icon name="check" size={20} color="var(--butter-700)" />A daily activity plan, ready each morning
                    </span>
                    <span style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                      <Icon name="check" size={20} color="var(--butter-700)" />
                      Printable worksheets in English and Tamil
                    </span>
                    <span style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                      <Icon name="check" size={20} color="var(--butter-700)" />
                      Simple progress notes for parents
                    </span>
                  </div>
                  <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', marginTop: 'auto', paddingTop: '4px' }}>
                    <Button variant="primary">Start free week</Button>
                    <Button variant="ghost">See a sample day</Button>
                  </div>
                </div>
              </Card>
            </div>
            <div style={{ height: '100%' }}>
              <Card tint="sky" padding={32} {...v.fullHeight}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', height: '100%' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '12px' }}>
                    <div
                      style={{
                        width: '64px',
                        height: '64px',
                        borderRadius: '16px',
                        background: 'var(--sky-100)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-around',
                      }}
                    >
                      <Icon name="star" size={32} color="var(--sky-700)" />
                    </div>
                    <Badge tone="info">Live, online</Badge>
                  </div>
                  <div>
                    <h3
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '27px',
                        lineHeight: '1.25',
                        letterSpacing: '-0.01em',
                        fontWeight: '700',
                        color: 'var(--text-strong)',
                        margin: '0 0 8px',
                      }}
                    >
                      SuperStar Parenting Program
                    </h3>
                    <p
                      style={{
                        fontFamily: 'var(--font-serif)',
                        fontSize: '19px',
                        lineHeight: '1.55',
                        color: 'var(--text-body)',
                        margin: '0',
                        textWrap: 'pretty',
                      }}
                    >
                      Live sessions with child experts and a small group of parents going through the same stage as you.
                    </p>
                  </div>
                  <div
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '10px',
                      fontSize: '17px',
                      color: 'var(--text-body)',
                    }}
                  >
                    <span style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                      <Icon name="check" size={20} color="var(--sky-700)" />
                      Weekly live sessions with experts
                    </span>
                    <span style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                      <Icon name="check" size={20} color="var(--sky-700)" />
                      Recordings to watch any time
                    </span>
                    <span style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                      <Icon name="check" size={20} color="var(--sky-700)" />A private circle for your batch
                    </span>
                  </div>
                  <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', marginTop: 'auto', paddingTop: '4px' }}>
                    <Button variant="primary">See schedule</Button>
                    <Button variant="ghost">How it works</Button>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </section>
        <section id="magazine" style={{ marginTop: '96px', background: 'var(--orange-50)', scrollMarginTop: '72px' }}>
          <div
            style={{
              maxWidth: '1200px',
              margin: '0 auto',
              padding: '64px 24px',
              display: 'flex',
              flexWrap: 'wrap',
              gap: '56px',
              alignItems: 'center',
              boxSizing: 'border-box',
            }}
          >
            <div
              style={{
                flex: '0 1 280px',
                minWidth: '220px',
                aspectRatio: '3 / 4',
                position: 'relative',
                borderRadius: '16px',
                background: 'var(--orange-100)',
                overflow: 'hidden',
                boxShadow: 'var(--shadow-lg)',
              }}
            >
              <image-slot
                id="magazine-cover"
                shape="rounded"
                radius="16"
                placeholder="Magazine cover — this month’s issue"
              ></image-slot>
            </div>
            <div style={{ flex: '1 1 420px', minWidth: '0' }}>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-700)',
                  marginBottom: '12px',
                }}
              >
                Print magazine
              </div>
              <h2
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(32px,3.8vw,44px)',
                  lineHeight: '1.15',
                  letterSpacing: '-0.015em',
                  fontWeight: '700',
                  color: 'var(--text-strong)',
                  margin: '0',
                  textWrap: 'balance',
                }}
              >
                A calm read, delivered to your door every month
              </h2>
              <p
                style={{
                  fontFamily: 'var(--font-serif)',
                  fontSize: '21px',
                  lineHeight: '1.6',
                  color: 'var(--text-body)',
                  margin: '16px 0 28px',
                  maxWidth: '560px',
                  textWrap: 'pretty',
                }}
              >
                {'The ParentCircle magazine comes in English and '}
                <span style={{ fontFamily: 'var(--font-tamil-serif)' }}>தமிழ்</span>
                {' — for parents and grandparents who’d rather read on paper.'}
              </p>
              <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                <Button variant="primary" size="lg">
                  Subscribe
                </Button>
                <Button variant="secondary" size="lg">
                  Read a free issue
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer
        style={{
          background: '#1e2528',
          color: 'var(--text-inverse)',
          '--neutral-100': '#eef2f3',
          '--neutral-200': '#d5dde0',
          '--neutral-300': '#b0bcc1',
          '--neutral-600': '#56666d',
          '--neutral-700': '#3b494f',
          '--neutral-800': '#2b363b',
        }}
      >
        <div
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '56px 24px 40px',
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,200px),1fr))',
            gap: '32px',
            boxSizing: 'border-box',
          }}
        >
          <div>
            <Logo variant="white" height={28} />
            <p
              style={{
                fontFamily: 'var(--font-serif)',
                fontSize: '19px',
                lineHeight: '1.5',
                color: 'var(--neutral-200)',
                margin: '16px 0 0',
                maxWidth: '300px',
              }}
            >
              Expert-backed guidance for every stage of raising a child — from infancy to the teenage years.
            </p>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--orange-300)',
                marginBottom: '2px',
              }}
            >
              Read
            </div>
            <a
              className="hv-j"
              href="#"
              style={{ fontSize: '17px', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Child health
            </a>
            <a
              className="hv-j"
              href="#"
              style={{ fontSize: '17px', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Learning
            </a>
            <a
              className="hv-j"
              href="#"
              style={{ fontSize: '17px', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Emotional wellness
            </a>
            <a
              className="hv-j"
              href="#"
              style={{ fontSize: '17px', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Activities
            </a>
            <a
              className="hv-j"
              href="#"
              style={{ fontSize: '17px', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Teens
            </a>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--orange-300)',
                marginBottom: '2px',
              }}
            >
              Community
            </div>
            <a
              className="hv-j"
              href={toUrl('/communities')}
              style={{ fontSize: '17px', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              All circles
            </a>
            <a
              className="hv-j"
              href={toUrl('/ask-the-expert')}
              style={{ fontSize: '17px', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Ask an expert
            </a>
            <a
              className="hv-j"
              href={toUrl('/guidelines')}
              style={{ fontSize: '17px', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Community guidelines
            </a>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--orange-300)',
                marginBottom: '2px',
              }}
            >
              Programs
            </div>
            <a
              className="hv-j"
              href="#"
              style={{ fontSize: '17px', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Little Learners @Home
            </a>
            <a
              className="hv-j"
              href="#"
              style={{ fontSize: '17px', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              SuperStar Parenting
            </a>
            <a
              className="hv-j"
              href="#"
              style={{ fontSize: '17px', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Print magazine
            </a>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--orange-300)',
                marginBottom: '2px',
              }}
            >
              About
            </div>
            <a
              className="hv-j"
              href={toUrl('/about')}
              style={{ fontSize: '17px', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              About us
            </a>
            <a
              className="hv-j"
              href="#"
              style={{ fontSize: '17px', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Our experts
            </a>
            <a
              className="hv-j"
              href="#"
              style={{ fontSize: '17px', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Contact
            </a>
            <a
              className="hv-j"
              href={toUrl('/privacy')}
              style={{ fontSize: '17px', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Privacy
            </a>
          </div>
        </div>
        <div
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '20px 24px 32px',
            borderTop: '1px solid var(--neutral-700)',
            fontSize: '15px',
            color: 'var(--neutral-300)',
            display: 'flex',
            justifyContent: 'space-between',
            gap: '16px',
            flexWrap: 'wrap',
            boxSizing: 'border-box',
          }}
        >
          <span>© 2026 Shri Harini Media Ltd. · A Ramco Group company · Chennai</span>
          <span>
            {'Read in English · '}
            <span style={{ fontFamily: 'var(--font-tamil-sans)' }}>தமிழில் படிக்க</span>
          </span>
        </div>
      </footer>
    </div>
  );
}
