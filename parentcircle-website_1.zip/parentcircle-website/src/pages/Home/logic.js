import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = {
    stage: 'toddler',
    topic: 'all',
    saved: ['a3'],
    heroSaved: false,
    lang: null,
    email: '',
    emailError: '',
    subscribed: false,
    joined: [],
  };

  stageList = [
    { id: 'baby', label: 'Baby', age: '0–1 year', icon: 'baby', feed: 'For your baby' },
    { id: 'toddler', label: 'Toddler', age: '1–3 years', icon: 'footprints', feed: 'For your toddler' },
    { id: 'preschool', label: 'Preschooler', age: '3–6 years', icon: 'puzzle', feed: 'For your preschooler' },
    { id: 'primary', label: 'Primary school', age: '6–10 years', icon: 'backpack', feed: 'For your school-goer' },
    { id: 'preteen', label: 'Pre-teen', age: '10–13 years', icon: 'bike', feed: 'For your pre-teen' },
    { id: 'teen', label: 'Teen', age: '13–18 years', icon: 'smartphone', feed: 'For your teenager' },
  ];

  topicList = [
    { id: 'all', label: 'For you' },
    { id: 'health', label: 'Health' },
    { id: 'learning', label: 'Learning' },
    { id: 'emotions', label: 'Emotions' },
    { id: 'play', label: 'Activities' },
    { id: 'teens', label: 'Teens & tweens' },
  ];

  articles = [
    {
      id: 'a14',
      topic: 'health',
      category: 'Nutrition',
      stages: ['baby'],
      title: 'Your baby’s first foods: a ragi-to-rice weaning plan',
      dek: 'A paediatric dietitian’s week-by-week guide from 6 months.',
      author: 'Anjali Rao',
      readTime: '7 min read',
    },
    {
      id: 'a2',
      topic: 'health',
      category: 'Nutrition',
      stages: ['toddler', 'preschool'],
      title: '5 iron-rich foods your toddler will actually eat',
      dek: 'Simple swaps for everyday Indian meals — ragi, dates, greens and more.',
      author: 'Anjali Rao',
      readTime: '5 min read',
    },
    {
      id: 'a6',
      topic: 'health',
      category: 'Child health',
      stages: ['baby', 'toddler'],
      title: 'Fever in babies: when to wait and when to call the doctor',
      dek: 'A paediatrician’s clear guide for worried parents and grandparents.',
      author: 'Dr. S. Raman',
      readTime: '6 min read',
    },
    {
      id: 'a12',
      topic: 'emotions',
      category: 'Behaviour',
      stages: ['toddler'],
      title: 'Biting, hitting, throwing: what your toddler is trying to tell you',
      dek: 'Most of it is communication, not bad behaviour. Here’s how to respond.',
      author: 'Dr. Meera Iyer',
      readTime: '6 min read',
    },
    {
      id: 'a7',
      topic: 'learning',
      category: 'Sleep',
      stages: ['baby', 'toddler'],
      title: 'Night waking at 9 months: is it a sleep regression?',
      dek: 'What’s normal, what helps, and when to talk to your doctor.',
      author: 'Dr. Kavitha Rao',
      readTime: '5 min read',
    },
    {
      id: 'a5',
      topic: 'play',
      category: 'Activities',
      stages: ['toddler', 'preschool', 'primary'],
      title: '10 rainy-day games using things already in your kitchen',
      dek: 'No screens, no shopping, plenty of laughter.',
      author: 'Priya Nair',
      readTime: '4 min read',
    },
    {
      id: 'a3',
      topic: 'learning',
      category: 'School & learning',
      stages: ['preschool', 'primary'],
      title: 'Is my child ready for Class 1? A gentle checklist',
      dek: 'It’s less about reading early and more about these six everyday skills.',
      author: 'Lakshmi Venkat',
      readTime: '8 min read',
    },
    {
      id: 'a13',
      topic: 'play',
      category: 'Activities',
      stages: ['preschool'],
      title: 'Little hands, big skills: 6 fine-motor games for 3-year-olds',
      dek: 'Rangoli dots, peeling peas and other everyday play that builds pencil grip.',
      author: 'Priya Nair',
      readTime: '5 min read',
    },
    {
      id: 'a8',
      topic: 'emotions',
      category: 'Emotional wellness',
      stages: ['preschool', 'primary', 'preteen'],
      title: 'When your child says “I hate you” — what to say next',
      dek: 'It stings. A child psychologist on staying calm and reconnecting.',
      author: 'Dr. Meera Iyer',
      readTime: '6 min read',
    },
    {
      id: 'a15',
      topic: 'learning',
      category: 'School & learning',
      stages: ['primary'],
      title: 'Homework without tears: a 20-minute routine that works',
      dek: 'Fewer reminders, more independence — tested by families in Chennai.',
      author: 'Lakshmi Venkat',
      readTime: '6 min read',
    },
    {
      id: 'a9',
      topic: 'emotions',
      category: 'Relationships',
      stages: ['baby', 'toddler', 'preschool', 'primary', 'preteen', 'teen'],
      title: 'Parents and grandparents disagree on discipline? Try this middle path',
      dek: 'Three conversations that help the whole family stay on the same side.',
      author: 'Ravi Kumar',
      readTime: '7 min read',
    },
    {
      id: 'a4',
      topic: 'teens',
      category: 'Teens',
      stages: ['preteen', 'teen'],
      title: 'Talking to your teenager about screen time — without a fight',
      dek: 'Make an agreement together instead of laying down rules.',
      author: 'Ravi Kumar',
      readTime: '7 min read',
    },
    {
      id: 'a10',
      topic: 'teens',
      category: 'Digital life',
      stages: ['preteen', 'teen'],
      title: 'Your child’s first phone: a family agreement you can print',
      dek: 'What to agree on before you hand it over — in plain words.',
      author: 'Sneha Pillai',
      readTime: '5 min read',
    },
    {
      id: 'a11',
      topic: 'learning',
      category: 'Exams',
      stages: ['teen'],
      title: 'Board exam stress: how to help without adding pressure',
      dek: 'What to say, what to skip, and how to spot when your teen needs more support.',
      author: 'Dr. Arvind Shankar',
      readTime: '8 min read',
    },
  ];

  circleList = [
    { id: 'toddler', name: 'Toddler Parents', members: '12,400 parents' },
    { id: 'grand', name: 'Grandparents Corner', members: '3,100 members' },
    { id: 'teen', name: 'Parents of Teens', members: '8,700 parents' },
  ];

  noop = () => {};
  fullHeight = { style: { height: '100%', boxSizing: 'border-box' } };

  toggleSave = (id) =>
    this.setState((s) => ({ saved: s.saved.includes(id) ? s.saved.filter((x) => x !== id) : [...s.saved, id] }));
  toggleJoin = (id) =>
    this.setState((s) => ({ joined: s.joined.includes(id) ? s.joined.filter((x) => x !== id) : [...s.joined, id] }));
  onEmail = (e) => this.setState({ email: e.target.value, emailError: '' });
  onSubscribe = () => {
    if (!/\S+@\S+\.\S+/.test(this.state.email))
      this.setState({ emailError: 'Please add your email so we can send the letter.' });
    else this.setState({ subscribed: true });
  };

  renderVals() {
    const S = this.state,
      P = this.props;
    const lang = S.lang ?? (P.defaultLanguage === 'Tamil' ? 'ta' : 'en');
    const grid = (P.feedLayout ?? 'List') === 'Grid';
    const stage = this.stageList.find((s) => s.id === S.stage);

    const stages = this.stageList.map((s) => {
      const on = S.stage === s.id;
      return {
        ...s,
        pressed: on ? 'true' : 'false',
        onClick: () => this.setState({ stage: on ? null : s.id }),
        bg: on ? 'var(--neutral-900)' : 'var(--white)',
        fg: on ? 'var(--text-inverse)' : 'var(--text-strong)',
        bd: on ? 'var(--neutral-900)' : 'var(--border-default)',
        sub: on ? 'var(--neutral-200)' : 'var(--text-muted)',
        ic: on ? 'var(--orange-300)' : 'var(--orange-600)',
      };
    });

    const topics = this.topicList.map((t) => ({
      ...t,
      selected: S.topic === t.id,
      onClick: () => this.setState({ topic: t.id }),
    }));

    const matches = this.articles.filter(
      (a) => (!S.stage || a.stages.includes(S.stage)) && (S.topic === 'all' || a.topic === S.topic),
    );
    const feed = matches.slice(0, 6).map((a) => ({
      id: a.id,
      card: {
        title: a.title,
        dek: a.dek,
        category: a.category,
        topic: a.topic,
        author: a.author,
        readTime: a.readTime,
        saved: S.saved.includes(a.id),
        onSave: () => this.toggleSave(a.id),
        onClick: this.noop,
      },
    }));
    const n = matches.length;

    const circles = this.circleList.map((c) => {
      const on = S.joined.includes(c.id);
      return {
        ...c,
        btn: on ? 'Joined' : 'Join',
        variant: on ? 'ghost' : 'secondary',
        icon: on ? 'check' : undefined,
        onClick: () => this.toggleJoin(c.id),
      };
    });

    return {
      isEn: lang === 'en',
      isTa: lang === 'ta',
      langLabel: lang === 'en' ? 'தமிழ்' : 'English',
      toggleLang: () => this.setState({ lang: lang === 'en' ? 'ta' : 'en' }),
      heroSaveIcon: S.heroSaved ? 'bookmark-check' : 'bookmark',
      heroSaveLabel: S.heroSaved ? 'Saved' : 'Save for later',
      toggleHeroSave: () => this.setState((s) => ({ heroSaved: !s.heroSaved })),
      stages,
      topics,
      feed,
      circles,
      feedTitle: stage ? stage.feed : 'Latest for every age',
      feedSub: (n === 1 ? '1 story' : n + ' stories') + (stage ? ' · ' + stage.age : ''),
      showList: !grid && n > 0,
      showGrid: grid && n > 0,
      isEmpty: n === 0,
      showAllAges: () => this.setState({ stage: null, topic: 'all' }),
      email: S.email,
      emailError: S.emailError || undefined,
      onEmail: this.onEmail,
      onSubscribe: this.onSubscribe,
      subscribed: S.subscribed,
      notSubscribed: !S.subscribed,
      fullHeight: this.fullHeight,
    };
  }
}

export default PageLogic;
