import { Fragment } from 'react';
import { Button, Icon } from '../../components/ds';
import { SiteFooter, SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Terms" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      id="top"
      data-screen-label="Terms of use"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader />
      <main>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '32px 24px 0', boxSizing: 'border-box' }}>
          <nav aria-label="Company" style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '48px' }}>
            <a
              className="hv-0"
              href={toUrl('/about')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              About us
            </a>
            <a
              className="hv-0"
              href={toUrl('/press')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Press releases
            </a>
            <a
              className="hv-0"
              href={toUrl('/guidelines')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Community guidelines
            </a>
            <a
              className="hv-0"
              href={toUrl('/community-help')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Community help
            </a>
            <a
              href={toUrl('/terms')}
              aria-current="page"
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                background: 'var(--neutral-900)',
                color: 'var(--text-inverse)',
                fontSize: '16px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Terms of use
            </a>
            <a
              className="hv-0"
              href={toUrl('/privacy')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Privacy policy
            </a>
            <a
              className="hv-0"
              href={toUrl('/contact')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Contact us
            </a>
          </nav>
          <div style={{ maxWidth: '760px' }}>
            <div
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--orange-700)',
                marginBottom: '12px',
              }}
            >
              Legal
            </div>
            <h1
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(38px,5vw,56px)',
                lineHeight: '1.08',
                letterSpacing: '-0.015em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0',
              }}
            >
              Terms of use
            </h1>
            <p
              style={{
                fontFamily: 'var(--font-serif)',
                fontSize: '22px',
                lineHeight: '1.55',
                color: 'var(--text-body)',
                margin: '16px 0 0',
                textWrap: 'pretty',
              }}
            >
              Welcome to ParentCircle, and other services and apps from the house of Shri Harini Media Ltd.
            </p>
          </div>
        </section>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '40px 24px 0', boxSizing: 'border-box' }}>
          <div style={{ background: 'var(--neutral-50)', borderRadius: '24px', padding: '28px' }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '12px',
                flexWrap: 'wrap',
                marginBottom: '16px',
              }}
            >
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                }}
              >
                On this page
              </div>
              <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>23 sections</span>
            </div>
            <ol style={{ listStyle: 'none', margin: '0', padding: '0', columns: '3 220px', columnGap: '32px' }}>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s1"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>1</span>
                  Who can use ParentCircle
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s2"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>2</span>
                  Creating an account
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s3"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>3</span>
                  Business and institution use
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s4"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>4</span>
                  Content
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s5"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>5</span>
                  User guidelines
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s6"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>6</span>
                  Your content
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s7"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>7</span>
                  Third-party links and services
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s8"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>8</span>
                  Contests and promotions
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s9"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>9</span>
                  Privacy
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s10"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>10</span>
                  Security
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s11"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>11</span>
                  Copyright
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s12"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>12</span>
                  Changes to these terms
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s13"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>13</span>
                  Additional services and payments
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s14"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>14</span>
                  Indemnity
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s15"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>15</span>
                  Disclaimer of warranties
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s16"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>16</span>
                  Limitation of liability
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s17"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>17</span>
                  Disruption of services
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s18"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>18</span>
                  Discontinuance and changes
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s19"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>19</span>
                  Applicable law and jurisdiction
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s20"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>20</span>
                  Our entire agreement
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s21"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>21</span>
                  Shipping
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s22"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>22</span>
                  Refunds and replacement
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s23"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>23</span>
                  Contact ParentCircle
                </a>
              </li>
            </ol>
          </div>
        </section>
        <article
          style={{
            maxWidth: '808px',
            margin: '0 auto',
            padding: '56px 24px 0',
            boxSizing: 'border-box',
            fontFamily: 'var(--font-reading)',
            fontSize: '19px',
            lineHeight: '1.7',
            color: 'var(--text-body)',
          }}
        >
          <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
            ParentCircle is a platform in the parenting space that enables parents, educators and child experts to meet
            like-minded individuals, to exchange ideas, information, and experiences, and share knowledge on topics
            related to parenting, wellness, learning, family and lifestyle.
          </p>
          <div
            style={{
              display: 'flex',
              gap: '14px',
              alignItems: 'flex-start',
              padding: '20px 22px',
              borderRadius: '16px',
              background: 'var(--orange-50)',
              margin: '24px 0 8px',
              fontFamily: 'var(--font-ui)',
            }}
          >
            <Icon name="file-text" size={24} color="var(--orange-700)" />
            <p style={{ fontSize: '17px', lineHeight: '1.55', color: 'var(--text-strong)', margin: '0' }}>
              {
                'Please note that when you use the products, services, and applications of Shri Harini Media Ltd., henceforth referred to by its property, ParentCircle, you agree to its Terms of Use and its '
              }
              <a href={toUrl('/privacy')}>Privacy Policy</a>. So, do take a few minutes to go through these terms
              carefully. Feel free to get in touch with us if you have any questions.
            </p>
          </div>
          <section id="s1" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>1</span>
              Who can use ParentCircle
            </h2>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              {
                'You must be at least fifteen (15) years of age or above, and must be capable of entering, performing and adhering to these terms, and you agree to be bound by the following terms and conditions. However, anyone under the age of 15, is also eligible to register on ParentCircle, provided you, the parent/guardian, give your consent and agree to be bound by these Terms of Use and its '
              }
              <a href={toUrl('/privacy')}>Privacy Policy</a>
              {' with respect to ParentCircle.'}
            </p>
          </section>
          <section id="s2" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>2</span>
              Creating an account on ParentCircle
            </h2>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              When you create your ParentCircle account, you need to provide accurate and complete information. You will
              be responsible for preserving the confidentiality of your password, and for all the actions of person/s
              accessing any of our sites through any password assigned to you. You will notify us immediately of any
              known or suspected unauthorized use of your account.
            </p>
          </section>
          <section id="s3" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>3</span>
              Business/Institute/Organization use of ParentCircle
            </h2>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              If you are using ParentCircle on behalf of a business, institution, organization or other entity, you are
              still individually bound by this agreement, even if your company has a separate agreement with us.
              Additionally, you represent and warrant that you are authorized to grant all permissions and licenses
              provided in these terms and bind the entity to these terms, and that you agree to these terms on the
              entity's behalf.
            </p>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              It is against our Terms of Use to represent other businesses or brands without authority and ParentCircle
              will not be held responsible for misleading and illegal representation of a brand, person or entity.
            </p>
          </section>
          <section id="s4" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>4</span>
              Content
            </h2>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              ParentCircle offers various types of services on our platform that may be protected by one or more laws
              regarding intellectual property. Content published on this platform is the sole property of the creator of
              the content and may be protected by copyrights, trademarks and other intellectual and proprietary rights.
              You may use our content for your personal, non-commercial purposes. However, you shall not reproduce,
              distribute, or otherwise use any of the materials without the prior written consent of the rights holder.
              You are completely responsible for determining if any of the content on our site is or is not protected by
              intellectual property rights. You are free to link to information on our site and encourage others to
              access the content on our site. You may establish a hypertext link to our site so long as the link does
              not state or imply any sponsorship or endorsement of your site by us. ParentCircle provides links and
              access to third party content. You are completely responsible for ensuring that you do not violate any
              intellectual property and/or other rights of the third parties.
            </p>
          </section>
          <section id="s5" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>5</span>
              User guidelines
            </h2>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              You agree to use our services only for lawful purposes. If you have an account with ParentCircle, you have
              complete access to all basic features such as searching for clipbooks, viewing public content, sharing,
              commenting and creating clipbooks. If you do not have an account with ParentCircle your access will be
              limited to searching for and viewing the public clipbooks.
            </p>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,320px),1fr))',
                gap: '16px',
                margin: '20px 0',
                fontFamily: 'var(--font-ui)',
              }}
            >
              <div style={{ border: '1px solid var(--border-default)', borderRadius: '16px', padding: '20px 22px' }}>
                <div style={{ fontSize: '17px', fontWeight: '700', color: 'var(--text-strong)', marginBottom: '10px' }}>
                  You agree not to use our site to post or collect materials that are:
                </div>
                <ul
                  style={{
                    margin: '0',
                    paddingLeft: '1.2em',
                    fontSize: '16px',
                    lineHeight: '1.55',
                    color: 'var(--text-body)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '6px',
                  }}
                >
                  <li>False, inaccurate and/or misleading</li>
                  <li>
                    Likely to infringe any third party's copyright, patent, trademark, or other proprietary rights or
                    rights of publicity or privacy
                  </li>
                  <li>Illegal or violates any law in force</li>
                  <li>Threatening or harassing</li>
                  <li>Obscene, gory or contain any kind of pornography</li>
                  <li>Excessively violent or prompting harm to self or others</li>
                  <li>
                    Content that qualifies as phishing or spam or that might abuse or present a security threat to
                    ParentCircle
                  </li>
                  <li>
                    Likely to contain any viruses, or other computer programming routines intended to damage,
                    detrimentally interfere with, surreptitiously intercept or expropriate any system, data or personal
                    information
                  </li>
                  <li>Likely to interfere with the ability of others to use our site</li>
                </ul>
              </div>
              <div style={{ border: '1px solid var(--border-default)', borderRadius: '16px', padding: '20px 22px' }}>
                <div style={{ fontSize: '17px', fontWeight: '700', color: 'var(--text-strong)', marginBottom: '10px' }}>
                  You agree not to:
                </div>
                <ul
                  style={{
                    margin: '0',
                    paddingLeft: '1.2em',
                    fontSize: '16px',
                    lineHeight: '1.55',
                    color: 'var(--text-body)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '6px',
                  }}
                >
                  <li>
                    Sell, sponsor, or otherwise monetise any other service or functionality of ParentCircle, without the
                    express written permission of ParentCircle
                  </li>
                  <li>Create a member profile for anyone other than a natural person</li>
                  <li>Post unwanted/unsolicited messages in content, comments etc., with a commercial intent</li>
                  <li>Use ParentCircle’s name, logo, trademark or branding without our prior approval</li>
                  <li>
                    Break or circumvent our security measures or otherwise test the vulnerability of our systems or
                    networks
                  </li>
                  <li>
                    Collect or store personally identifiable information from ParentCircle or its users without
                    permission
                  </li>
                  <li>Sell or otherwise transfer your username for compensation</li>
                  <li>Directly compensate users for following or unfollowing</li>
                  <li>
                    Create or display ads/campaigns/properties that look like or could be confused with ParentCircle
                    content
                  </li>
                </ul>
              </div>
            </div>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              Any unacceptable use of our service, may result in immediate termination of your account and suspension of
              service access in the future.
            </p>
          </section>
          <section id="s6" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>6</span>
              Your content
            </h2>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              ParentCircle allows you to post content such as photos, comments, videos, articles and other material.
              Anything that you post or otherwise make available on our platforms is referred to as ‘user content’. You
              solely own the rights to the content you create and post on ParentCircle and you assume complete
              responsibility for it. You accept all risk associated with your published content, including issues
              related to accuracy and/or legal claims. You agree that you have the necessary rights to the content that
              you publish on ParentCircle, and that doing so doesn’t conflict with any licenses you may have granted to
              others. While you still own this content, you also grant ParentCircle a license to the content and/or
              information you provide us. In addition, you grant ParentCircle and its users a non-exclusive,
              royalty-free, transferable, sub-licensable, worldwide license to use, store, display, reproduce, re-clip,
              modify, create derivative works, perform and distribute your user content on ParentCircle. It may also
              include promoting your content on social media, partner companies and services for distributing your
              content. Nothing in these terms shall restrict other legal rights ParentCircle may have, to user content.
              We do not moderate anyone’s content, but we reserve the right to modify or remove user content for any
              reason, including what we believe violates these terms or our policies. ParentCircle does not assume any
              liability for anything that you or anyone else publishes on our site.
            </p>
          </section>
          <section id="s7" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>7</span>
              Third-party links, sites, and services
            </h2>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              Our products may contain links to third-party websites, advertisers, services, special offers, or other
              events or activities that are not owned or controlled by ParentCircle. We do not endorse or assume any
              responsibility for any such third-party sites, information, materials, products, or services. If you
              access any third party website, service, or content from ParentCircle, you do so at your own risk and you
              agree that ParentCircle will have no liability arising from your use of, or access to any third-party
              website, service, or content.
            </p>
          </section>
          <section id="s8" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>8</span>
              Contests / Promotions
            </h2>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              On occasions, we may organise contests and other promotions in association with a sponsor. By
              participating in a promotion, you submit to that promotion's terms and conditions, including providing us
              with permission, if required, to share your personally identifiable information with a particular sponsor.
            </p>
          </section>
          <section id="s9" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>9</span>
              Privacy
            </h2>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              {'Our '}
              <a href={toUrl('/privacy')}>Privacy Policy</a>
              {
                ' explains how we collect, store and use the information you provide us, including personal information.'
              }
            </p>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              {'Our '}
              <a href={toUrl('/privacy')}>Privacy Policy</a>
              {
                ' may be updated from time to time. By continuing to use our site, you accept our updated and/or revised policy. Hence it is advisable to check it from time to time.'
              }
            </p>
          </section>
          <section id="s10" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>10</span>
              Security
            </h2>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              ParentCircle is truly concerned about the security of our properties. While we take all necessary measures
              to protect the security of your content and information, we cannot guarantee that unauthorized third
              parties will be unable to breach the security of our site. If you discover that your account has been
              compromised in any manner, you should let us know immediately. This will help us take appropriate action
              to improve our security measures.
            </p>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              {'To report a security breach, please email us at: '}
              <a href="mailto:contact@parentcircle.com">contact@parentcircle.com</a>.
            </p>
          </section>
          <section id="s11" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>11</span>
              Copyright
            </h2>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              {
                'ParentCircle respects the intellectual property rights of others and expects its users to do the same. If you are concerned that there is a copyright or other intellectual property rights violation/infringement, please write to us at '
              }
              <a href="mailto:contact@parentcircle.com">contact@parentcircle.com</a>. ParentCircle will, at its sole
              discretion, take appropriate action, including removal of the disputed material from our site.
              ParentCircle reserves the right to disable and/or terminate the accounts of users who repeatedly infringe
              or have been repeatedly charged with infringing the copyrights, and/or intellectual property rights of
              others.
            </p>
          </section>
          <section id="s12" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>12</span>
              Changes to Terms of Use
            </h2>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              ParentCircle may add to or change or update this Terms of Use, from time to time, entirely at our own
              discretion. You are responsible for checking these Terms of Use periodically to remain in compliance with
              these terms. Your use of the site after any amendment to the Terms of Use shall constitute your acceptance
              to these terms, and you also agree to be bound by any such changes/revisions.
            </p>
          </section>
          <section id="s13" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>13</span>
              Additional services
            </h2>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              ParentCircle also offer a platform that facilitates users (both account holders and guests) to
              purchase/subscribe to products/services that we may offer, using a payment gateway. All payments made
              against the purchases/services shall be compulsorily in INR or any other currency acceptable in the
              Republic of India. You, as a buyer, understand that upon initiating a transaction, you are entering into a
              legally binding and enforceable contract with us to purchase the products and/or services from us, using
              the payment facility, and you shall pay to us the transaction price, through your issuing bank using
              payment gateway.
            </p>
            <p style={{ margin: '0 0 0.6em', textWrap: 'pretty' }}>
              While availing any of the payment method/s available on our site, ParentCircle will not be responsible or
              assume any liability whatsoever, with respect to any loss or damage arising directly or indirectly to you
              due to:
            </p>
            <ul
              style={{ margin: '0 0 1em', paddingLeft: '1.2em', display: 'flex', flexDirection: 'column', gap: '4px' }}
            >
              <li>Lack of authorization for any transaction/s</li>
              <li>Exceeding the preset limit mutually agreed upon by and between you and your bank</li>
              <li>Any payment issues arising out of the transaction</li>
              <li>Decline of transaction for any other reason/s</li>
            </ul>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              You understand, accept and agree that the payment facility provided by ParentCircle is neither a banking
              nor a financial service, but is merely a facilitator providing an electronic, automated online electronic
              payment system, receiving payment for the transactions on the site, via the authorized banking
              infrastructure and credit card payment gateway networks. Further, by providing a payment facility,
              ParentCircle is neither acting as a trustee nor acting in a fiduciary capacity with respect to the
              transaction or the transaction price. You, as the buyer understand that any payment made to us for
              purchase is non-refundable; however the company can take reversal decisions based on the merit of a case,
              and any such decision shall be at our sole discretion. Any occurrence of transaction or payment failure
              caused due to technical reasons would be reversed in the same account and through our bank, subject to the
              set rules laid down by our banker/s in such cases. Such refund shall be made in INR only and shall be
              equivalent to the transaction price received in INR.
            </p>
          </section>
          <section id="s14" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>14</span>
              Indemnity
            </h2>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              You agree to hold us and our affiliates, agents and licensors harmless from any claim that may arise from
              your use of any of our sites.
            </p>
          </section>
          <section id="s15" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>15</span>
              Disclaimer of warranties
            </h2>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              ParentCircle is provided “as is” and “as available” without any warranties, express or implied.
            </p>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              You agree that use of ParentCircle platforms is at your sole risk and that you are solely responsible for
              any damage or loss resulting from use of material, information and/or data on ParentCircle. ParentCircle,
              its affiliates, agents and licensors cannot and do not warrant the accuracy, completeness, relevance,
              non-infringement, merchantability, or fitness for a particular purpose of the information, content and
              services available through our platforms. ParentCircle does not guarantee our platforms to be error-free,
              secure, continuously available or free of viruses or other harmful components. ParentCircle is not a
              substitute for professional services or advice. Neither ParentCircle nor its users, while participating in
              ParentCircle are engaged in rendering legal, medical, counselling or other professional services or
              advice. ParentCircle, its affiliates, agents, and licensors make no warranty regarding any goods or
              services referred to, advertised on, or obtained through our platforms, other than those express
              warranties ParentCircle itself specifically makes on any ParentCircle order form.
            </p>
          </section>
          <section id="s16" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>16</span>
              Limitation of liability
            </h2>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              To the maximum extent permitted by law, ParentCircle will not be liable for any indirect, incidental,
              special, consequential or punitive damages, or any loss of profits or revenues, whether incurred directly
              or indirectly, or any loss of data, use, goodwill, or other intangible losses, resulting from (a) your
              access to or use of or inability to access or use the products; (b) any conduct or content of any third
              party on the products, including without limitation, any defamatory, offensive or illegal conduct of other
              users or third parties; or (c) unauthorized access, use or alteration of your transmissions or content.
            </p>
          </section>
          <section id="s17" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>17</span>
              Potential disruption of services
            </h2>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              Access to ParentCircle may, on occasions, be unavailable, delayed, limited or slowed due to damage caused
              by severe weather, earthquakes, wars, insurrection, riots, terrorism, civil commotion, act of God,
              accident, fire, water damage, explosion, mechanical breakdown or natural disasters. If access to our site
              is unavailable, delayed or limited, or if our site does not operate quickly and efficiently, you may be
              unable to transmit your instructions for transactions and other matters, or such instructions may not be
              promptly executed or you may be unable to retrieve information on a timely basis. If your operations are
              dependent on such communications with us, and such communications are disrupted or delayed, you may suffer
              losses. ParentCircle will not be liable for any such loss.
            </p>
          </section>
          <section id="s18" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>18</span>
              Discontinuance, modification and restrictions
            </h2>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              ParentCircle may discontinue, change, suspend or restrict access to any of our sites or any portion of our
              sites at any time without liability to you or any third party.
            </p>
          </section>
          <section id="s19" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>19</span>
              Applicable law and exclusive jurisdiction
            </h2>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              Terms of Use shall be governed by and interpreted and construed in accordance with the laws of India. The
              place of jurisdiction shall be exclusively in Chennai.
            </p>
          </section>
          <section id="s20" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>20</span>
              Our entire agreement
            </h2>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              {'Our Terms of Use and '}
              <a href={toUrl('/privacy')}>Privacy Policy</a>
              {
                ' constitute the entire understanding between you and ParentCircle. If a part of this agreement is deemed unenforceable, the remaining provisions of the agreement will remain in full force and effect.'
              }
            </p>
          </section>
          <section id="s21" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>21</span>
              Shipping
            </h2>
            <div
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'center',
                padding: '16px 20px',
                borderRadius: '16px',
                background: 'var(--sky-50)',
                margin: '0 0 1em',
                fontFamily: 'var(--font-ui)',
              }}
            >
              <Icon name="truck" size={26} color="var(--sky-700)" />
              <span style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-strong)' }}>
                Deliveries usually take 8 days to arrive, however in rare cases they can take up to 30 days.
              </span>
            </div>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              A Product will be deemed delivered to the client, a designated location, delivery point or representative
              of the client, including a member of the family, or any other person or authority entitled to receive the
              respective Product. We use third-party couriers to deliver orders, and we are not responsible for any
              third party acts or omissions including lost or delayed orders. Orders are sent out through regular
              shipping or through express delivery.
            </p>
          </section>
          <section id="s22" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>22</span>
              Refunds and replacement
            </h2>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              We accept returns of products in case you have received a wrong product by mischance.
            </p>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              {
                'In such a case, we request you to contact us immediately within 1 day of receiving such a product by writing an email to us at '
              }
              <a href="mailto:learnathome@parentcircle.in">learnathome@parentcircle.in</a>
              {
                ' with the details of the book and Order ID. Please use the email ID from which you had originally placed the order.'
              }
            </p>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              On a case-to-case basis, we will ensure that if you have received any damaged or wrong product, we will
              either issue you a refund or replacement, immediately after we receive the product back from you. To be
              eligible for a return, your item must be unused and in the same condition that you received it. It must
              also be in the original packaging.
            </p>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              Our Customer Care team will guide you on how to return the product to us. We will ensure that your queries
              are served on priority.
            </p>
          </section>
          <section id="s23" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>23</span>
              Contact ParentCircle
            </h2>
            <p style={{ margin: '0 0 20px', textWrap: 'pretty' }}>
              If you have any questions about these Terms of Use or ParentCircle’s treatment of your personal
              information, please contact us at:
            </p>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,270px),1fr))',
                gap: '12px',
                fontFamily: 'var(--font-ui)',
              }}
            >
              <a
                className="hv-f"
                href="mailto:contact@parentcircle.com"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '8px',
                  padding: '20px',
                  borderRadius: '16px',
                  border: '1px solid var(--border-default)',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <Icon name="mail" size={24} color="var(--orange-600)" />
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Email</span>
                <span
                  style={{
                    fontSize: '17px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    overflowWrap: 'break-word',
                  }}
                >
                  contact@parentcircle.com
                </span>
              </a>
              <a
                className="hv-f"
                href="tel:+914424466623"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '8px',
                  padding: '20px',
                  borderRadius: '16px',
                  border: '1px solid var(--border-default)',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <Icon name="phone" size={24} color="var(--orange-600)" />
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Phone</span>
                <span style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                  +91 44 2446 6623
                </span>
              </a>
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '8px',
                  padding: '20px',
                  borderRadius: '16px',
                  border: '1px solid var(--border-default)',
                }}
              >
                <Icon name="map-pin" size={24} color="var(--orange-600)" />
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Address</span>
                <span style={{ fontSize: '16px', lineHeight: '1.5', color: 'var(--text-strong)' }}>
                  No 8/14, Sri Renga Vihar, Karpagam Garden 1st Cross Street, Adyar, Chennai 600020, Tamil Nadu, India
                </span>
              </div>
            </div>
          </section>
        </article>
      </main>
      {v.showTop ? (
        <div style={{ position: 'fixed', right: '24px', bottom: '24px', zIndex: '30' }}>
          <Button variant="dark" size="sm" icon="arrow-up" onClick={v.toTop}>
            Back to top
          </Button>
        </div>
      ) : null}
      <SiteFooter spaced />
    </div>
  );
}
