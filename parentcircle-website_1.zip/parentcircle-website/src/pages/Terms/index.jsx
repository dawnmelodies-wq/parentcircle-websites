import { createPage } from '../../lib/createPage';
import view from './view';
import Logic from './logic';

const css = `summary::-webkit-details-marker{display:none}
html{scroll-behavior:smooth}
body{margin:0;background:var(--white);color:var(--text-body);font-family:var(--font-ui)}
a{color:var(--text-link)} a:hover{color:var(--text-link-hover)}
button:focus-visible,a:focus-visible{outline:3px solid var(--orange-300);outline-offset:2px}
@media (prefers-reduced-motion: reduce){*{transition:none!important;scroll-behavior:auto!important}}
`;

export default createPage({ name: 'Terms', css, view, Logic });
