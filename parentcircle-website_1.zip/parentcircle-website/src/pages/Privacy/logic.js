import React from 'react';
import { PageLogicBase } from '../../lib/createPage';

class PageLogic extends PageLogicBase {
  state = { showTop: false };
  onScroll = () => {
    const s = window.scrollY > 900;
    if (s !== this.state.showTop) this.setState({ showTop: s });
  };
  componentDidMount() {
    window.addEventListener('scroll', this.onScroll, { passive: true });
    this.onScroll();
  }
  componentWillUnmount() {
    window.removeEventListener('scroll', this.onScroll);
  }
  renderVals() {
    return {
      showTop: this.state.showTop,
      toTop: (e) => {
        if (e && e.preventDefault) e.preventDefault();
        window.scrollTo({ top: 0, behavior: 'smooth' });
        document.documentElement.scrollTop = 0;
        document.body.scrollTop = 0;
      },
    };
  }
}

export default PageLogic;
