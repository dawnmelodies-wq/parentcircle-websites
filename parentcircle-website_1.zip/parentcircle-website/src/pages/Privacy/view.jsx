import { Fragment } from 'react';
import { Button, Icon, Logo } from '../../components/ds';
import { SiteHeader } from '../../components/layout';
import { toUrl } from '../../lib/paths';

/** Markup for the "Privacy" page. `v` is the view-model returned by PageLogic#renderVals(). */
export default function view(v) {
  return (
    <div
      id="top"
      data-screen-label="Privacy policy"
      style={{
        minHeight: '100vh',
        background: 'var(--white)',
        fontFamily: 'var(--font-ui)',
        color: 'var(--text-body)',
      }}
    >
      <SiteHeader />
      <main>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '32px 24px 0', boxSizing: 'border-box' }}>
          <nav aria-label="Company" style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '48px' }}>
            <a
              className="hv-0"
              href={toUrl('/about')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              About us
            </a>
            <a
              className="hv-0"
              href={toUrl('/press')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Press releases
            </a>
            <a
              className="hv-0"
              href={toUrl('/guidelines')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Community guidelines
            </a>
            <a
              className="hv-0"
              href={toUrl('/community-help')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Community help
            </a>
            <a
              className="hv-0"
              href={toUrl('/terms')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Terms of use
            </a>
            <a
              href={toUrl('/privacy')}
              aria-current="page"
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                background: 'var(--neutral-900)',
                color: 'var(--text-inverse)',
                fontSize: '16px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Privacy policy
            </a>
            <a
              className="hv-0"
              href={toUrl('/contact')}
              style={{
                height: '40px',
                padding: '0 16px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                color: 'var(--text-strong)',
                fontSize: '16px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
              }}
            >
              Contact us
            </a>
          </nav>
          <div style={{ maxWidth: '760px' }}>
            <div
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--orange-700)',
                marginBottom: '12px',
              }}
            >
              Legal
            </div>
            <h1
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 'clamp(38px,5vw,56px)',
                lineHeight: '1.08',
                letterSpacing: '-0.015em',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0',
              }}
            >
              Privacy policy
            </h1>
            <p
              style={{
                fontFamily: 'var(--font-serif)',
                fontSize: '22px',
                lineHeight: '1.55',
                color: 'var(--text-body)',
                margin: '16px 0 0',
                textWrap: 'pretty',
              }}
            >
              We at Shri Harini Media Ltd, henceforth referred to by our property, ‘ParentCircle’, value your privacy
              and respect how you care about the way your personal information is collected, used and shared.
            </p>
          </div>
        </section>
        <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '40px 24px 0', boxSizing: 'border-box' }}>
          <div style={{ background: 'var(--neutral-50)', borderRadius: '24px', padding: '28px' }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '12px',
                flexWrap: 'wrap',
                marginBottom: '16px',
              }}
            >
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--text-muted)',
                }}
              >
                On this page
              </div>
              <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>8 sections</span>
            </div>
            <ol style={{ listStyle: 'none', margin: '0', padding: '0', columns: '2 280px', columnGap: '32px' }}>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s1"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>1</span>
                  The information we collect
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s2"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>2</span>
                  Using your personal information
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s3"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>3</span>
                  Sharing your personal information
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s4"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>4</span>
                  Storing and securing your information
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s5"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>5</span>
                  Deleting your account
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s6"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>6</span>
                  Changes to this policy
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s7"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>7</span>
                  Linking to other websites
                </a>
              </li>
              <li style={{ breakInside: 'avoid', marginBottom: '6px' }}>
                <a
                  className="hv-5"
                  href="#s8"
                  style={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px 0',
                    fontSize: '16px',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <span style={{ width: '24px', flex: 'none', fontWeight: '700', color: 'var(--orange-700)' }}>8</span>
                  Contact ParentCircle
                </a>
              </li>
            </ol>
          </div>
        </section>
        <article
          style={{
            maxWidth: '808px',
            margin: '0 auto',
            padding: '56px 24px 0',
            boxSizing: 'border-box',
            fontFamily: 'var(--font-reading)',
            fontSize: '19px',
            lineHeight: '1.7',
            color: 'var(--text-body)',
          }}
        >
          <div
            style={{
              display: 'flex',
              gap: '14px',
              alignItems: 'flex-start',
              padding: '20px 22px',
              borderRadius: '16px',
              background: 'var(--sage-50)',
              margin: '0 0 8px',
              fontFamily: 'var(--font-ui)',
            }}
          >
            <Icon name="shield-check" size={24} color="var(--sage-700)" />
            <p style={{ fontSize: '17px', lineHeight: '1.55', color: 'var(--text-strong)', margin: '0' }}>
              By using or accessing our services (web, mobile or any other products of ParentCircle collectively known
              as ‘services’), you acknowledge that you accept the practices and policies outlined in this Privacy
              Policy, and you hereby consent that we will collect, use, and share your information as mentioned in this
              policy.
            </p>
          </div>
          <section id="s1" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>1</span>
              The information we collect
            </h2>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              When you create an account with ParentCircle, you give us your name and email address, and create a
              username and password. You must provide us with accurate and complete information. You will be responsible
              for preserving the confidentiality of your password and for all the actions of persons accessing any of
              our sites through any password assigned to you. You will notify us immediately of any known or suspected
              unauthorized use of your account.
            </p>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              Your user profile helps you customize your account and connect with other ParentCircle users. To help you
              connect with other users and to personalize your experience, we may ask you for additional information,
              including, but not restricted to your photo, date of birth, interests, location, contacts and DOB of
              children. Some of this information, such as, your name and username, will be listed publicly on our
              services, including in search results.
            </p>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              Whenever you share content you see on ParentCircle via email, we may store that email address of the
              person, even if he/she does not have an account on ParentCircle, to send him/her email as part of our
              services. You may also give us permission to access your information in other services. For example, you
              may link your Facebook, Twitter and/or other social media accounts to ParentCircle, which allows us to
              obtain information from those accounts (e.g., your friends or contacts). The information we may obtain
              depends on your settings or privacy policies in these accounts.
            </p>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              We may collect additional information such as your address and phone number for the purpose of enabling
              transactions on our website, and for purchasing/subscribing to any of our products/services.
            </p>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              We receive some other information automatically when you use ParentCircle. These include:
            </p>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,300px),1fr))',
                gap: '12px',
                fontFamily: 'var(--font-ui)',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  gap: '14px',
                  alignItems: 'flex-start',
                  padding: '18px 20px',
                  borderRadius: '16px',
                  border: '1px solid var(--border-default)',
                }}
              >
                <Icon name="monitor-smartphone" size={24} color="var(--sage-700)" />
                <div style={{ minWidth: '0' }}>
                  <div
                    style={{ fontSize: '17px', fontWeight: '700', color: 'var(--text-strong)', marginBottom: '4px' }}
                  >
                    Log data
                  </div>
                  <div style={{ fontSize: '16px', lineHeight: '1.55', color: 'var(--text-body)' }}>
                    Includes your access devices’ hardware info, operating system info, your network info and location
                    details.
                  </div>
                </div>
              </div>
              <div
                style={{
                  display: 'flex',
                  gap: '14px',
                  alignItems: 'flex-start',
                  padding: '18px 20px',
                  borderRadius: '16px',
                  border: '1px solid var(--border-default)',
                }}
              >
                <Icon name="cookie" size={24} color="var(--sage-700)" />
                <div style={{ minWidth: '0' }}>
                  <div
                    style={{ fontSize: '17px', fontWeight: '700', color: 'var(--text-strong)', marginBottom: '4px' }}
                  >
                    Cookies
                  </div>
                  <div style={{ fontSize: '16px', lineHeight: '1.55', color: 'var(--text-body)' }}>
                    Similar to other websites, ParentCircle uses cookies (a small text file sent by our server to your
                    access device each time you visit our website), to personalize your browsing experience and to
                    maintain your session.
                  </div>
                </div>
              </div>
            </div>
          </section>
          <section id="s2" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>2</span>
              Using your personal information
            </h2>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>ParentCircle may use your personal information to:</p>
            <ul
              style={{
                listStyle: 'none',
                margin: '0',
                padding: '0',
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,300px),1fr))',
                gap: '8px',
                fontFamily: 'var(--font-ui)',
              }}
            >
              <li
                style={{
                  display: 'flex',
                  gap: '10px',
                  alignItems: 'flex-start',
                  padding: '12px 14px',
                  borderRadius: '12px',
                  background: 'var(--neutral-50)',
                  fontSize: '16px',
                  lineHeight: '1.5',
                  color: 'var(--text-strong)',
                }}
              >
                <Icon name="check" size={20} color="var(--sage-700)" />
                Administer this website
              </li>
              <li
                style={{
                  display: 'flex',
                  gap: '10px',
                  alignItems: 'flex-start',
                  padding: '12px 14px',
                  borderRadius: '12px',
                  background: 'var(--neutral-50)',
                  fontSize: '16px',
                  lineHeight: '1.5',
                  color: 'var(--text-strong)',
                }}
              >
                <Icon name="check" size={20} color="var(--sage-700)" />
                Allow you to access and use our website
              </li>
              <li
                style={{
                  display: 'flex',
                  gap: '10px',
                  alignItems: 'flex-start',
                  padding: '12px 14px',
                  borderRadius: '12px',
                  background: 'var(--neutral-50)',
                  fontSize: '16px',
                  lineHeight: '1.5',
                  color: 'var(--text-strong)',
                }}
              >
                <Icon name="check" size={20} color="var(--sage-700)" />
                Publish information about you on the site
              </li>
              <li
                style={{
                  display: 'flex',
                  gap: '10px',
                  alignItems: 'flex-start',
                  padding: '12px 14px',
                  borderRadius: '12px',
                  background: 'var(--neutral-50)',
                  fontSize: '16px',
                  lineHeight: '1.5',
                  color: 'var(--text-strong)',
                }}
              >
                <Icon name="check" size={20} color="var(--sage-700)" />
                Publish your postings on the site for public viewing
              </li>
              <li
                style={{
                  display: 'flex',
                  gap: '10px',
                  alignItems: 'flex-start',
                  padding: '12px 14px',
                  borderRadius: '12px',
                  background: 'var(--neutral-50)',
                  fontSize: '16px',
                  lineHeight: '1.5',
                  color: 'var(--text-strong)',
                }}
              >
                <Icon name="check" size={20} color="var(--sage-700)" />
                Help you connect with other users on the site
              </li>
              <li
                style={{
                  display: 'flex',
                  gap: '10px',
                  alignItems: 'flex-start',
                  padding: '12px 14px',
                  borderRadius: '12px',
                  background: 'var(--neutral-50)',
                  fontSize: '16px',
                  lineHeight: '1.5',
                  color: 'var(--text-strong)',
                }}
              >
                <Icon name="check" size={20} color="var(--sage-700)" />
                Help us transact with you to send to you products that you purchase
              </li>
              <li
                style={{
                  display: 'flex',
                  gap: '10px',
                  alignItems: 'flex-start',
                  padding: '12px 14px',
                  borderRadius: '12px',
                  background: 'var(--neutral-50)',
                  fontSize: '16px',
                  lineHeight: '1.5',
                  color: 'var(--text-strong)',
                }}
              >
                <Icon name="check" size={20} color="var(--sage-700)" />
                Enable us to provide you with services you subscribe to
              </li>
              <li
                style={{
                  display: 'flex',
                  gap: '10px',
                  alignItems: 'flex-start',
                  padding: '12px 14px',
                  borderRadius: '12px',
                  background: 'var(--neutral-50)',
                  fontSize: '16px',
                  lineHeight: '1.5',
                  color: 'var(--text-strong)',
                }}
              >
                <Icon name="check" size={20} color="var(--sage-700)" />
                Send marketing communications to you
              </li>
            </ul>
          </section>
          <section id="s3" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>3</span>
              Sharing your personal information
            </h2>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              We may disclose any information we collect, with third parties, only after we receive your consent to do
              so. We may disclose non-private or non-personal information aggregated and non-personally identifiable.
              Any such disclosure will not include non-public, personal information regarding individual users.
            </p>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              We employ third parties to assist us in providing and improving our services, such as without limitation,
              maintenance, database management and web analytics companies. Where we disclose your personal information
              to such third parties, they will be obligated to use such personal information in accordance with the
              terms of this privacy statement.
            </p>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              In addition to the disclosures deemed necessary for the purposes identified elsewhere above, ParentCircle
              may disclose your personal information to the extent that it is required to do so by law, in connection
              with any legal proceedings or prospective legal proceedings, and in order to establish, exercise or defend
              its legal rights. ParentCircle may sell, transfer or otherwise share some or all of its assets, including
              the information identified in this Privacy Policy, in connection with a merger, acquisition,
              reorganization or sale of assets or in the event of bankruptcy.
            </p>
          </section>
          <section id="s4" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>4</span>
              Storing and securing your information
            </h2>
            <p style={{ margin: '0 0 1em', textWrap: 'pretty' }}>
              ParentCircle will take reasonable technical and organisational precautions to prevent any loss, misuse,
              misrepresentation or alteration of your personal information. Information that ParentCircle collects may
              be stored and processed in and/or transferred between any of the countries in which ParentCircle, its
              affiliates or service providers operate, to enable the use of the information in accordance with this
              privacy policy.
            </p>
            <div
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'flex-start',
                padding: '16px 20px',
                borderRadius: '16px',
                background: 'var(--butter-50)',
                fontFamily: 'var(--font-ui)',
              }}
            >
              <Icon name="globe" size={24} color="var(--butter-700)" />
              <span style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--text-strong)' }}>
                Please note that any information that you submit for publication on the website may be published on the
                Internet and be available around the world.
              </span>
            </div>
          </section>
          <section id="s5" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>5</span>
              Deleting your account
            </h2>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              If you decide to delete your account, your user profile will no longer be visible on our platform.
              However, we may retain your user content for a commercially reasonable period of time for backup,
              archival, and/or audit purposes. Furthermore, ParentCircle and its users may retain and continue to use,
              store, display, reproduce, re-clip, modify and distribute any of the content you have made publicly
              available through ParentCircle (comments, clips, clipbooks etc.).
            </p>
          </section>
          <section id="s6" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>6</span>
              Changes to this policy
            </h2>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              ParentCircle may update this Privacy Policy as it sees fit at any time and will post a new version on this
              website. You should keep checking this page to be aware of any changes to our Privacy Policy, as you will,
              at all times be bound by our updated policies. By continuing to use ParentCircle, you agree to accept any
              changes and/or updates to our policy.
            </p>
          </section>
          <section id="s7" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>7</span>
              Linking to other websites
            </h2>
            <p style={{ margin: '0', textWrap: 'pretty' }}>
              ParentCircle may contain links to other websites/affiliates, and is not responsible for the privacy
              policies or practices of such websites.
            </p>
          </section>
          <section id="s8" style={{ scrollMarginTop: '96px', paddingTop: '40px' }}>
            <h2
              style={{
                display: 'flex',
                gap: '14px',
                alignItems: 'baseline',
                fontFamily: 'var(--font-display)',
                fontSize: '26px',
                lineHeight: '1.3',
                fontWeight: '700',
                color: 'var(--text-strong)',
                margin: '0 0 12px',
              }}
            >
              <span style={{ fontSize: '18px', color: 'var(--orange-700)', minWidth: '28px' }}>8</span>
              Contact ParentCircle
            </h2>
            <p style={{ margin: '0 0 20px', textWrap: 'pretty' }}>
              If you have any questions about this Privacy Policy or ParentCircle’s treatment of your personal
              information, please contact us at:
            </p>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,270px),1fr))',
                gap: '12px',
                fontFamily: 'var(--font-ui)',
              }}
            >
              <a
                className="hv-f"
                href="mailto:contact@parentcircle.com"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '8px',
                  padding: '20px',
                  borderRadius: '16px',
                  border: '1px solid var(--border-default)',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <Icon name="mail" size={24} color="var(--orange-600)" />
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Email</span>
                <span
                  style={{
                    fontSize: '17px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    overflowWrap: 'break-word',
                  }}
                >
                  contact@parentcircle.com
                </span>
              </a>
              <a
                className="hv-f"
                href="tel:+914424466623"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '8px',
                  padding: '20px',
                  borderRadius: '16px',
                  border: '1px solid var(--border-default)',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
              >
                <Icon name="phone" size={24} color="var(--orange-600)" />
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Phone</span>
                <span style={{ fontSize: '17px', fontWeight: '600', color: 'var(--text-strong)' }}>
                  +91 44 2446 6623
                </span>
              </a>
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '8px',
                  padding: '20px',
                  borderRadius: '16px',
                  border: '1px solid var(--border-default)',
                }}
              >
                <Icon name="map-pin" size={24} color="var(--orange-600)" />
                <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>Address</span>
                <span style={{ fontSize: '16px', lineHeight: '1.5', color: 'var(--text-strong)' }}>
                  No 8/14, Sri Renga Vihar, Karpagam Garden 1st Cross Street, Adyar, Chennai 600020, Tamil Nadu, India
                </span>
              </div>
            </div>
          </section>
        </article>
      </main>
      <footer
        style={{
          marginTop: '96px',
          background: '#1e2528',
          color: 'var(--text-inverse)',
          '--neutral-100': '#eef2f3',
          '--neutral-200': '#d5dde0',
          '--neutral-300': '#b0bcc1',
          '--neutral-600': '#56666d',
          '--neutral-700': '#3b494f',
          '--neutral-800': '#2b363b',
        }}
      >
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '64px 24px 0', boxSizing: 'border-box' }}>
          <div
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '32px 48px',
              alignItems: 'flex-start',
              justifyContent: 'space-between',
              paddingBottom: '48px',
              borderBottom: '1px solid var(--neutral-700)',
            }}
          >
            <div
              style={{
                flex: '1 1 340px',
                minWidth: '0',
                maxWidth: '460px',
                display: 'flex',
                flexDirection: 'column',
                gap: '18px',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'flex-start', alignSelf: 'stretch' }}>
                <Logo variant="white" height={32} />
              </div>
              <p
                style={{
                  fontFamily: 'var(--font-serif)',
                  fontSize: '20px',
                  lineHeight: '1.55',
                  color: 'var(--neutral-200)',
                  margin: '0',
                  textWrap: 'pretty',
                }}
              >
                Expert-backed guidance for every stage of raising a child — from infancy to the teenage years.
              </p>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                <a
                  className="hv-i"
                  href="https://www.instagram.com/parentcircle/"
                  target="_blank"
                  rel="noopener"
                  style={{
                    height: '40px',
                    padding: '0 14px 0 12px',
                    borderRadius: '999px',
                    background: 'var(--neutral-800)',
                    color: 'var(--neutral-100)',
                    fontSize: '15px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="instagram" size={18} color="currentColor" />
                  Instagram
                </a>
                <a
                  className="hv-i"
                  href="https://www.facebook.com/ParentCirclemagazine/"
                  target="_blank"
                  rel="noopener"
                  style={{
                    height: '40px',
                    padding: '0 14px 0 12px',
                    borderRadius: '999px',
                    background: 'var(--neutral-800)',
                    color: 'var(--neutral-100)',
                    fontSize: '15px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="facebook" size={18} color="currentColor" />
                  Facebook
                </a>
                <a
                  className="hv-i"
                  href="https://www.youtube.com/user/parentcircleindia"
                  target="_blank"
                  rel="noopener"
                  style={{
                    height: '40px',
                    padding: '0 14px 0 12px',
                    borderRadius: '999px',
                    background: 'var(--neutral-800)',
                    color: 'var(--neutral-100)',
                    fontSize: '15px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="youtube" size={18} color="currentColor" />
                  YouTube
                </a>
                <a
                  className="hv-i"
                  href="https://twitter.com/Parent_Circle"
                  target="_blank"
                  rel="noopener"
                  style={{
                    height: '40px',
                    padding: '0 14px 0 12px',
                    borderRadius: '999px',
                    background: 'var(--neutral-800)',
                    color: 'var(--neutral-100)',
                    fontSize: '15px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="twitter" size={18} color="currentColor" />X
                </a>
                <a
                  className="hv-i"
                  href="https://www.pinterest.com/parentcirclecom/"
                  target="_blank"
                  rel="noopener"
                  style={{
                    height: '40px',
                    padding: '0 14px 0 12px',
                    borderRadius: '999px',
                    background: 'var(--neutral-800)',
                    color: 'var(--neutral-100)',
                    fontSize: '15px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="pin" size={18} color="currentColor" />
                  Pinterest
                </a>
              </div>
            </div>
            <div
              style={{
                flex: '1 1 320px',
                minWidth: '0',
                maxWidth: '420px',
                padding: '28px',
                borderRadius: '20px',
                background: 'var(--neutral-800)',
                display: 'flex',
                flexDirection: 'column',
                gap: '10px',
                boxSizing: 'border-box',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-300)',
                }}
              >
                <Icon name="stethoscope" size={18} color="var(--orange-300)" />
                Need help?
              </div>
              <div
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '24px',
                  lineHeight: '1.25',
                  fontWeight: '700',
                  color: 'var(--white)',
                }}
              >
                Ask our experts
              </div>
              <p style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--neutral-200)', margin: '0 0 8px' }}>
                Paediatricians, psychologists and educators answer within 48 hours — you can ask anonymously.
              </p>
              <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                <a href={toUrl('/ask-the-expert')} style={{ textDecoration: 'none' }}>
                  <Button variant="primary" icon="message-circle">
                    Ask a question
                  </Button>
                </a>
                <a
                  className="hv-i"
                  href={toUrl('/join')}
                  style={{
                    height: '48px',
                    padding: '0 18px',
                    borderRadius: 'var(--radius-md)',
                    border: '1.5px solid var(--neutral-600)',
                    color: 'var(--white)',
                    fontSize: '17px',
                    fontWeight: '600',
                    display: 'flex',
                    alignItems: 'center',
                    textDecoration: 'none',
                  }}
                >
                  Join free
                </a>
              </div>
            </div>
          </div>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,180px),1fr))',
              gap: '36px 32px',
              padding: '48px 0',
            }}
          >
            <nav aria-label="Read" style={{ display: 'flex', flexDirection: 'column', gap: '14px', minWidth: '0' }}>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-300)',
                }}
              >
                Read
              </div>
              <a
                className="hv-j"
                href={toUrl('/stories')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Stories
              </a>
              <a
                className="hv-j"
                href={toUrl('/parents-of-india')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Parents of India
              </a>
              <a
                className="hv-j"
                href={toUrl('/ask-the-expert')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Ask an expert
              </a>
              <a
                className="hv-j"
                href={toUrl('/search?query=')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Explore
              </a>
            </nav>
            <nav
              aria-label="Community"
              style={{ display: 'flex', flexDirection: 'column', gap: '14px', minWidth: '0' }}
            >
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-300)',
                }}
              >
                Community
              </div>
              <a
                className="hv-j"
                href={toUrl('/communities')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                All circles
              </a>
              <a
                className="hv-j"
                href={toUrl('/guidelines')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Community guidelines
              </a>
              <a
                className="hv-j"
                href={toUrl('/community-help')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Community help
              </a>
            </nav>
            <nav aria-label="Programs" style={{ display: 'flex', flexDirection: 'column', gap: '14px', minWidth: '0' }}>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-300)',
                }}
              >
                Programs
              </div>
              <a
                className="hv-j"
                href={toUrl('/programs')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                All programs
              </a>
              <a
                className="hv-j"
                href={toUrl('/superstar')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                SuperStar Parenting
              </a>
              <a
                className="hv-j"
                href={toUrl('/programs')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Little Learners @Home
              </a>
            </nav>
            <nav aria-label="About" style={{ display: 'flex', flexDirection: 'column', gap: '14px', minWidth: '0' }}>
              <div
                style={{
                  fontSize: '14px',
                  fontWeight: '700',
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: 'var(--orange-300)',
                }}
              >
                About
              </div>
              <a
                className="hv-j"
                href={toUrl('/about')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                About us
              </a>
              <a
                className="hv-j"
                href={toUrl('/press')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Press releases
              </a>
              <a
                className="hv-j"
                href={toUrl('/contact')}
                style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
              >
                Contact us
              </a>
            </nav>
          </div>
        </div>
        <div style={{ borderTop: '1px solid var(--neutral-700)' }}>
          <div
            style={{
              maxWidth: '1200px',
              margin: '0 auto',
              padding: '20px 24px 28px',
              boxSizing: 'border-box',
              display: 'flex',
              flexWrap: 'wrap',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: '12px 24px',
            }}
          >
            <span style={{ fontSize: '15px', lineHeight: '1.5', color: 'var(--neutral-300)' }}>
              © 2026 Shri Harini Media Ltd. · A Ramco Group company · Chennai
            </span>
            <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '8px 20px' }}>
              <a
                className="hv-j"
                href={toUrl('/privacy')}
                style={{ fontSize: '15px', color: 'var(--neutral-200)', textDecoration: 'none' }}
              >
                Privacy policy
              </a>
              <a
                className="hv-j"
                href={toUrl('/terms')}
                style={{ fontSize: '15px', color: 'var(--neutral-200)', textDecoration: 'none' }}
              >
                Terms of use
              </a>
              <a
                className="hv-i"
                href="#top"
                onClick={v.toTop}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  height: '40px',
                  padding: '0 14px',
                  borderRadius: '999px',
                  background: 'var(--neutral-800)',
                  fontSize: '15px',
                  fontWeight: '600',
                  color: 'var(--neutral-100)',
                  textDecoration: 'none',
                }}
              >
                <Icon name="arrow-up" size={16} color="currentColor" />
                Back to top
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
