import React from 'react';
import Icon from './Icon.jsx';

const SIZES = {
  sm: {
    h: 40,
    px: 16,
    fs: 15,
    ic: 18,
  },
  md: {
    h: 48,
    px: 22,
    fs: 17,
    ic: 20,
  },
  lg: {
    h: 56,
    px: 28,
    fs: 19,
    ic: 22,
  },
};
function Button({
  variant = 'primary',
  size = 'md',
  icon,
  iconRight,
  fullWidth,
  disabled,
  children,
  onClick,
  type = 'button',
  style,
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const V = {
    primary: {
      bg: '#c9600f',
      bgH: 'var(--orange-600)',
      fg: '#fff',
      bd: 'transparent',
    },
    secondary: {
      bg: 'var(--white)',
      bgH: 'var(--neutral-50)',
      fg: 'var(--text-strong)',
      bd: 'var(--border-strong)',
    },
    soft: {
      bg: 'var(--orange-50)',
      bgH: 'var(--orange-100)',
      fg: 'var(--orange-700)',
      bd: 'transparent',
    },
    ghost: {
      bg: 'transparent',
      bgH: 'var(--neutral-100)',
      fg: 'var(--text-strong)',
      bd: 'transparent',
    },
    dark: {
      bg: '#2f5360',
      bgH: '#264550',
      fg: 'var(--text-inverse)',
      bd: 'transparent',
    },
  }[variant];
  return React.createElement(
    'button',
    {
      type: type,
      disabled: disabled,
      onClick: onClick,
      onMouseEnter: () => setHover(true),
      onMouseLeave: () => {
        setHover(false);
        setPress(false);
      },
      onMouseDown: () => setPress(true),
      onMouseUp: () => setPress(false),
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        height: s.h,
        padding: '0 ' + s.px + 'px',
        width: fullWidth ? '100%' : undefined,
        fontFamily: 'var(--font-ui)',
        fontSize: s.fs,
        fontWeight: 600,
        lineHeight: 1,
        borderRadius: 'var(--radius-md)',
        border: '1.5px solid ' + V.bd,
        background: hover && !disabled ? V.bgH : V.bg,
        color: V.fg,
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.45 : 1,
        transform: press ? 'scale(0.98)' : 'none',
        transition: 'background var(--duration-fast) var(--ease-standard), transform var(--duration-fast)',
        whiteSpace: 'nowrap',
        ...style,
      },
    },
    icon &&
      React.createElement(Icon, {
        name: icon,
        size: s.ic,
      }),
    children,
    iconRight &&
      React.createElement(Icon, {
        name: iconRight,
        size: s.ic,
      }),
  );
}

export default Button;
