import React from 'react';
import Icon from './Icon.jsx';

function Input({
  label,
  hint,
  error,
  icon,
  placeholder,
  value,
  defaultValue,
  onChange,
  type = 'text',
  disabled,
  multiline,
  rows = 4,
  id,
  style,
}) {
  const [focus, setFocus] = React.useState(false);
  const Tag = multiline ? 'textarea' : 'input';
  const bd = error ? 'var(--danger)' : focus ? 'var(--border-focus)' : 'var(--border-default)';
  return React.createElement(
    'div',
    {
      style: {
        width: '100%',
        ...style,
      },
    },
    label &&
      React.createElement(
        'label',
        {
          htmlFor: id,
          style: {
            display: 'block',
            fontSize: 16,
            fontWeight: 600,
            color: 'var(--text-strong)',
            marginBottom: 8,
          },
        },
        label,
      ),
    React.createElement(
      'div',
      {
        style: {
          position: 'relative',
          display: 'flex',
          alignItems: multiline ? 'flex-start' : 'center',
        },
      },
      icon &&
        React.createElement(Icon, {
          name: icon,
          size: 20,
          color: 'var(--text-subtle)',
          style: {
            position: 'absolute',
            left: 14,
            top: multiline ? 14 : undefined,
          },
        }),
      React.createElement(Tag, {
        id: id,
        type: multiline ? undefined : type,
        rows: multiline ? rows : undefined,
        placeholder: placeholder,
        value: value,
        defaultValue: defaultValue,
        onChange: onChange,
        disabled: disabled,
        onFocus: () => setFocus(true),
        onBlur: () => setFocus(false),
        style: {
          width: '100%',
          boxSizing: 'border-box',
          minHeight: 'var(--control-h-md)',
          padding: multiline ? '12px 14px' : '0 14px',
          paddingLeft: icon ? 44 : 14,
          fontFamily: 'var(--font-ui)',
          fontSize: 17,
          lineHeight: 1.5,
          color: 'var(--text-strong)',
          background: disabled ? 'var(--neutral-50)' : 'var(--white)',
          border: '1.5px solid ' + bd,
          borderRadius: 'var(--radius-sm)',
          outline: 'none',
          resize: 'vertical',
          boxShadow: focus ? 'var(--focus-ring)' : 'none',
          transition: 'border-color var(--duration-fast), box-shadow var(--duration-fast)',
        },
      }),
    ),
    (error || hint) &&
      React.createElement(
        'div',
        {
          style: {
            fontSize: 15,
            marginTop: 6,
            color: error ? 'var(--danger)' : 'var(--text-muted)',
          },
        },
        error || hint,
      ),
  );
}

export default Input;
