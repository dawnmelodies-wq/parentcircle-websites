import React from 'react';
import Icon from './Icon.jsx';

const C = {
  health: 'sage',
  learning: 'sky',
  emotions: 'blush',
  play: 'butter',
  teens: 'lilac',
};
function Tag({ topic, selected, icon, onClick, onRemove, children, style }) {
  const [hover, setHover] = React.useState(false);
  const hue = C[topic];
  const bg = selected ? 'var(--neutral-900)' : hue ? 'var(--' + hue + '-50)' : 'var(--white)';
  const fg = selected ? 'var(--text-inverse)' : hue ? 'var(--' + hue + '-700)' : 'var(--text-strong)';
  const bd = selected ? 'var(--neutral-900)' : hue ? 'var(--' + hue + '-100)' : 'var(--border-default)';
  const El = onClick ? 'button' : 'span';
  return React.createElement(
    El,
    {
      onClick: onClick,
      onMouseEnter: () => setHover(true),
      onMouseLeave: () => setHover(false),
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        height: 38,
        padding: '0 16px',
        borderRadius: 999,
        border: '1px solid ' + bd,
        background: bg,
        color: fg,
        fontFamily: 'var(--font-ui)',
        fontSize: 16,
        fontWeight: 500,
        whiteSpace: 'nowrap',
        cursor: onClick ? 'pointer' : 'default',
        filter: hover && onClick && !selected ? 'brightness(0.97)' : 'none',
        ...style,
      },
    },
    icon &&
      React.createElement(Icon, {
        name: icon,
        size: 18,
      }),
    children,
    onRemove &&
      React.createElement(
        'span',
        {
          role: 'button',
          'aria-label': 'Remove',
          onClick: (e) => {
            e.stopPropagation();
            onRemove();
          },
          style: {
            display: 'inline-flex',
            marginRight: -4,
            cursor: 'pointer',
          },
        },
        React.createElement(Icon, {
          name: 'x',
          size: 16,
        }),
      ),
  );
}

export default Tag;
