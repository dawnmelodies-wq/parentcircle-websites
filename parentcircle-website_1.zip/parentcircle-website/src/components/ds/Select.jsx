import React from 'react';
import Icon from './Icon.jsx';

function Select({ label, hint, error, options = [], value, defaultValue, onChange, placeholder, disabled, id, style }) {
  const [focus, setFocus] = React.useState(false);
  return React.createElement(
    'div',
    {
      style: {
        width: '100%',
        ...style,
      },
    },
    label &&
      React.createElement(
        'label',
        {
          htmlFor: id,
          style: {
            display: 'block',
            fontSize: 16,
            fontWeight: 600,
            color: 'var(--text-strong)',
            marginBottom: 8,
          },
        },
        label,
      ),
    React.createElement(
      'div',
      {
        style: {
          position: 'relative',
        },
      },
      React.createElement(
        'select',
        {
          id: id,
          value: value,
          defaultValue: value === undefined ? (defaultValue ?? (placeholder ? '' : undefined)) : undefined,
          onChange: onChange,
          disabled: disabled,
          onFocus: () => setFocus(true),
          onBlur: () => setFocus(false),
          style: {
            width: '100%',
            height: 'var(--control-h-md)',
            appearance: 'none',
            WebkitAppearance: 'none',
            padding: '0 44px 0 14px',
            fontFamily: 'var(--font-ui)',
            fontSize: 17,
            color: 'var(--text-strong)',
            background: 'var(--white)',
            cursor: 'pointer',
            border:
              '1.5px solid ' + (error ? 'var(--danger)' : focus ? 'var(--border-focus)' : 'var(--border-default)'),
            borderRadius: 'var(--radius-sm)',
            outline: 'none',
            boxShadow: focus ? 'var(--focus-ring)' : 'none',
          },
        },
        placeholder &&
          React.createElement(
            'option',
            {
              value: '',
              disabled: true,
            },
            placeholder,
          ),
        options.map((o) => {
          const v = typeof o === 'string' ? o : o.value;
          const l = typeof o === 'string' ? o : o.label;
          return React.createElement(
            'option',
            {
              key: v,
              value: v,
            },
            l,
          );
        }),
      ),
      React.createElement(Icon, {
        name: 'chevron-down',
        size: 20,
        color: 'var(--text-muted)',
        style: {
          position: 'absolute',
          right: 14,
          top: 14,
          pointerEvents: 'none',
        },
      }),
    ),
    (error || hint) &&
      React.createElement(
        'div',
        {
          style: {
            fontSize: 15,
            marginTop: 6,
            color: error ? 'var(--danger)' : 'var(--text-muted)',
          },
        },
        error || hint,
      ),
  );
}

export default Select;
