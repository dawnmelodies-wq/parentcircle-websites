import React from 'react';
import IconButton from './IconButton.jsx';

function Dialog({ open = true, title, children, actions, onClose, width = 520, inline }) {
  if (!open) return null;
  const box = React.createElement(
    'div',
    {
      role: 'dialog',
      'aria-modal': 'true',
      'aria-label': title,
      style: {
        width: '100%',
        maxWidth: width,
        background: 'var(--white)',
        borderRadius: 'var(--radius-xl)',
        boxShadow: 'var(--shadow-lg)',
        padding: 32,
        boxSizing: 'border-box',
        position: 'relative',
      },
    },
    onClose &&
      React.createElement(IconButton, {
        icon: 'x',
        label: 'Close',
        size: 44,
        onClick: onClose,
        style: {
          position: 'absolute',
          top: 16,
          right: 16,
        },
      }),
    title &&
      React.createElement(
        'h2',
        {
          style: {
            margin: '0 48px 12px 0',
            fontFamily: 'var(--font-display)',
            fontSize: 27,
            lineHeight: 1.25,
            fontWeight: 700,
            color: 'var(--text-strong)',
          },
        },
        title,
      ),
    React.createElement(
      'div',
      {
        style: {
          fontSize: 18,
          lineHeight: 1.6,
          color: 'var(--text-body)',
        },
      },
      children,
    ),
    actions &&
      React.createElement(
        'div',
        {
          style: {
            display: 'flex',
            gap: 12,
            justifyContent: 'flex-end',
            marginTop: 28,
            flexWrap: 'wrap',
          },
        },
        actions,
      ),
  );
  if (inline) return box;
  return React.createElement(
    'div',
    {
      onClick: (e) => e.target === e.currentTarget && onClose && onClose(),
      style: {
        position: 'fixed',
        inset: 0,
        zIndex: 100,
        background: 'rgba(31,27,24,0.45)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 24,
      },
    },
    box,
  );
}

export default Dialog;
