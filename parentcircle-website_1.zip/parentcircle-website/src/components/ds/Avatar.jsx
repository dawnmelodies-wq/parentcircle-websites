import React from 'react';

const HUES = ['sage', 'sky', 'blush', 'butter', 'lilac'];
function Avatar({ name = '', src, size = 44, ring }) {
  const initials = name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0])
    .join('')
    .toUpperCase();
  const hue = HUES[(name.charCodeAt(0) || 0) % HUES.length];
  return React.createElement(
    'span',
    {
      title: name,
      style: {
        width: size,
        height: size,
        flex: 'none',
        borderRadius: '50%',
        overflow: 'hidden',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'var(--' + hue + '-700)',
        color: 'var(--' + hue + '-100)',
        fontFamily: 'var(--font-ui)',
        fontWeight: 700,
        fontSize: Math.round(size * 0.38),
        boxShadow: ring ? '0 0 0 2px var(--white), 0 0 0 4px var(--pc-orange)' : 'none',
      },
    },
    src
      ? React.createElement('img', {
          src: src,
          alt: name,
          style: {
            width: '100%',
            height: '100%',
            objectFit: 'cover',
          },
        })
      : initials,
  );
}

export default Avatar;
