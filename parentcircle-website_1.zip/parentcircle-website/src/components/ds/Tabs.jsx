import React from 'react';

function Tabs({ tabs = [], value, defaultValue, onChange, variant = 'underline' }) {
  const [inner, setInner] = React.useState(defaultValue ?? (tabs[0] && (tabs[0].value ?? tabs[0])));
  const cur = value ?? inner;
  const pick = (v) => {
    setInner(v);
    onChange && onChange(v);
  };
  const pill = variant === 'pill';
  return React.createElement(
    'div',
    {
      role: 'tablist',
      style: {
        display: 'flex',
        flexWrap: 'wrap',
        gap: 8,
        maxWidth: '100%',
      },
    },
    tabs.map((t) => {
      const v = t.value ?? t;
      const l = t.label ?? t;
      const on = v === cur;
      return React.createElement(
        'button',
        {
          key: v,
          role: 'tab',
          'aria-selected': on,
          onClick: () => pick(v),
          style: {
            display: 'inline-flex',
            alignItems: 'center',
            gap: 6,
            background: on ? 'var(--neutral-900)' : 'var(--white)',
            border: '1px solid ' + (on ? 'var(--neutral-900)' : 'var(--border-default)'),
            cursor: 'pointer',
            whiteSpace: 'nowrap',
            fontFamily: 'var(--font-ui)',
            fontSize: 16,
            fontWeight: 500,
            color: on ? 'var(--text-inverse)' : 'var(--text-strong)',
            height: 38,
            padding: '0 16px',
            borderRadius: 999,
          },
        },
        l,
      );
    }),
  );
}

export default Tabs;
