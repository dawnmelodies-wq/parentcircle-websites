import React from 'react';
import ICONS from './lucide-icons.json';

const LUCIDE = 'https://unpkg.com/lucide-static@0.469.0/icons/';
function Icon({ name, size = 22, color = 'currentColor', label, style }) {
  const svg = ICONS[name];
  const url = svg ? 'url("data:image/svg+xml,' + encodeURIComponent(svg) + '")' : 'url(' + LUCIDE + name + '.svg)';
  return React.createElement('span', {
    role: label ? 'img' : undefined,
    'aria-label': label,
    'aria-hidden': label ? undefined : true,
    style: {
      display: 'inline-block',
      flex: 'none',
      width: size,
      height: size,
      background: color,
      WebkitMask: url + ' center / contain no-repeat',
      mask: url + ' center / contain no-repeat',
      ...style,
    },
  });
}

export default Icon;
