import React from 'react';
import Icon from './Icon.jsx';

function IconButton({ icon, label, variant = 'ghost', size = 48, active, onClick, style }) {
  const [hover, setHover] = React.useState(false);
  const V = {
    ghost: [
      active ? 'var(--orange-50)' : 'transparent',
      'var(--neutral-100)',
      active ? 'var(--orange-600)' : 'var(--text-strong)',
      'transparent',
    ],
    outline: [
      'var(--white)',
      'var(--neutral-50)',
      active ? 'var(--orange-600)' : 'var(--text-strong)',
      'var(--border-default)',
    ],
    filled: ['var(--action-primary)', 'var(--action-primary-hover)', '#fff', 'transparent'],
  }[variant];
  return React.createElement(
    'button',
    {
      type: 'button',
      'aria-label': label,
      title: label,
      'aria-pressed': active,
      onClick: onClick,
      onMouseEnter: () => setHover(true),
      onMouseLeave: () => setHover(false),
      style: {
        width: size,
        height: size,
        borderRadius: 'var(--radius-pill)',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: hover ? V[1] : V[0],
        color: V[2],
        border: '1px solid ' + V[3],
        cursor: 'pointer',
        padding: 0,
        flex: 'none',
        transition: 'background var(--duration-fast)',
        ...style,
      },
    },
    React.createElement(Icon, {
      name: icon,
      size: Math.round(size * 0.46),
    }),
  );
}

export default IconButton;
