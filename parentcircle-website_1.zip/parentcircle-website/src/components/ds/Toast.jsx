import React from 'react';
import Icon from './Icon.jsx';

const T = {
  neutral: ['info', 'var(--orange-300)'],
  success: ['circle-check', 'var(--sage-300)'],
  error: ['circle-alert', '#f2a19b'],
};
function Toast({ tone = 'neutral', children, action, onAction, onClose }) {
  const [ic, c] = T[tone] || T.neutral;
  return React.createElement(
    'div',
    {
      role: 'status',
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        minHeight: 56,
        padding: '10px 12px 10px 18px',
        boxSizing: 'border-box',
        background: 'var(--surface-inverse)',
        color: 'var(--text-inverse)',
        borderRadius: 'var(--radius-md)',
        boxShadow: 'var(--shadow-lg)',
        maxWidth: 520,
        fontFamily: 'var(--font-ui)',
        fontSize: 17,
      },
    },
    React.createElement(Icon, {
      name: ic,
      size: 22,
      color: c,
    }),
    React.createElement(
      'span',
      {
        style: {
          flex: 1,
        },
      },
      children,
    ),
    action &&
      React.createElement(
        'button',
        {
          onClick: onAction,
          style: {
            background: 'none',
            border: 0,
            color: 'var(--orange-300)',
            fontWeight: 700,
            fontSize: 17,
            cursor: 'pointer',
            padding: '8px 10px',
            fontFamily: 'inherit',
          },
        },
        action,
      ),
    onClose &&
      React.createElement(
        'button',
        {
          'aria-label': 'Dismiss',
          onClick: onClose,
          style: {
            background: 'none',
            border: 0,
            color: 'var(--neutral-300)',
            cursor: 'pointer',
            padding: 8,
            display: 'inline-flex',
          },
        },
        React.createElement(Icon, {
          name: 'x',
          size: 20,
        }),
      ),
  );
}

export default Toast;
