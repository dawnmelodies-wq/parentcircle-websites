import React from 'react';

function Logo({ variant = 'color', height = 28, base = '', style }) {
  const file =
    {
      color: 'logo.svg',
      white: 'logo-white.svg',
      'mono-ink': 'logo-mono-ink.svg',
      'mono-white': 'logo-mono-white.svg',
    }[variant] || 'logo.svg';
  return React.createElement('img', {
    src: base + 'assets/' + file,
    alt: 'ParentCircle',
    style: {
      height,
      width: 'auto',
      display: 'block',
      ...style,
    },
  });
}

export default Logo;
