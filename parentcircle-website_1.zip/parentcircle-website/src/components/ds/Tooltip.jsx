import React from 'react';

function Tooltip({ text, children, placement = 'top', open }) {
  const [hover, setHover] = React.useState(false);
  const show = open ?? hover;
  const top = placement === 'top';
  return React.createElement(
    'span',
    {
      style: {
        position: 'relative',
        display: 'inline-flex',
      },
      onMouseEnter: () => setHover(true),
      onMouseLeave: () => setHover(false),
      onFocus: () => setHover(true),
      onBlur: () => setHover(false),
    },
    children,
    show &&
      React.createElement(
        'span',
        {
          role: 'tooltip',
          style: {
            position: 'absolute',
            left: '50%',
            transform: 'translateX(-50%)',
            [top ? 'bottom' : 'top']: 'calc(100% + 8px)',
            background: 'var(--neutral-900)',
            color: 'var(--text-inverse)',
            fontFamily: 'var(--font-ui)',
            fontSize: 15,
            lineHeight: 1.35,
            padding: '8px 12px',
            borderRadius: 8,
            whiteSpace: 'nowrap',
            boxShadow: 'var(--shadow-md)',
            zIndex: 50,
            pointerEvents: 'none',
          },
        },
        text,
      ),
  );
}

export default Tooltip;
