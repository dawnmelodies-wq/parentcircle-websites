import React from 'react';

const T = {
  neutral: ['var(--neutral-700)', 'var(--neutral-100)'],
  brand: ['var(--orange-700)', 'var(--orange-100)'],
  success: ['var(--success)', 'var(--success-bg)'],
  warning: ['var(--warning)', 'var(--butter-100)'],
  danger: ['var(--danger)', 'var(--danger-bg)'],
  info: ['var(--info)', 'var(--info-bg)'],
  solid: ['var(--pc-orange)', 'var(--neutral-900)'],
};
function Badge({ tone = 'neutral', children, style }) {
  const [bg, fg] = T[tone] || T.neutral;
  return React.createElement(
    'span',
    {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        height: 26,
        padding: '0 10px',
        borderRadius: 6,
        background: bg,
        color: fg,
        fontFamily: 'var(--font-ui)',
        fontSize: 14,
        fontWeight: 700,
        lineHeight: 1,
        whiteSpace: 'nowrap',
        ...style,
      },
    },
    children,
  );
}

export default Badge;
