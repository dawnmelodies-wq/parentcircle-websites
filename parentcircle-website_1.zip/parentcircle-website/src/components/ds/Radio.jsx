import React from 'react';

function Radio({ name, options = [], value, defaultValue, onChange, direction = 'column' }) {
  const [inner, setInner] = React.useState(defaultValue);
  const cur = value ?? inner;
  return React.createElement(
    'div',
    {
      role: 'radiogroup',
      style: {
        display: 'flex',
        flexDirection: direction,
        gap: direction === 'row' ? 20 : 12,
        flexWrap: 'wrap',
      },
    },
    options.map((o) => {
      const v = typeof o === 'string' ? o : o.value;
      const l = typeof o === 'string' ? o : o.label;
      const on = cur === v;
      return React.createElement(
        'label',
        {
          key: v,
          style: {
            display: 'flex',
            gap: 12,
            alignItems: 'center',
            cursor: 'pointer',
            minHeight: 32,
            fontSize: 17,
            color: 'var(--text-strong)',
          },
          onClick: () => {
            setInner(v);
            onChange && onChange(v);
          },
        },
        React.createElement(
          'span',
          {
            role: 'radio',
            'aria-checked': on,
            style: {
              width: 24,
              height: 24,
              flex: 'none',
              borderRadius: '50%',
              boxSizing: 'border-box',
              border: '2px solid ' + (on ? 'var(--action-primary)' : 'var(--border-strong)'),
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              background: '#fff',
            },
          },
          on &&
            React.createElement('span', {
              style: {
                width: 12,
                height: 12,
                borderRadius: '50%',
                background: 'var(--action-primary)',
              },
            }),
        ),
        l,
      );
    }),
  );
}

export default Radio;
