import React from 'react';

function Card({ variant = 'raised', tint, padding = 24, interactive, onClick, children, style }) {
  const [hover, setHover] = React.useState(false);
  const bg = tint ? 'var(--' + tint + '-50)' : variant === 'sunken' ? 'var(--surface-sunken)' : 'var(--surface-card)';
  const shadow = variant === 'raised' ? 'var(--shadow-sm)' : 'none';
  const border =
    variant === 'outline'
      ? '1px solid var(--border-default)'
      : variant === 'raised'
        ? '1px solid var(--border-subtle)'
        : 'none';
  return React.createElement(
    'div',
    {
      onClick: onClick,
      onMouseEnter: () => setHover(true),
      onMouseLeave: () => setHover(false),
      style: {
        background: bg,
        borderRadius: 'var(--radius-lg)',
        padding,
        boxShadow: shadow,
        border,
        cursor: interactive ? 'pointer' : undefined,
        transform: 'none',
        transition:
          'box-shadow var(--duration-base) var(--ease-standard), transform var(--duration-base) var(--ease-standard)',
        ...style,
      },
    },
    children,
  );
}

export default Card;
