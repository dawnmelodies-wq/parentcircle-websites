import React from 'react';
import Icon from './Icon.jsx';

function Checkbox({ label, description, checked, defaultChecked, onChange, disabled }) {
  const [inner, setInner] = React.useState(!!defaultChecked);
  const on = checked ?? inner;
  const toggle = () => {
    if (disabled) return;
    setInner(!on);
    onChange && onChange(!on);
  };
  return React.createElement(
    'label',
    {
      style: {
        display: 'flex',
        gap: 12,
        alignItems: description ? 'flex-start' : 'center',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1,
        minHeight: 32,
      },
    },
    React.createElement(
      'span',
      {
        role: 'checkbox',
        'aria-checked': on,
        tabIndex: 0,
        onClick: toggle,
        onKeyDown: (e) => (e.key === ' ' || e.key === 'Enter') && (e.preventDefault(), toggle()),
        style: {
          width: 24,
          height: 24,
          flex: 'none',
          marginTop: description ? 1 : 0,
          borderRadius: 6,
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: on ? 'var(--action-primary)' : 'var(--white)',
          border: '2px solid ' + (on ? 'var(--action-primary)' : 'var(--border-strong)'),
          color: '#fff',
          transition: 'background var(--duration-fast)',
        },
      },
      on &&
        React.createElement(Icon, {
          name: 'check',
          size: 16,
        }),
    ),
    React.createElement(
      'span',
      {
        onClick: toggle,
      },
      React.createElement(
        'span',
        {
          style: {
            display: 'block',
            fontSize: 17,
            color: 'var(--text-strong)',
            lineHeight: description ? 1.4 : '24px',
          },
        },
        label,
      ),
      description &&
        React.createElement(
          'span',
          {
            style: {
              display: 'block',
              fontSize: 15,
              color: 'var(--text-muted)',
              marginTop: 2,
            },
          },
          description,
        ),
    ),
  );
}

export default Checkbox;
