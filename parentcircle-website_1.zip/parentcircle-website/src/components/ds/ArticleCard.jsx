import React from 'react';
import Icon from './Icon.jsx';

const HUE = {
  health: 'sage',
  learning: 'sky',
  emotions: 'blush',
  play: 'butter',
  teens: 'lilac',
};
function ArticleCard({
  title,
  dek,
  category,
  topic,
  author,
  readTime,
  image,
  layout = 'vertical',
  onClick,
  onSave,
  saved,
}) {
  const [hover, setHover] = React.useState(false);
  const hue = HUE[topic] || 'orange';
  const row = layout === 'row';
  const media = React.createElement(
    'div',
    {
      style: {
        flex: row ? '0 0 168px' : undefined,
        aspectRatio: row ? '4 / 3' : '16 / 10',
        borderRadius: 'var(--radius-md)',
        overflow: 'hidden',
        background: 'var(--' + hue + '-100)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      },
    },
    image
      ? React.createElement('img', {
          src: image,
          alt: '',
          style: {
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            transform: hover ? 'scale(1.03)' : 'none',
            transition: 'transform var(--duration-slow) var(--ease-standard)',
          },
        })
      : React.createElement(Icon, {
          name: 'image',
          size: 28,
          color: 'var(--' + hue + '-300)',
        }),
  );
  return React.createElement(
    'article',
    {
      onClick: onClick,
      onMouseEnter: () => setHover(true),
      onMouseLeave: () => setHover(false),
      style: {
        display: 'flex',
        flexDirection: row ? 'row-reverse' : 'column',
        gap: row ? 24 : 16,
        cursor: onClick ? 'pointer' : undefined,
        alignItems: row ? 'flex-start' : 'stretch',
      },
    },
    media,
    React.createElement(
      'div',
      {
        style: {
          flex: 1,
          minWidth: 0,
        },
      },
      category &&
        React.createElement(
          'div',
          {
            style: {
              fontFamily: 'var(--font-ui)',
              fontSize: 14,
              fontWeight: 700,
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              color: 'var(--' + hue + '-700)',
              marginBottom: 8,
            },
          },
          category,
        ),
      React.createElement(
        'h3',
        {
          style: {
            margin: 0,
            fontFamily: 'var(--font-display)',
            fontWeight: 700,
            fontSize: row ? 22 : 24,
            lineHeight: 1.25,
            color: 'var(--text-strong)',
            letterSpacing: '-0.01em',
            textDecoration: hover && onClick ? 'underline' : 'none',
            textDecorationThickness: 1,
            textUnderlineOffset: 4,
            textWrap: 'pretty',
          },
        },
        title,
      ),
      dek &&
        React.createElement(
          'p',
          {
            style: {
              margin: '8px 0 0',
              fontFamily: 'var(--font-serif)',
              fontSize: 18,
              lineHeight: 1.5,
              color: 'var(--text-muted)',
              textWrap: 'pretty',
            },
          },
          dek,
        ),
      (author || readTime) &&
        React.createElement(
          'div',
          {
            style: {
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              marginTop: 12,
              fontFamily: 'var(--font-ui)',
              fontSize: 15,
              color: 'var(--text-muted)',
            },
          },
          author &&
            React.createElement(
              'span',
              {
                style: {
                  color: 'var(--text-strong)',
                  fontWeight: 500,
                },
              },
              author,
            ),
          author &&
            readTime &&
            React.createElement(
              'span',
              {
                'aria-hidden': 'true',
              },
              '\xB7',
            ),
          readTime && React.createElement('span', null, readTime),
          onSave &&
            React.createElement(
              'button',
              {
                'aria-label': 'Save',
                onClick: (e) => {
                  e.stopPropagation();
                  onSave();
                },
                style: {
                  marginLeft: 'auto',
                  background: 'none',
                  border: 0,
                  padding: 8,
                  cursor: 'pointer',
                  color: saved ? 'var(--orange-600)' : 'var(--text-muted)',
                  display: 'inline-flex',
                },
              },
              React.createElement(Icon, {
                name: saved ? 'bookmark-check' : 'bookmark',
                size: 22,
              }),
            ),
        ),
    ),
  );
}

export default ArticleCard;
