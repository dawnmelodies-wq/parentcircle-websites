import React from 'react';

function Switch({ label, description, checked, defaultChecked, onChange, disabled }) {
  const [inner, setInner] = React.useState(!!defaultChecked);
  const on = checked ?? inner;
  const toggle = () => {
    if (disabled) return;
    setInner(!on);
    onChange && onChange(!on);
  };
  return React.createElement(
    'label',
    {
      style: {
        display: 'flex',
        gap: 16,
        alignItems: 'center',
        justifyContent: 'space-between',
        cursor: 'pointer',
        opacity: disabled ? 0.5 : 1,
      },
      onClick: toggle,
    },
    label &&
      React.createElement(
        'span',
        null,
        React.createElement(
          'span',
          {
            style: {
              display: 'block',
              fontSize: 17,
              color: 'var(--text-strong)',
            },
          },
          label,
        ),
        description &&
          React.createElement(
            'span',
            {
              style: {
                display: 'block',
                fontSize: 15,
                color: 'var(--text-muted)',
                marginTop: 2,
              },
            },
            description,
          ),
      ),
    React.createElement(
      'span',
      {
        role: 'switch',
        'aria-checked': on,
        style: {
          width: 52,
          height: 30,
          flex: 'none',
          borderRadius: 999,
          position: 'relative',
          background: on ? 'var(--action-primary)' : 'var(--neutral-300)',
          transition: 'background var(--duration-base) var(--ease-standard)',
        },
      },
      React.createElement('span', {
        style: {
          position: 'absolute',
          top: 3,
          left: on ? 25 : 3,
          width: 24,
          height: 24,
          borderRadius: '50%',
          background: '#fff',
          boxShadow: 'var(--shadow-sm)',
          transition: 'left var(--duration-base) var(--ease-standard)',
        },
      }),
    ),
  );
}

export default Switch;
