import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <main
      style={{
        minHeight: '100vh',
        display: 'grid',
        placeItems: 'center',
        fontFamily: 'var(--font-ui)',
        textAlign: 'center',
        padding: 24,
      }}
    >
      <div>
        <h1 style={{ fontFamily: 'var(--font-serif)', color: 'var(--text-strong)' }}>Page not found</h1>
        <p>
          <Link to="/">Back to the ParentCircle home page</Link>
        </p>
      </div>
    </main>
  );
}
