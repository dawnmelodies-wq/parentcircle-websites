import { Button, Icon, Logo } from '../ds';
import { toUrl } from '../../lib/paths';

/** Site footer. `spaced` adds the 96px gap above it used on long content pages. */
export default function SiteFooter({ spaced = false }) {
  return (
    <footer
      style={{
        ...(spaced ? { marginTop: '96px' } : null),
        background: '#1e2528',
        color: 'var(--text-inverse)',
        '--neutral-100': '#eef2f3',
        '--neutral-200': '#d5dde0',
        '--neutral-300': '#b0bcc1',
        '--neutral-600': '#56666d',
        '--neutral-700': '#3b494f',
        '--neutral-800': '#2b363b',
      }}
    >
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '64px 24px 0', boxSizing: 'border-box' }}>
        <div
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            gap: '32px 48px',
            alignItems: 'flex-start',
            justifyContent: 'space-between',
            paddingBottom: '48px',
            borderBottom: '1px solid var(--neutral-700)',
          }}
        >
          <div
            style={{
              flex: '1 1 340px',
              minWidth: '0',
              maxWidth: '460px',
              display: 'flex',
              flexDirection: 'column',
              gap: '18px',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'flex-start', alignSelf: 'stretch' }}>
              <Logo variant="white" height={32} />
            </div>
            <p
              style={{
                fontFamily: 'var(--font-serif)',
                fontSize: '20px',
                lineHeight: '1.55',
                color: 'var(--neutral-200)',
                margin: '0',
                textWrap: 'pretty',
              }}
            >
              Expert-backed guidance for every stage of raising a child — from infancy to the teenage years.
            </p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
              <a
                className="hv-i"
                href="https://www.instagram.com/parentcircle/"
                target="_blank"
                rel="noopener"
                style={{
                  height: '40px',
                  padding: '0 14px 0 12px',
                  borderRadius: '999px',
                  background: 'var(--neutral-800)',
                  color: 'var(--neutral-100)',
                  fontSize: '15px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                <Icon name="instagram" size={18} color="currentColor" />
                Instagram
              </a>
              <a
                className="hv-i"
                href="https://www.facebook.com/ParentCirclemagazine/"
                target="_blank"
                rel="noopener"
                style={{
                  height: '40px',
                  padding: '0 14px 0 12px',
                  borderRadius: '999px',
                  background: 'var(--neutral-800)',
                  color: 'var(--neutral-100)',
                  fontSize: '15px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                <Icon name="facebook" size={18} color="currentColor" />
                Facebook
              </a>
              <a
                className="hv-i"
                href="https://www.youtube.com/user/parentcircleindia"
                target="_blank"
                rel="noopener"
                style={{
                  height: '40px',
                  padding: '0 14px 0 12px',
                  borderRadius: '999px',
                  background: 'var(--neutral-800)',
                  color: 'var(--neutral-100)',
                  fontSize: '15px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                <Icon name="youtube" size={18} color="currentColor" />
                YouTube
              </a>
              <a
                className="hv-i"
                href="https://twitter.com/Parent_Circle"
                target="_blank"
                rel="noopener"
                style={{
                  height: '40px',
                  padding: '0 14px 0 12px',
                  borderRadius: '999px',
                  background: 'var(--neutral-800)',
                  color: 'var(--neutral-100)',
                  fontSize: '15px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                <Icon name="twitter" size={18} color="currentColor" />X
              </a>
              <a
                className="hv-i"
                href="https://www.pinterest.com/parentcirclecom/"
                target="_blank"
                rel="noopener"
                style={{
                  height: '40px',
                  padding: '0 14px 0 12px',
                  borderRadius: '999px',
                  background: 'var(--neutral-800)',
                  color: 'var(--neutral-100)',
                  fontSize: '15px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  textDecoration: 'none',
                }}
              >
                <Icon name="pin" size={18} color="currentColor" />
                Pinterest
              </a>
            </div>
          </div>
          <div
            style={{
              flex: '1 1 320px',
              minWidth: '0',
              maxWidth: '420px',
              padding: '28px',
              borderRadius: '20px',
              background: 'var(--neutral-800)',
              display: 'flex',
              flexDirection: 'column',
              gap: '10px',
              boxSizing: 'border-box',
            }}
          >
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--orange-300)',
              }}
            >
              <Icon name="stethoscope" size={18} color="var(--orange-300)" />
              Need help?
            </div>
            <div
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '24px',
                lineHeight: '1.25',
                fontWeight: '700',
                color: 'var(--white)',
              }}
            >
              Ask our experts
            </div>
            <p style={{ fontSize: '17px', lineHeight: '1.5', color: 'var(--neutral-200)', margin: '0 0 8px' }}>
              Paediatricians, psychologists and educators answer within 48 hours — you can ask anonymously.
            </p>
            <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
              <a href={toUrl('/ask-the-expert')} style={{ textDecoration: 'none' }}>
                <Button variant="primary" icon="message-circle">
                  Ask a question
                </Button>
              </a>
              <a
                className="hv-i"
                href={toUrl('/join')}
                style={{
                  height: '48px',
                  padding: '0 18px',
                  borderRadius: 'var(--radius-md)',
                  border: '1.5px solid var(--neutral-600)',
                  color: 'var(--white)',
                  fontSize: '17px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  textDecoration: 'none',
                }}
              >
                Join free
              </a>
            </div>
          </div>
        </div>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,180px),1fr))',
            gap: '36px 32px',
            padding: '48px 0',
          }}
        >
          <nav aria-label="Read" style={{ display: 'flex', flexDirection: 'column', gap: '14px', minWidth: '0' }}>
            <div
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--orange-300)',
              }}
            >
              Read
            </div>
            <a
              className="hv-j"
              href={toUrl('/stories')}
              style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Stories
            </a>
            <a
              className="hv-j"
              href={toUrl('/parents-of-india')}
              style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Parents of India
            </a>
            <a
              className="hv-j"
              href={toUrl('/ask-the-expert')}
              style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Ask an expert
            </a>
            <a
              className="hv-j"
              href={toUrl('/search?query=')}
              style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Explore
            </a>
          </nav>
          <nav aria-label="Community" style={{ display: 'flex', flexDirection: 'column', gap: '14px', minWidth: '0' }}>
            <div
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--orange-300)',
              }}
            >
              Community
            </div>
            <a
              className="hv-j"
              href={toUrl('/communities')}
              style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              All circles
            </a>
            <a
              className="hv-j"
              href={toUrl('/guidelines')}
              style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Community guidelines
            </a>
            <a
              className="hv-j"
              href={toUrl('/community-help')}
              style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Community help
            </a>
          </nav>
          <nav aria-label="Programs" style={{ display: 'flex', flexDirection: 'column', gap: '14px', minWidth: '0' }}>
            <div
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--orange-300)',
              }}
            >
              Programs
            </div>
            <a
              className="hv-j"
              href={toUrl('/programs')}
              style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              All programs
            </a>
            <a
              className="hv-j"
              href={toUrl('/superstar')}
              style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              SuperStar Parenting
            </a>
            <a
              className="hv-j"
              href={toUrl('/programs')}
              style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Little Learners @Home
            </a>
          </nav>
          <nav aria-label="About" style={{ display: 'flex', flexDirection: 'column', gap: '14px', minWidth: '0' }}>
            <div
              style={{
                fontSize: '14px',
                fontWeight: '700',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                color: 'var(--orange-300)',
              }}
            >
              About
            </div>
            <a
              className="hv-j"
              href={toUrl('/about')}
              style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              About us
            </a>
            <a
              className="hv-j"
              href={toUrl('/press')}
              style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Press releases
            </a>
            <a
              className="hv-j"
              href={toUrl('/contact')}
              style={{ fontSize: '17px', lineHeight: '1.4', color: 'var(--neutral-100)', textDecoration: 'none' }}
            >
              Contact us
            </a>
          </nav>
        </div>
      </div>
      <div style={{ borderTop: '1px solid var(--neutral-700)' }}>
        <div
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '20px 24px 28px',
            boxSizing: 'border-box',
            display: 'flex',
            flexWrap: 'wrap',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '12px 24px',
          }}
        >
          <span style={{ fontSize: '15px', lineHeight: '1.5', color: 'var(--neutral-300)' }}>
            © 2026 Shri Harini Media Ltd. · A Ramco Group company · Chennai
          </span>
          <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '8px 20px' }}>
            <a
              className="hv-j"
              href={toUrl('/privacy')}
              style={{ fontSize: '15px', color: 'var(--neutral-200)', textDecoration: 'none' }}
            >
              Privacy policy
            </a>
            <a
              className="hv-j"
              href={toUrl('/terms')}
              style={{ fontSize: '15px', color: 'var(--neutral-200)', textDecoration: 'none' }}
            >
              Terms of use
            </a>
            <a
              className="hv-i"
              href="#"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                height: '40px',
                padding: '0 14px',
                borderRadius: '999px',
                background: 'var(--neutral-800)',
                fontSize: '15px',
                fontWeight: '600',
                color: 'var(--neutral-100)',
                textDecoration: 'none',
              }}
            >
              <Icon name="arrow-up" size={16} color="currentColor" />
              Back to top
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
