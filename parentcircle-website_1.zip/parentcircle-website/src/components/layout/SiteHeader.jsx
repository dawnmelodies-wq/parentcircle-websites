import { Avatar, Button, Icon, IconButton, Logo } from '../ds';
import { toUrl } from '../../lib/paths';

const NAV_ITEMS = [
  ['read', 'Read', '/'],
  ['watch', 'Watch', '/#watch'],
  ['community', 'Community', null],
  ['programs', 'Programs', '/#programs'],
];
const LINK = {
  height: '44px',
  padding: '0 12px',
  borderRadius: '999px',
  color: 'var(--text-muted)',
  fontSize: '17px',
  fontWeight: '600',
  display: 'flex',
  alignItems: 'center',
  textDecoration: 'none',
  whiteSpace: 'nowrap',
};
const ACTIVE_LINK = {
  height: '44px',
  padding: '0 12px',
  borderRadius: '999px',
  background: 'var(--neutral-100)',
  color: 'var(--text-strong)',
  fontSize: '17px',
  fontWeight: '600',
  display: 'flex',
  alignItems: 'center',
  textDecoration: 'none',
  whiteSpace: 'nowrap',
};

/**
 * Main site header (logo, section nav, "More" menu, search, sign-in / profile).
 * @param {{ active?: 'read' | 'watch' | 'community' | 'programs', communityHref?: string }} props
 */
export default function SiteHeader({ active, communityHref = '/communities' }) {
  return (
    <header
      style={{
        position: 'sticky',
        top: '0',
        zIndex: '20',
        background: 'rgba(255,255,255,0.94)',
        backdropFilter: 'blur(8px)',
        WebkitBackdropFilter: 'blur(8px)',
        borderBottom: '1px solid var(--border-default)',
      }}
    >
      <div
        style={{
          maxWidth: '1200px',
          margin: '0 auto',
          padding: '0 24px',
          height: '72px',
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
        }}
      >
        <a
          href={toUrl('/')}
          aria-label="ParentCircle home"
          style={{ flex: 'none', display: 'flex', marginRight: '20px' }}
        >
          <Logo height={28} />
        </a>
        <nav
          aria-label="Main"
          data-main-nav=""
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            height: '44px',
            gap: '4px',
            flex: '0 1 auto',
            minWidth: '0',
            overflow: 'hidden',
          }}
        >
          {NAV_ITEMS.map(([key, label, href]) =>
            key === active ? (
              <a key={key} href={toUrl(href ?? communityHref)} aria-current="page" style={ACTIVE_LINK}>
                {label}
              </a>
            ) : (
              <a key={key} href={toUrl(href ?? communityHref)} className="hv-3" style={LINK}>
                {label}
              </a>
            ),
          )}
        </nav>
        <details data-more-menu="" style={{ position: 'static', flex: 'none', marginLeft: '-8px' }}>
          <summary
            className="hv-3"
            style={{
              height: '44px',
              padding: '0 10px 0 12px',
              borderRadius: '999px',
              color: 'var(--text-muted)',
              fontSize: '17px',
              fontWeight: '600',
              display: 'flex',
              alignItems: 'center',
              gap: '4px',
              cursor: 'pointer',
              listStyle: 'none',
              whiteSpace: 'nowrap',
              userSelect: 'none',
            }}
          >
            More
            <Icon name="chevron-down" size={16} />
          </summary>
          <div
            style={{
              position: 'absolute',
              top: 'calc(100% + 8px)',
              left: '50%',
              transform: 'translateX(-50%)',
              zIndex: '40',
              width: 'min(940px, calc(100% - 32px))',
              maxHeight: 'calc(100vh - 96px)',
              overflow: 'auto',
              padding: '16px',
              boxSizing: 'border-box',
              borderRadius: '20px',
              background: 'var(--white)',
              border: '1px solid var(--border-default)',
              boxShadow: 'var(--shadow-lg)',
              display: 'flex',
              flexDirection: 'column',
              gap: '8px',
            }}
          >
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,180px),1fr))',
                gap: '8px 20px',
              }}
            >
              <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                <div
                  style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--text-muted)',
                    padding: '6px 10px 6px',
                  }}
                >
                  Read
                </div>
                <a
                  className="hv-0"
                  href={toUrl('/search?query=')}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    minHeight: '44px',
                    padding: '8px 10px',
                    borderRadius: '10px',
                    fontSize: '16px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="compass" size={20} color="var(--text-muted)" />
                  <span style={{ flex: '1', minWidth: '0' }}>Explore</span>
                </a>
                <a
                  className="hv-0"
                  href={toUrl('/stories')}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    minHeight: '44px',
                    padding: '8px 10px',
                    borderRadius: '10px',
                    fontSize: '16px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="book-open" size={20} color="var(--text-muted)" />
                  <span style={{ flex: '1', minWidth: '0' }}>Stories</span>
                </a>
                <a
                  className="hv-0"
                  href={toUrl('/parents-of-india')}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    minHeight: '44px',
                    padding: '8px 10px',
                    borderRadius: '10px',
                    fontSize: '16px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="map-pin" size={20} color="var(--text-muted)" />
                  <span style={{ flex: '1', minWidth: '0' }}>Parents of India</span>
                </a>
                <a
                  className="hv-0"
                  href={toUrl('/ask-the-expert')}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    minHeight: '44px',
                    padding: '8px 10px',
                    borderRadius: '10px',
                    fontSize: '16px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="stethoscope" size={20} color="var(--text-muted)" />
                  <span style={{ flex: '1', minWidth: '0' }}>Ask an expert</span>
                </a>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                <div
                  style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--text-muted)',
                    padding: '6px 10px 6px',
                  }}
                >
                  Community
                </div>
                <a
                  className="hv-0"
                  href={toUrl('/communities')}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    minHeight: '44px',
                    padding: '8px 10px',
                    borderRadius: '10px',
                    fontSize: '16px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="users" size={20} color="var(--text-muted)" />
                  <span style={{ flex: '1', minWidth: '0' }}>Community</span>
                  <span
                    style={{
                      height: '22px',
                      padding: '0 8px',
                      borderRadius: '999px',
                      background: 'var(--orange-600)',
                      color: 'var(--white)',
                      fontSize: '14px',
                      fontWeight: '700',
                      display: 'inline-flex',
                      alignItems: 'center',
                    }}
                  >
                    New
                  </span>
                </a>
                <a
                  className="hv-0"
                  href={toUrl('/guidelines')}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    minHeight: '44px',
                    padding: '8px 10px',
                    borderRadius: '10px',
                    fontSize: '16px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="shield-check" size={20} color="var(--text-muted)" />
                  <span style={{ flex: '1', minWidth: '0' }}>Community guidelines</span>
                </a>
                <a
                  className="hv-0"
                  href={toUrl('/community-help')}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    minHeight: '44px',
                    padding: '8px 10px',
                    borderRadius: '10px',
                    fontSize: '16px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="life-buoy" size={20} color="var(--text-muted)" />
                  <span style={{ flex: '1', minWidth: '0' }}>Community help</span>
                </a>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                <div
                  style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--text-muted)',
                    padding: '6px 10px 6px',
                  }}
                >
                  Initiatives
                </div>
                <a
                  className="hv-0"
                  href="https://www.parentcircle.com/gadget-free-hour/"
                  target="_blank"
                  rel="noopener"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    minHeight: '44px',
                    padding: '8px 10px',
                    borderRadius: '10px',
                    fontSize: '16px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="hourglass" size={20} color="var(--text-muted)" />
                  <span style={{ flex: '1', minWidth: '0' }}>Gadget Free Hour</span>
                  <Icon name="arrow-up-right" size={16} color="var(--neutral-400)" />
                </a>
                <a
                  className="hv-0"
                  href="https://www.dotlearningcircle.com/"
                  target="_blank"
                  rel="noopener"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    minHeight: '44px',
                    padding: '8px 10px',
                    borderRadius: '10px',
                    fontSize: '16px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="graduation-cap" size={20} color="var(--text-muted)" />
                  <span style={{ flex: '1', minWidth: '0' }}>The Dot Learning Circle</span>
                  <Icon name="arrow-up-right" size={16} color="var(--neutral-400)" />
                </a>
                <a
                  className="hv-0"
                  href={toUrl('/press')}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    minHeight: '44px',
                    padding: '8px 10px',
                    borderRadius: '10px',
                    fontSize: '16px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="newspaper" size={20} color="var(--text-muted)" />
                  <span style={{ flex: '1', minWidth: '0' }}>Press releases</span>
                </a>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0' }}>
                <div
                  style={{
                    fontSize: '14px',
                    fontWeight: '700',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    color: 'var(--text-muted)',
                    padding: '6px 10px 6px',
                  }}
                >
                  About
                </div>
                <a
                  className="hv-0"
                  href={toUrl('/about')}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    minHeight: '44px',
                    padding: '8px 10px',
                    borderRadius: '10px',
                    fontSize: '16px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="info" size={20} color="var(--text-muted)" />
                  <span style={{ flex: '1', minWidth: '0' }}>About us</span>
                </a>
                <a
                  className="hv-0"
                  href={toUrl('/privacy')}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    minHeight: '44px',
                    padding: '8px 10px',
                    borderRadius: '10px',
                    fontSize: '16px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="lock" size={20} color="var(--text-muted)" />
                  <span style={{ flex: '1', minWidth: '0' }}>Privacy policy</span>
                </a>
                <a
                  className="hv-0"
                  href={toUrl('/terms')}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    minHeight: '44px',
                    padding: '8px 10px',
                    borderRadius: '10px',
                    fontSize: '16px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="file-text" size={20} color="var(--text-muted)" />
                  <span style={{ flex: '1', minWidth: '0' }}>Terms of use</span>
                </a>
                <a
                  className="hv-0"
                  href={toUrl('/contact')}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    minHeight: '44px',
                    padding: '8px 10px',
                    borderRadius: '10px',
                    fontSize: '16px',
                    fontWeight: '600',
                    color: 'var(--text-strong)',
                    textDecoration: 'none',
                  }}
                >
                  <Icon name="mail" size={20} color="var(--text-muted)" />
                  <span style={{ flex: '1', minWidth: '0' }}>Contact us</span>
                </a>
              </div>
            </div>
          </div>
        </details>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 'none', marginLeft: 'auto' }}>
          <a href={toUrl('/search?query=')} aria-label="Search" style={{ display: 'flex' }}>
            <IconButton icon="search" label="Search" />
          </a>
          <span data-auth="out" style={{ display: 'contents' }}>
            <a href={toUrl('/sign-in')} style={{ display: 'flex', textDecoration: 'none' }}>
              <Button variant="ghost" size="sm">
                Sign in
              </Button>
            </a>{' '}
            <a href={toUrl('/join')} style={{ display: 'flex', textDecoration: 'none' }}>
              <Button variant="primary" size="sm">
                Join free
              </Button>
            </a>
          </span>
          <span data-auth="in" style={{ display: 'none', alignItems: 'center', gap: '8px' }}>
            <a
              className="hv-3"
              href={toUrl('/profile#notification')}
              aria-label="Notifications, 3 new"
              style={{
                position: 'relative',
                width: '48px',
                height: '48px',
                borderRadius: '999px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--text-strong)',
                textDecoration: 'none',
              }}
            >
              <Icon name="bell" size={22} />
              <span
                style={{
                  position: 'absolute',
                  top: '6px',
                  right: '6px',
                  minWidth: '18px',
                  height: '18px',
                  padding: '0 5px',
                  boxSizing: 'border-box',
                  borderRadius: '999px',
                  background: 'var(--orange-600)',
                  color: 'var(--white)',
                  fontSize: '12px',
                  fontWeight: '700',
                  lineHeight: '18px',
                  textAlign: 'center',
                  boxShadow: '0 0 0 2px var(--white)',
                }}
              >
                3
              </span>
            </a>{' '}
            <a
              className="hv-0"
              href={toUrl('/profile#activities')}
              aria-label="Your profile"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                height: '44px',
                padding: '0 14px 0 4px',
                borderRadius: '999px',
                border: '1px solid var(--border-default)',
                textDecoration: 'none',
                color: 'var(--text-strong)',
              }}
            >
              <Avatar name="Priya Raman" size={36} />
              <span data-auth-name="" style={{ fontSize: '16px', fontWeight: '600' }}>
                Priya
              </span>
            </a>
          </span>
        </div>
      </div>
    </header>
  );
}
