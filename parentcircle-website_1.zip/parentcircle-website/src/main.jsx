import React from 'react';
import { createRoot } from 'react-dom/client';
import { HashRouter } from 'react-router-dom';
import App from './App';
import { initSiteBehaviors } from './lib/siteBehaviors';
import './lib/imageSlot.js';
import './lib/siteMenu.js';
import './styles/index.css';

initSiteBehaviors();

createRoot(document.getElementById('root')).render(
  <HashRouter>
    <App />
  </HashRouter>,
);
