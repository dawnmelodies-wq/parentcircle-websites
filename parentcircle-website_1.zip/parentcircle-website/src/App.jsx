import { Suspense, lazy } from 'react';
import { Route, Routes } from 'react-router-dom';
import { routes } from './routes.generated';
import { useLinkNavigation } from './lib/useLinkNavigation';

const pages = routes.map((r) => ({ ...r, Component: lazy(r.load) }));
const NotFound = lazy(() => import('./components/NotFound'));

export default function App() {
  useLinkNavigation();
  return (
    <Suspense fallback={null}>
      <Routes>
        {pages.map(({ path, Component }) => (
          <Route key={path} path={path} element={<Component />} />
        ))}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
}
