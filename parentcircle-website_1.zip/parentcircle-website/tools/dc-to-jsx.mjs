#!/usr/bin/env node
/**
 * dc-to-jsx — one-off migration tool.
 *
 * Converts the original design-tool pages (`*.dc.html`: an HTML template with
 * `{{ bindings }}`, <sc-if>/<sc-for>, <x-import> design-system components and a
 * `class Component extends DCLogic` script) into plain React modules:
 *
 *   src/pages/<Name>/view.jsx   JSX markup  (export default function view(v) {…})
 *   src/pages/<Name>/logic.js   page state / behaviour (verbatim class)
 *   src/pages/<Name>/index.jsx  wiring: <style> + createPage(logic, view)
 *   src/styles/interactions.css hover/active rules that used `style-hover=""`
 *   src/routes.generated.js     route table
 *
 * Usage:  node tools/dc-to-jsx.mjs <dir-with-dc-html-files>
 *
 * The generated code is committed; the tool is kept for reference/re-runs.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseDocument } from 'htmlparser2';

const SRC = path.resolve(process.argv[2] || '../src/pages');
const OUT = path.resolve(import.meta.dirname, '..');

/* ------------------------------------------------------------------ routes */
const ROUTES = {
  'Home v2': { slug: '', title: 'ParentCircle' },
  Home: { slug: 'home' },
  About: { slug: 'about' },
  Article: { slug: 'article' },
  'Ask the Expert': { slug: 'ask-the-expert' },
  'Baby Names': { slug: 'baby-names' },
  'Challenge Video': { slug: 'challenge-video' },
  Communities: { slug: 'communities' },
  'Community Help': { slug: 'community-help' },
  Contact: { slug: 'contact' },
  FAQ: { slug: 'faq' },
  Guidelines: { slug: 'guidelines' },
  Join: { slug: 'join' },
  'Name List': { slug: 'name-list' },
  'Parents of India': { slug: 'parents-of-india' },
  Press: { slug: 'press' },
  Privacy: { slug: 'privacy' },
  Profile: { slug: 'profile' },
  Programs: { slug: 'programs' },
  Quotes: { slug: 'quotes' },
  Recipes: { slug: 'recipes' },
  Search: { slug: 'search' },
  'Sign In': { slug: 'sign-in' },
  Stories: { slug: 'stories' },
  SuperStar: { slug: 'superstar' },
  Terms: { slug: 'terms' },
  Video: { slug: 'video' },
  Videos: { slug: 'videos' },
};
const componentName = (n) =>
  n.replace(/[^A-Za-z0-9]+(.)?/g, (_, c) => (c || '').toUpperCase()).replace(/^./, (c) => c.toUpperCase());

const LINK_RE = /ParentCircle(?:%20| )([A-Za-z0-9%' ]+?)\.dc\.html/g;
function rewriteLinks(text) {
  return text
    .replace(LINK_RE, (m, name) => {
      const n = decodeURIComponent(name);
      if (!ROUTES[n]) throw new Error('Unknown page link: ' + m);
      return '/' + ROUTES[n].slug;
    })
    .replace(/(["'(`])images\//g, '$1/images/');
}

/* --------------------------------------------------------------- utilities */
const INLINE_TAGS = new Set(
  'a abbr b bdi bdo br cite code del dfn em i img ins kbd label mark q s samp small span strike strong sub sup u var wbr button input select textarea'.split(
    ' ',
  ),
);
const BLOCK_TAGS = new Set(
  'address article aside blockquote details div dl dt dd fieldset figure footer form h1 h2 h3 h4 h5 h6 header hr li main nav ol p pre section summary table ul sc-if sc-for'.split(
    ' ',
  ),
);
const VOID = new Set('area base br col embed hr img input link meta source track wbr'.split(' '));
const EVENT_MAP = {
  onclick: 'onClick',
  onchange: 'onChange',
  oninput: 'onInput',
  onsubmit: 'onSubmit',
  onkeydown: 'onKeyDown',
  onkeyup: 'onKeyUp',
  onkeypress: 'onKeyPress',
  onmousedown: 'onMouseDown',
  onmouseup: 'onMouseUp',
  onmouseenter: 'onMouseEnter',
  onmouseleave: 'onMouseLeave',
  onfocus: 'onFocus',
  onblur: 'onBlur',
  ondoubleclick: 'onDoubleClick',
  oncontextmenu: 'onContextMenu',
  onmousemove: 'onMouseMove',
  onmouseover: 'onMouseOver',
  onmouseout: 'onMouseOut',
  onpaste: 'onPaste',
  onscroll: 'onScroll',
  onload: 'onLoad',
  onerror: 'onError',
};
const ATTR_MAP = {
  class: 'className',
  for: 'htmlFor',
  tabindex: 'tabIndex',
  autocomplete: 'autoComplete',
  maxlength: 'maxLength',
  minlength: 'minLength',
  allowfullscreen: 'allowFullScreen',
  readonly: 'readOnly',
  inputmode: 'inputMode',
  frameborder: 'frameBorder',
  srcset: 'srcSet',
  crossorigin: 'crossOrigin',
  contenteditable: 'contentEditable',
  spellcheck: 'spellCheck',
  autofocus: 'autoFocus',
  colspan: 'colSpan',
  rowspan: 'rowSpan',
  datetime: 'dateTime',
  autoplay: 'autoPlay',
  playsinline: 'playsInline',
  referrerpolicy: 'referrerPolicy',
};
const HOST_STYLE_PROPS = new Set([
  'position',
  'left',
  'right',
  'top',
  'bottom',
  'inset',
  'width',
  'height',
  'z-index',
  'transform',
]);
const URL_ATTRS = new Set(['href', 'src', 'poster', 'action']);
const isRootPath = (s) => typeof s === 'string' && s.startsWith('/') && !s.startsWith('//');
const kebabToCamel = (s) => s.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
const q = (s) =>
  JSON.stringify(s)
    .replace(/\u00a0/g, '\\u00a0')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');

/* -------------------------------------------------------------- expressions */
class Scope {
  constructor(vars = [], parent = null) {
    this.vars = new Set(vars);
    this.parent = parent;
  }
  has(n) {
    return this.vars.has(n) || (this.parent ? this.parent.has(n) : false);
  }
}
const KEYWORDS = new Set(['true', 'false', 'null', 'undefined']);
/** `{{ a.b[0] }}` → `v.a?.b?.[0]` (loop variables stay as they are). */
function expr(src, scope) {
  const re = /\s+|'(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*"|\d+(?:\.\d+)?|[A-Za-z_$][\w$]*|===|!==|==|!=|&&|\|\||[^\s]/g;
  let out = '';
  let prev = '';
  let m;
  while ((m = re.exec(src.trim()))) {
    const t = m[0];
    if (/^\s+$/.test(t)) {
      out += ' ';
      continue;
    }
    if (/^[A-Za-z_$]/.test(t)) {
      if (prev === '.') out += t;
      else if (KEYWORDS.has(t)) out += t;
      else out += scope.has(t) ? t : 'v.' + t;
    } else if (t === '.') out += '?.';
    else if (t === '[' && (/^[A-Za-z_$\]]/.test(prev.slice(-1)) || prev === ']')) out += '?.[';
    else out += t;
    if (!/^\s+$/.test(t)) prev = t;
  }
  return out;
}
const WHOLE = /^\s*\{\{([\s\S]+?)\}\}\s*$/;
function isBound(raw) {
  return raw.includes('{{');
}
/** attribute value → JS expression source, or {lit: string} for static strings */
function attrValue(raw, scope) {
  const w = raw.match(WHOLE);
  if (w) return { js: expr(w[1], scope) };
  if (raw.includes('{{')) {
    const parts = raw.split(/\{\{([\s\S]+?)\}\}/g);
    const body = parts
      .map((s, i) => (i & 1 ? '${' + expr(s, scope) + " ?? ''}" : s.replace(/[`\\$]/g, '\\$&')))
      .join('');
    return { js: '`' + body + '`' };
  }
  return { lit: raw };
}

/* ------------------------------------------------------------------ styles */
const pseudoRules = new Map(); // key -> {cls, css}
function pseudoClass(pseudo, css) {
  const key = pseudo + '|' + css.trim();
  if (!pseudoRules.has(key))
    pseudoRules.set(key, { cls: 'hv-' + pseudoRules.size.toString(36), pseudo, css: css.trim() });
  return pseudoRules.get(key).cls;
}
function splitDecls(css) {
  const out = [];
  let start = 0;
  let depth = 0;
  let quote = '';
  for (let i = 0; i < css.length; i++) {
    const c = css[i];
    if (quote) {
      if (c === '\\') i++;
      else if (c === quote) quote = '';
    } else if (c === '"' || c === "'") quote = c;
    else if (c === '(') depth++;
    else if (c === ')') depth = Math.max(0, depth - 1);
    else if (c === ';' && depth === 0) {
      out.push(css.slice(start, i));
      start = i + 1;
    }
  }
  out.push(css.slice(start));
  return out.map((d) => d.trim()).filter(Boolean);
}
const camelProp = (p) =>
  p.startsWith('--')
    ? p
    : kebabToCamel(
        p.replace(/^-(webkit|moz|ms|o)-/, (_, x) => (x === 'ms' ? 'ms-' : x[0].toUpperCase() + x.slice(1) + '-')),
      );
const propKey = (k) => (/^[A-Za-z_$][\w$]*$/.test(k) ? k : q(k));
/** style="a:b;c:{{x}}" → object-literal source */
function styleObject(raw, scope) {
  const parts = [];
  for (const decl of splitDecls(raw)) {
    const i = decl.indexOf(':');
    if (i < 0) continue;
    const prop = decl.slice(0, i).trim();
    const val = decl.slice(i + 1).trim();
    const av = attrValue(val, scope);
    parts.push(`${propKey(camelProp(prop))}: ${av.js ?? q(av.lit)}`);
  }
  return '{ ' + parts.join(', ') + ' }';
}
function hostStyleObject(raw) {
  const parts = [];
  for (const decl of splitDecls(raw)) {
    const i = decl.indexOf(':');
    const prop = decl.slice(0, i).trim();
    if (HOST_STYLE_PROPS.has(prop)) parts.push(`${propKey(camelProp(prop))}: ${q(decl.slice(i + 1).trim())}`);
  }
  return parts.length ? '{ ' + parts.join(', ') + ' }' : null;
}

/* -------------------------------------------------------------------- text */
function jsxText(s) {
  if (/[{}<>&\u00a0]/.test(s) || s.trim() !== s || /^\s*$/.test(s)) return `{${q(s)}}`;
  return s;
}
const cssOf = (el) => el.attribs?.style || '';
const isFlexish = (el) => /display\s*:\s*(inline-)?(flex|grid)/.test(cssOf(el));
const isPre = (el) => /white-space\s*:\s*pre/.test(cssOf(el)) || ['pre', 'textarea'].includes(el.name);

/* --------------------------------------------------------------- generator */
let warnings = [];
function convertChildren(parent, scope, ctx) {
  const kids = parent.children || [];
  const out = [];
  kids.forEach((n, idx) => {
    if (n.type === 'comment') return;
    if (n.type === 'text') {
      const raw = n.data;
      const whitespaceOnly = !raw.trim();
      if (isPre(parent)) {
        out.push(...textParts(raw, scope));
        return;
      }
      if (whitespaceOnly) {
        if (!raw.includes(' ') && !raw.includes('\u00a0')) return; // runtime drops newline-only nodes
        if (isFlexish(parent) || ['ul', 'ol', 'select', 'table', 'tbody', 'tr', 'dl'].includes(parent.name)) return;
        const prev = kids
          .slice(0, idx)
          .reverse()
          .find((k) => k.type !== 'comment');
        const next = kids.slice(idx + 1).find((k) => k.type !== 'comment');
        if (!prev || !next) return;
        const blockish = (k) =>
          k.type === 'tag' &&
          (BLOCK_TAGS.has(k.name) ||
            (k.name === 'x-import' && /Card|Dialog|Toast/.test(k.attribs['component-from-global-scope'] || '')));
        if (blockish(prev) || blockish(next)) return;
        out.push('{" "}');
        return;
      }
      // collapse whitespace; trim edges that touch the parent's boundary
      let s = raw.replace(/[ \t\r\n\f]+/g, ' ');
      const hasPrev = idx > 0 && kids.slice(0, idx).some((k) => k.type !== 'comment');
      const hasNext = kids.slice(idx + 1).some((k) => k.type !== 'comment');
      const inlineParent = INLINE_TAGS.has(parent.name) && !isFlexish(parent);
      if (!hasPrev && !inlineParent) s = s.replace(/^ /, '');
      if (!hasNext && !inlineParent) s = s.replace(/ $/, '');
      if (isFlexish(parent)) s = s.trim();
      out.push(...textParts(s, scope));
      return;
    }
    if (n.type === 'tag' || n.type === 'script' || n.type === 'style') out.push(convertElement(n, scope, ctx));
  });
  return out.filter(Boolean);
}
function textParts(s, scope) {
  if (!s.includes('{{')) return s === '' ? [] : [jsxText(s)];
  const parts = s.split(/\{\{([\s\S]+?)\}\}/g);
  const res = [];
  parts.forEach((p, i) => {
    if (i & 1) res.push(`{${expr(p, scope)}}`);
    else if (p !== '') res.push(jsxText(p));
  });
  return res;
}

function convertElement(el, scope, ctx) {
  const name = el.name;
  if (name === 'sc-if') {
    const cond = expr(el.attribs.value.replace(WHOLE, '$1'), scope);
    const body = wrapFragment(convertChildren(el, scope, ctx));
    return `{${cond} ? (${body}) : null}`;
  }
  if (name === 'sc-for') {
    const list = expr(el.attribs.list.replace(WHOLE, '$1'), scope);
    const as = el.attribs.as || 'item';
    const idx = '$i' + ctx.depth;
    const inner = new Scope([as], scope);
    const body = wrapFragment(convertChildren(el, inner, { ...ctx, depth: ctx.depth + 1 }), idx);
    return `{(${list} ?? []).map((${as}, ${idx}) => (${body}))}`;
  }
  if (name === 'site-header') {
    ctx.layout.add('SiteHeader');
    const a = el.attribs.active ? ` active="${el.attribs.active}"` : '';
    const c = el.attribs['community-href'] !== '/communities' ? ` communityHref="${el.attribs['community-href']}"` : '';
    return `<SiteHeader${a}${c} />`;
  }
  if (name === 'site-footer') {
    ctx.layout.add('SiteFooter');
    return el.attribs.spaced === 'true' ? '<SiteFooter spaced />' : '<SiteFooter />';
  }
  if (name === 'x-import') return convertImport(el, scope, ctx);
  return convertDom(el, scope, ctx);
}
function wrapFragment(children, key) {
  const k = key ? ` key={${key}}` : '';
  if (!key && children.length === 1 && children[0].startsWith('<')) return children[0];
  return `<Fragment${k}>${children.join('\n')}</Fragment>`;
}

function convertDom(el, scope, ctx) {
  const tag = el.name;
  const custom = tag.includes('-');
  const props = [];
  let classStatic = '';
  let classDyn = null;
  const pseudos = [];
  for (const [rawName, value] of Object.entries(el.attribs)) {
    if (rawName.startsWith('hint-')) continue;
    if (rawName.startsWith('style-')) {
      pseudos.push(pseudoClass(rawName.slice(6), value));
      continue;
    }
    const av = attrValue(value, scope);
    let key = rawName;
    if (rawName === 'class') {
      if (av.lit !== undefined) classStatic = av.lit;
      else classDyn = av.js;
      continue;
    }
    if (rawName === 'style') {
      if (av.js && WHOLE.test(value)) props.push(`style={styleOf(${av.js})}`);
      else props.push(`style={${styleObject(value, scope)}}`);
      continue;
    }
    if (!custom) {
      if (EVENT_MAP[rawName.toLowerCase()] && /^on/i.test(rawName)) key = EVENT_MAP[rawName.toLowerCase()];
      else if (ATTR_MAP[rawName]) key = ATTR_MAP[rawName];
    }
    if ((key === 'href' || key === 'src' || key === 'poster' || key === 'action') && av.lit !== undefined)
      av.lit = rewriteLinks(av.lit);
    let val = av.js;
    if (URL_ATTRS.has(key)) {
      if (val !== undefined) {
        val = `toUrl(${val})`;
        ctx.url = true;
      } else if (isRootPath(av.lit)) {
        val = `toUrl(${q(av.lit)})`;
        av.lit = undefined;
        ctx.url = true;
      }
    }
    if (val !== undefined && key === 'value') val = `(${val}) ?? ''`;
    if (val !== undefined && key === 'checked') val = `(${val}) ?? false`;
    if (av.lit !== undefined) {
      if (
        av.lit === '' &&
        ['open', 'hidden', 'disabled', 'checked', 'selected', 'required', 'controls', 'autoFocus'].includes(key)
      )
        warnings.push(`boolean attr "${key}" empty in <${tag}>`);
      props.push(
        /^[^"{}\\\n]*$/.test(av.lit) && !av.lit.includes('&') ? `${key}="${av.lit}"` : `${key}={${q(av.lit)}}`,
      );
    } else props.push(`${key}={${val}}`);
  }
  const clsKey = custom ? 'class' : 'className';
  if (classDyn || pseudos.length) {
    if (classDyn)
      props.unshift(
        `${clsKey}={[${classDyn}${classStatic ? `, ${q(classStatic)}` : ''}${pseudos.map((p) => ', ' + q(p)).join('')}].filter(Boolean).join(' ')}`,
      );
    else props.unshift(`${clsKey}=${q([classStatic, ...pseudos].filter(Boolean).join(' '))}`);
  } else if (classStatic) props.unshift(`${clsKey}=${q(classStatic)}`);

  const children = convertChildren(el, scope, ctx);
  const open = props.length ? `<${tag} ${props.join(' ')}` : `<${tag}`;
  if (VOID.has(tag)) return open + ' />';
  if (!children.length) return open + `></${tag}>`;
  return `${open}>${children.join('\n')}</${tag}>`;
}

function convertImport(el, scope, ctx) {
  const g = el.attribs['component-from-global-scope'];
  const comp = g.split('.').pop();
  ctx.used.add(comp);
  const props = [];
  let hostStyle;
  for (const [rawName, value] of Object.entries(el.attribs)) {
    if (rawName === 'component-from-global-scope' || rawName.startsWith('hint-')) continue;
    if (rawName === 'style') {
      hostStyle = value;
      continue;
    }
    const av = attrValue(value, scope);
    if (rawName === 'dc-props') {
      props.push(`{...(${av.js})}`);
      continue;
    }
    let key = rawName;
    if (key.includes('-') && !key.startsWith('aria-') && !key.startsWith('data-')) key = kebabToCamel(key);
    if ((URL_ATTRS.has(key) || key === 'image') && (av.js !== undefined || isRootPath(av.lit))) {
      ctx.url = true;
      props.push(`${key}={toUrl(${av.js ?? q(av.lit)})}`);
    } else if (av.lit !== undefined) {
      props.push(/^[^"{}\\\n&]*$/.test(av.lit) ? `${key}="${av.lit}"` : `${key}={${q(av.lit)}}`);
    } else props.push(`${key}={${av.js}}`);
  }
  const children = convertChildren(el, scope, ctx);
  const open = props.length ? `<${comp} ${props.join(' ')}` : `<${comp}`;
  const node = children.length ? `${open}>${children.join('\n')}</${comp}>` : `${open} />`;
  const hs = hostStyle ? hostStyleObject(hostStyle) : null;
  return hs ? `<div style={${hs}}>${node}</div>` : node;
}

/* ------------------------------------------------- shared header / footer */
const NAV_RE = /(<nav aria-label="Main"[^>]*>)([\s\S]*?)(<\/nav>)/;
const NAV_KEYS = { Read: 'read', Watch: 'watch', Community: 'community', Programs: 'programs' };
const grab = (text, tag) => text.match(new RegExp(`<${tag}\\b[\\s\\S]*?</${tag}>`))?.[0];
const squash = (s) => s.replace(/\s+/g, ' ');
const storiesText = rewriteLinks(fs.readFileSync(path.join(SRC, 'ParentCircle Stories.dc.html'), 'utf8'));
const CANON_HEADER = grab(storiesText, 'header');
const CANON_FOOTER = grab(storiesText, 'footer');
const normHeader = (h) => squash(h.replace(NAV_RE, '$1@@NAV@@$3'));
const CANON_HEADER_NORM = normHeader(CANON_HEADER);
let sharedUsed = { header: false, footer: false };

/** Swap the standard header/footer markup for <site-header>/<site-footer> placeholders. */
function extractShared(tpl) {
  const h = grab(tpl, 'header');
  if (h && normHeader(h) === CANON_HEADER_NORM) {
    const anchors = [...h.match(NAV_RE)[2].matchAll(/<a href="([^"]*)"([^>]*)>([^<]*)<\/a>/g)];
    const active = anchors.find((a) => a[2].includes('aria-current'));
    const community = anchors.find((a) => a[3] === 'Community')[1];
    tpl = tpl.replace(
      h,
      `<site-header active="${active ? NAV_KEYS[active[3]] : ''}" community-href="${community}"></site-header>`,
    );
    sharedUsed.header = true;
  }
  const f = grab(tpl, 'footer');
  if (f) {
    const spaced = f.startsWith('<footer style="margin-top:96px;');
    const base = spaced ? f.replace('margin-top:96px;', '') : f;
    if (squash(base) === squash(CANON_FOOTER)) {
      tpl = tpl.replace(f, `<site-footer spaced="${spaced}"></site-footer>`);
      sharedUsed.footer = true;
    }
  }
  return tpl;
}

function writeSharedComponents() {
  const dir = path.join(OUT, 'src/components/layout');
  fs.mkdirSync(dir, { recursive: true });
  const scope = new Scope();

  // header: nav links are data-driven; everything else is the original markup
  const nav = CANON_HEADER.match(NAV_RE)[2];
  const anchors = [...nav.matchAll(/<a href="([^"]*)"([^>]*)>([^<]*)<\/a>/g)];
  const active = anchors.find((a) => a[2].includes('aria-current'));
  const inactive = anchors.find((a) => !a[2].includes('aria-current'));
  const styleOfAnchor = (a) => styleObject(a[2].match(/style="([^"]*)"/)[1], scope);
  const hoverCls = pseudoClass('hover', inactive[2].match(/style-hover="([^"]*)"/)[1]);
  const headerDom = parseDocument(CANON_HEADER.replace(NAV_RE, '$1@@NAV@@$3'), {
    lowerCaseTags: false,
    lowerCaseAttributeNames: false,
  });
  const hctx = { depth: 0, used: new Set() };
  let headerJsx = convertChildren(
    { type: 'root', name: '#root', attribs: {}, children: headerDom.children },
    scope,
    hctx,
  ).join('\n');
  headerJsx = headerJsx.replace(
    '@@NAV@@',
    `{NAV_ITEMS.map(([key, label, href]) =>
      key === active ? (
        <a key={key} href={toUrl(href ?? communityHref)} aria-current="page" style={ACTIVE_LINK}>{label}</a>
      ) : (
        <a key={key} href={toUrl(href ?? communityHref)} className="${hoverCls}" style={LINK}>{label}</a>
      ),
    )}`,
  );
  fs.writeFileSync(
    path.join(dir, 'SiteHeader.jsx'),
    `import { ${[...hctx.used].sort().join(', ')} } from '../ds';
import { toUrl } from '../../lib/paths';

const NAV_ITEMS = [
  ['read', 'Read', '/'],
  ['watch', 'Watch', '/#watch'],
  ['community', 'Community', null],
  ['programs', 'Programs', '/#programs'],
];
const LINK = ${styleOfAnchor(inactive)};
const ACTIVE_LINK = ${styleOfAnchor(active)};

/**
 * Main site header (logo, section nav, "More" menu, search, sign-in / profile).
 * @param {{ active?: 'read' | 'watch' | 'community' | 'programs', communityHref?: string }} props
 */
export default function SiteHeader({ active, communityHref = '/communities' }) {
  return (
${headerJsx}
  );
}
`,
  );

  // footer
  const fctx = { depth: 0, used: new Set() };
  const footerDom = parseDocument(CANON_FOOTER, { lowerCaseTags: false, lowerCaseAttributeNames: false });
  let footerJsx = convertChildren(
    { type: 'root', name: '#root', attribs: {}, children: footerDom.children },
    scope,
    fctx,
  ).join('\n');
  if (!footerJsx.startsWith('<footer style={{ ')) throw new Error('unexpected footer markup');
  footerJsx = footerJsx.replace('<footer style={{ ', "<footer style={{ ...(spaced ? { marginTop: '96px' } : null), ");
  fs.writeFileSync(
    path.join(dir, 'SiteFooter.jsx'),
    `import { ${[...fctx.used].sort().join(', ')} } from '../ds';
${fctx.url ? "import { toUrl } from '../../lib/paths';" : ''}

/** Site footer. \`spaced\` adds the 96px gap above it used on long content pages. */
export default function SiteFooter({ spaced = false }) {
  return (
${footerJsx}
  );
}
`,
  );
  fs.writeFileSync(
    path.join(dir, 'index.js'),
    "export { default as SiteHeader } from './SiteHeader.jsx';\nexport { default as SiteFooter } from './SiteFooter.jsx';\n",
  );
}

/* Targeted adjustments needed when moving from the design-tool runtime to a bundler. */
function applyPatches(pageName, js) {
  // Routes live in the URL hash (works from a plain file and on GitHub Pages) — see src/lib/paths.js
  js = js.replace(/(location\.href\s*=\s*)(['"]\/[^'"]*['"])/g, '$1toUrl($2)');
  js = js.replace(/\blocation\.(search|hash)\b/g, 'pageLocation().$1');
  // image files are addressed relative to index.html
  js = js.replace(/(['"`])\/(images|assets)\//g, '$1$2/');
  js = js.replace(
    "history.replaceState(null, '', '#' + h)",
    "history.replaceState(null, '', toUrl(pageLocation().pathname + '#' + h))",
  );
  js = js.replace(
    "history.replaceState(null, '', location.pathname + '?query=' + encodeURIComponent(v))",
    "history.replaceState(null, '', toUrl('/search?query=' + encodeURIComponent(v)))",
  );
  if (/\blocation\.pathname/.test(js)) throw new Error(pageName + ': unhandled location.pathname');
  if (pageName === 'Home v2') {
    js = js.replace("import(new URL('pc-tamil.js', document.baseURI).href)", "import('../../lib/tamilStrings.js')");
    // the header-overflow measurer in lib/siteMenu.js must resume once this page is left
    js = js.replace('componentWillUnmount() {', 'componentWillUnmount() { window.__pcHomeNav = false;');
  }
  return js;
}

function pathImports(js) {
  const names = ['toUrl', 'pageLocation'].filter((n) => js.includes(n + '('));
  return names.length ? `import { ${names.join(', ')} } from '../../lib/paths';\n` : '';
}

/* --------------------------------------------------------------- page build */
const pages = fs
  .readdirSync(SRC)
  .filter((f) => f.endsWith('.dc.html'))
  .sort();
const routeTable = [];
fs.rmSync(path.join(OUT, 'src/pages'), { recursive: true, force: true });

for (const file of pages) {
  const pageName = file.replace(/^ParentCircle /, '').replace(/\.dc\.html$/, '');
  if (!ROUTES[pageName]) throw new Error('No route for ' + pageName);
  const comp = componentName(pageName);
  let text = rewriteLinks(fs.readFileSync(path.join(SRC, file), 'utf8'));
  let tpl = text.slice(text.indexOf('<x-dc>') + 6, text.indexOf('</x-dc>'));
  const scriptM = text.match(/<script type="text\/x-dc" data-dc-script[^>]*>([\s\S]*?)<\/script>/);
  tpl = extractShared(tpl);
  const dom = parseDocument(tpl, {
    lowerCaseTags: false,
    lowerCaseAttributeNames: false,
    decodeEntities: true,
    recognizeSelfClosing: false,
  });

  // helmet → page css
  let css = '';
  const helmet = dom.children.find((c) => c.name === 'helmet');
  if (helmet) for (const c of helmet.children) if (c.name === 'style') css += c.children.map((t) => t.data).join('');
  css = css
    .replace(/^\n+|\s+$/g, '')
    .split('\n')
    .map((l) => l.replace(/^ {4}/, ''))
    .join('\n');
  const root = { type: 'root', name: '#root', attribs: {}, children: dom.children.filter((c) => c.name !== 'helmet') };
  warnings = [];
  const ctx = { depth: 0, used: new Set(), layout: new Set() };
  const kids = convertChildren(root, new Scope(), ctx);
  const body = kids.length === 1 && kids[0].startsWith('<') ? kids[0] : `<>${kids.join('\n')}</>`;
  if (warnings.length) console.warn(pageName, [...new Set(warnings)]);

  const dir = path.join(OUT, 'src/pages', comp);
  fs.mkdirSync(dir, { recursive: true });
  const usesStyleOf = body.includes('styleOf(');
  const imports = [
    `import { Fragment } from 'react';`,
    ctx.used.size ? `import { ${[...ctx.used].sort().join(', ')} } from '../../components/ds';` : '',
    ctx.layout.size ? `import { ${[...ctx.layout].sort().join(', ')} } from '../../components/layout';` : '',
    usesStyleOf ? `import { styleOf } from '../../lib/styleOf';` : '',
    ctx.url ? `import { toUrl } from '../../lib/paths';` : '',
  ]
    .filter(Boolean)
    .join('\n');
  fs.writeFileSync(
    path.join(dir, 'view.jsx'),
    `${imports}\n\n/** Markup for the "${pageName}" page. \`v\` is the view-model returned by PageLogic#renderVals(). */\nexport default function view(v) {\n  return (\n${body}\n  );\n}\n`,
  );

  let hasLogic = false;
  if (scriptM) {
    let js = scriptM[1].trim();
    js = js.replace(/class Component extends DCLogic/, 'class PageLogic extends PageLogicBase');
    js = applyPatches(pageName, js);
    if (!/class PageLogic extends PageLogicBase/.test(js)) throw new Error(pageName + ': no Component class');
    fs.writeFileSync(
      path.join(dir, 'logic.js'),
      `import React from 'react';\nimport { PageLogicBase } from '../../lib/createPage';\n${pathImports(js)}\n${js}\n\nexport default PageLogic;\n`,
    );
    hasLogic = true;
  }
  fs.writeFileSync(
    path.join(dir, 'index.jsx'),
    `import { createPage } from '../../lib/createPage';\nimport view from './view';\n${hasLogic ? "import Logic from './logic';\n" : ''}\nconst css = ${'`'}${css.replace(/[`\\$]/g, '\\$&')}\n${'`'};\n\nexport default createPage({ name: ${q(pageName)}, css, view${hasLogic ? ', Logic' : ''} });\n`,
  );
  routeTable.push({ pageName, comp, slug: ROUTES[pageName].slug });
}

writeSharedComponents();

/* hover / active rules */
let sheet =
  '/* GENERATED by tools/dc-to-jsx.mjs — hover/active styles that were `style-hover` / `style-active` attributes. */\n';
for (const { cls, pseudo, css } of pseudoRules.values()) {
  const important = splitDecls(css)
    .map((d) => (/!\s*important$/i.test(d) ? d : d + ' !important'))
    .join(';');
  sheet += `.${cls}:${pseudo}{${important}}\n`;
}
fs.writeFileSync(path.join(OUT, 'src/styles/interactions.css'), sheet);

/* route table */
routeTable.sort((a, b) => a.slug.localeCompare(b.slug));
const lines = routeTable.map(
  (r) => `  { path: ${q('/' + r.slug)}, name: ${q(r.pageName)}, load: () => import('./pages/${r.comp}') },`,
);
fs.writeFileSync(
  path.join(OUT, 'src/routes.generated.js'),
  `// GENERATED by tools/dc-to-jsx.mjs\nexport const routes = [\n${lines.join('\n')}\n];\n`,
);
console.log(`converted ${routeTable.length} pages, ${pseudoRules.size} interaction rules`);
