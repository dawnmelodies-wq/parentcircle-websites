# ParentCircle website

React 18 + Vite implementation of the ParentCircle website redesign (28 pages: home, stories, videos,
community, programs, profile, legal pages, …). It is a one-to-one port of the original design files —
same markup, styles, images and behaviour — organised as a conventional front-end project.

## Quick start

### Just view the site (no installation)

Extract the zip first (right-click → Extract All), then open **`docs/index.html`** in Chrome, Edge or Firefox.
`docs/` is the ready-built website: one `index.html` plus the `images/` and `assets/` folders.
Pages are addressed with `#`, e.g. `docs/index.html#/stories`.

### Publish on GitHub Pages

1. Push this project to GitHub (the `docs/` folder must be included).
2. On GitHub: **Settings → Pages → Build and deployment → Source: "Deploy from a branch"**,
   Branch: **main**, Folder: **/docs** → Save.
3. After a minute the site is live at `https://<user>.github.io/<repository>/`
   (here: https://dawnmelodies-wq.github.io/parentcircle-website/).

### Develop

Requires Node.js 18 or newer.

```bash
npm install
npm run dev          # http://localhost:5173  (hot reload)
npm run build        # rebuilds docs/  — commit it to update GitHub Pages
npm run preview      # serves docs/ at http://localhost:4173
```

## Project structure

```
index.html                  Vite entry (source)
docs/                       production build — open docs/index.html or publish with GitHub Pages
public/
  images/                   all site imagery (hero photos, press clippings, social icons, slot photos…)
  assets/                   logos
src/
  main.jsx                  bootstrap (router, global behaviours)
  App.jsx                   routes (lazy-loaded pages)
  routes.generated.js       route table: path -> page module
  components/
    ds/                     design-system components (Button, Card, Tabs, Input, Icon, Logo …)
    layout/                 SiteHeader / SiteFooter shared by 22 / 23 pages
    NotFound.jsx
  pages/<Page>/
    index.jsx               createPage({ css, view, Logic })
    view.jsx                markup (JSX) — renders the view-model
    logic.js                state + behaviour for that page (class extending PageLogicBase)
  lib/
    createPage.jsx          page host (state, lifecycle, page-scoped <style>)
    siteBehaviors.js        header shadow, back-to-top, scroll reveal, button-in-link forwarding
    siteMenu.js             "More" menu, nav overflow, signed-in/out header swap
    imageSlot.js            <image-slot> custom element (drop / replace a photo)
    imageSlotDefaults.json  default picture + framing for every <image-slot>
    paths.js                toUrl() / pageLocation(): hash-based page URLs, relative image paths
    tamilStrings.js         Tamil / Hindi strings for the home page language switch
    useLinkNavigation.js    in-app navigation for <a href> links + #section scrolling
  styles/
    tokens/                 design tokens (colors, typography, spacing, base)
    interactions.css        hover / active states
tools/dc-to-jsx.mjs         migration script used to generate pages from the original design files
```

### How a page works

`view.jsx` is a pure function of a view-model (`v`). The view-model comes from `logic.js`
(`renderVals()`), and `logic.js` keeps the page state (`this.state` / `this.setState`). Pages without
interactivity have no `logic.js`.

### Images

Images live in `public/images` (copied to `docs/images`) and are referenced relative to `index.html`. `<image-slot>` placeholders show the
picture listed in `src/lib/imageSlotDefaults.json`; a photo dropped onto a slot is stored in the
browser's IndexedDB (per browser, not shared).

### Sign-in state

The header swaps "Sign in / Join free" for notifications + profile when `localStorage['pc-signed-in'] === '1'`
(set by the Sign in / Join pages; sign out clears it). There is no backend; the forms are front-end only.

## Routes

| Path | Page |
| --- | --- |
| `#/` | Home v2 |
| `#/about` | About |
| `#/article` | Article |
| `#/ask-the-expert` | Ask the Expert |
| `#/baby-names` | Baby Names |
| `#/challenge-video` | Challenge Video |
| `#/communities` | Communities |
| `#/community-help` | Community Help |
| `#/contact` | Contact |
| `#/faq` | FAQ |
| `#/guidelines` | Guidelines |
| `#/home` | Home |
| `#/join` | Join |
| `#/name-list` | Name List |
| `#/parents-of-india` | Parents of India |
| `#/press` | Press |
| `#/privacy` | Privacy |
| `#/profile` | Profile |
| `#/programs` | Programs |
| `#/quotes` | Quotes |
| `#/recipes` | Recipes |
| `#/search` | Search |
| `#/sign-in` | Sign In |
| `#/stories` | Stories |
| `#/superstar` | SuperStar |
| `#/terms` | Terms |
| `#/video` | Video |
| `#/videos` | Videos |

## Formatting

```bash
npm run format        # prettier
```

## Notes

* `src/pages/*` and `src/routes.generated.js` were produced from the original design files by
  `tools/dc-to-jsx.mjs` and are now regular, hand-editable source code.
* Fonts load from Google Fonts and icons are bundled (`src/components/ds/lucide-icons.json`); an internet
  connection is needed for the web fonts and for the video / CDN thumbnails used on some pages.
