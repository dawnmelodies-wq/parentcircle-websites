import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';

/**
 * The production build goes to docs/ as ONE self-contained index.html (all JS/CSS
 * inlined) plus the images. That folder works:
 *   - opened directly from disk (double-click docs/index.html),
 *   - on GitHub Pages ("Deploy from a branch" → main → /docs),
 *   - on any static host, in any sub-folder.
 */
export default defineConfig({
  base: './',
  plugins: [react(), viteSingleFile()],
  server: { port: 5173, host: true },
  preview: { port: 4173, host: true },
  build: { outDir: 'docs', emptyOutDir: true, chunkSizeWarningLimit: 4000 },
});
